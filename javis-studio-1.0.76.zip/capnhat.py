"""Javis Studio – PHÁT HÀNH + TỰ CẬP NHẬT qua OneDrive.

Máy NGUỒN (có file `.nguon` trong thư mục Studio, vd C:\\Javis\\ve-tu – nơi Claude / Javis sửa mã):
  mỗi khi mã nguồn khác bản đã phát hành -> tự chép bản mới vào  <OneDrive>\\FILE TPW GROUP CTY\\_JAVIS STUDIO (cai dat)\\ban-moi\\
  (app\\ + phien-ban.json ghi số bản + mã băm từng file) và chép bộ cài CAI-DAT-JAVIS-STUDIO.bat ra thư mục cài đặt.
Máy ĐÃ CÀI (không có `.nguon`):
  khi mở Studio và mỗi 5 phút: so số bản trong OneDrive với bản đang chạy -> có bản mới thì chép các file đã đổi
  (giữ bản cũ trong _cu\\<số bản>\\), KHÔNG đụng du-lieu\\ (job, màu, cấu hình AI) và file cấu hình máy.
"""
import os, json, time, shutil, hashlib, socket
from pathlib import Path

GOC = Path(__file__).resolve().parent
BO_QUA_THU_MUC = {"du-lieu", "xuat", "_cu", "__pycache__", ".git", "node_modules", "may-chu"}   # may-chu: khoá riêng + danh sách tài khoản – KHÔNG BAO GIỜ phát hành
BO_QUA_DUOI = (".tmp", ".pyc", ".log")
BO_QUA_TEN = {".nguon", "phien-ban.json", "nguon-cap-nhat.txt"}


def la_nguon(goc=GOC):
    return (Path(goc) / ".nguon").is_file()


def thu_muc_ban_moi(cfg=None):
    f = (cfg or {}).get("thu_muc_ban_moi")
    if f: return Path(f)
    try:                                                          # bộ cài ghi lại chỗ lấy bản mới của máy này
        t = (GOC / "nguon-cap-nhat.txt").read_text(encoding="utf-8-sig").strip()
        if t: return Path(t)
    except OSError: pass
    return Path(os.path.expanduser("~")) / "OneDrive" / "FILE TPW GROUP CTY" / "_JAVIS STUDIO (cai dat)" / "ban-moi"


def _bam(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for k in iter(lambda: f.read(1 << 20), b""): h.update(k)
    return h.hexdigest()[:20]


def danh_sach(goc=GOC):
    """{đường dẫn tương đối (dấu /): mã băm} của mọi file chương trình (bỏ dữ liệu, bản sao lưu, file tạm)"""
    goc = Path(goc); out = {}
    for p in sorted(goc.rglob("*")):
        rel = p.relative_to(goc)
        if not p.is_file() or rel.parts[0] in BO_QUA_THU_MUC or rel.parts[0].startswith("_sao-luu") or p.name in BO_QUA_TEN or p.suffix in BO_QUA_DUOI: continue
        if any(x in BO_QUA_THU_MUC for x in rel.parts[:-1]): continue
        if rel.parts[0] == "skp-sdk" and p.suffix.lower() != ".dll": continue     # SketchUp SDK: chỉ cần các file .dll (bỏ header, ví dụ, tài liệu)
        out[rel.as_posix()] = _bam(p)
    return out


def doc(p, md=None):
    try: return json.loads(Path(p).read_text(encoding="utf-8"))
    except Exception: return md


def _ghi(p, d):
    p = Path(p); p.parent.mkdir(parents=True, exist_ok=True); t = p.with_suffix(p.suffix + ".tmp")
    t.write_text(json.dumps(d, ensure_ascii=False, indent=1), encoding="utf-8"); os.replace(t, p)


def ban_dang_chay(goc=GOC):
    return doc(Path(goc) / "phien-ban.json", {}) or {}


def phat_hanh(phien_ban, cfg=None, goc=GOC, ep=False):
    """máy nguồn: chép bản hiện tại ra OneDrive nếu khác bản đã phát hành. Trả dict trạng thái."""
    dich = thu_muc_ban_moi(cfg)
    if not dich.parent.is_dir(): return {"ok": False, "loi": f"Không thấy thư mục cài đặt trên OneDrive: {dich.parent}"}
    ds = danh_sach(goc); cu = doc(dich / "phien-ban.json", {}) or {}
    if not ep and cu.get("files") == ds and cu.get("phien_ban") == phien_ban: return {"ok": True, "moi": False, "so_ban": cu.get("so_ban"), "phien_ban": phien_ban}
    app = dich / "app"; app.mkdir(parents=True, exist_ok=True)
    for rel, h in ds.items():
        if (cu.get("files") or {}).get(rel) == h and (app / rel).is_file(): continue
        d = app / rel; d.parent.mkdir(parents=True, exist_ok=True); t = d.with_name(d.name + ".tmp")
        shutil.copy2(Path(goc) / rel, t); os.replace(t, d)
    for rel in set(cu.get("files") or {}) - set(ds):              # file đã bỏ khỏi nguồn
        try: (app / rel).unlink()
        except OSError: pass
    so_ban = int(time.time())
    man = dict(phien_ban=phien_ban, so_ban=so_ban, ngay=time.strftime("%Y-%m-%d %H:%M"), may=socket.gethostname(), files=ds)
    _ghi(dich / "phien-ban.json", man)                            # ghi CUỐI CÙNG: máy khác chỉ thấy bản mới khi đủ file
    for ten in ("CAI-DAT-JAVIS-STUDIO.bat", "HUONG-DAN-CAI-DAT.txt"):
        if (Path(goc) / ten).is_file():
            try: shutil.copy2(Path(goc) / ten, dich.parent / ten)
            except OSError: pass
    _ghi(Path(goc) / "phien-ban.json", {k: v for k, v in man.items()})
    return {"ok": True, "moi": True, "so_ban": so_ban, "phien_ban": phien_ban, "so_file": len(ds)}


def kiem_tra(cfg=None, goc=GOC):
    """máy đã cài: có bản mới trên OneDrive không?"""
    if la_nguon(goc): return {"co_moi": False, "nguon": True}
    man = doc(thu_muc_ban_moi(cfg) / "phien-ban.json", None)
    if not man: return {"co_moi": False, "loi": "Chưa thấy bản phát hành trên OneDrive (máy chưa đồng bộ OneDrive?)"}
    dang = ban_dang_chay(goc)
    return {"co_moi": int(man.get("so_ban") or 0) > int(dang.get("so_ban") or 0), "moi": {k: man.get(k) for k in ("phien_ban", "so_ban", "ngay", "may")},
            "dang": {k: dang.get(k) for k in ("phien_ban", "so_ban", "ngay")}}


def ap_dung(cfg=None, goc=GOC):
    """máy đã cài: chép các file đã đổi từ OneDrive vào thư mục chương trình (giữ bản cũ trong _cu\\)."""
    goc = Path(goc)
    if la_nguon(goc): return {"ok": False, "loi": "Đây là máy nguồn – không tự ghi đè mã nguồn."}
    nguon = thu_muc_ban_moi(cfg); man = doc(nguon / "phien-ban.json", None)
    if not man: return {"ok": False, "loi": "Không đọc được bản phát hành."}
    dang = ban_dang_chay(goc); doi = []
    for rel, h in (man.get("files") or {}).items():
        d = goc / rel
        if d.is_file() and _bam(d) == h: continue
        s = nguon / "app" / rel
        if not s.is_file(): return {"ok": False, "loi": f"OneDrive chưa tải xong file {rel} – thử lại sau ít phút."}
        if _bam(s) != h: return {"ok": False, "loi": f"File {rel} trên OneDrive đang đồng bộ dở – thử lại sau ít phút."}
        doi.append(rel)
    sl = goc / "_cu" / str(dang.get("so_ban") or "truoc")
    for rel in doi:
        d = goc / rel
        if d.is_file():
            (sl / rel).parent.mkdir(parents=True, exist_ok=True); shutil.copy2(d, sl / rel)
        d.parent.mkdir(parents=True, exist_ok=True); t = d.with_name(d.name + ".tmp")
        shutil.copy2(nguon / "app" / rel, t); os.replace(t, d)
    _ghi(goc / "phien-ban.json", {k: man.get(k) for k in ("phien_ban", "so_ban", "ngay", "may", "files")})
    # dọn bớt bản cũ: giữ 3 lần gần nhất
    try:
        cu = sorted([p for p in (goc / "_cu").iterdir() if p.is_dir()], key=lambda p: p.stat().st_mtime)
        for p in cu[:-3]: shutil.rmtree(p, ignore_errors=True)
    except OSError: pass
    return {"ok": True, "so_file": len(doi), "phien_ban": man.get("phien_ban"), "so_ban": man.get("so_ban")}
