"""JAVIS STUDIO - phần mềm vẽ tủ của TPW GROUP: thư viện tủ, xem/sửa 3D, xuất file cắt Biesse (.cix) + layout + label + phụ kiện.
Chạy: python vetu.py   (mở cửa sổ riêng, dữ liệu nằm trong thư mục du-lieu cạnh file này)
"""
import os, sys, json, re, time, secrets, threading, subprocess, webbrowser, urllib.request, urllib.parse, traceback, hashlib, socket, ipaddress, html, io
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import engine, xuat, ai, capnhat, giayphep, skp, base64, banquyen

PHIEN_BAN = "1.0.76"
GOC = Path(__file__).resolve().parent
DATA = GOC / "du-lieu"; JOBS = DATA / "jobs"; MAU = DATA / "mau"
TOKEN = secrets.token_urlsafe(18)
TT = {"ui": 0.0}
MAC_DINH = {"cong": 8770, "thu_muc_xuat": "", "ollama_url": "http://127.0.0.1:11434", "mo_hinh": "", "trinh_duyet": "edge"}


def doc_json(f, md):
    try: return json.loads(Path(f).read_text(encoding="utf-8"))
    except Exception: return md


def ghi_json(f, d):
    Path(f).parent.mkdir(parents=True, exist_ok=True)
    tmp = str(f) + ".tmp"; Path(tmp).write_text(json.dumps(d, ensure_ascii=False, indent=1), encoding="utf-8"); os.replace(tmp, f)


def doc_cfg():
    c = dict(MAC_DINH); c.update(doc_json(DATA / "cau-hinh.json", {}))
    if not c["thu_muc_xuat"]:
        od = Path(os.path.expanduser("~")) / "OneDrive" / "FILE TPW GROUP CTY" / "FILE CNC"
        c["thu_muc_xuat"] = str(od / "_JAVIS") if od.is_dir() else str(GOC / "xuat")
    return c


def ten_file(ten):
    return (re.sub(r'[\\/:*?"<>|\x00-\x1f]', "-", str(ten or "")).strip(" .") or "khong-ten")[:80]


# ---------------------------------------------------------------- màu vật liệu lấy từ website nhà cung cấp
MAU_SAN = [dict(id="s1", ten="Trắng", hex="#f4f3ef"), dict(id="s2", ten="Xám nhạt", hex="#c9cbcc"), dict(id="s3", ten="Xám đậm", hex="#5b5f63"),
           dict(id="s4", ten="Đen", hex="#232426"), dict(id="s5", ten="Gỗ sồi sáng", hex="#c9a57a"), dict(id="s6", ten="Gỗ óc chó", hex="#6b4a34"),
           dict(id="s7", ten="Xanh rêu", hex="#5d6b56"), dict(id="s8", ten="Đá trắng", hex="#e9e8e4"), dict(id="s9", ten="Đá xám", hex="#9a9c9f")]


def _tai(url, toi_da=8_000_000):
    """tải 1 địa chỉ web công khai (chặn địa chỉ nội bộ / máy mình); trả về (bytes, content-type, url cuối)"""
    for _ in range(4):
        u = urllib.parse.urlsplit(url)
        if u.scheme not in ("http", "https") or not u.hostname: raise ValueError("Chỉ nhận link http/https.")
        for inf in socket.getaddrinfo(u.hostname, None):
            ip = ipaddress.ip_address(inf[4][0])
            if ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_reserved or ip.is_multicast: raise ValueError("Link này trỏ vào mạng nội bộ – không tải.")
        rq = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130 Safari/537.36", "Accept": "*/*"})
        op = urllib.request.build_opener(_KhongChuyen)
        try:
            r = op.open(rq, timeout=20)
        except urllib.error.HTTPError as e:
            if e.code in (301, 302, 303, 307, 308) and e.headers.get("Location"):
                url = urllib.parse.urljoin(url, e.headers["Location"]); continue
            raise
        b = r.read(toi_da + 1)
        if len(b) > toi_da: raise ValueError("File quá lớn.")
        return b, (r.headers.get("Content-Type") or "").split(";")[0].strip().lower(), url
    raise ValueError("Chuyển hướng quá nhiều lần.")


class _KhongChuyen(urllib.request.HTTPRedirectHandler):       # tự kiểm từng lần chuyển hướng (không để nhảy vào mạng nội bộ)
    def redirect_request(self, *a, **k): return None


def mau_tu_web(url):
    b, ct, url = _tai(str(url).strip())
    ten = ""
    if not ct.startswith("image/"):
        t = b.decode("utf-8", "replace")
        def meta(k):
            m = re.search(r'<meta[^>]+(?:property|name)=["\']%s["\'][^>]*content=["\']([^"\']+)' % re.escape(k), t, re.I) or \
                re.search(r'<meta[^>]+content=["\']([^"\']+)["\'][^>]*(?:property|name)=["\']%s["\']' % re.escape(k), t, re.I)
            return html.unescape(m.group(1)).strip() if m else ""
        anh = meta("og:image") or meta("twitter:image")
        ten = meta("og:title") or (re.search(r"<title[^>]*>(.*?)</title>", t, re.I | re.S) or [0, ""])[1]
        ten = re.sub(r"\s+", " ", html.unescape(ten)).strip()
        if not anh: raise ValueError("Trang này không có ảnh màu để lấy. Bấm chuột phải vào ảnh màu trên trang → 'Copy image address' rồi dán link ảnh đó.")
        b, ct, _ = _tai(urllib.parse.urljoin(url, anh))
        if not ct.startswith("image/"): raise ValueError("Không tải được ảnh màu từ trang này.")
    host = urllib.parse.urlsplit(url).hostname or ""
    ten = (ten or os.path.basename(urllib.parse.urlsplit(url).path).rsplit(".", 1)[0].replace("-", " ").replace("_", " ")).strip()[:70] or "Màu mới"
    mid = hashlib.sha1(b).hexdigest()[:12]; MAU.mkdir(parents=True, exist_ok=True); hx = "#b9b3a8"; duoi = {"image/png": "png", "image/webp": "webp", "image/gif": "gif"}.get(ct, "jpg")
    try:
        from PIL import Image
        im = Image.open(io.BytesIO(b)).convert("RGB"); w, h = im.size; s = min(w, h)
        im = im.crop(((w - s) // 2, (h - s) // 2, (w + s) // 2, (h + s) // 2)); im.thumbnail((768, 768))
        r, g, bl = im.resize((1, 1)).getpixel((0, 0)); hx = "#%02x%02x%02x" % (r, g, bl); duoi = "jpg"
        im.save(MAU / f"{mid}.jpg", "JPEG", quality=88)
    except ImportError:
        (MAU / f"{mid}.{duoi}").write_bytes(b)
    e = dict(id=mid, ten=ten, hex=hx, anh=f"/mau/{mid}.{duoi}", nguon=host, link=url)
    ds = [x for x in doc_json(DATA / "mau.json", []) if x.get("id") != mid] + [e]
    ghi_json(DATA / "mau.json", ds)
    return e


# ---------------------------------------------------------------- AI vẽ nhanh
AI_HE_THONG = """Bạn là Javis Studio, trợ lý vẽ tủ bếp / tủ áo cho xưởng TPW (Sydney). Người dùng ra lệnh bằng tiếng Việt, bạn trả về DUY NHẤT một JSON:
{"noi": "câu trả lời ngắn", "lenh": [ ... ]}
Các lệnh:
{"op":"moi"}                                  xoá hết, vẽ lại từ đầu
{"op":"hang","x":0,"tu":[TU,...]}             thêm 1 hàng tủ nối tiếp từ trái sang phải, bắt đầu tại x (mm)
{"op":"sua","so":[1,2] | "tat_ca" | "duoi" | "treo" | "cao","dat":{...}}   sửa thông số các tủ có sẵn (so = số thứ tự tủ)
{"op":"xoa","so":[3]}                         xoá tủ
{"op":"phong","tuong_trai":true,"tuong_phai":false,"tran":2400}   người dùng nói bên nào sát tường / trần cao bao nhiêu (để tự thêm filler, panel, bulkhead)
{"op":"phong","kho_da":3200,"splashback":"da"}   khổ tấm đá dài (3050 Caesarstone thường / 3200 jumbo Smartstone, Talostone / 3270 Caesarstone jumbo) để báo mối nối; splashback "gach" | "da" | "kinh"
   có thể thêm "kieu":"thang"|"L_trai"|"L_phai"|"U", "dai_a","dai_b","dai_c" (dài tường sau A / trái B / phải C, mm), "b_tuong","c_tuong" (đầu ngoài dãy B / C sát tường)
{"op":"hang","day":"B",...}                    "day": dãy tủ – A tường sau (mặc định), B tường trái, C tường phải, D đảo. x đo từ đầu trái của dãy khi đứng nhìn vào dãy đó
TU = {"loai":..., "w":rộng, tuỳ chọn: "h","d","canh","hoc","ke","shadowline","ten","ray","sl_giua","ban_le","kieu_canh","mo","day_da","phu_kien","hoc_duoi","lo2_cao","mr_kieu","tl_kieu","tl_chia"}
"kieu_canh": "phang" | "shaker" (cửa shaker). "mo": "tay_nam" | "shadowline" | "push" (bấm mở, không tay). Mặt đá: "day_da": số mm bất kỳ 6–150 (thường 12 compact, 18 / 33 laminate, 20 / 40 đá). Bếp âm mặt đá: trên mat_da ghi "ma_may" = mã bếp (vd WHI643BD, PIE631BB5E, CI905ZDTB5) – Studio tự lấy lỗ khoét; không có mã thì "bep_rong"/"bep_sau"; "bep_x" = tâm lỗ cách đầu trái mặt đá (bỏ trống = tự đặt giữa hộc lò dưới bếp). Bếp gas: thêm "bep_gas": true trên mat_da (Studio kiểm hút mùi ≥ 650 trên bếp gas theo AS/NZS 5601.1:2022). Chậu rửa: ghi "ma_may" = mã chậu lên TỦ CHẬU duoi_chau (vd SN1063U, LUA190, BWX120-41/27) – Studio tự khoét mặt đá giữa tủ chậu + kiểm rộng tủ.
loai: duoi_canh (tủ dưới cánh), duoi_hoc (tủ dưới ngăn kéo), duoi_chau (tủ chậu rửa), duoi_keo (tủ kéo thùng rác BIN / kệ gia vị spice rack, rộng 300-450, thêm "phu_kien":"thung_rac"|"ke_gia_vi"), treo (tủ treo), hut_mui (tủ treo có hút mùi âm), cao (tủ cao/pantry), lo_nuong (tủ cao có lò nướng), tu_ao (tủ áo), ke_mo (kệ mở), may_rua (máy rửa chén: "mr_kieu":"am" = âm tủ có cửa cùng màu cánh | "ban_am" | "roi"; rộng 600), tu_lanh (tủ lạnh: "tl_kieu":"am" = âm tủ có cửa cùng màu cánh, rộng 600 | "roi" = tủ lạnh rời, chừa khoảng theo model), thiet_bi (thiết bị khác, chỉ chừa chỗ), mat_da (mặt đá), tam (tấm hông/filler)
Loại góc / đặc biệt (học từ Cabinet Vision): goc_l (tủ dưới góc L 900×900), goc_mu (tủ dưới góc mù: "cua_w" rộng cửa, "mu_ben":"L"|"R"), treo_goc (tủ treo góc L 600×600, "sau_nhanh":300), treo_mu (tủ treo góc mù 650, "cua_w":310, "mu_ben"), cao_mu (tủ cao góc mù / blind pantry 1100, "cua_w":500), cong (tủ cong đầu hàng, "cong_ben").
Tuỳ chọn thêm: "lat":"HF"|"HK"|"HS"|"HL" (tủ treo cánh lật Aventos – HF 2 cánh gập cho tủ cao 480-1060, HK/HL nhỏ); "hoc_trong":1-3 (tủ dưới cánh có ngăn kéo trong sau cánh); "vi_song":true (tủ dưới lò vi sóng + 1 ngăn kéo dưới, rộng 600); "lo_duoi":true (hộc lò âm dưới bếp, rộng 600, không cánh); "noc_lien":true (tủ dưới không mặt đá: laundry / bàn); "stack":"L"|"M"|"R" + "stack_w","stack_d" (né ống / cột sau tủ); tủ áo "kieu_ao":"1_treo"|"2_treo"|"ke"|"chia" ("chia" = vách giữa, trái ngăn kéo + kệ, phải treo; "hoc_ao":2-5), "ke_giay":1-2 (kệ giày nghiêng); "cua_lua":true (cửa lùa 2-4 cánh cho treo / cao / duoi_canh / tu_ao, "canh" = số cánh); "gap_doi":true (cánh gập bi-fold); "ruou":true (kệ rượu – thùng mở, lưới ô ráp rãnh, cho duoi_canh / treo / cao / ke_mo); "ray": hãng ngăn kéo "tandembox"|"legrabox"|"avantech"|"nova_pro"|"atira"|"go" (anh nói "Legrabox", "Hettich", "Grass"…); "ma_may": mã model thiết bị (lò, tủ lạnh, hút mùi…); goc_l "space_corner":"1+2"|"2deu"|"3deu" (Blum SPACE CORNER – ngăn kéo góc); "tach": cao thùng dưới (mm) để tủ cao / tủ áo / tủ lò tách 2 thùng chồng nhau – BẮT BUỘC khi tủ cao > 2400 (ván dài nhất 2410), vd trần 2780: tủ lò chân 130 + 1530 + hộp trên 1130. Tủ lạnh rời: "tl_kieu":"roi", "tl_hop": cao hộp trên (vd 790), "tl_panel": panel sâu (750).
Đơn vị mm ("3m6" = 3600, "6 tấc" = 600). Tủ dưới chuẩn cao 730 sâu 560 (chân 130); tủ treo cao 900 sâu 300; tủ cao 2270 sâu 579. Cánh rộng tối đa 600 mỗi cánh: tủ > 600 dùng 2 cánh.
KHÔNG chép số trong ví dụ: tự tính bề rộng từng tủ để TỔNG đúng bằng chiều dài người dùng nói.
Tủ dưới và tủ cao đi chung 1 hàng; tủ treo là 1 hàng riêng (cũng bắt đầu x=0 trừ khi phía dưới là tủ cao). Tổng bề rộng 1 hàng phải bằng chiều dài người dùng yêu cầu.
Ví dụ: "bếp thẳng 3m, có tủ chậu 900, 1 tủ hộc 3 ngăn, còn lại tủ cánh, tủ treo phía trên, shadowline"
{"noi":"Em vẽ bếp thẳng 3000: chậu 900, hộc 600, 2 tủ cánh 750, tủ treo 4 cái 750.","lenh":[{"op":"moi"},{"op":"hang","x":0,"tu":[{"loai":"duoi_canh","w":750,"shadowline":true},{"loai":"duoi_chau","w":900,"shadowline":true},{"loai":"duoi_hoc","w":600,"hoc":3,"shadowline":true},{"loai":"duoi_canh","w":750,"shadowline":true}]},{"op":"hang","x":0,"tu":[{"loai":"treo","w":750},{"loai":"treo","w":750},{"loai":"treo","w":750},{"loai":"treo","w":750}]}]}
Ví dụ: "đổi tủ 2 thành 4 ngăn kéo" -> {"noi":"Đã đổi tủ 2 thành 4 ngăn kéo.","lenh":[{"op":"sua","so":[2],"dat":{"loai":"duoi_hoc","hoc":4}}]}
"""


def chieu_dai_yeu_cau(cau):
    """đọc chiều dài người dùng nói: "3m6" -> 3600, "2.4m" -> 2400, "dài 3600" -> 3600. Không thấy -> None"""
    c = cau.lower().replace(",", ".")
    m = re.search(r"(\d+)\s*m\s*(\d{1,2})(?!\d)", c)
    if m: return int(m.group(1)) * 1000 + int(m.group(2).ljust(3, "0")[:3]) * (1 if len(m.group(2)) == 3 else 1)
    m = re.search(r"(\d+(?:\.\d+)?)\s*(?:m|mét|met)\b", c)
    if m and float(m.group(1)) < 20: return int(round(float(m.group(1)) * 1000))
    m = re.search(r"(?:dài|dai|rộng|rong|tổng|tong)\s*(\d{4})\b", c)
    return int(m.group(1)) if m else None


def can_hang(ds, L, co_dan=("duoi_canh", "treo", "ke_mo")):
    """ép tổng bề rộng 1 hàng = L bằng cách chia lại các tủ 'co dãn' (tủ cánh, tủ treo); tủ chậu / hộc / thiết bị giữ nguyên"""
    cd = [t for t in ds if t.get("loai") in co_dan and not any(t.get(k) for k in ("vi_song", "lo_duoi", "lat", "stack"))]   # tủ lò / vi sóng / cánh lật / né ống giữ đúng bề rộng
    co_dinh = sum(float(t.get("w", 0)) for t in ds if t not in cd)
    con = L - co_dinh
    if not cd or con < 300 * len(cd) or abs(sum(float(t.get("w", 0)) for t in ds) - L) < 1: return ds
    while con / len(cd) > 900:                      # tủ quá rộng: thêm 1 tủ cùng loại
        k = dict(cd[-1]); k["id"] = secrets.token_hex(4); ds.insert(ds.index(cd[-1]) + 1, k); cd.append(k)
    w = int(con // len(cd))
    for t in cd: t["w"] = float(w)
    cd[-1]["w"] = float(con - w * (len(cd) - 1))
    return ds


def ap_lenh(job, lenh, cau=""):
    """áp danh sách lệnh AI vào job; kiểm từng giá trị, bỏ cái lạ"""
    tu = list(job.get("tu", [])); n = 0
    trong = not tu                       # job đang trống thì coi như vẽ mới, kể cả khi mô hình quên lệnh "moi"
    dai = chieu_dai_yeu_cau(cau) if trong or any(isinstance(x, dict) and x.get("op") == "moi" for x in (lenh if isinstance(lenh, list) else [])) else None
    khoa = {k for k, *_ in engine.THAM_SO} | {"loai"}
    # kiểu cửa cho tủ mới: lấy theo câu anh nói (nếu nói rõ 1 kiểu), không thì theo lựa chọn "Kiểu cửa cho tủ mới" của job
    md = {k: x for k, x in (job.get("mac_dinh") or {}).items() if (k, x) in (("mo", "tay_nam"), ("mo", "shadowline"), ("mo", "push"), ("kieu_canh", "phang"), ("kieu_canh", "shaker"))}
    c0 = re.sub(r"kh[ôo]ng (c[óo] |d[ùu]ng )?tay n[ắa]m|no handles?|handle ?less", " ", cau.lower()); ep = {}
    noi_mo = [k for k, rx in (("shadowline", r"shadow\s*line|finger\s*pull"), ("tay_nam", r"tay n[ắa]m|handle"), ("push", r"b[ấa]m m[ởo]|nh[ấa]n m[ởo]|push")) if re.search(rx, c0)]
    if len(noi_mo) == 1: ep["mo"] = md["mo"] = noi_mo[0]
    if "shaker" in c0: ep["kieu_canh"] = md["kieu_canh"] = "shaker"
    def sach(d):
        o = {}
        for k, v in (d or {}).items():
            if k not in khoa: continue
            if k == "loai" and (v not in engine.THU_VIEN or engine.THU_VIEN[v].get("_loai")): continue
            if k in ("w", "h", "d", "x", "y", "z", "chan", "day_da"):
                try: v = max(0.0, min(6000.0, float(v)))
                except (TypeError, ValueError): continue
            o[k] = v
        d = d or {}
        if "mo" not in o and isinstance(d.get("shadowline"), bool): o["mo"] = "shadowline" if d["shadowline"] else "tay_nam"
        return o
    ph = dict(job.get("phong") or {}); moi = trong
    c = cau.lower()                        # tường / trần: đọc thẳng từ câu anh nói (không tin số mô hình tự bịa)
    if re.search(r"gi[ưữ]a (2|hai) (b[ứu]c )?t[ưườ]+ng|hai b[êe]n (l[àa] |c[óo] |s[áa]t )?t[ưườ]+ng|between (two|2) walls|wall(s)? (on )?both sides", c): ph["tuong_trai"] = ph["tuong_phai"] = True; n += 1
    if re.search(r"(b[êe]n )?tr[áa]i (l[àa] |c[óo] |s[áa]t |gi[áa]p )?t[ưườ]+ng|t[ưườ]+ng (b[êe]n |ph[íi]a )?tr[áa]i|left (side )?(is a |is )?wall|wall on the left", c): ph["tuong_trai"] = True; n += 1
    if re.search(r"(b[êe]n )?ph[ảa]i (l[àa] |c[óo] |s[áa]t |gi[áa]p )?t[ưườ]+ng|t[ưườ]+ng (b[êe]n |ph[íi]a )?ph[ảa]i|right (side )?(is a |is )?wall|wall on the right", c): ph["tuong_phai"] = True; n += 1
    m = re.search(r"(?:tr[ầa]n|ceiling)(?: nh[àa])?(?: cao| height| is)?\s*(\d{4}|\d(?:[.,]\d+)?\s*m\d*)", c)
    if m:
        t = chieu_dai_yeu_cau("dài " + m.group(1)) if m.group(1).isdigit() else chieu_dai_yeu_cau(m.group(1))
        if t and 2000 <= t <= 4000: ph["tran"] = float(t); n += 1
    F = float(ph.get("filler") or 30); P = 16.0
    for L in lenh if isinstance(lenh, list) else []:
        if not isinstance(L, dict): continue
        op = L.get("op")
        if op == "moi": tu = []; n += 1; moi = True
        elif op == "hang":
            ds = []
            for t in L.get("tu") or []:
                s = sach(t)
                if "loai" not in s: continue
                for k in ("mo", "kieu_canh"):
                    if k in ep: s[k] = ep[k]
                    elif k not in s and k in md: s[k] = md[k]
                lo = s.pop("loai"); u = engine.tu_moi(lo, id=secrets.token_hex(4), **s)
                if lo == "mat_da" and "y" not in s: u["_khong_y"] = True
                if u.get("ma_may") and lo in ("may_rua", "lo_nuong", "tu_lanh", "thiet_bi", "duoi_canh"):   # AI ghi mã máy -> gắn spec có sẵn (không cần mạng)
                    try:
                        import spec as _sp
                        sp0 = _sp.co_san(u["ma_may"])
                        if sp0: _sp.ap_vao_tu(u, sp0)
                    except Exception: pass
                ds.append(u)
            try: x0 = float(L.get("x", 0) or 0)
            except (TypeError, ValueError): x0 = 0.0
            ds2 = []                      # cánh tối đa ~600: tủ quá rộng thì tách thành nhiều tủ bằng nhau
            for t in ds:
                k = -(-int(float(t["w"])) // 1200) if t["loai"] in engine.CO_CANH and float(t["w"]) > 1200 else 1
                for i in range(k): ds2.append(dict(t, w=round(float(t["w"]) / k, 1), id=secrets.token_hex(4)))
            ds = ds2
            treo = bool(ds) and all(t["loai"] in engine.TU_TREO for t in ds)
            dd = L.get("day") if L.get("day") in ("B", "C", "D") else "A"
            duoi_co = [t for t in tu if t.get("loai") in engine.TU_DUOI + engine.TU_CAO + ("thiet_bi",) and (t.get("day") or "A") == dd]   # chỉ tủ cùng dãy
            co_x = x0 > 0                                  # AI đã đặt vị trí cụ thể (đọc từ bản vẽ) -> giữ đúng bề rộng, không co dãn
            if treo and duoi_co and not co_x and any(t["loai"] in engine.TU_CAO for t in duoi_co):       # tủ treo chỉ chạy trên phần tủ thấp, không qua đầu tủ cao
                thap = [t for t in duoi_co if t["loai"] not in engine.TU_CAO]
                if thap:
                    x0 = min(float(t["x"]) for t in thap); ds = can_hang(ds, max(float(t["x"]) + float(t["w"]) for t in thap) - x0)
            elif dai and ds and not co_x:
                dau = sum((F if ph.get("tuong_" + b) else P) for b in ("trai", "phai"))      # chừa filler sát tường / panel hông 2 đầu
                noi = sum(1 for a, b in zip(ds, ds[1:]) if (a["loai"] in engine.TU_CAO) != (b["loai"] in engine.TU_CAO)) * P
                mem = ("duoi_canh", "treo", "ke_mo")
                ds = can_hang(ds, dai - dau - (0 if treo else noi), co_dan=mem if any(t["loai"] in mem for t in ds) else ("cao", "tu_ao", "duoi_hoc"))
            nen = [u for u in duoi_co if u["loai"] in engine.TU_DUOI]
            for t in ds:                                   # mặt đá không ghi "y": đặt lên đỉnh tủ dưới cùng dãy (chân + thùng)
                if t.pop("_khong_y", False) and nen: t["y"] = max(float(u.get("chan") or 0) + float(u["h"]) for u in nen)
            moi_h = engine.xep_hang(ds, x0)
            if L.get("day") in ("B", "C", "D"):
                for t in moi_h: t["day"] = L["day"]
            tu += moi_h; n += len(ds)
        elif op == "phong":                 # hình dạng phòng / chiều dài tường (đọc từ bản vẽ)
            if L.get("kieu") in ("thang", "L_trai", "L_phai", "U"): ph["kieu"] = L["kieu"]; n += 1
            for k in ("dai_a", "dai_b", "dai_c", "tran"):
                try:
                    v = float(L.get(k) or 0)
                    if 300 <= v <= 20000: ph[k] = v
                except (TypeError, ValueError): pass
            for k in ("filler", "filler_goc", "filler_goc_treo"):             # bản vẽ ghi filler 18 / filler góc 18 (PRAKASH) – không ép về 30 / 50
                try:
                    v = float(L.get(k))
                    if 0 <= v <= 150: ph[k] = v
                except (TypeError, ValueError): pass
            for k in ("tuong_trai", "tuong_phai", "b_tuong", "c_tuong"):
                if isinstance(L.get(k), bool): ph[k] = L[k]
            try:
                kd = float(L.get("kho_da") or 0)
                if 2400 <= kd <= 3600: ph["kho_da"] = kd; n += 1          # khổ tấm đá (bản vẽ / anh nói "đá jumbo 3200")
            except (TypeError, ValueError): pass
            if L.get("splashback") in ("gach", "da", "kinh"): ph["splashback"] = L["splashback"]
        elif op in ("sua", "xoa"):
            so = L.get("so")
            nhom = {"duoi": ("duoi_canh", "duoi_hoc", "duoi_chau"), "treo": ("treo",), "cao": ("cao", "tu_ao")}
            if so == "tat_ca": idx = list(range(len(tu)))
            elif isinstance(so, str) and so in nhom: idx = [i for i, t in enumerate(tu) if t.get("loai") in nhom[so]]
            else: idx = [int(s) - 1 for s in (so if isinstance(so, list) else [so]) if str(s).strip().lstrip("-").isdigit() and 0 < int(s) <= len(tu)]
            if op == "xoa": tu = [t for i, t in enumerate(tu) if i not in idx]; n += len(idx)
            else:
                d = sach(L.get("dat"))
                for i in idx:
                    t = dict(tu[i])
                    if "loai" in d and d["loai"] != t.get("loai"):       # đổi loại: giữ vị trí + bề rộng
                        giu = {k: t[k] for k in ("id", "x", "z", "goc", "w", "mo", "kieu_canh", "vl_thung", "vl_mat") if k in t}
                        t = engine.tu_moi(d["loai"], **giu)
                    t.update({k: v for k, v in d.items() if k != "loai"}); tu[i] = t; n += 1
    job = dict(job); job["tu"] = tu; job["phong"] = ph
    if md: job["mac_dinh"] = dict(dict(mo="tay_nam", kieu_canh="phang"), **md)
    if moi and tu:            # bản vẽ mới: tự thêm panel hông, filler sát tường, kicker, bulkhead theo quy tắc
        job, _ = engine.hoan_thien(job)
    return job, n


PDF_HE_THONG = """Bạn đọc BẢN VẼ THIẾT KẾ BẾP / TỦ (mặt bằng + mặt đứng, số đo mm) và dựng lại đúng bằng lệnh của Javis Studio.
Đọc kỹ: chiều dài từng tường, từng tủ theo thứ tự trái -> phải trên mỗi mặt đứng, tủ dưới / ngăn kéo / chậu / tủ treo / tủ cao / máy rửa chén / tủ lạnh / lò, cao tủ, sâu tủ, kiểu mở (handle / fingerpull / push), cửa shaker hay phẳng.
Bếp chữ L / U: dùng op "phong" với kieu + dai_a/dai_b/dai_c, rồi "hang" có "day" cho từng tường. Bề rộng tủ lấy ĐÚNG số trên bản vẽ, không làm tròn, không tự bịa.
Bắt đầu bằng {"op":"moi"}. "noi": tóm tắt ngắn đã đọc được gì + chỗ nào bản vẽ không rõ.
CÁCH ĐỌC BẢN VẼ TPW (Revit, mặt bằng A101 + mặt đứng A102 tỉ lệ 1:20) – rút từ job PRAKASH đã kiểm:
- Dải số trên / dưới mặt đứng là bề rộng TỪNG Ô từ trái sang phải; "18" đứng riêng = panel hông / filler 18. Số dọc bên cạnh = chân (145), thùng (737), đá (18), khoảng hở (580), tủ treo (720), bulkhead (200), tổng 2400.
- Số đo gồm cả cánh: tủ dưới sâu "600" = thùng 582; tủ treo "350" = thùng 332 → dùng "d" = số đó trừ 18.
- Dấu X đỏ nét đứt trên 1 ô = 1 cánh; 1 X phủ 2 ô cạnh nhau = 2 cánh; "DR" = ngăn kéo; "RH" = tủ hút mùi (hut_mui, thường cao 600); khối có lò / vi sóng = lo_nuong; hộp màu khác ghi "FIXED" = ke_mo có kệ cố định.
- Bếp chữ L: dãy nào ở mặt đứng kia hiện ra như 1 ô TRƠN rộng 600 (tủ dưới) / 350 (tủ treo) ở đầu góc = dãy đó chạy vào góc. Ô trơn 600 cuối dãy chạy vào góc + cánh bên cạnh = tủ góc mù goc_mu (w = cánh + 600, cua_w = cánh, mu_ben phía góc). Dãy kia bắt đầu từ góc sau 600 (hoặc 350) + 18 filler.
- Studio chỉ có tường sau A, trái B, phải C: đặt dãy chạy vào góc làm A, dãy kia làm C (kieu "L_phai") nếu góc ở bên phải A khi nhìn vào A; ngược lại B (kieu "L_trai").
- Tủ treo: "y" = chân + thùng + đá + khoảng hở (vd 145 + 737 + 18 + 580 = 1480). Tủ cao / tháp lò: "h" = tới đỉnh tủ treo trừ chân.
- Ô tủ treo trơn ở góc + cánh bên cạnh = treo_mu (w = cánh + mặt trơn, cua_w = cánh). Tủ cao có ô trơn ở góc = cao_mu.
- Ô tủ dưới có lò (OVEN) không cánh = duoi_canh "lo_duoi":true; ô có lò vi sóng (MW / MICROWAVE) + ngăn kéo dưới = duoi_canh "vi_song":true. Tủ treo cánh lật lên (mũi tên đi lên / "LIFT UP" / "AVENTOS") = treo "lat":"HF" (cao > 600) hoặc "HK".
- Ghi chú "PIPE" / "STACK" / ô né cột sau tủ = "stack":"L"|"M"|"R".
- Ghi chú "WINE" / "WINE RACK" / ô lưới chai rượu = "ruou":true (không cánh).
- Tủ cao / tủ lò có 2 thùng chồng (đường ngang chia thùng, hộp trên riêng) hoặc cao > 2400 = "tach": cao thùng dưới.
- Bản vẽ ghi MÃ THIẾT BỊ (vd "DW: F&P DW60U6I1", "OVEN: Bosch HBG634BS1", "RH: Westinghouse WRI825BC", "FRIDGE: KIR81AFE0") → đặt "ma_may": "<mã>" vào đúng tủ đó (may_rua / lo_nuong / hut_mui / tu_lanh). Studio tự tra lỗ khoét / hộc theo mã. Không có mã thì bỏ trống, KHÔNG bịa.
- Mặt đá: ghi "S01 LAMINATE 18" / "20MM STONE"… = "day_da" đúng số ghi (bất kỳ 6–150). Mặt đá chạy suốt dãy, sâu 600 (= thùng 582 + cánh 18).
- Filler góc tủ treo khác tủ dưới: tủ treo dãy kia bắt đầu sau 350 (thùng treo 332 + cánh 18) – không phải 600.
VÍ DỤ ĐÃ KIỂM (job PRAKASH, bếp L 2586 × 2900, đáp án đúng):
{"noi":"Bếp L: dãy trái 2586 chạy vào góc (góc mù), dãy sau 2900 có tháp lò.","lenh":[{"op":"moi"},
{"op":"phong","kieu":"L_phai","dai_a":2586,"dai_c":2900,"tran":2400,"filler":18,"filler_goc":18,"tuong_trai":false},
{"op":"hang","day":"A","x":18,"tu":[{"loai":"duoi_hoc","w":600,"hoc":3,"h":737,"d":582,"chan":145,"mo":"push"},{"loai":"duoi_chau","w":900,"canh":2,"h":737,"d":582,"chan":145,"mo":"push"},{"loai":"goc_mu","w":1068,"cua_w":468,"canh":2,"mu_ben":"R","h":737,"d":582,"chan":145,"mo":"push"}]},
{"op":"hang","day":"A","x":18,"tu":[{"loai":"treo","w":600,"h":720,"d":332,"y":1480},{"loai":"ke_mo","w":900,"h":720,"d":332,"y":1480,"ke":0,"ke_cd":1},{"loai":"treo","w":718,"h":720,"d":332,"y":1480},{"loai":"treo","w":350,"canh":0,"h":720,"d":332,"y":1480}]},
{"op":"hang","day":"C","x":618,"tu":[{"loai":"duoi_canh","w":446,"canh":1,"ban_le":"L"},{"loai":"duoi_canh","w":900,"canh":2},{"loai":"duoi_canh","w":300,"canh":1,"ban_le":"R"}]},
{"op":"hang","day":"C","x":2282,"tu":[{"loai":"lo_nuong","w":600,"h":2055,"d":582,"chan":145,"canh":2,"hoc_duoi":1,"lo_y":300,"lo_cao":595,"lo2_cao":380}]},
{"op":"hang","day":"C","x":368,"tu":[{"loai":"treo","w":232,"canh":1,"ban_le":"L"},{"loai":"treo","w":464,"canh":1,"ban_le":"R"},{"loai":"hut_mui","w":900,"h":600,"d":332,"y":1600},{"loai":"treo","w":300,"canh":1,"ban_le":"R"}]},
{"op":"hang","day":"A","x":0,"tu":[{"loai":"mat_da","w":2586,"d":600,"day_da":18}]},{"op":"hang","day":"C","x":600,"tu":[{"loai":"mat_da","w":1664,"d":600,"day_da":18}]}]}
(Ở ví dụ trên tủ dưới dãy C cũng có h 737 / d 582 / chân 145, tủ treo h 720 / d 332 / y 1480 như dãy A – viết đủ khi trả lệnh.)
"""


def doc_pdf(b64, trang=0, rong=2200):
    """PDF -> ảnh trang (PNG data-URL) + chữ của mọi trang + kích thước trang (point). Dùng pypdfium2."""
    import pypdfium2 as pdfium
    doc = pdfium.PdfDocument(base64.b64decode(b64)); n = len(doc); trang = max(0, min(int(trang or 0), n - 1))
    pg = doc[trang]; w, h = pg.get_size(); anh = pg.render(scale=min(4.0, rong / max(w, h))).to_pil()
    buf = io.BytesIO(); anh.save(buf, "PNG"); chu = []
    for i in range(min(n, 12)):
        try: chu.append(f"--- Trang {i + 1} ---\n" + doc[i].get_textpage().get_text_range())
        except Exception: pass
    return dict(so_trang=n, trang=trang, w_pt=w, h_pt=h, anh="data:image/png;base64," + base64.b64encode(buf.getvalue()).decode(), chu="\n".join(chu)[:20000])


def hoi_ai(cfg, cau, job):
    """AI RIÊNG của Studio (Cài đặt › AI cho Studio): Ollama / Claude API / OpenAI / dùng chung Javis Local"""
    tom = [f"{i + 1}. {t.get('loai')} rộng {t.get('w'):g} x={t.get('x', 0):g}" for i, t in enumerate(job.get("tu", []))]
    user = ("Tủ đang có:\n" + ("\n".join(tom) if tom else "(chưa có tủ nào)") + "\n\nLệnh: " + cau)
    txt = ai.hoi(ai.cau_hinh(cfg), AI_HE_THONG, user)
    a, b = txt.find("{"), txt.rfind("}")
    return json.loads(txt[a:b + 1])


# ---------------------------------------------------------------- HTTP
class H(BaseHTTPRequestHandler):
    server_version = "JavisStudio"

    def log_message(self, *a): pass

    def gui(self, code, body, ctype="application/json; charset=utf-8"):
        if not isinstance(body, (bytes, bytearray)):
            body = (body if isinstance(body, str) else json.dumps(body, ensure_ascii=False)).encode("utf-8")
        self.send_response(code); self.send_header("Content-Type", ctype); self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store"); self.send_header("X-Content-Type-Options", "nosniff"); self.end_headers()
        try: self.wfile.write(body)
        except OSError: pass

    def ok_nguon(self):
        h = (self.headers.get("Host") or "").split(":")[0]
        return h in ("127.0.0.1", "localhost")

    def do_GET(self):
        if not self.ok_nguon(): return self.gui(403, {"loi": "host"})
        p = self.path.split("?")[0]
        if p == "/" and not _hop_le():                           # chưa có mã kích hoạt / hết hạn / bị thu hồi -> trang kích hoạt
            if giayphep.thong_tin().get("may_chu") and not banquyen.trang_thai().get("ten"):
                tt = giayphep.thong_tin()
                h = DANG_NHAP.replace("__TOKEN__", TOKEN).replace("__PB__", PHIEN_BAN).replace("__MAYCHU__", html.escape(tt["may_chu"] or "")).replace("__TEN__", html.escape(tt["ten"] or "")).replace("__LYDO__", html.escape(tt["ly_do"] or ""))
                return self.gui(200, h, "text/html; charset=utf-8")
            h = TRANG_KH.replace("__TOKEN__", TOKEN).replace("__PB__", PHIEN_BAN).replace("__LY__", html.escape(banquyen.trang_thai()["ly_do"]))
            return self.gui(200, h, "text/html; charset=utf-8")
        if p == "/" and False:
            tt = giayphep.thong_tin()
            h = DANG_NHAP.replace("__TOKEN__", TOKEN).replace("__PB__", PHIEN_BAN).replace("__MAYCHU__", html.escape(tt["may_chu"] or "")).replace("__TEN__", html.escape(tt["ten"] or "")).replace("__LYDO__", html.escape(tt["ly_do"] or ""))
            return self.gui(200, h, "text/html; charset=utf-8")
        if p == "/":
            html_ = (GOC / "ui.html").read_text(encoding="utf-8").replace("__TOKEN__", TOKEN).replace("__PB__", PHIEN_BAN)
            return self.gui(200, html_, "text/html; charset=utf-8")
        if p == "/favicon.ico": return self.gui(204, b"", "image/x-icon")
        m = re.fullmatch(r"/mau/([0-9a-f]{12})\.(jpg|png|webp|gif)", p)
        if m and (MAU / p[5:]).is_file():
            return self.gui(200, (MAU / p[5:]).read_bytes(), {"jpg": "image/jpeg", "png": "image/png", "webp": "image/webp", "gif": "image/gif"}[m.group(2)])
        if p.startswith("/lib/") and re.fullmatch(r"/lib/[\w.\-]+\.js", p):
            f = GOC / "lib" / p[5:]
            if f.is_file(): return self.gui(200, f.read_bytes(), "text/javascript; charset=utf-8")
        self.gui(404, {"loi": "khong co"})

    def do_POST(self):
        if not self.ok_nguon() or self.headers.get("X-Javis-Token") != TOKEN: return self.gui(403, {"loi": "token"})
        try:
            n = int(self.headers.get("Content-Length") or 0)
            d = json.loads(self.rfile.read(n) or b"{}") if n else {}
            p = self.path.split("?")[0]
            if p in ("/api/kich-hoat", "/api/ban-quyen", "/api/cap-nhat-gh"): return self.gui(200, self.bq(p, d))
            if p not in ("/api/dang-nhap", "/api/song", "/api/thoat", "/api/tk") and not _hop_le():
                return self.gui(401, {"khoa": True, "loi": giayphep.TT.get("ly_do") or "Cần đăng nhập."})
            self.gui(200, self.post(p, d))
        except Exception as e:
            traceback.print_exc(); self.gui(500, {"loi": f"{type(e).__name__}: {e}"})

    def bq(self, p, d):
        if p == "/api/kich-hoat":
            try: return banquyen.kich_hoat(d.get("ma"))
            except ValueError as e: return {"ok": False, "loi": str(e)}
        if p == "/api/ban-quyen":
            if d.get("lai"): banquyen.kiem_mang(cho=True)
            return dict(banquyen.trang_thai(), phien_ban=PHIEN_BAN, moi=(banquyen.TT["moi"] or {}).get("phien_ban") if banquyen.co_ban_moi(PHIEN_BAN) else None)
        if p == "/api/cap-nhat-gh":
            if capnhat.la_nguon(): return {"ok": False, "tin": "Máy nguồn (máy sửa mã) không tự cập nhật từ GitHub."}
            ok, kq = banquyen.cap_nhat(PHIEN_BAN)
            if ok: banquyen.khoi_dong_lai()
            return {"ok": ok, "tin": (f"Đã cập nhật lên bản {kq} – Studio tự mở lại sau vài giây." if ok else kq)}
        return {}

    def post(self, p, d):
        cfg = doc_cfg()
        if p == "/api/khoi-dong":
            TT["ui"] = time.time()
            return dict(thu_vien=engine.THU_VIEN, chung=engine.CHUNG, tham_so=engine.THAM_SO,
                        vat_lieu={k: dict(ten=v["ten"], mau=v["mau"], lz=v["lz"]) for k, v in engine.VAT_LIEU.items()},
                        cfg=dict(thu_muc_xuat=cfg["thu_muc_xuat"], mo_hinh=ai.mo_ta(ai.cau_hinh(cfg))), gan_nhat=doc_json(DATA / "gan-nhat.json", {}).get("ten"))
        if p == "/api/song": TT["ui"] = time.time(); return {"ok": 1}
        if p == "/api/catalog": return {"catalog": doc_json(GOC / "lib" / "catalog_cv.json", [])}      # thư viện tủ lấy từ Cabinet Vision (MN Joinery, Huân)
        if p == "/api/dung":
            job = d.get("job") or {}; moi = None; gh = []
            if (job.get("phong") or {}).get("tu_dong", True) and job.get("tu"):       # tự hoàn thiện: panel / filler / kicker luôn đi theo tủ
                j2, gh = engine.hoan_thien(job)
                if json.dumps(j2.get("tu"), sort_keys=True) != json.dumps(job.get("tu"), sort_keys=True): moi = dict(tu=j2["tu"], phong=j2["phong"])
                job = j2
            kq = engine.dung_job(job)
            ct = [dict(cab=x["cab"], n=x["name"], vl=x["vl"], w=x["w"], h=x["h"], lo=len(x["holes"]), nep=x["edges"], e45=x["e45"], note=x["note"]) for x in kq["chi_tiet"]]
            cb = [g for g in gh if any(k in g for k in ("còn hở", "lấn vào", "dài hơn tường"))] + kq["canh_bao"]      # cảnh báo ở góc chữ L / số đo tường
            return dict(tu=kq["tu"], chi_tiet=ct, phu_kien=kq["phu_kien"], canh_bao=cb, ghi_chu=kq.get("ghi_chu", []), nep=kq["nep"], job=moi, day=kq["day"], splash=kq["splash"])
        if p == "/api/hoan-thien":
            job = d.get("job") or {}
            if d.get("go"): job = dict(job, tu=[t for t in job.get("tu", []) if not t.get("auto")]); return {"job": job, "ghi": []}
            j, ghi = engine.hoan_thien(job); return {"job": j, "ghi": ghi}
        if p == "/api/xep": return xuat.xem_truoc(d.get("job") or {})
        if p == "/api/xuat":
            job = d.get("job") or {}
            if not job.get("tu"): return {"loi": "Job chưa có tủ nào."}
            r = xuat.xuat(job, cfg["thu_muc_xuat"])
            return r
        if p == "/api/ban-ve":
            job = d.get("job") or {}
            if not job.get("tu"): return {"loi": "Job chưa có tủ nào."}
            import banve, tempfile
            ten = re.sub(r'[\\/:*?"<>|]', "-", f"BAN VE 2D - {job.get('so', '')} {job.get('ten', '')}").strip() + ".pdf"
            out = os.path.join(cfg["thu_muc_xuat"], "_ban-ve"); os.makedirs(out, exist_ok=True); path = os.path.join(out, ten)
            n = banve.ban_ve(path, job)
            p_da = path.replace("BAN VE 2D - ", "MAT DA - THO DA - ")
            try: p_da = p_da if banve.ban_ve_da(p_da, job) else ""
            except Exception: p_da = ""
            p_en = path.replace("BAN VE 2D - ", "BENCHTOP - STONEMASON - ") if p_da else ""
            try: p_en = p_en if p_en and banve.ban_ve_da(p_en, job, en=True) else ""
            except Exception: p_en = ""
            try:
                if os.name == "nt": os.startfile(path)
            except Exception: pass
            p_bv = path.replace("BAN VE 2D - ", "DRAWINGS - EN - ")
            try: banve.ban_ve(p_bv, job, en=True)
            except Exception: p_bv = ""
            return {"duong_dan": path, "trang": n, "mat_da": p_da, "mat_da_en": p_en, "ban_ve_en": p_bv}
        if p == "/api/skp":                                       # thả file SketchUp -> cây khối 3D (SketchUp C SDK)
            if not skp.co_sdk(): return {"loi": "Máy này chưa có SketchUp SDK (thư mục skp-sdk).", "khong_sdk": True}
            tam = DATA / "tam"; tam.mkdir(parents=True, exist_ok=True); f = tam / ("nhap-" + secrets.token_hex(4) + ".skp")
            f.write_bytes(base64.b64decode(d.get("b64") or ""))
            try: cay, so = skp.doc(f)
            finally:
                try: f.unlink()
                except Exception: pass
            return {"cay": cay, "so": so}
        if p == "/api/xem3d":                                     # 1 file HTML 3D tự chứa để gửi khách / thợ (WhatsApp, OneDrive Share)
            job = d.get("job") or {}
            if not job.get("tu"): return {"loi": "Job chưa có tủ nào."}
            if (job.get("phong") or {}).get("tu_dong", True): job, _ = engine.hoan_thien(job)
            import xem3d
            ten = re.sub(r'[\\/:*?"<>|]', "-", f"XEM 3D - {job.get('so', '')} {job.get('ten', '')}").strip(" -") + ".html"
            out = os.path.join(cfg["thu_muc_xuat"], "XEM 3D"); os.makedirs(out, exist_ok=True); path = os.path.join(out, ten)
            n = xem3d.tao(job, path, lang=d.get("lang") or "vi")
            try:
                if os.name == "nt": subprocess.Popen(["explorer", "/select,", path])
            except Exception: pass
            return {"duong_dan": path, "thu_muc": out, "so_tu": n, "kb": round(os.path.getsize(path) / 1024), "onedrive": "onedrive" in path.lower()}
        if p == "/api/dang-nhap":
            return giayphep.dang_nhap(str(d.get("may_chu") or ""), str(d.get("ten") or ""), str(d.get("mat_khau") or ""))
        if p == "/api/tk": return giayphep.thong_tin()
        if p == "/api/dang-xuat": giayphep.dang_xuat(); return {"ok": 1}
        if p == "/api/cai-dat":                                   # ⚙ Cài đặt: AI riêng + cập nhật
            a = ai.cau_hinh(cfg)
            return dict(phien_ban=PHIEN_BAN, ban=capnhat.ban_dang_chay(), nguon=capnhat.la_nguon(), thu_muc_ban_moi=str(capnhat.thu_muc_ban_moi(cfg)),
                        ai=ai.che(a), ai_nhan=ai.NHAN, ai_mo_ta=ai.mo_ta(a), ollama=ai.ds_ollama(a["ollama_url"]))
        if p == "/api/ai-luu":
            cu = ai.cau_hinh(cfg); moi = {k: d.get(k, cu.get(k)) for k in ai.MAC_DINH}
            for k in ("claude_key", "openai_key"):                  # ô key để trống / còn dấu •••• = giữ key cũ
                v = str(d.get(k) or "")
                moi[k] = cu.get(k, "") if (not v or v.startswith("••••")) else v.strip()
            if d.get("xoa_key"): moi[d["xoa_key"]] = ""
            if moi.get("nguon") not in ai.NHAN: moi["nguon"] = "ollama"
            c = doc_json(DATA / "cau-hinh.json", {}); c["ai"] = moi; ghi_json(DATA / "cau-hinh.json", c)
            return {"ok": 1, "ai": ai.che(moi), "ai_mo_ta": ai.mo_ta(moi)}
        if p == "/api/ai-thu":
            try:
                t0 = time.time(); r = ai.hoi(ai.cau_hinh(cfg), 'Trả lời đúng JSON {"ok": true, "noi": "<1 câu chào ngắn tiếng Việt>"}', "Thử kết nối.", toi_da=80)
                return {"ok": 1, "noi": r[:200], "giay": round(time.time() - t0, 1)}
            except Exception as e: return {"loi": str(e)[:300]}
        if p == "/api/cap-nhat-kiem":
            if capnhat.la_nguon(): return dict(nguon=True, **TT.get("phat_hanh", {}))
            return capnhat.kiem_tra(cfg)
        if p == "/api/cap-nhat":                                  # bấm "Cập nhật": chép bản mới rồi tự mở lại Studio
            r = capnhat.ap_dung(cfg)
            if r.get("ok"): threading.Timer(0.8, mo_lai).start()
            return r
        if p == "/api/phat-hanh":
            if not capnhat.la_nguon(): return {"loi": "Chỉ máy nguồn mới phát hành."}
            r = capnhat.phat_hanh(PHIEN_BAN, cfg, ep=True); TT["phat_hanh"] = r; return r
        if p == "/api/mo-thu-muc":
            f = str(d.get("duong_dan") or cfg["thu_muc_xuat"])
            goc = os.path.abspath(cfg["thu_muc_xuat"])
            if os.path.abspath(f).startswith(goc) and os.path.isdir(f) and sys.platform.startswith("win"): os.startfile(f)
            return {"ok": 1}
        if p == "/api/luu":
            job = d.get("job") or {}; ten = ten_file(f"{job.get('so', '')} {job.get('ten', '')}".strip())
            ghi_json(JOBS / (ten + ".jvs"), job); ghi_json(DATA / "gan-nhat.json", {"ten": ten})
            return {"ok": 1, "ten": ten}
        if p == "/api/jobs":
            JOBS.mkdir(parents=True, exist_ok=True)
            fs = sorted(JOBS.glob("*.jvs"), key=lambda f: -f.stat().st_mtime)
            return {"jobs": [dict(ten=f.stem, luc=time.strftime("%d/%m %H:%M", time.localtime(f.stat().st_mtime))) for f in fs[:200]]}
        if p == "/api/mo":
            f = JOBS / (ten_file(d.get("ten")) + ".jvs")
            if not f.is_file(): return {"loi": "Không thấy job này."}
            ghi_json(DATA / "gan-nhat.json", {"ten": f.stem}); return {"job": doc_json(f, {})}
        if p in ("/api/pdf", "/api/pdf-ai"):                     # bản vẽ PDF: làm nền mặt bằng / AI dựng lại tủ
            try: kq = doc_pdf(d.get("b64") or "", d.get("trang") or 0)
            except ImportError: return {"loi": "Thiếu thư viện đọc PDF (pypdfium2). Mở lại Studio để tự cài, hoặc chạy: py -m pip install pypdfium2"}
            except Exception as e: return {"loi": f"Không đọc được PDF: {e}"}
            if p == "/api/pdf": return kq
            a = ai.cau_hinh(cfg)
            user = ("Chữ / số đo trích từ bản vẽ (có thể lộn xộn thứ tự):\n" + (kq["chu"] or "(PDF không có lớp chữ – xem bản vẽ đính kèm)") + "\n\nDựng lại toàn bộ tủ theo bản vẽ.")
            try:
                txt = ai.hoi(a, AI_HE_THONG + "\n" + PDF_HE_THONG, user, toi_da=6000, pdf=d.get("b64") if a.get("nguon") == "claude" else None)
                i, j = txt.find("{"), txt.rfind("}"); r = json.loads(txt[i:j + 1])
            except Exception as e:
                return {"loi": f"AI chưa đọc được bản vẽ ({ai.mo_ta(a)}): {e if isinstance(e, RuntimeError) else type(e).__name__}. Bản vẽ phức tạp nên dùng Claude API (Cài đặt ⚙)."}
            job2, n = ap_lenh(dict(d.get("job") or {}, tu=[]), r.get("lenh"), "")
            return {"job": job2, "noi": str(r.get("noi") or "")[:800], "n": n}
        if p == "/api/tra-spec":                 # gõ mã model thiết bị -> tự tìm spec lắp đặt (có link nguồn để kiểm)
            import spec
            return spec.tra(cfg, d.get("ma"), str(d.get("loai") or ""), bool(d.get("moi")))
        if p == "/api/luu-spec":                 # anh bấm "Áp vào tủ" = đã xem: nhớ lại cho lần sau (không cần tra lại)
            import spec
            s0 = dict(spec.lam_sach(d.get("spec") or {}), chac=True, da_xac_nhan=True); spec.luu(d.get("ma"), s0); return {"ok": 1}
        if p == "/api/ai":
            job = d.get("job") or {}; cau = str(d.get("lenh") or "").strip()[:2000]
            if not cau: return {"loi": "Chưa nhập lệnh."}
            try: kq = hoi_ai(cfg, cau, job)
            except Exception as e:
                return {"loi": f"Chưa gọi được AI ({ai.mo_ta(ai.cau_hinh(cfg))}): {e if isinstance(e, RuntimeError) else type(e).__name__}. Đổi AI trong Cài đặt (nút ⚙)."}
            job2, n = ap_lenh(job, kq.get("lenh"), cau)
            return {"job": job2, "noi": str(kq.get("noi") or "")[:400], "n": n}
        if p == "/api/mau-ds": return {"san": MAU_SAN, "web": doc_json(DATA / "mau.json", [])}
        if p == "/api/mau-tu-web":
            try: return {"mau": mau_tu_web(d.get("url"))}
            except ValueError as e: return {"loi": str(e)}
            except Exception as e: return {"loi": f"Không lấy được màu từ link này ({type(e).__name__}). Thử dán thẳng link ảnh màu."}
        if p == "/api/mau-xoa":
            ghi_json(DATA / "mau.json", [x for x in doc_json(DATA / "mau.json", []) if x.get("id") != d.get("id")]); return {"ok": 1}
        if p == "/api/thoat":
            threading.Timer(0.3, lambda: os._exit(0)).start(); return {"ok": 1}
        return {"loi": "khong co"}


def _hop_le():
    """được dùng: tài khoản máy chủ (máy anh Tan) HOẶC mã kích hoạt (máy thợ, Phong, Kiên…)"""
    try:
        if giayphep.hop_le(): return True
    except Exception: pass
    return banquyen.trang_thai()["ok"]


TRANG_KH = """<!doctype html><html><head><meta charset="utf-8"><title>Javis Studio – kích hoạt</title><style>
body{margin:0;background:radial-gradient(circle at 30% 20%,#17313a,#0b0f13 60%);color:#e6e9ee;font:15px Segoe UI,Arial;display:flex;align-items:center;justify-content:center;height:100vh}
.b{background:#121820;border:1px solid #233040;border-radius:16px;padding:28px 30px;width:560px}h1{margin:0 0 4px;font-size:22px;letter-spacing:.06em}h1 span{color:#3ec6e0}
p{color:#9aa4b0;line-height:1.5}textarea{width:100%;height:90px;background:#0d1217;color:#e6e9ee;border:1px solid #2a3542;border-radius:8px;padding:8px;font:13px Consolas,monospace;box-sizing:border-box}
button{margin-top:12px;background:#18b8d8;color:#04161b;border:0;border-radius:8px;padding:10px 18px;font-weight:700;cursor:pointer;margin-right:8px}#kq{margin-top:12px;color:#ff9b9b;min-height:20px}
</style></head><body><div class="b"><h1>JAVIS <span>STUDIO</span></h1><p>TPW GROUP · v__PB__<br>__LY__</p>
<textarea id="ma" placeholder="Dán mã kích hoạt anh Tan gửi vào đây"></textarea><br><button id="go">Kích hoạt</button><button id="th" style="background:#2a3542;color:#e6e9ee">Thử lại</button><div id="kq"></div></div>
<script>const T="__TOKEN__";async function api(p,b){const r=await fetch(p,{method:'POST',headers:{'Content-Type':'application/json','X-Javis-Token':T},body:JSON.stringify(b||{})});return r.json()}
go.onclick=async()=>{kq.textContent='Đang kiểm tra...';const r=await api('/api/kich-hoat',{ma:ma.value});if(r.ok)location.reload();else kq.textContent=r.loi||r.ly_do||'Không được'};
th.onclick=async()=>{kq.textContent='Đang kết nối...';const r=await api('/api/ban-quyen',{lai:1});if(r.ok)location.reload();else kq.textContent=r.ly_do};
setInterval(()=>fetch('/api/song',{method:'POST',headers:{'Content-Type':'application/json','X-Javis-Token':T},body:'{}'}).catch(()=>{}),4000);</script></body></html>"""


def kiem_tai_khoan():
    """mỗi giờ hỏi máy chủ tài khoản: bị huỷ -> khoá ngay (giao diện tự chuyển về trang đăng nhập)"""
    while True:
        try: giayphep.gia_han()
        except Exception: traceback.print_exc()
        time.sleep(3600)


DANG_NHAP = """<!DOCTYPE html><html lang="vi"><head><meta charset="utf-8"><title>Javis Studio – Đăng nhập</title>
<style>body{margin:0;height:100vh;display:flex;align-items:center;justify-content:center;font:14px system-ui,Segoe UI,sans-serif;background:radial-gradient(circle at 30% 20%,#17313a,#0b0f13 60%);color:#e6edf3}
.b{width:360px;background:#121820;border:1px solid #233040;border-radius:16px;padding:28px;box-shadow:0 20px 60px rgba(0,0,0,.5)}h1{margin:0;font-size:22px;letter-spacing:.06em}h1 span{color:#3ec6e0}
.mu{color:#8b96a3;font-size:12px}label{display:block;margin:14px 0 5px;color:#aab4c0;font-size:12px}input{width:100%;box-sizing:border-box;background:#0d1217;border:1px solid #2a3542;color:#e6edf3;border-radius:8px;padding:10px;font:inherit}
button{width:100%;margin-top:18px;background:#18b8d8;border:0;color:#04161b;font-weight:700;border-radius:8px;padding:11px;font:inherit;cursor:pointer}#l{color:#ff9b9b;font-size:13px;margin-top:12px;min-height:18px}</style></head>
<body><div class="b"><h1>JAVIS <span>STUDIO</span></h1><div class="mu">TPW GROUP · v__PB__ · cần tài khoản do anh Tan cấp</div>
<label>Máy chủ tài khoản</label><input id="mc" value="__MAYCHU__" placeholder="vd DESKTOP-PMRMUKG hoặc 192.168.1.20">
<label>Tên đăng nhập</label><input id="t" value="__TEN__" autocomplete="username"><label>Mật khẩu</label><input id="m" type="password" autocomplete="current-password">
<button id="g">Đăng nhập</button><div id="l">__LYDO__</div></div>
<script>const T='__TOKEN__';const $=s=>document.querySelector(s);
async function go(){ $('#l').textContent='Đang kiểm tra…'; try{ const r=await fetch('/api/dang-nhap',{method:'POST',headers:{'Content-Type':'application/json','X-Javis-Token':T},body:JSON.stringify({may_chu:$('#mc').value,ten:$('#t').value,mat_khau:$('#m').value})}); const j=await r.json();
 if(j.ok)location.reload(); else $('#l').textContent=j.loi||'Không đăng nhập được.' }catch(e){ $('#l').textContent='Lỗi: '+e } }
$('#g').onclick=go; document.querySelectorAll('input').forEach(i=>i.onkeydown=e=>{if(e.key==='Enter')go()}); ($('#t').value?$('#m'):$('#t')).focus();
setInterval(()=>fetch('/api/song',{method:'POST',headers:{'Content-Type':'application/json','X-Javis-Token':T},body:'{}'}).catch(()=>{}),4000);</script></body></html>"""


def mo_lai():
    """sau khi cập nhật: chạy lại Studio bằng bộ khởi động (không cửa sổ đen) rồi tắt bản này"""
    exe = sys.executable
    if os.name == "nt" and exe.lower().endswith("python.exe") and os.path.isfile(exe[:-10] + "pythonw.exe"): exe = exe[:-10] + "pythonw.exe"
    try: subprocess.Popen([exe, str(GOC / "khoi-dong.pyw")], cwd=str(GOC), creationflags=0x00000008 if os.name == "nt" else 0)   # DETACHED_PROCESS
    except Exception: traceback.print_exc()
    os._exit(0)


def tu_phat_hanh():
    """máy nguồn: mỗi phút xem mã có đổi không -> tự phát hành ra OneDrive cho các máy đã cài"""
    while True:
        try: TT["phat_hanh"] = capnhat.phat_hanh(PHIEN_BAN, doc_cfg())
        except Exception as e: TT["phat_hanh"] = {"ok": False, "loi": f"{type(e).__name__}: {e}"}
        time.sleep(60)


def mo_cua_so(url):
    if sys.platform.startswith("win"):
        edge = [r"%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe", r"%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"]
        chrome = [r"%ProgramFiles%\Google\Chrome\Application\chrome.exe", r"%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe", r"%LocalAppData%\Google\Chrome\Application\chrome.exe"]
        for pth in (chrome + edge if doc_cfg().get("trinh_duyet") == "chrome" else edge + chrome):
            exe = os.path.expandvars(pth)
            if os.path.isfile(exe):
                try: subprocess.Popen([exe, "--app=" + url, "--window-size=1600,980", "--window-position=60,40"]); return
                except Exception: pass
    webbrowser.open(url)


def nap_he_hoc():
    """du-lieu/he-hoc.json: Huân sửa / thêm số cắt hãng ray (vd {"avantech": {"hau": [85,123,171,235], "kiem": true}}) – không cần sửa code"""
    for k, v in (doc_json(DATA / "he-hoc.json", {}) or {}).items():
        if isinstance(v, dict):
            engine.HE_HOC[k] = dict(engine.HE_HOC.get(k) or engine.HE_HOC["tandembox"], **{a: (tuple(b) if a == "hau" else b) for a, b in v.items()})


def main():
    nap_he_hoc()
    for st in (sys.stdout, sys.stderr):
        try: st.reconfigure(encoding="utf-8", errors="replace")
        except Exception: pass
    JOBS.mkdir(parents=True, exist_ok=True)
    if not any(JOBS.glob("*.jvs")) and (GOC / "mau").is_dir():      # lần đầu: chép job mẫu để mở ra là có cái xem
        import shutil
        for f in (GOC / "mau").glob("*.jvs"): shutil.copy2(f, JOBS / f.name)
        ghi_json(DATA / "gan-nhat.json", {"ten": "00 BEP MAU 3M6 (thu)"})
    if "--khong-cap-nhat" not in sys.argv and not capnhat.la_nguon():   # máy thợ: tự lấy bản mới trên GitHub khi mở
        try:
            banquyen.kiem_mang(cho=True)
            if banquyen.co_ban_moi(PHIEN_BAN):
                ok, kq = banquyen.cap_nhat(PHIEN_BAN)
                if ok: print(f"Đã cập nhật lên {kq}, mở lại..."); banquyen.khoi_dong_lai(); time.sleep(5); return
        except Exception: traceback.print_exc()

    def _dinh_ky():
        while True:
            time.sleep(6 * 3600)
            try: banquyen.kiem_mang()
            except Exception: pass
    threading.Thread(target=_dinh_ky, daemon=True).start()
    cfg = doc_cfg(); cong = int(os.environ.get("VETU_PORT") or cfg.get("cong", 8770))
    cu = doc_json(DATA / "phien.json", {})
    if cu.get("token"):     # chỉ cho 1 bản chạy: nhờ bản cũ tự tắt
        try:
            rq = urllib.request.Request(f"http://127.0.0.1:{cu.get('cong', cong)}/api/thoat", b"{}", {"X-Javis-Token": cu["token"], "Content-Type": "application/json"})
            urllib.request.urlopen(rq, timeout=2).read(); time.sleep(0.8)
        except Exception: pass
    srv = None
    for _ in range(12):
        try: srv = ThreadingHTTPServer(("127.0.0.1", cong), H); break
        except OSError: time.sleep(0.5)
    if srv is None:
        print(f"Cổng {cong} đang bị chương trình khác dùng."); sys.exit(1)
    ghi_json(DATA / "phien.json", {"pid": os.getpid(), "cong": cong, "token": TOKEN})
    url = f"http://127.0.0.1:{cong}/"
    print(f"JAVIS STUDIO {PHIEN_BAN} đang chạy: {url}\nFile cắt xuất ra: {cfg['thu_muc_xuat']}\nĐóng cửa sổ này để tắt.")
    if "--no-browser" not in sys.argv:
        threading.Timer(6.0, lambda: None if time.time() - TT["ui"] < 8 else mo_cua_so(url)).start()
    if capnhat.la_nguon(): threading.Thread(target=tu_phat_hanh, daemon=True).start()
    threading.Thread(target=kiem_tai_khoan, daemon=True).start()
    try: srv.serve_forever()
    except KeyboardInterrupt: pass


if __name__ == "__main__":
    main()
