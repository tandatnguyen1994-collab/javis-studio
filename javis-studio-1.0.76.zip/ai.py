"""Javis Studio – AI RIÊNG của Studio (không dính Javis Local trừ khi anh chọn "dùng chung").
Nguồn:  ollama  – mô hình chạy trên máy (Ollama), chọn mô hình nào cũng được
        claude  – Claude API (cần API key của Anthropic)
        openai  – OpenAI hoặc mọi API kiểu OpenAI (OpenRouter, Groq, Gemini…): địa chỉ + key + tên mô hình
        chung   – dùng chung mô hình với Javis Local (C:\\Javis\\du-lieu\\cau-hinh.json)
        tat     – tắt ô "Nói với Javis"
Cấu hình nằm trong du-lieu\\cau-hinh.json (khoá "ai") – bản cập nhật không đụng tới."""
import json, urllib.request, urllib.error
from pathlib import Path

GOC = Path(__file__).resolve().parent
MAC_DINH = dict(nguon="ollama", ollama_url="http://127.0.0.1:11434", ollama_model="", claude_key="", claude_model="claude-sonnet-5-5",
                openai_url="https://api.openai.com/v1", openai_key="", openai_model="gpt-4o-mini")
NHAN = {"ollama": "Ollama – mô hình trên máy", "claude": "Claude API (Anthropic)", "openai": "OpenAI / API kiểu OpenAI", "chung": "Dùng chung với Javis Local", "tat": "Tắt AI"}


def cau_hinh(cfg):
    a = dict(MAC_DINH); a.update((cfg or {}).get("ai") or {})
    if not (cfg or {}).get("ai") and (cfg or {}).get("mo_hinh"): a["ollama_model"] = cfg["mo_hinh"]     # cấu hình cũ (0.9.0 trở về trước)
    return a


def che(a):
    """bản gửi lên giao diện: không lộ key"""
    b = dict(a)
    for k in ("claude_key", "openai_key"):
        v = b.get(k) or ""; b[k] = ("••••" + v[-4:]) if v else ""; b[k + "_co"] = bool(v)
    return b


def _javis_local():
    c = {}
    for f in (GOC.parent / "du-lieu" / "cau-hinh.json", Path("C:/Javis/du-lieu/cau-hinh.json")):
        try: c = json.loads(f.read_text(encoding="utf-8")); break
        except Exception: pass
    nao = str(c.get("nao") or "")
    return nao.split("local:", 1)[1] if nao.startswith("local:") else ""


def ds_ollama(url):
    try:
        d = json.loads(urllib.request.urlopen(url.rstrip("/") + "/api/tags", timeout=4).read())
        return sorted(m.get("name") for m in d.get("models", []) if m.get("name"))
    except Exception:
        return []


def _post(url, body, headers, timeout=180):
    rq = urllib.request.Request(url, json.dumps(body).encode(), dict({"Content-Type": "application/json"}, **headers))
    try: return json.loads(urllib.request.urlopen(rq, timeout=timeout).read())
    except urllib.error.HTTPError as e:
        try: msg = json.loads(e.read()).get("error")
        except Exception: msg = None
        if isinstance(msg, dict): msg = msg.get("message")
        raise RuntimeError(f"HTTP {e.code}: {msg or e.reason}")


def mo_ta(a):
    n = a.get("nguon")
    if n == "ollama": return f"Ollama · {a.get('ollama_model') or 'chưa chọn mô hình'}"
    if n == "claude": return f"Claude API · {a.get('claude_model')}"
    if n == "openai": return f"{a.get('openai_url')} · {a.get('openai_model')}"
    if n == "chung": return f"Chung Javis Local · {_javis_local() or 'chưa có'}"
    return "Tắt"


def hoi(a, he_thong, user, json_out=True, toi_da=1500, pdf=None):
    """gọi AI đã chọn -> chuỗi trả lời"""
    n = a.get("nguon", "ollama")
    if n == "tat": raise RuntimeError("AI đang tắt – bật trong Cài đặt › AI cho Studio.")
    if n in ("ollama", "chung"):
        model = _javis_local() if n == "chung" else a.get("ollama_model")
        if not model:
            ds = ds_ollama(a["ollama_url"]); model = ds[0] if ds else ""
        if not model: raise RuntimeError("Chưa có mô hình Ollama nào trên máy – cài Ollama + tải 1 mô hình, hoặc chọn Claude / OpenAI trong Cài đặt.")
        m = [{"role": "system", "content": he_thong}, {"role": "user", "content": user}]
        if any(k in model.lower() for k in ("qwen", "deepseek")): m.append({"role": "assistant", "content": "<think>\n\n</think>\n\n"})
        body = {"model": model, "messages": m, "stream": False, "keep_alive": "30m", "think": False, "options": {"num_ctx": 8192, "temperature": 0.1, "num_predict": toi_da}}
        if json_out: body["format"] = "json"
        try: d = _post(a["ollama_url"].rstrip("/") + "/api/chat", body, {})
        except RuntimeError:
            body.pop("think", None); d = _post(a["ollama_url"].rstrip("/") + "/api/chat", body, {})
        return (d.get("message") or {}).get("content", "")
    if n == "claude":
        if not a.get("claude_key"): raise RuntimeError("Chưa nhập Claude API key (Cài đặt › AI cho Studio).")
        body = {"model": a.get("claude_model") or MAC_DINH["claude_model"], "max_tokens": toi_da, "temperature": 0.1, "system": he_thong + ("\nChỉ trả về 1 đối tượng JSON, không viết gì khác." if json_out else ""),
                "messages": [{"role": "user", "content": ([{"type": "document", "source": {"type": "base64", "media_type": "application/pdf", "data": pdf}}] if pdf else []) + [{"type": "text", "text": user}]}]}
        d = _post("https://api.anthropic.com/v1/messages", body, {"x-api-key": a["claude_key"], "anthropic-version": "2023-06-01"}, timeout=300 if pdf else 120)
        return "".join(c.get("text", "") for c in d.get("content", []) if c.get("type") == "text")
    if n == "openai":
        if not a.get("openai_key"): raise RuntimeError("Chưa nhập API key (Cài đặt › AI cho Studio).")
        body = {"model": a.get("openai_model"), "temperature": 0.1, "max_tokens": toi_da, "messages": [{"role": "system", "content": he_thong}, {"role": "user", "content": user}]}
        if json_out: body["response_format"] = {"type": "json_object"}
        d = _post(a["openai_url"].rstrip("/") + "/chat/completions", body, {"Authorization": "Bearer " + a["openai_key"]}, timeout=120)
        return ((d.get("choices") or [{}])[0].get("message") or {}).get("content", "")
    raise RuntimeError(f"Nguồn AI lạ: {n}")
