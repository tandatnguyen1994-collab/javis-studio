"""Javis Studio – GIẤY PHÉP / TÀI KHOẢN (phía máy dùng).
- Đăng nhập bằng tài khoản anh Tan cấp trên MÁY CHỦ TÀI KHOẢN (thư mục may-chu, chạy trên máy của anh Tan).
- Máy chủ trả "giấy phép" KÝ SỐ (Ed25519) gắn với tên tài khoản + mã máy, hạn 1 ngày. Studio kiểm chữ ký bằng khoá công khai
  (khoa-cong-khai.pem) -> không tự làm / sửa giấy phép được.
- Mỗi lần mở + mỗi giờ: hỏi máy chủ gia hạn. Tài khoản bị huỷ -> khoá ngay. Mất mạng -> dùng tiếp tới hết hạn giấy phép (1 ngày).
- Máy chủ (có khoá riêng khớp khoá công khai) thì không cần đăng nhập."""
import os, sys, json, time, base64, hashlib, socket, getpass, urllib.request, urllib.error
from pathlib import Path

GOC = Path(__file__).resolve().parent
TT_FILE = GOC / "du-lieu" / "giay-phep.json"
PUB_FILE = GOC / "khoa-cong-khai.pem"
CONG_MAC_DINH = 8790
TT = {"ly_do": "", "kiem_luc": 0}


def _crypto():
    try:
        from cryptography.hazmat.primitives import serialization
        from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey  # noqa
        return serialization
    except ImportError:
        return None


def ma_may():
    """mã máy ổn định: MachineGuid của Windows + tên người dùng"""
    g = ""
    if os.name == "nt":
        try:
            import winreg
            k = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Cryptography", 0, winreg.KEY_READ | 0x0100)
            g = winreg.QueryValueEx(k, "MachineGuid")[0]
        except OSError: pass
    if not g:
        for f in ("/etc/machine-id", "/var/lib/dbus/machine-id"):
            try: g = Path(f).read_text().strip(); break
            except OSError: pass
    return hashlib.sha256(f"{g}|{getpass.getuser()}|javis-studio".encode()).hexdigest()[:24]


def _doc():
    try: return json.loads(TT_FILE.read_text(encoding="utf-8"))
    except Exception: return {}


def _ghi(d):
    TT_FILE.parent.mkdir(parents=True, exist_ok=True); t = TT_FILE.with_suffix(".tmp")
    t.write_text(json.dumps(d, ensure_ascii=False), encoding="utf-8"); os.replace(t, TT_FILE)


def _pub():
    ser = _crypto()
    if not ser or not PUB_FILE.is_file(): return None
    try: return ser.load_pem_public_key(PUB_FILE.read_bytes())
    except Exception: return None


def la_may_chu():
    """máy chạy máy chủ tài khoản: có khoá riêng KHỚP khoá công khai -> chủ phần mềm, không cần đăng nhập"""
    ser = _crypto(); pub = _pub(); f = GOC / "may-chu" / "du-lieu" / "khoa-rieng.pem"
    if not ser or not pub or not f.is_file(): return False
    try:
        k = ser.load_pem_private_key(f.read_bytes(), password=None); m = os.urandom(16)
        pub.verify(k.sign(m), m); return True
    except Exception: return False


def doc_giay(gp):
    """kiểm chữ ký -> dict nội dung, hoặc None"""
    pub = _pub()
    if not pub or not gp or "." not in gp: return None
    a, b = gp.split(".", 1)
    try:
        noi = base64.urlsafe_b64decode(a + "=="); pub.verify(base64.urlsafe_b64decode(b + "=="), noi)
        return json.loads(noi)
    except Exception: return None


def hop_le():
    """True nếu được dùng ngay bây giờ (không gọi mạng)"""
    if la_may_chu(): TT["ly_do"] = ""; return True
    if not _crypto(): TT["ly_do"] = "Thiếu thư viện bảo mật (cryptography) – chạy lại file cài đặt."; return False
    if not _pub():
        TT["ly_do"] = ("Máy nguồn: chạy may-chu\\CAI-MAY-CHU-TAI-KHOAN.bat một lần để tạo máy chủ tài khoản." if (GOC / ".nguon").is_file()
                       else "Chưa có khoá máy chủ tài khoản (khoa-cong-khai.pem) – bấm cập nhật Studio hoặc hỏi anh Tan."); return False
    s = _doc(); g = doc_giay(s.get("giay_phep"))
    if not g: TT["ly_do"] = s.get("ly_do") or "Chưa đăng nhập."; return False
    if g.get("may") != ma_may(): TT["ly_do"] = "Giấy phép không phải của máy này – đăng nhập lại."; return False
    if float(g.get("het_han", 0)) < time.time(): TT["ly_do"] = "Quá 1 ngày chưa kết nối được máy chủ tài khoản – kết nối mạng rồi đăng nhập lại."; return False
    TT["ly_do"] = ""; return True


def thong_tin():
    s = _doc(); g = doc_giay(s.get("giay_phep")) or {}
    return dict(may_chu=s.get("may_chu", ""), ten=g.get("ten") or s.get("ten", ""), ho_ten=g.get("ho_ten", ""), het_han=g.get("het_han"),
                tk_het_han=g.get("tk_het_han", ""), chu=la_may_chu(), ly_do=TT["ly_do"], ma_may=ma_may())


def _post(may_chu, duong, d, timeout=8):
    url = may_chu if may_chu.startswith("http") else "http://" + may_chu
    if ":" not in url.split("//", 1)[1]: url += f":{CONG_MAC_DINH}"
    rq = urllib.request.Request(url.rstrip("/") + duong, json.dumps(d).encode(), {"Content-Type": "application/json"})
    try: return json.loads(urllib.request.urlopen(rq, timeout=timeout).read())
    except urllib.error.HTTPError as e:
        try: return json.loads(e.read())
        except Exception: return {"loi": f"Máy chủ báo lỗi {e.code}"}


def dang_nhap(may_chu, ten, mat_khau):
    may_chu = (may_chu or "").strip() or _doc().get("may_chu", "")
    if not may_chu: return {"loi": "Nhập địa chỉ máy chủ tài khoản (anh Tan đưa)."}
    try: r = _post(may_chu, "/dang-nhap", dict(ten=ten.strip(), mat_khau=mat_khau, may=ma_may(), ten_may=socket.gethostname()))
    except Exception as e: return {"loi": f"Không kết nối được máy chủ tài khoản {may_chu} ({type(e).__name__}). Kiểm mạng / địa chỉ."}
    if r.get("loi"): return r
    if not doc_giay(r.get("giay_phep")): return {"loi": "Giấy phép máy chủ trả về không hợp lệ (khoá không khớp) – cập nhật Studio."}
    _ghi(dict(may_chu=may_chu, ten=ten.strip(), phien=r.get("phien"), giay_phep=r["giay_phep"])); hop_le()
    return {"ok": 1}


def gia_han():
    """hỏi máy chủ: còn được dùng không. Trả 'ok' / 'huy' / 'mat_mang'"""
    if la_may_chu(): return "ok"
    s = _doc()
    if not s.get("phien"): return "huy"
    try: r = _post(s["may_chu"], "/gia-han", dict(ten=s.get("ten"), may=ma_may(), phien=s.get("phien")))
    except Exception: TT["kiem_luc"] = time.time(); return "mat_mang"
    TT["kiem_luc"] = time.time()
    if r.get("huy") or r.get("loi"):
        TT["ly_do"] = r.get("loi") or "Tài khoản đã bị huỷ."; _ghi(dict(may_chu=s.get("may_chu", ""), ten=s.get("ten", ""), ly_do=TT["ly_do"])); return "huy"
    if doc_giay(r.get("giay_phep")): s["giay_phep"] = r["giay_phep"]; _ghi(s)
    hop_le(); return "ok"


def dang_xuat():
    s = _doc()
    try:
        if s.get("phien"): _post(s["may_chu"], "/dang-xuat", dict(ten=s.get("ten"), may=ma_may(), phien=s.get("phien")), timeout=3)
    except Exception: pass
    _ghi(dict(may_chu=s.get("may_chu", ""), ten=s.get("ten", ""))); hop_le()
