"""Javis Studio – TRA SPEC THIẾT BỊ theo mã model (anh Tan 21/11: "bỏ model phụ kiện vào tự tìm kiếm để lấy spec cho đúng").
Thứ tự: (1) bộ nhớ đã tra (du-lieu/spec-may.json) và bảng có sẵn trong Studio  (2) Claude API + web search (nếu AI = Claude)
(3) tự tìm trên mạng (DuckDuckGo) + đọc trang hãng rồi nhờ AI đang chọn (Ollama / OpenAI…) rút số.
Kết quả luôn kèm link nguồn để anh / Huân kiểm trước khi áp vào tủ – Studio KHÔNG tự đổi kích thước khi chưa bấm "Áp vào tủ"."""
import json, re, html, time, urllib.request, urllib.parse
from pathlib import Path
import ai, engine

GOC = Path(__file__).resolve().parent
KHO = GOC / "du-lieu" / "spec-may.json"
TRUONG = ("hang", "ten", "loai_may", "rong", "cao", "sau", "hoc_rong_min", "hoc_cao", "hoc_sau_min", "khoet_rong", "khoet_sau", "panel_cao_min", "panel_cao_max", "panel_day_max", "panel_nang_max", "ghi")
HUONG_DAN = """Bạn tra THÔNG SỐ LẮP ĐẶT của 1 thiết bị bếp / phụ kiện tủ (thị trường Úc) theo mã model. Ưu tiên trang hãng hoặc
"installation instructions" / "dimensions" PDF. Trả về DUY NHẤT 1 JSON:
{"hang":"Bosch","ten":"tên đầy đủ","loai_may":"oven|microwave|combi|cooktop|cooktop_gas|rangehood|dishwasher|fridge|sink|other",
 "rong":595,"cao":595,"sau":548,              (kích thước máy, mm)
 "hoc_rong_min":560,"hoc_cao":600,"hoc_sau_min":550,   (hộc / niche cần chừa trong tủ, mm – bỏ trống nếu không có)
 "khoet_rong":0,"khoet_sau":0,               (lỗ khoét: bếp từ / hút mùi âm / chậu, mm)
 "ghi":"ghi chú lắp đặt quan trọng: thông gió, khe hở, cửa door-on-door…","nguon":["url",...],"chac":true|false}
Số nào không tìm thấy thì để null – KHÔNG đoán. "chac" = false nếu không chắc đúng model."""


def chuan(ma):
    return re.sub(r"[^0-9A-Z]", "", str(ma or "").upper())


def _kho():
    try: return json.loads(KHO.read_text(encoding="utf-8"))
    except Exception: return {}


def luu(ma, spec):
    d = _kho(); d[chuan(ma)] = dict(spec, _luu=time.strftime("%Y-%m-%d %H:%M"))
    KHO.parent.mkdir(parents=True, exist_ok=True); KHO.write_text(json.dumps(d, ensure_ascii=False, indent=1), encoding="utf-8")


def _so(v):
    try:
        f = float(str(v).replace(",", ".").strip())
        return round(f, 1) if 0 < f < 5000 else None
    except (TypeError, ValueError): return None


def lam_sach(d):
    """giữ đúng các trường, số là mm hợp lý"""
    o = {k: d.get(k) for k in TRUONG}
    for k in ("rong", "cao", "sau", "hoc_rong_min", "hoc_cao", "hoc_sau_min", "khoet_rong", "khoet_sau", "panel_cao_min", "panel_cao_max", "panel_day_max", "panel_nang_max"): o[k] = _so(o[k])
    for k in ("hang", "ten", "loai_may", "ghi"): o[k] = str(o[k] or "")[:400]
    o["nguon"] = [str(u)[:300] for u in (d.get("nguon") or []) if str(u).startswith("http")][:6]
    o["chac"] = bool(d.get("chac")) and bool(o["nguon"])
    return o


def _json(txt):
    i, j = txt.find("{"), txt.rfind("}")
    if i < 0 or j <= i: raise RuntimeError("AI không trả JSON")
    return json.loads(txt[i:j + 1])


# THIẾT BỊ CÓ SẴN (tra tài liệu hãng 21/11 03:30) – Tra spec chạy được không cần mạng. Chỉ ghi số có nguồn.
_BOSCH60 = dict(hang="Bosch", loai_may="oven", rong=594, cao=595, sau=548, hoc_rong_min=560, hoc_cao=585, hoc_sau_min=550,
                ghi="Hộc lắp (cao × rộng × sâu): 585–595 × 560–568 × 550", nguon=["https://media3.bosch-home.com/Documents/specsheet/en-AU/HBG633BB1B.pdf"])
_FP60 = dict(hang="Fisher & Paykel", loai_may="oven", rong=596, cao=598, sau=565, hoc_rong_min=560, hoc_cao=580, hoc_sau_min=550,
             ghi="Hộc tối thiểu cao 580 (từ đáy) × rộng 560 × sâu 550 (data sheet F&P lò 60cm)",
             nguon=["https://www.fisherpaykel.com/on/demandware.static/-/Sites-fpa-master-catalog/default/dw3469cac8/DesignPlanning-FisherPaykelNZ/FP-DataSheet-OB60SD11PB1-Oven-ASIA-AU-NZ-SG-90001796A.pdf"])
THIET_BI_SAN = {
    **{m: dict(_BOSCH60, ten=f"Bosch Serie 8 {m} lò 60cm") for m in ("HBG633BS1A", "HBG634BS1", "HBG633BB1B", "HBG634BB1B", "HBG633BS1B", "HRG635BS1B")},
    **{m: dict(_FP60, ten=f"Fisher & Paykel {m} lò 60cm") for m in ("OB60SD7PX1", "OB60SD9PX1", "OB60SD10PX1", "OB60SD11PX1", "OB60SD11PB1", "OB60SC7CEX2", "OB60SC7LEX1")},
    "OB60NC9DEX1": dict(_FP60, ten="Fisher & Paykel OB60NC9DEX1 lò compact 45cm", cao=458, hoc_cao=440, ghi="Hộc tối thiểu cao 440 × rộng 560 × sâu 550",
                        nguon=["https://www.fisherpaykel.com/on/demandware.static/-/Sites-fpa-master-catalog/default/dwc48cf441/DesignPlanning-FisherPaykelNZ/FP-DataSheet-OB60NC9DEX1-Oven-NZ-90001661A.pdf"]),
    # tủ lạnh âm (integrated) – hộc lọt lòng
    **{m: dict(hang="Fisher & Paykel", ten=f"Fisher & Paykel {m} cột 61cm (integrated column)", loai_may="fridge", rong=603, cao=2134, sau=610,
               hoc_rong_min=610, hoc_cao=2134, hoc_sau_min=635, ghi="Hộc cao 2134 × rộng 610, sâu tối thiểu 635 (dịch vụ điện nước ngoài hộc); panel cửa dày 16–25, khe 3 tới tủ bên",
               nguon=["https://media.architectureau.com/media/files/FP-DataSheet-RS6121FRJK1-IntegratedColumnFreezer-AU-90001312A.pdf"])
       for m in ("RS6121SRK1", "RS6121SLK1", "RS6121FRJK1", "RS6121FLJK1")},
    **{m: dict(hang="Bosch", ten=f"Bosch {m} tủ lạnh âm 177", loai_may="fridge", rong=558, cao=1772, sau=545, hoc_rong_min=560, hoc_cao=1775, hoc_sau_min=550,
               ghi="Hộc lắp 1775 × 560 × 550 (flat hinge – cửa tủ gắn trực tiếp cánh)", nguon=["https://media3.bosch-home.com/Documents/specsheet/en-ZA/KIR81AFE0.pdf"])
       for m in ("KIR81AFE0", "KIR81AF30", "KIF81PFE0")},
    "RB60V18": dict(hang="Fisher & Paykel", ten="Fisher & Paykel RB60V18 tủ lạnh + đông âm 60cm", loai_may="fridge", rong=555, cao=1773, sau=544,
                    hoc_rong_min=564, hoc_cao=1782, hoc_sau_min=550, ghi="Hộc 1782–1786 cao × 564–570 rộng × sâu ≥ 550 (số từ trang nhà bán lẻ John Lewis – kiểm hướng dẫn lắp F&P)",
                    nguon=["https://www.johnlewis.com/fisher-paykel-rb60v18-integrated-60-40-fridge-freezer/p1727470"]),
    # máy rửa chén âm (integrated) – hộc + tấm cửa cùng màu cánh
    **{m: dict(hang="Fisher & Paykel", ten=f"Fisher & Paykel {m} máy rửa chén âm 60cm", loai_may="dishwasher", rong=598, cao=820, sau=552,
               hoc_rong_min=600, hoc_cao=820, hoc_sau_min=560, panel_cao_min=665, panel_cao_max=717, panel_day_max=19, panel_nang_max=8,
               ghi="Máy cao 820–880; tấm cửa cao 665–717 × rộng 596–605 × dày 16–19, nặng 4–8 kg; chân 100–212 dưới tấm cửa",
               nguon=["https://www.fisherpaykel.com/on/demandware.static/-/Sites-fpa-master-catalog/default/dw7bf0b1d5/DesignPlanning-FisherPaykelAU/FP-DataSheet-DW60U6I1-IntegratedDishwasher-AU-NZ-90001569A.pdf"])
       for m in ("DW60U6I1", "DW60U2I1")},
    **{m: dict(hang="Fisher & Paykel", ten=f"Fisher & Paykel {m} máy rửa chén âm 60cm", loai_may="dishwasher", rong=597, cao=820, sau=554,
               hoc_rong_min=600, hoc_cao=820, hoc_sau_min=580, panel_cao_min=677,
               ghi="Hộc tối thiểu cao 820 × rộng 600 × sâu 580; tấm cửa cao tối thiểu 677",
               nguon=["https://fisherpaykel.com/on/demandware.static/-/Sites-fpa-master-catalog/default/dwde051198/DesignPlanning-FisherPaykelSG/FP-DataSheet-en-DW60U4I2-DW60U4HI2-IntegratedDishwasher-0-90002306B-AU-NZ-UK-IE-CN.pdf"])
       for m in ("DW60U4I2", "DW60U4HI2")},
    **{m: dict(hang="Bosch", ten=f"Bosch Series 6 {m} máy rửa chén âm hoàn toàn 60cm", loai_may="dishwasher", rong=598, cao=815, sau=550,
               hoc_rong_min=600, hoc_cao=815, hoc_sau_min=550, panel_nang_max=8.5 if m.startswith("SMD") else None,
               ghi="Hộc 815–875 cao × 600 rộng × 550 sâu" + (" ; tấm cửa nặng 2.5–8.5 kg" if m.startswith("SMD") else ""),
               nguon=["https://media3.bosch-home.com/Documents/specsheet/en-IE/SMV6ZCX01G.pdf" if m.startswith("SMV") else "https://www.bosch-home.ie/en/mkt-product/dishwashers/built-in-dishwashers/bifulldishwashers60width/SMD6ZCX61G"])
       for m in ("SMV6ZCX01G", "SMV6ZCX10G", "SMD6ZCX60G", "SMD6ZCX61G")},
    # BẾP (cooktop): lỗ khoét mặt đá – số theo tài liệu lắp đặt hãng (khoet_rong × khoet_sau)
    **{m: dict(hang="Westinghouse", ten=f"Westinghouse {m} bếp từ 60cm", loai_may="cooktop", khoet_rong=560, khoet_sau=490,
               ghi="Lỗ khoét 560×490 (dung sai +1, góc R5) theo hướng dẫn lắp đặt Westinghouse bếp từ 60cm",
               nguon=[{"BC": "https://resource.electrolux.com.au/Public/File/?Id=46321", "BD": "https://resource.electrolux.com.au/Public/File/?Id=58421", "BE": "https://resource.electrolux.com.au/Public/File/?Id=62718"}[m[-2:]]])
       for m in ("WHI633BC", "WHI643BC", "WHI645BC", "WHI743BC", "WHI635BD", "WHI643BD", "WHI645BD", "WHI642BE", "WHI632BE")},
    **{m: dict(hang="Westinghouse", ten=f"Westinghouse {m} bếp từ 90cm", loai_may="cooktop", khoet_rong=880, khoet_sau=490,
               ghi="Lỗ khoét 880×490 (dung sai +1, góc R5) theo hướng dẫn lắp đặt Westinghouse bếp từ 90cm",
               nguon=["https://resource.electrolux.com.au/Public/File/?Id=46321" if m.endswith("BC") else "https://www.bettaelectrical.co.nz/content/WHI943BD-instal-WHS_DIM_AspireRange_Cooktops_90_Apr23.pdf"])
       for m in ("WHI943BC", "WHI945BC", "WHI943BD", "WHI955BD")},
    **{m: dict(hang="Bosch", ten=f"Bosch {m} bếp từ 60cm", loai_may="cooktop", khoet_rong=560, khoet_sau=490,
               ghi="Lỗ khoét 560 × 490–500; mặt đá dày tối thiểu 16" + ("" if m in ("PIE631BB5E", "PID631BB5E", "PUE611BB5E") else " – CHƯA CÓ LINK GỐC cho mã này, cần kiểm"),
               nguon=[{"PIE631BB5E": "https://media3.bsh-group.com/Documents/specsheet/en-GB/PIE631BB5E.pdf", "PID631BB5E": "https://media3.bsh-group.com/Documents/specsheet/en-SG/PID631BB5E.pdf",
                       "PUE611BB5E": "https://media3.bosch-home.com/Documents/specsheet/en-AU/PUE611BB5E.pdf"}.get(m, "")])
       for m in ("PIE631BB5E", "PID631BB5E", "PUE611BB5E", "PIE631HB1E", "PIE631FB1E")},
    "CI764DTB4": dict(hang="Fisher & Paykel", ten="Fisher & Paykel CI764DTB4 bếp từ 70cm", loai_may="cooktop", khoet_rong=725, khoet_sau=490,
                      ghi="Lỗ khoét 725×490 – CHƯA CÓ LINK GỐC, cần Huân kiểm; lỗ KHÔNG nằm giữa chiều sâu mặt bếp",
                      nguon=[]),
    "CI905DTB4": dict(hang="Fisher & Paykel", ten="Fisher & Paykel CI905DTB4 bếp từ 90cm", loai_may="cooktop", khoet_rong=870, khoet_sau=494,
                      ghi="Lỗ khoét 870×494 – giữa theo chiều rộng, LỆCH theo chiều sâu (bản DTB3: mép trước lỗ cách mép trước mặt bếp 8 mm) – xem bản vẽ lắp đặt",
                      nguon=["https://www.fisherpaykel.com/on/demandware.static/-/Sites-fpa-master-catalog/default/dw3d859993/DesignPlanning-FisherPaykelIE/FP-DataSheet-en-CI905DTB4-InductionCooktop-90002226B-AS-AU-CN-IE-NZ-SG-UK.pdf"]),
    **{m: dict(hang="Fisher & Paykel", ten=f"Fisher & Paykel {m} bếp từ 90cm", loai_may="cooktop", khoet_rong=850, khoet_sau=490,
               ghi="Lỗ khoét tối thiểu 850×490",
               nguon=["https://www.fisherpaykel.com/on/demandware.static/-/Sites-fpa-master-catalog/default/dw8fc4583a/InstallationManuals-FisherPaykelAU/FP-InstallSheet-en-CI905ZZDT-CI905ZDTB-CI804ZZDT-CI804ZDTB5-CI604ZZDT-CI604ZDT-CI302ZDTB5-0-433436A-NZ-AU-UK-IE-SG.pdf"])
       for m in ("CI905ZDTB5", "CI905ZZDTB5")},
    "CI804ZDTB5": dict(hang="Fisher & Paykel", ten="Fisher & Paykel CI804ZDTB5 bếp từ 80cm", loai_may="cooktop", khoet_rong=720, khoet_sau=490,
                       ghi="Lỗ khoét 720×490; khoang dưới mặt đá cao tối thiểu 65",
                       nguon=["https://www.fisherpaykel.com/on/demandware.static/-/Sites-fpa-master-catalog/default/dw8fc4583a/InstallationManuals-FisherPaykelAU/FP-InstallSheet-en-CI905ZZDT-CI905ZDTB-CI804ZZDT-CI804ZDTB5-CI604ZZDT-CI604ZDT-CI302ZDTB5-0-433436A-NZ-AU-UK-IE-SG.pdf"]),
    # CHẬU RỬA (sink): lỗ khoét mặt đá + rộng tủ chậu tối thiểu (hoc_rong_min = rộng NGOÀI tủ chậu, theo "Min Cabinet Size" của hãng)
    "SN1063U": dict(hang="Oliveri", ten="Oliveri Sonetto SN1063U chậu đôi âm (undermount)", loai_may="sink", rong=785, sau=455, cao=205, khoet_rong=736, khoet_sau=406,
                    ghi="Khoét theo template 736 × 406, góc R25 (chậu âm – thợ đá đo chậu thật trước khi cắt)",
                    nguon=["https://www.winnings.com.au/manuals/ak/8/7/4/2/874222a591125301972cb99a3de13b46457413fd_sn1063u_productsheet.pdf"]),
    "SN1050U": dict(hang="Oliveri", ten="Oliveri Sonetto SN1050U chậu đơn âm", loai_may="sink", rong=520, sau=455, cao=205, hoc_rong_min=600,
                    ghi="Tủ chậu tối thiểu 600; lỗ khoét lấy theo template hãng (chưa có số khoét sâu)",
                    nguon=["https://www.winnings.com.au/manuals/ak/3/9/1/b/391b53112fec3c4266696a02d26bdaf6c5d46be2_Oliveri_SN1050U_Sonetto_Undermount_Sink_Specifications_Sheet.pdf"]),
    **{m: dict(hang="Oliveri", ten=f"Oliveri Sonetto {m} chậu đôi có bàn ráo (lắp nổi)", loai_may="sink", rong=1300, sau=510, khoet_rong=1284, khoet_sau=494, hoc_rong_min=800,
               ghi="Lắp nổi (inset): khoét 1284 × 494 góc R10; tủ chậu tối thiểu 800",
               nguon=["https://www.appliancesonline.com.au/ak/4/1/7/c/417c33ca1984ceea221de6b3be50fa071ea775fe_Oliveri_Sonetto_Sink_SN1071_Specifications_Sheet.pdf"])
       for m in ("SN1071", "SN1072")},
    **{m: dict(hang="Oliveri", ten=f"Oliveri Sonetto {m} chậu 1¾ có bàn ráo (lắp nổi)", loai_may="sink", rong=1415, sau=510, khoet_rong=1399, khoet_sau=494, hoc_rong_min=900,
               ghi="Lắp nổi (inset): khoét 1399 × 494 góc R10; tủ chậu tối thiểu 900",
               nguon=["https://manualmachine.com/oliveri/sn1011/4586266-specifications-sheet"])
       for m in ("SN1011", "SN1012")},
    "LUA190": dict(hang="Abey", ten="Abey Lucia LUA190 chậu 1⅓ (nổi / âm / lọt)", loai_may="sink", rong=608, sau=440, cao=200, khoet_rong=565, khoet_sau=400, hoc_rong_min=700,
                   ghi="Khoét 565 × 400 (số nhà bán lẻ in từ hãng – thợ đá đo chậu thật); tủ chậu tối thiểu 700 (bản LUA190T14)",
                   nguon=["https://www.winnings.com.au/p/abey-lucia-1-and-13-bowl-sink-lua190", "https://cdn.shopify.com/s/files/1/0633/0931/6345/files/LUA190T14.pdf"]),
    "BCX120/220-38/38": dict(hang="Franke", ten="Franke Bell BCX120/220-38/38 chậu đôi", loai_may="sink", rong=840, sau=460, cao=180, khoet_rong=825, khoet_sau=445, hoc_rong_min=900,
                             ghi="Khoét lắp nổi 825 × 445; âm / lọt theo template hãng; tủ chậu 900",
                             nguon=["https://www.franke.com/au/en/home-solutions/products/all-products/product-detail-page.html/127.0681.034.html"]),
    "BWX120-41/27": dict(hang="Franke", ten="Franke Bow Centre BWX120-41/27 chậu 1½ âm", loai_may="sink", khoet_rong=780, khoet_sau=490, hoc_rong_min=900,
                         ghi="Khoét 780 × 490; tủ chậu tối thiểu 900",
                         nguon=["https://franke.com/content/dam/franke/au/en/home-solutions/spec-sheets/reece/BOW%20CENTRE%20BWX%20120-41-27%20(with%20accessories).pdf.coredownload.pdf"]),
    "KBX120-34OFB": dict(hang="Franke", ten="Franke Kubus KBX120-34OFB chậu đôi âm", loai_may="sink", rong=770, sau=450, cao=200, hoc_rong_min=800,
                         ghi="Tủ chậu 800; lỗ khoét theo template hãng (bản spec không in số)",
                         nguon=["https://www.appliancesonline.com.au/ak/f/6/8/a/f68a1e761cf145b9d9f069e3d12bbc54a1ab45df_KBX120_34OFB_Franke_Specifications_Sheet.pdf"]),
    # BẾP GAS (cooktop_gas): Studio tự kiểm khoảng cách hút mùi / tủ treo theo AS/NZS 5601.1:2022
    "WHG644SC": dict(hang="Westinghouse", ten="Westinghouse WHG644SC bếp gas 60cm 4 lò", loai_may="cooktop_gas", rong=595, sau=530, cao=55, khoet_rong=560, khoet_sau=490,
                     ghi="Lỗ khoét 560 × 490", nguon=["https://www.homeclearance.com.au/manuals/ak/9/d/a/0/9da0f5b28c338d4b0b7a9a54ef04c52e896c10c1_Westinghouse_WHG644SC_Factsheet_Updated082026.pdf"]),
    "WHG958SC": dict(hang="Westinghouse", ten="Westinghouse WHG958SC bếp gas 90cm 5 lò", loai_may="cooktop_gas", rong=895, sau=530, cao=55, khoet_rong=860, khoet_sau=490,
                     ghi="Lỗ khoét 860 × 490", nguon=["https://www.winnings.com.au/manuals/ak/7/b/b/4/7bb430a222c7e75dab04ced40f10dd4c29d2a9c0_Westinghouse_WHG958SC_Factsheet_Updates082026.pdf"]),
    "WHG638BC": dict(hang="Westinghouse", ten="Westinghouse WHG638BC bếp gas kính 60cm", loai_may="cooktop_gas", rong=600, sau=530, khoet_rong=560, khoet_sau=490,
                     ghi="Lỗ khoét 560 × 490; ống gas bên trái", nguon=["https://cdn.shopify.com/s/files/1/0096/7740/6305/files/Westinghouse_WHG639BD_Product_Sheet.pdf"]),
    **{m: dict(hang="Westinghouse", ten=f"Westinghouse {m} bếp gas 60cm", loai_may="cooktop_gas", khoet_rong=570, khoet_sau=490,
               ghi="Lỗ khoét 570 × 490 (số nhà bán lẻ – kiểm sách hướng dẫn)",
               nguon=[{"WHG640SA": "https://www.winnings.com.au/p/westinghouse-60cm-natural-gas-cooktop-whg640sa", "WHG640SB": "https://www.winnings.com.au/p/westinghouse-60cm-natural-gas-cooktop-whg640sb",
                       "WHG645SA": "https://www.appliancesonline.com.au/product/westinghouse-whg645sa-gas-cooktop"}[m]])
       for m in ("WHG640SA", "WHG640SB", "WHG645SA")},
    "WVG6515SD": dict(hang="Westinghouse", ten="Westinghouse WVG6515SD lò gas 60cm", loai_may="oven", rong=596, cao=597, sau=568, hoc_rong_min=565, hoc_cao=590, hoc_sau_min=560,
                      ghi="Lắp nhô (proud): 590 cao × 565 rộng × 560 sâu; lắp lọt (flush): 600 × 600 × 581",
                      nguon=["https://cdn.shopify.com/s/files/1/0096/7740/6305/files/Westinghouse_WVG6515SD_Factsheet.pdf"]),
    "WVE665S": dict(hang="Westinghouse", ten="Westinghouse WVE665S lò đôi 60cm", loai_may="oven", rong=596, cao=888, sau=568, hoc_rong_min=565, hoc_cao=885, hoc_sau_min=560,
                    ghi="Lắp nhô: 885 cao × 565 rộng × 560 sâu; lắp lọt: 893 × 600 × 581",
                    nguon=["https://www.winnings.com.au/p/westinghouse-60cm-electric-builtin-oven-wve665s"]),
}


def co_san(ma):
    """bộ nhớ + bảng máy hút mùi có sẵn trong engine"""
    m = chuan(ma)
    if not m: return None
    k = _kho()
    if m in k: return dict(k[m], tu_bo_nho=True)          # anh đã bấm "Áp vào tủ" = đã xác nhận
    tb = THIET_BI_SAN.get(m) or next((v for kk, v in THIET_BI_SAN.items() if chuan(kk) == m), None) or next((v for kk, v in THIET_BI_SAN.items() if chuan(kk) in m), None)
    if tb: return dict(lam_sach(dict(tb, chac=True)), tu_bo_nho=True)
    mm, may = engine.tra_may(ma)
    if may:
        o = lam_sach(dict(hang="", ten=may.get("ten") or mm, loai_may="rangehood", khoet_rong=may.get("cat_w"), khoet_sau=may.get("cat_d"),
                          hoc_rong_min=may.get("long_min") or None, hoc_sau_min=may.get("sau_min") or None,
                          ghi=f"Bảng máy hút mùi có sẵn trong Studio – nguồn: {may.get('nguon', 'CV / Huân')}" + (f" | Cao trên bếp: {may['nguon_cao']}" if may.get("nguon_cao") else ""), nguon=[]))
        return dict(o, tu_bo_nho=True, chac=True)
    return None


def _claude_web(a, ma, loai):
    """Claude API + công cụ web search của Anthropic: tìm + đọc trang hãng, trả JSON có nguồn"""
    body = {"model": a.get("claude_model") or ai.MAC_DINH["claude_model"], "max_tokens": 1500, "temperature": 0,
            "system": HUONG_DAN, "tools": [{"type": "web_search_20250305", "name": "web_search", "max_uses": 5}],
            "messages": [{"role": "user", "content": f"Mã model: {ma}\nLoại tủ trong Studio: {loai or 'không rõ'}\nTra spec lắp đặt và trả JSON."}]}
    d = ai._post("https://api.anthropic.com/v1/messages", body, {"x-api-key": a["claude_key"], "anthropic-version": "2023-06-01"}, timeout=180)
    txt, urls = "", []
    for c in d.get("content", []):
        if c.get("type") == "text":
            txt += c.get("text", "")
            for ci in c.get("citations") or []:
                if ci.get("url"): urls.append(ci["url"])
        elif c.get("type") == "web_search_tool_result" and isinstance(c.get("content"), list):
            urls += [r.get("url") for r in c["content"] if r.get("url")][:3]
    r = _json(txt); r["nguon"] = list(dict.fromkeys((r.get("nguon") or []) + urls))
    return r


def _tai(url, toi_da=400000, timeout=15):
    rq = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) JavisStudio"})
    with urllib.request.urlopen(rq, timeout=timeout) as f:
        if "pdf" in (f.headers.get("Content-Type") or "").lower(): return ""
        return f.read(toi_da).decode("utf-8", "replace")


def chu(h):
    h = re.sub(r"(?is)<(script|style|noscript|svg)[^>]*>.*?</\1>", " ", h)
    h = re.sub(r"(?s)<[^>]+>", " ", h)
    return re.sub(r"\s+", " ", html.unescape(h)).strip()


def tim_web(ma, n=4):
    """DuckDuckGo bản HTML: link kết quả (ưu tiên trang hãng / nhà bán lớn ở Úc)"""
    q = urllib.parse.quote(f"{ma} installation dimensions specifications")
    trang = _tai("https://html.duckduckgo.com/html/?q=" + q)
    urls = []
    for m in re.finditer(r'class="result__a"[^>]*href="([^"]+)"', trang):
        u = html.unescape(m.group(1))
        if "uddg=" in u: u = urllib.parse.unquote(u.split("uddg=", 1)[1].split("&", 1)[0])
        if u.startswith("http") and u not in urls: urls.append(u)
    uu = ("bosch", "siemens", "miele", "smeg", "westinghouse", "electrolux", "fisherpaykel", "asko", "neff", "aeg", "ilve", "belling", "schweigen", "qasair", "blanco", "franke",
          "harveynorman", "appliancesonline", "thegoodguys", "binglee", "winnings", "e-catalogue", "installation")
    urls.sort(key=lambda u: 0 if any(k in u.lower() for k in uu) else 1)
    return urls[:n]


def _web_ai(a, ma, loai):
    urls = tim_web(ma); doan = []
    for u in urls:
        try:
            t = chu(_tai(u))
            if chuan(ma)[:6] and chuan(ma)[:6] in chuan(t):           # trang phải nhắc tới đúng model
                doan.append(f"### {u}\n{t[:9000]}")
        except Exception: pass
    if not doan: raise RuntimeError("Không tìm thấy trang nào nói đúng model này" + (f" (đã thử {len(urls)} link)" if urls else ""))
    r = _json(ai.hoi(a, HUONG_DAN, f"Mã model: {ma}\nLoại tủ: {loai or 'không rõ'}\nNỘI DUNG CÁC TRANG TÌM ĐƯỢC:\n" + "\n\n".join(doan)[:30000], toi_da=900))
    r["nguon"] = list(dict.fromkeys((r.get("nguon") or []) + [d.split("\n", 1)[0][4:] for d in doan]))
    return r


def tra(cfg, ma, loai="", moi=False):
    """-> {ok, spec, cach} | {loi}"""
    ma = str(ma or "").strip()[:60]
    if len(chuan(ma)) < 3: return {"loi": "Nhập mã model (vd HBG634BS1, P591, DFS097A50A)."}
    if not moi:
        s = co_san(ma)
        if s: return {"ok": 1, "spec": s, "cach": "bộ nhớ Studio"}
    a = ai.cau_hinh(cfg); n = a.get("nguon")
    loi = []
    if n == "claude" and a.get("claude_key"):
        try: return {"ok": 1, "spec": lam_sach(_claude_web(a, ma, loai)), "cach": "Claude + tìm web"}
        except Exception as e: loi.append(f"Claude: {e}")
    if n != "tat":
        try: return {"ok": 1, "spec": lam_sach(_web_ai(a, ma, loai)), "cach": f"tìm web + {ai.mo_ta(a)}"}
        except Exception as e: loi.append(str(e))
    try: urls = tim_web(ma, 6)
    except Exception: urls = []
    return {"loi": "Chưa rút được spec tự động" + (": " + "; ".join(loi) if loi else " (AI đang tắt)") + ". Mở link hãng bên dưới để xem rồi gõ số tay.", "link": urls}


def ap_vao_tu(t, sp):
    """gắn spec vào tủ + đổi thông số tủ theo máy (giống nút "Áp vào tủ" trên giao diện)"""
    t["spec"] = {k: sp.get(k) for k in TRUONG + ("nguon",)}
    hoc = sp.get("hoc_cao") or sp.get("cao"); lo = t.get("loai")
    if lo == "hut_mui":
        if sp.get("khoet_rong"): t["cat_w"] = sp["khoet_rong"]
        if sp.get("khoet_sau"): t["cat_d"] = sp["khoet_sau"]
    elif lo == "lo_nuong" and hoc:
        t["lo2_cao" if "micro" in str(sp.get("loai_may") or "") else "lo_cao"] = hoc
    elif lo == "tu_lanh" and hoc: t["tl_cao"] = hoc
    elif lo == "mat_da":
        if sp.get("loai_may") == "cooktop_gas": t["bep_gas"] = True
        if sp.get("khoet_rong"): t["bep_rong"] = sp["khoet_rong"]
        if sp.get("khoet_sau"): t["bep_sau"] = sp["khoet_sau"]
    elif lo == "thiet_bi":
        for a, b in (("w", "rong"), ("h", "cao"), ("d", "sau")):
            if sp.get(b): t[a] = sp[b]
    return t
