# JAVIS STUDIO – bộ khởi động KHÔNG cửa sổ đen (chạy bằng pythonw). Biểu tượng Desktop / Start Menu trỏ vào file này.
import os, sys, subprocess, traceback
from pathlib import Path

GOC = Path(__file__).resolve().parent
os.chdir(GOC); sys.path.insert(0, str(GOC))
(GOC / "du-lieu").mkdir(exist_ok=True)
if sys.stdout is None or sys.executable.lower().endswith("pythonw.exe"):         # không có cửa sổ: ghi nhật ký ra file
    log = open(GOC / "du-lieu" / "nhat-ky.txt", "a", encoding="utf-8", buffering=1)
    sys.stdout = sys.stderr = log
thieu = []
try: import reportlab  # noqa: F401  (in layout / nhãn PDF)
except ImportError: thieu.append("reportlab")
try: import cryptography  # noqa: F401  (kiểm giấy phép ký số)
except ImportError: thieu.append("cryptography")
try: import pypdfium2  # noqa: F401  (đọc bản vẽ PDF)
except ImportError: thieu.append("pypdfium2")
if thieu:                                                                        # máy mới: tự cài thư viện, không hiện cửa sổ
    py = sys.executable[:-11] + "python.exe" if sys.executable.lower().endswith("pythonw.exe") else sys.executable
    subprocess.run([py, "-m", "pip", "install", "--user", "--quiet", "--disable-pip-version-check", *thieu],
                   creationflags=0x08000000 if os.name == "nt" else 0)          # CREATE_NO_WINDOW
    import site, importlib; importlib.invalidate_caches()
    try: sys.path.append(site.getusersitepackages())
    except Exception: pass
try:
    import vetu
    vetu.main()
except SystemExit:
    raise
except Exception:
    traceback.print_exc()
    if os.name == "nt":
        import ctypes
        ctypes.windll.user32.MessageBoxW(0, "Javis Studio không mở được. Xem du-lieu\\nhat-ky.txt hoặc gửi file đó cho Javis.", "Javis Studio", 0x10)
