# -*- coding: utf-8 -*-
"""Đọc file SketchUp (.skp) bằng SketchUp C SDK (SketchUpAPI.dll) – không cần cài SketchUp.

doc(path) -> cây khối {ten, v:[x,y,z,...] (mm, toạ độ thế giới, trục Z đứng), f:[i,j,k,...], con:[...]}
Mỗi Group / Component trong SketchUp là 1 nút, để "Quét thành tủ" lấy được từng tủ.
SDK đặt ở  <Studio>/skp-sdk/  (giải nén nguyên gói SDK_Win, chỉ cần các file .dll).
"""
import ctypes as C, os, sys, threading
from pathlib import Path

GOC = Path(__file__).resolve().parent
INCH = 25.4
_KHOA = threading.Lock()          # SDK không an toàn đa luồng
_LIB = None


class Pt(C.Structure): _fields_ = [("x", C.c_double), ("y", C.c_double), ("z", C.c_double)]
class Tf(C.Structure): _fields_ = [("v", C.c_double * 16)]           # cột-trước (column-major)

R = C.c_void_p                     # mọi SU...Ref là struct {void*} – truyền như con trỏ


def tim_dll():
    ds = sorted((GOC / "skp-sdk").rglob("SketchUpAPI.dll"), key=lambda p: ("x64" not in p.as_posix().lower(), len(p.parts)))
    return ds[0] if ds else None


def co_sdk():
    return sys.platform == "win32" and tim_dll() is not None


def _nap():
    global _LIB
    if _LIB: return _LIB
    if sys.platform != "win32": raise RuntimeError("Đọc .skp chỉ chạy trên Windows.")
    d = tim_dll()
    if not d: raise RuntimeError("Chưa có SketchUp SDK. Giải nén gói SDK_Win vào thư mục skp-sdk của Studio.")
    try: os.add_dll_directory(str(d.parent))
    except Exception: pass
    os.environ["PATH"] = str(d.parent) + os.pathsep + os.environ.get("PATH", "")
    L = C.CDLL(str(d))
    L.SUInitialize()
    _LIB = L
    return L


def _ok(r, ten):
    if r != 0: raise RuntimeError(f"SketchUp SDK lỗi {r} ở {ten}")


def _chuoi(L, ham, ref):
    s = R(); _ok(L.SUStringCreate(C.byref(s)), "SUStringCreate")
    try:
        if ham(ref, C.byref(s)) != 0: return ""
        n = C.c_size_t(); L.SUStringGetUTF8Length(s, C.byref(n))
        b = C.create_string_buffer(n.value + 1); k = C.c_size_t()
        L.SUStringGetUTF8(s, C.c_size_t(n.value + 1), b, C.byref(k))
        return b.value.decode("utf-8", "replace")
    finally: L.SUStringRelease(C.byref(s))


def _ds(L, dem, lay, ref):
    n = C.c_size_t(); _ok(dem(ref, C.byref(n)), "đếm")
    if not n.value: return []
    a = (R * n.value)(); k = C.c_size_t()
    _ok(lay(ref, n, a, C.byref(k)), "lấy")
    return [R(a[i]) for i in range(k.value)]


def _nhan(a, b):                    # ma trận 4×4 cột-trước: a·b
    o = [0.0] * 16
    for c in range(4):
        for r in range(4):
            o[c * 4 + r] = sum(a[k * 4 + r] * b[c * 4 + k] for k in range(4))
    return o


DV = [1.0, 0, 0, 0, 0, 1.0, 0, 0, 0, 0, 1.0, 0, 0, 0, 0, 1.0]


def _an(L, ve_phan_tu, ref):
    """bỏ group / component đang ẩn"""
    try:
        e = R(ve_phan_tu(ref)); h = C.c_bool()
        return L.SUDrawingElementGetHidden(e, C.byref(h)) == 0 and h.value
    except Exception: return False


def _mat(L, ents, m, nut):
    """các mặt (face) trong entities -> tam giác, nhân ma trận m, đơn vị mm"""
    v, f = nut["v"], nut["f"]
    for mt in _ds(L, L.SUEntitiesGetNumFaces, L.SUEntitiesGetFaces, ents):
        mh = R()
        if L.SUMeshHelperCreate(C.byref(mh), mt) != 0: continue
        try:
            nv = C.c_size_t(); L.SUMeshHelperGetNumVertices(mh, C.byref(nv))
            nt = C.c_size_t(); L.SUMeshHelperGetNumTriangles(mh, C.byref(nt))
            if not nv.value or not nt.value: continue
            P = (Pt * nv.value)(); k = C.c_size_t(); L.SUMeshHelperGetVertices(mh, nv, P, C.byref(k))
            I = (C.c_size_t * (nt.value * 3))(); k2 = C.c_size_t(); L.SUMeshHelperGetVertexIndices(mh, C.c_size_t(nt.value * 3), I, C.byref(k2))
            o = len(v) // 3
            for p in P[:k.value]:
                x, y, z = p.x, p.y, p.z
                w = m[3] * x + m[7] * y + m[11] * z + m[15] or 1.0
                v += [round((m[0] * x + m[4] * y + m[8] * z + m[12]) / w * INCH, 2),
                      round((m[1] * x + m[5] * y + m[9] * z + m[13]) / w * INCH, 2),
                      round((m[2] * x + m[6] * y + m[10] * z + m[14]) / w * INCH, 2)]
            f += [o + I[i] for i in range(k2.value)]
        finally: L.SUMeshHelperRelease(C.byref(mh))


def _di(L, ents, m, nut, sau, dem):
    if sau > 30: return
    _mat(L, ents, m, nut)
    for g in _ds(L, L.SUEntitiesGetNumGroups, L.SUEntitiesGetGroups, ents):
        if _an(L, L.SUGroupToDrawingElement, g): continue
        t = Tf(); L.SUGroupGetTransform(g, C.byref(t)); e = R(); _ok(L.SUGroupGetEntities(g, C.byref(e)), "SUGroupGetEntities")
        con = dict(ten=_chuoi(L, L.SUGroupGetName, g) or "Group", v=[], f=[], con=[]); dem[0] += 1
        _di(L, e, _nhan(m, list(t.v)), con, sau + 1, dem)
        if con["f"] or con["con"]: nut["con"].append(con)
    for ins in _ds(L, L.SUEntitiesGetNumInstances, L.SUEntitiesGetInstances, ents):
        if _an(L, L.SUComponentInstanceToDrawingElement, ins): continue
        t = Tf(); L.SUComponentInstanceGetTransform(ins, C.byref(t))
        dn = R(); _ok(L.SUComponentInstanceGetDefinition(ins, C.byref(dn)), "GetDefinition")
        e = R(); _ok(L.SUComponentDefinitionGetEntities(dn, C.byref(e)), "DefinitionGetEntities")
        ten = _chuoi(L, L.SUComponentInstanceGetName, ins) or _chuoi(L, L.SUComponentDefinitionGetName, dn) or "Component"
        con = dict(ten=ten, v=[], f=[], con=[]); dem[0] += 1
        _di(L, e, _nhan(m, list(t.v)), con, sau + 1, dem)
        if con["f"] or con["con"]: nut["con"].append(con)


def _khai_bao(L):
    for ten in ("SUGroupToDrawingElement", "SUComponentInstanceToDrawingElement"):
        getattr(L, ten).restype = C.c_void_p; getattr(L, ten).argtypes = [C.c_void_p]
    for ten in ("SUEntitiesGetFaces", "SUEntitiesGetGroups", "SUEntitiesGetInstances"):
        getattr(L, ten).argtypes = [C.c_void_p, C.c_size_t, C.c_void_p, C.c_void_p]
    for ten in ("SUEntitiesGetNumFaces", "SUEntitiesGetNumGroups", "SUEntitiesGetNumInstances", "SUGroupGetTransform", "SUGroupGetEntities",
                "SUComponentInstanceGetTransform", "SUComponentInstanceGetDefinition", "SUComponentDefinitionGetEntities",
                "SUMeshHelperGetNumVertices", "SUMeshHelperGetNumTriangles", "SUDrawingElementGetHidden",
                "SUGroupGetName", "SUComponentInstanceGetName", "SUComponentDefinitionGetName", "SUStringGetUTF8Length"):
        getattr(L, ten).argtypes = [C.c_void_p, C.c_void_p]
    L.SUModelGetEntities.argtypes = [C.c_void_p, C.c_void_p]
    L.SUMeshHelperCreate.argtypes = [C.c_void_p, C.c_void_p]
    for ten in ("SUMeshHelperGetVertices", "SUMeshHelperGetVertexIndices", "SUStringGetUTF8"):
        getattr(L, ten).argtypes = [C.c_void_p, C.c_size_t, C.c_void_p, C.c_void_p]


def doc(path):
    """đọc .skp -> cây khối (mm, trục Z đứng như SketchUp)"""
    with _KHOA:
        L = _nap()
        if not getattr(L, "_da_kb", False): _khai_bao(L); L._da_kb = True
        md = R(); b = str(path).encode("utf-8")
        if hasattr(L, "SUModelCreateFromFileWithStatus"):
            st = C.c_int(); r = L.SUModelCreateFromFileWithStatus(C.byref(md), b, C.byref(st))
        else: r = L.SUModelCreateFromFile(C.byref(md), b)
        if r != 0: raise RuntimeError(f"Không mở được file .skp (mã {r}). File hỏng, hoặc lưu bằng SketchUp mới hơn bộ SDK.")
        try:
            e = R(); _ok(L.SUModelGetEntities(md, C.byref(e)), "SUModelGetEntities")
            goc = dict(ten=Path(path).stem, v=[], f=[], con=[]); dem = [0]
            _di(L, e, DV, goc, 0, dem)
            return goc, dem[0]
        finally: L.SUModelRelease(C.byref(md))
