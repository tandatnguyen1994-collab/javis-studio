"""Javis Studio – xuất 1 FILE HTML 3D TỰ CHỨA cho khách / thợ xem (không cần mạng, không cần cài gì):
three.js + điều khiển xoay + dữ liệu tủ + ảnh màu vật liệu nhúng hết vào 1 file. Mở bằng trình duyệt điện thoại / máy tính.
Gửi file qua WhatsApp, hoặc để trong OneDrive rồi bấm Share để lấy link."""
import base64, json, re, html
from pathlib import Path
import engine

GOC = Path(__file__).resolve().parent


def _b64(p):
    return base64.b64encode(Path(p).read_bytes()).decode()


def _mau(job):
    """màu anh Tan chọn: {vai: {hex, anh (data URL), ten}}"""
    out = {}
    for vai, m in (job.get("mau") or {}).items():
        if not isinstance(m, dict): continue
        x = {"hex": m.get("hex"), "ten": m.get("ten", "")}
        a = str(m.get("anh") or "")
        mm = re.fullmatch(r"/mau/([0-9a-f]{12})\.(jpg|png|webp|gif)", a)
        f = GOC / "du-lieu" / "mau" / (mm.group(1) + "." + mm.group(2)) if mm else None
        if f and f.is_file():
            x["anh"] = f"data:image/{'jpeg' if mm.group(2) == 'jpg' else mm.group(2)};base64," + _b64(f)
        out[vai] = x
    return out


def tao(job, path, lang="vi"):
    """job đã hoàn thiện (có panel / filler…) -> ghi file HTML. Trả số tủ."""
    kq = engine.dung_job(job)
    tu = [dict(so=t["so"], ten=t.get("ten", ""), loai=t.get("loai", ""), x=t["x"], y=t["y"], z=t["z"], goc=t["goc"], w=t["w"], h=t["h"], d=t["d"],
               khoi=[{k: v for k, v in b.items() if k in ("b", "c", "k", "a", "r", "pl", "cung")} for b in t["khoi"]]) for t in kq["tu"]]
    data = dict(ten=f"{job.get('so', '')} {job.get('ten', '')}".strip() or "Javis Studio", tu=tu, mau=_mau(job), day=kq.get("day") or [], splash=kq.get("splash") or [])
    three = _b64(GOC / "lib" / "three.module.min.js")
    orbit = (GOC / "lib" / "OrbitControls.js").read_text(encoding="utf-8").replace("from 'three'", "from 'three'")
    orbit64 = base64.b64encode(orbit.encode("utf-8")).decode()
    ten = html.escape(data["ten"])
    s = TPL.replace("__LANG__", "en" if lang == "en" else "vi").replace("__TEN__", ten).replace("__THREE__", three).replace("__ORBIT__", orbit64).replace("__DATA__", json.dumps(data, ensure_ascii=False).replace("</", "<\\/"))
    Path(path).write_text(s, encoding="utf-8")
    return len(tu)


TPL = r"""<!DOCTYPE html><html lang="__LANG__"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1">
<title>__TEN__ – 3D</title>
<script type="importmap">{"imports":{"three":"data:text/javascript;base64,__THREE__","orbit":"data:text/javascript;base64,__ORBIT__"}}</script>
<style>html,body{margin:0;height:100%;overflow:hidden;font:14px system-ui,-apple-system,Segoe UI,sans-serif;background:linear-gradient(#dfe4ea,#f4f5f7 55%,#e7e9ec)}
#c{width:100%;height:100%;display:block;touch-action:none}#top{position:absolute;left:12px;top:10px;right:12px;display:flex;gap:8px;align-items:center;flex-wrap:wrap;pointer-events:none}
#top b{font-size:15px;color:#1d2733;margin-right:auto}button{pointer-events:auto;border:1px solid #cfd5dc;background:rgba(255,255,255,.92);border-radius:8px;padding:7px 11px;font-size:13px;color:#1d2733}
button.on{background:#18b8d8;color:#fff;border-color:#18b8d8}#bot{position:absolute;left:12px;right:12px;bottom:10px;display:flex;gap:10px;align-items:center;color:#4b5563;font-size:12px}
#bot input{flex:1;max-width:260px}#nh{position:absolute;right:12px;bottom:40px;color:#7a8492;font-size:11px}</style></head>
<body><canvas id="c"></canvas><div id="top"><b>__TEN__</b><button id="bmo" data-vi="Mở cửa" data-en="Open doors">Mở cửa</button><button id="ban" data-vi="Ẩn cánh" data-en="Hide doors">Ẩn cánh</button><button id="bfit" data-vi="Toàn cảnh" data-en="Fit view">Toàn cảnh</button><button id="blg">EN</button></div>
<div id="bot"><span data-vi="Tách tấm" data-en="Explode panels">Tách tấm</span> <input type="range" id="tach" min="0" max="100" value="0"></div><div id="nh" data-vi="Javis Studio · TPW GROUP · kéo 1 ngón: xoay · 2 ngón: phóng / dời" data-en="Javis Studio · TPW GROUP · drag 1 finger: rotate · 2 fingers: zoom / pan">Javis Studio · TPW GROUP · kéo 1 ngón: xoay · 2 ngón: phóng / dời</div>
<script type="module">
import * as THREE from 'three'; import { OrbitControls } from 'orbit';
const D=__DATA__, cv=document.getElementById('c'), ren=new THREE.WebGLRenderer({canvas:cv,antialias:true,alpha:true});
ren.setPixelRatio(Math.min(devicePixelRatio,2)); ren.shadowMap.enabled=true; ren.shadowMap.type=THREE.PCFSoftShadowMap; ren.toneMapping=THREE.ACESFilmicToneMapping;
const scene=new THREE.Scene(), cam=new THREE.PerspectiveCamera(38,1,20,80000), ctl=new OrbitControls(cam,cv); ctl.enableDamping=true; ctl.maxPolarAngle=Math.PI*.52;
scene.add(new THREE.HemisphereLight(0xffffff,0xb9bec6,1.15)); const sun=new THREE.DirectionalLight(0xfff4e6,2.1); sun.position.set(2600,4200,4600); sun.castShadow=true; sun.shadow.mapSize.set(2048,2048); sun.shadow.bias=-.0004; sun.shadow.normalBias=3;
Object.assign(sun.shadow.camera,{left:-6000,right:9000,top:6000,bottom:-3000,near:100,far:16000}); scene.add(sun,sun.target); const fill=new THREE.DirectionalLight(0xdde8ff,.55); fill.position.set(-2400,1800,3200); scene.add(fill);
const floor=new THREE.Mesh(new THREE.PlaneGeometry(40000,40000),new THREE.MeshStandardMaterial({color:0xd9dcdf,roughness:.95})); floor.rotation.x=-Math.PI/2; floor.receiveShadow=true; scene.add(floor);
const EM=new THREE.LineBasicMaterial({color:0x1c2026,transparent:true,opacity:.42}), MAT=new Map(), TL=new THREE.TextureLoader();
function mat(k){ const m=D.mau[k.r], kim=k.r==='tay'||k.r==='kl', key=m?(k.r+'|'+(m.anh||m.hex)):(k.c+(kim?'k':''));
  if(!MAT.has(key)){ const o={color:m?(m.anh?0xffffff:m.hex):k.c,roughness:kim?.35:(k.r==='da'||k.r==='sb')?.28:.7,metalness:kim?.55:0};
    if(m&&m.anh){ const t=TL.load(m.anh); t.wrapS=t.wrapT=THREE.RepeatWrapping; t.colorSpace=THREE.SRGBColorSpace; t.repeat.set(1/900,1/900); o.map=t } MAT.set(key,new THREE.MeshStandardMaterial(o)) }
  return MAT.get(key) }
function boxUV(a,b,c){ const g=new THREE.BoxGeometry(a,b,c), uv=g.attributes.uv, d=[[c,b],[c,b],[a,c],[a,c],[a,b],[a,b]]; for(let f=0;f<6;f++)for(let i=0;i<4;i++){const j=f*4+i; uv.setXY(j,uv.getX(j)*d[f][0],uv.getY(j)*d[f][1])} return g }
const anims=[], groups=[], root=new THREE.Group(); scene.add(root);
for(const t of D.tu){ const g=new THREE.Group(); g.position.set(t.x,t.y,t.z); g.rotation.y=t.goc*Math.PI/180; const piv={};
  for(const k of t.khoi){ const [x,y,z,sx,sy,sz]=k.b; if(sx<=0||sy<=0||sz<=0)continue; const mt=mat(k); let m;
    if(k.pl){ const P=k.pl, sh=new THREE.Shape(), f=([a,b])=>P.ax==='y'?[a,-b]:P.ax==='x'?[-a,b]:[a,b];
      P.pts.map(f).forEach(([a,b],j)=>j?sh.lineTo(a,b):sh.moveTo(a,b)); sh.closePath();
      (P.lo||[]).forEach(L=>{ const h=new THREE.Path(); L.map(f).forEach(([a,b],j)=>j?h.lineTo(a,b):h.moveTo(a,b)); h.closePath(); sh.holes.push(h) });
      const gg=new THREE.ExtrudeGeometry(sh,{depth:P.d,bevelEnabled:false}); if(P.ax==='y')gg.rotateX(-Math.PI/2); else if(P.ax==='x')gg.rotateY(Math.PI/2);
      m=new THREE.Mesh(gg,mt); m.position.set(...P.o); m.add(new THREE.LineSegments(new THREE.EdgesGeometry(gg,20),EM)); m.castShadow=m.receiveShadow=true; g.add(m); continue }
    if(k.cung){ const c=k.cung, r=c.r, ve=k.k==='canh', R2=ve?r+16:r, R1=ve?r:0, P2=Math.PI/2, sh=new THREE.Shape(), S=+c.s||0, a0=c.ben==='R'?0:P2;
      if(R1>0){ if(c.ben==='R'){ sh.moveTo(R1,-S); sh.lineTo(R2,-S); sh.lineTo(R2,0); sh.absarc(0,0,R2,0,P2,false); sh.lineTo(0,R1); sh.absarc(0,0,R1,P2,0,true); sh.lineTo(R1,-S) }
        else{ sh.moveTo(-R2,-S); sh.lineTo(-R1,-S); sh.lineTo(-R1,0); sh.absarc(0,0,R1,Math.PI,P2,true); sh.lineTo(0,R2); sh.absarc(0,0,R2,P2,Math.PI,false); sh.lineTo(-R2,-S) } }
      else{ sh.absarc(0,0,R2,a0,a0+P2,false); sh.lineTo(0,0) }
      const gg=new THREE.ExtrudeGeometry(sh,{depth:sy,bevelEnabled:false,curveSegments:24}); gg.rotateX(Math.PI/2); m=new THREE.Mesh(gg,mt); m.position.set(c.cx,y+sy,c.cz); m.castShadow=true; g.add(m); continue }
    const gg=(D.mau[k.r]&&D.mau[k.r].anh)?boxUV(sx,sy,sz):new THREE.BoxGeometry(sx,sy,sz); m=new THREE.Mesh(gg,mt); m.castShadow=m.receiveShadow=true;
    if(k.k!=='tay')m.add(new THREE.LineSegments(new THREE.EdgesGeometry(gg),EM));
    const a=k.a;
    if(a&&a.kieu==='cua'){ const p=new THREE.Group(); p.position.set(a.px,0,a.pz); m.position.set(x+sx/2-a.px,y+sy/2,z+sz/2-a.pz); p.add(m); g.add(p); anims.push({o:p,t:'cua',s:a.ban_le==='L'?-1:1}); if(a.id)piv[a.id]={o:p,px:a.px,pz:a.pz}; p.userData.canh=1 }
    else if(a&&a.kieu==='gap'&&piv[a.cha]){ const q=piv[a.cha], p=new THREE.Group(); p.position.set(a.px-q.px,0,a.pz-q.pz); m.position.set(x+sx/2-a.px,y+sy/2,z+sz/2-a.pz); p.add(m); q.o.add(p); anims.push({o:p,t:'gap',s:a.s||1,g:a.g||1.57}) }
    else if(a&&a.kieu==='lat'){ const p=new THREE.Group(); p.position.set(0,a.py,a.pz); m.position.set(x+sx/2,y+sy/2-a.py,z+sz/2-a.pz); p.add(m); g.add(p); anims.push({o:p,t:'lat',s:a.s||1}); p.userData.canh=1; if(a.id)piv[a.id]={o:p,py:a.py,pz:a.pz} }
    else if(a&&a.kieu==='latx'&&piv[a.cha]){ const q=piv[a.cha], p=new THREE.Group(); p.position.set(0,a.py-q.py,a.pz-q.pz); m.position.set(x+sx/2,y+sy/2-a.py,z+sz/2-a.pz); p.add(m); q.o.add(p); anims.push({o:p,t:'latx',s:a.s||1}) }
    else{ m.position.set(x+sx/2,y+sy/2,z+sz/2); g.add(m); if(a&&a.kieu==='hoc')anims.push({o:m,t:'hoc',z0:z+sz/2,k:a.k||0,d:t.d}); else if(a&&a.kieu==='truot')anims.push({o:m,t:'truot',x0:x+sx/2,dx:a.dx||0}) }
    if(k.k==='canh'||k.k==='mat_hoc')m.userData.canh=1 }
  root.add(g); groups.push(g) }
for(const s of D.splash){ const d=D.day.find(x=>x.id===s.day); if(!d)continue; const [x,y,z,sx,sy,sz]=s.b, g=new THREE.Group(), gc=((d.goc%360)+360)%360;
  const [wx,wz]=gc===90?[d.ox,d.oz]:gc===180?[d.ox,d.oz]:gc===270?[d.ox,d.oz]:[d.ox,d.oz]; g.position.set(wx,0,wz); g.rotation.y=d.goc*Math.PI/180;
  const m=new THREE.Mesh(new THREE.BoxGeometry(sx,sy,sz),mat({r:'sb',c:s.loai==='kinh'?'#dfe9e6':'#e4e1da'})); m.position.set(x+sx/2,y+sy/2,z+sz/2); m.receiveShadow=true; g.add(m); root.add(g) }
// tường sau
root.updateMatrixWorld(true); const bb=new THREE.Box3().setFromObject(root), sz=bb.getSize(new THREE.Vector3());
const WH=Math.max(sz.y+250,2600), WM=new THREE.MeshStandardMaterial({color:0xf2f0ec,roughness:1,side:THREE.DoubleSide}), tuong=(D.day||[]).filter(d=>d.id!=='D'&&+d.dai>0);
if(tuong.length){ for(const d of tuong){ const g=(+d.goc||0)*Math.PI/180, ux=Math.cos(g), uz=-Math.sin(g), nx=Math.sin(g), nz=Math.cos(g), L=+d.dai;      // mỗi dãy sát tường: 1 mảng tường sau lưng dãy
    const w=new THREE.Mesh(new THREE.PlaneGeometry(L,WH),WM); w.position.set(+d.ox+ux*L/2-nx*2,WH/2,+d.oz+uz*L/2-nz*2); w.rotation.y=g; w.receiveShadow=true; scene.add(w) } }
else { const wall=new THREE.Mesh(new THREE.PlaneGeometry(sz.x+1200,WH),WM); wall.position.set((bb.min.x+bb.max.x)/2,WH/2,bb.min.z-2); wall.receiveShadow=true; scene.add(wall) }
// tách tấm
for(const g of groups){ const gb=new THREE.Box3().setFromObject(g), gc=g.worldToLocal(gb.getCenter(new THREE.Vector3())), gs=gb.getSize(new THREE.Vector3());
  for(const c of g.children){ const b=new THREE.Box3().setFromObject(c); if(b.isEmpty())continue; const d=g.worldToLocal(b.getCenter(new THREE.Vector3())).sub(gc); d.set(d.x/Math.max(gs.x,1),d.y/Math.max(gs.y,1),d.z/Math.max(gs.z,1)).multiplyScalar(2); c.userData.p0=c.position.clone(); c.userData.td=d } }
let tach=0, mo=false;
document.getElementById('tach').oninput=e=>{ tach=e.target.value/100; for(const g of groups)for(const c of g.children)if(c.userData.p0)c.position.copy(c.userData.p0).addScaledVector(c.userData.td,tach*420) };
document.getElementById('bmo').onclick=e=>{ mo=!mo; e.target.classList.toggle('on',mo) };
let LG=document.documentElement.lang==='en'?'en':'vi'; const datLang=l=>{ LG=l; document.documentElement.lang=l; document.querySelectorAll('[data-vi]').forEach(e=>e.textContent=e.dataset[l]); document.getElementById('blg').textContent=l==='en'?'VI':'EN' };
document.getElementById('blg').onclick=()=>datLang(LG==='en'?'vi':'en'); datLang(LG);
document.getElementById('ban').onclick=e=>{ const an=e.target.classList.toggle('on'); root.traverse(o=>{ if(o.userData.canh)o.visible=!an }) };
function fit(){ const c=bb.getCenter(new THREE.Vector3()), t=Math.tan(cam.fov*Math.PI/360), asp=Math.max(cam.aspect,.3), need=Math.max((sz.y+sz.z*.35)/2/t,Math.hypot(sz.x,sz.z)/2/(t*asp))*1.2+600;
  ctl.target.copy(c); cam.position.copy(c).addScaledVector(HUONG,need); ctl.update() }
// nhìn từ phía MẶT CÁNH: trung bình hướng mặt trước các tủ (theo bề rộng), lệch ngang ~25°, hơi cao
const HUONG=(()=>{ let fx=0,fz=0; for(const t of D.tu){ if(['tam','mat_da'].includes(t.loai))continue; const g=t.goc*Math.PI/180; fx+=Math.sin(g)*t.w; fz+=Math.cos(g)*t.w }
  let L=Math.hypot(fx,fz); if(L<1){fx=0;fz=1;L=1} fx/=L; fz/=L; const a=25*Math.PI/180, rx=fx*Math.cos(a)+fz*Math.sin(a), rz=-fx*Math.sin(a)+fz*Math.cos(a);
  return new THREE.Vector3(rx,.42,rz).normalize() })();
document.getElementById('bfit').onclick=fit;
function size(){ const w=cv.clientWidth,h=cv.clientHeight; if(cv.width!==Math.floor(w*ren.getPixelRatio())||cv.height!==Math.floor(h*ren.getPixelRatio())){ren.setSize(w,h,false);cam.aspect=w/h;cam.updateProjectionMatrix()} }
size(); fit();
(function loop(){ requestAnimationFrame(loop); size(); ctl.update();
  for(const a of anims){ const tg=mo?1:0; a.c=(a.c??0)+(tg-(a.c??0))*.14;
    if(a.t==='cua')a.o.rotation.y=a.s*a.c*1.75; else if(a.t==='gap')a.o.rotation.y=a.s*a.c*a.g; else if(a.t==='lat')a.o.rotation.x=a.s*a.c*1.4; else if(a.t==='latx')a.o.rotation.x=a.s*a.c*2.6; else if(a.t==='truot')a.o.position.x=a.x0+a.c*a.dx; else a.o.position.z=a.z0+a.c*Math.min(a.d*.72,420)*(1-.12*a.k)+(a.o.userData.td?a.o.userData.td.z*tach*420:0) }
  ren.render(scene,cam) })();
</script></body></html>"""
