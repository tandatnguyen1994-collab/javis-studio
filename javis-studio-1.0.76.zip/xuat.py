"""Javis Studio - xuất bộ file cắt: .cix (mỗi tấm 1 file) + CncRun##.txt + layout.pdf + label.pdf + danh sách chi tiết / phụ kiện."""
import os, re, csv, datetime, json
from engine import VAT_LIEU, dung_job, dung_ca_job
from cnc import write_sheet, nest, place_fn

M, GAP = 4, 10


def _font():
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.ttfonts import TTFont
    if "JV" in pdfmetrics.getRegisteredFontNames(): return "JV", "JVB"
    cands = [(r"C:\Windows\Fonts\arial.ttf", r"C:\Windows\Fonts\arialbd.ttf"),
             ("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf")]
    for a, b in cands:
        if os.path.exists(a):
            pdfmetrics.registerFont(TTFont("JV", a)); pdfmetrics.registerFont(TTFont("JVB", b if os.path.exists(b) else a))
            return "JV", "JVB"
    return "Helvetica", "Helvetica-Bold"


def ma_job(job):
    return (re.sub(r"[^0-9A-Za-z]", "", str(job.get("so") or "")) or "00")[:6]


def xep_tam(job, budget=1.5):
    """-> (kq dung_job, nhom:[{vl, v, sheets:[{prog, placed:[...], dung%}]}], kiem:[lỗi])"""
    kq = dung_ca_job(job); so = ma_job(job); nhom = []; kiem = []
    for vl, v in VAT_LIEU.items():
        ps = [p for p in kq["chi_tiet"] if p["vl"] == vl and not p.get("ngoai")]
        if not ps: continue
        ok = []
        for p in ps:
            fits = lambda w, h: w <= v["lx"] - 2 * M and h <= v["ly"] - 2 * M
            if fits(p["w"], p["h"]) or (p["rot"] and fits(p["h"], p["w"])): ok.append(p)
            else: kiem.append(f"#{p['cab']} {p['name']} {p['w']:.0f}x{p['h']:.0f} không lọt tấm – bỏ qua, phải chia nhỏ")
        Q = [dict(w=p["w"], h=p["h"], canrot=p["rot"]) for p in ok]
        sheets = []
        for si, sh in enumerate(nest(Q, v["lx"], v["ly"], budget) if Q else [], 1):
            items = sorted(sh["items"], key=lambda it: Q[it[0]]["w"] * Q[it[0]]["h"])       # miếng nhỏ cắt trước
            placed = []; used = 0
            for pn, (i, x, y, r) in enumerate(items, 1):
                p = ok[i]; fn = place_fn(p["w"], p["h"], r, x, y)
                poly = [fn(*q) for q in p["poly"]]
                holes = [(*fn(a, b), d, dp) for a, b, d, dp in p["holes"]]
                grooves = [([fn(gx, gy) for gx, gy in g], dp) for g, dp in p.get("grooves", [])]
                cutouts = [[fn(*q) for q in c] for c in p.get("cutouts", [])]       # lỗ khoét kín giữa miếng (đáy tủ hút mùi P591…)
                xs = [q[0] for q in poly]; ys = [q[1] for q in poly]
                bb = (min(xs), min(ys), max(xs), max(ys)); used += p["w"] * p["h"]
                if bb[0] < M - .01 or bb[1] < M - .01 or bb[2] > v["lx"] - M + .01 or bb[3] > v["ly"] - M + .01:
                    kiem.append(f"{vl} tấm {si} miếng {pn}: lấn mép tấm")
                for hx, hy, d, dp in holes:
                    if not (bb[0] < hx < bb[2] and bb[1] < hy < bb[3]): kiem.append(f"{vl} tấm {si} miếng {pn}: lỗ ngoài miếng")
                for c_ in cutouts:
                    if not all(bb[0] < cx < bb[2] and bb[1] < cy < bb[3] for cx, cy in c_): kiem.append(f"{vl} tấm {si} miếng {pn}: lỗ khoét ra ngoài miếng")
                placed.append(dict(poly=poly, holes=holes, grooves=grooves, cutouts=cutouts, pn=pn, src=p, r=r, bb=bb))
            for a in placed:
                for b in placed:
                    if a["pn"] < b["pn"] and a["bb"][0] < b["bb"][2] - .01 + GAP - 10 and b["bb"][0] < a["bb"][2] - .01 and a["bb"][1] < b["bb"][3] - .01 and b["bb"][1] < a["bb"][3] - .01:
                        kiem.append(f"{vl} tấm {si}: miếng {a['pn']} đè miếng {b['pn']}")
            sheets.append(dict(prog=f"J{so}{v['ma']}{si:02d}", placed=placed, dung=round(used / (v["lx"] * v["ly"]) * 100)))
        nhom.append(dict(vl=vl, v=v, sheets=sheets))
    return kq, nhom, kiem


def xem_truoc(job):
    """dữ liệu xếp tấm gọn cho giao diện"""
    kq, nhom, kiem = xep_tam(job, 0.6)
    out = []
    for g in nhom:
        out.append(dict(vl=g["vl"], ten=g["v"]["ten"], lx=g["v"]["lx"], ly=g["v"]["ly"], mau=g["v"]["mau"], sheets=[
            dict(prog=s["prog"], dung=s["dung"], parts=[dict(pn=q["pn"], poly=q["poly"], cab=q["src"]["cab"], n=q["src"]["name"],
                                                               w=q["src"]["w"], h=q["src"]["h"], holes=[(h[0], h[1], h[2]) for h in q["holes"]]) for q in s["placed"]])
            for s in g["sheets"]]))
    return dict(nhom=out, kiem=kiem, canh_bao=kq["canh_bao"])


def ten_mau(job, vl):
    """tên màu anh Tan chọn cho nhóm vật liệu này (để in lên layout / nhãn)"""
    m = (job.get("mau") or {}).get({"HMR16": "thung", "MAU16B": "mat2"}.get(vl, "mat")) or {}
    return str(m.get("ten") or "")[:40]


def _layout_pdf(path, job, g, ngay):
    from reportlab.pdfgen import canvas
    from reportlab.lib.pagesizes import A4
    F, FB = _font(); c = canvas.Canvas(path, pagesize=A4); PW, PH = A4; v = g["v"]
    for si, s in enumerate(g["sheets"], 1):
        k = (PW - 60) / v["lx"]; ox, oy = 30, PH - 40 - v["ly"] * k
        c.setLineWidth(1); c.rect(ox, oy, v["lx"] * k, v["ly"] * k)
        for q in s["placed"]:
            pth = c.beginPath(); pts = q["poly"]; pth.moveTo(ox + pts[0][0] * k, oy + pts[0][1] * k)
            for x, y in pts[1:]: pth.lineTo(ox + x * k, oy + y * k)
            pth.close(); c.setFillColorRGB(.96, .93, .86); c.setLineWidth(.5); c.drawPath(pth, fill=1, stroke=1)
            for co in q.get("cutouts", []):                              # lỗ khoét kín: vẽ trắng
                ph = c.beginPath(); ph.moveTo(ox + co[0][0] * k, oy + co[0][1] * k)
                for x, y in co[1:]: ph.lineTo(ox + x * k, oy + y * k)
                ph.close(); c.setFillColorRGB(1, 1, 1); c.drawPath(ph, fill=1, stroke=1)
            c.setStrokeColorRGB(.3, .3, .35); c.setLineWidth(.3)
            for gr_, dp in q.get("grooves", []):                    # rãnh (uốn cong) vẽ thành vạch
                for (x1, y1), (x2, y2) in zip(gr_, gr_[1:]): c.line(ox + x1 * k, oy + y1 * k, ox + x2 * k, oy + y2 * k)
            c.setStrokeColorRGB(0, 0, 0); c.setFillColorRGB(.8, 0, 0)
            for hx, hy, d, dp in q["holes"]:
                if dp <= 1: c.setFillColorRGB(.85, .6, 0)
                c.circle(ox + hx * k, oy + hy * k, max(.5, d * k / 2), fill=1, stroke=0)
                if dp <= 1: c.setFillColorRGB(.8, 0, 0)
            c.setFillColorRGB(0, 0, 0); c.setFont(FB, 8)
            c.drawCentredString(ox + (q["bb"][0] + q["bb"][2]) / 2 * k, oy + (q["bb"][1] + q["bb"][3]) / 2 * k - 3, str(q["pn"]))
        c.setFont(FB, 8); y = oy - 18
        c.drawString(30, y, f"{'#':<4}"); c.drawString(55, y, "Rộng"); c.drawString(105, y, "Dài"); c.drawString(155, y, "Tên"); c.drawString(330, y, "Tủ"); c.drawString(365, y, "Nẹp / ghi chú")
        c.setFont(F, 7.5)
        for q in s["placed"]:
            y -= 11
            if y < 95: break
            p = q["src"]; w, l = sorted((p["w"], p["h"]))
            c.drawString(30, y, str(q["pn"])); c.drawRightString(90, y, f"{w:.1f}"); c.drawRightString(140, y, f"{l:.1f}")
            c.drawString(155, y, p["name"][:34]); c.drawString(330, y, "#" + p["cab"])
            nt = ("nẹp " + ",".join(p["edges"]) if p["edges"] else "") + (" | 45°: " + ",".join(p["e45"]) if p["e45"] else "") + ((" | " + p["note"]) if p["note"] else "")
            c.drawString(365, y, nt[:52])
        c.setLineWidth(.8); c.rect(30, 25, PW - 60, 60); c.line(PW / 2, 25, PW / 2, 85)
        c.setFont(F, 8.5); c.drawCentredString(PW / 4 + 15, 71, v["mat"].strip() + (f"  ({ten_mau(job, g['vl'])})" if ten_mau(job, g["vl"]) else "")); c.drawCentredString(PW / 4 + 15, 58, f"Sheet {si} of {len(g['sheets'])} ({v['ly']} x {v['lx']})")
        c.setFont(FB, 15); c.drawCentredString(PW / 4 + 15, 34, f"*{s['prog']}*")
        c.setFont(F, 9); c.drawCentredString(PW * 3 / 4 - 15, 64, f"JOB {job.get('so', '')} – {job.get('ten', '')}"[:48])
        c.drawCentredString(PW * 3 / 4 - 15, 40, f"{ngay} | Javis Studio | dùng {s['dung']}% tấm")
        c.showPage()
    c.save()


def _label_pdf(path, job, g):
    from reportlab.pdfgen import canvas
    from reportlab.lib.pagesizes import A4
    F, FB = _font(); c = canvas.Canvas(path, pagesize=A4); PW, PH = A4
    labs = [(si, s["prog"], q) for si, s in enumerate(g["sheets"], 1) for q in s["placed"]]
    SO = {}                                                       # chị Bích: số tủ phải là SỐ (1,2,3…), mỗi tủ 1 số
    for _, _, q in labs:
        cb = str(q["src"]["cab"])
        if cb not in SO: SO[cb] = cb if cb.isdigit() else None
    n_ = 0
    for cb in SO:
        if SO[cb] is None:
            n_ += 1
            while str(n_) in SO.values(): n_ += 1
            SO[cb] = str(n_)
    cw, ch = PW / 2, PH / 4
    for n, (si, prog, q) in enumerate(labs):
        j = n % 8
        if n and j == 0: c.showPage()
        x0, y0 = (j % 2) * cw + 8, PH - (j // 2 + 1) * ch + 6; w, h = cw - 16, ch - 12; p = q["src"]
        c.setDash(3, 2); c.setLineWidth(.4); c.rect(x0, y0, w, h); c.setDash()
        c.setFont(F, 8.5); c.drawString(x0 + 6, y0 + h - 14, f"Job: {job.get('so', '')} {job.get('ten', '')}"[:40])
        c.setFont(FB, 8); c.drawString(x0 + 6, y0 + h - 27, f"{p['name']}"[:34])
        c.setFont(F, 7); c.drawString(x0 + 6, y0 + h - 38, (p.get("tu_ten") or "")[:38])
        ed = ("Nẹp: " + ",".join(p["edges"]) if p["edges"] else "Không nẹp") + (f"  |  NẸP 45°: {','.join(p['e45'])}" if p["e45"] else "")
        c.drawString(x0 + 6, y0 + h - 49, ed)
        if p["note"]: c.setFillColorRGB(.65, 0, 0); c.drawString(x0 + 6, y0 + h - 59, p["note"][:58]); c.setFillColorRGB(0, 0, 0)
        c.setLineWidth(.6); c.rect(x0 + w - 62, y0 + h - 34, 56, 28); c.setFont(FB, 9)
        c.drawCentredString(x0 + w - 34, y0 + h - 18, f"Sheet {si}"); c.drawCentredString(x0 + w - 34, y0 + h - 29, f"Part {q['pn']}")
        c.setFont(FB, 20); c.drawString(x0 + 8, y0 + 46, f"# {SO[str(p['cab'])]}")
        c.setFont(FB, 10); c.drawString(x0 + 8, y0 + 26, f"{p['w']:.1f} x {p['h']:.1f}")
        c.setFont(F, 5.5); c.drawString(x0 + 6, y0 + 6, f"{g['v']['mat'].strip()} {ten_mau(job, g['vl'])}   {prog}")
        # hình miếng + cạnh dán nẹp
        bx, by, bw, bh = x0 + w * .42, y0 + 14, w * .54, h * .52
        k = min(bw / p["w"], bh / p["h"]) * .82; px, py = bx + (bw - p["w"] * k) / 2, by + (bh - p["h"] * k) / 2
        pts = p["poly"]; pth = c.beginPath(); pth.moveTo(px + pts[0][0] * k, py + pts[0][1] * k)
        for x, y in pts[1:]: pth.lineTo(px + x * k, py + y * k)
        pth.close(); c.setLineWidth(.8); c.setFillColorRGB(1, 1, 1); c.drawPath(pth, fill=1, stroke=1)
        c.setFillColorRGB(0, 0, 0); c.setFont(FB, 8)                       # chị Bích: số chiều dài nằm ngay trên, giữa hình miếng
        c.drawCentredString(px + p["w"] * k / 2, py + p["h"] * k + (10 if "T" in p["edges"] else 4), f"{p['w']:.1f}")
        for hx, hy, d, dp in p["holes"]:
            c.setFillColorRGB(*((.85, .6, 0) if dp <= 1 else (.8, 0, 0))); c.circle(px + hx * k, py + hy * k, 1.6 if dp <= 1 else .9, fill=1, stroke=0)
        pos = {"T": (px + p["w"] * k / 2, py + p["h"] * k), "B": (px + p["w"] * k / 2, py), "L": (px, py + p["h"] * k / 2), "R": (px + p["w"] * k, py + p["h"] * k / 2)}
        for sd in p["edges"]:
            c.setFillColorRGB(1, 1, 1); c.circle(*pos[sd], 6, fill=1, stroke=1); c.setFillColorRGB(0, 0, 0); c.setFont(FB, 7); c.drawCentredString(pos[sd][0], pos[sd][1] - 2.5, "E")
        for sd in p["e45"]:
            c.setFillColorRGB(1, .83, 0); c.circle(*pos[sd], 7.5, fill=1, stroke=1); c.setFillColorRGB(0, 0, 0); c.setFont(FB, 6.5); c.drawCentredString(pos[sd][0], pos[sd][1] - 2.3, "45")
    c.save()


def xuat(job, goc):
    """ghi cả bộ vào goc/<JOB so - ten>/ ; trả về tóm tắt"""
    kq, nhom, kiem = xep_tam(job, 3.0)
    so = ma_job(job); now = datetime.datetime.now(); ngay = now.strftime("%d-%m-%Y")
    ten = re.sub(r'[\\/:*?"<>|]', "-", f"JOB {job.get('so', '')} - {job.get('ten', 'KHONG TEN')}").strip()
    out = os.path.join(goc, ten); os.makedirs(out, exist_ok=True)
    tom = []
    for gi, g in enumerate(nhom, 1):
        v = g["v"]; gdir = os.path.join(out, f"{gi} - {re.sub(r'[^0-9A-Za-z ._-]', '', g['vl'])} {v['lz']:g}mm"); os.makedirs(gdir, exist_ok=True)
        for f in os.listdir(gdir):                       # file .cix cũ của lần xuất trước: đổi tên giữ lại, không xoá
            if f.lower().endswith(".cix"): os.replace(os.path.join(gdir, f), os.path.join(gdir, f + ".cu"))
        for s in g["sheets"]:
            write_sheet(os.path.join(gdir, s["prog"] + ".cix"), v["lx"], v["ly"], v["lz"], v["mat"], s["placed"], v["tnm"], v["crc"], "10_MDF")
        run = [f"^Job         : {job.get('so', '')} - {job.get('ten', '')} (JAVIS)", "^Description : ", f"^Date        : {now.strftime('%A, %b %d %Y')}", f"^Sheets      : {len(g['sheets'])}"]
        run += [f"{s['prog']},Nest Sheet {k},{v['ly']:g},{v['lx']:g},{v['lz']:g},{v['mat']},0,1,{v['c9']},B,0," for k, s in enumerate(g["sheets"], 1)]
        open(os.path.join(gdir, f"CncRun{so}.txt"), "w", newline="", encoding="utf-8").write("\r\n".join(run) + "\r\n")
        _layout_pdf(os.path.join(gdir, "layout.pdf"), job, g, ngay); _label_pdf(os.path.join(gdir, "label.pdf"), job, g)
        tom.append(dict(vl=g["vl"], ten=v["ten"], tam=len(g["sheets"]), mieng=sum(len(s["placed"]) for s in g["sheets"]), thu_muc=gdir, file=[s["prog"] + ".cix" for s in g["sheets"]]))
    with open(os.path.join(out, "DANH SACH CHI TIET.csv"), "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f); w.writerow(["Tủ", "Tên tủ", "Chi tiết", "Vật liệu", "Rộng", "Dài", "Số lỗ", "Nẹp", "Nẹp 45", "Ghi chú"])
        for p in kq["chi_tiet"]:
            a, b = sorted((p["w"], p["h"])); w.writerow(["#" + p["cab"], p.get("tu_ten", ""), p["name"], VAT_LIEU[p["vl"]]["ten"], a, b, len(p["holes"]), " ".join(p["edges"]), " ".join(p["e45"]), p["note"]])
    with open(os.path.join(out, "PHU KIEN.csv"), "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f); w.writerow(["Phụ kiện", "Số lượng"])
        for k, n in sorted(kq["phu_kien"].items()): w.writerow([k, n])
        for g in tom: w.writerow([f"Số tấm – {g['ten']}", g["tam"]])
        for vl, m in kq["nep"].items(): w.writerow([f"Nẹp cạnh cho {VAT_LIEU[vl]['ten']} (mét)", m])
    json.dump(job, open(os.path.join(out, "job.jvs"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    try:
        import banve; banve.ban_ve(os.path.join(out, "BAN VE 2D.pdf"), job); banve.ban_ve_da(os.path.join(out, "MAT DA - THO DA.pdf"), job); banve.ban_ve_da(os.path.join(out, "BENCHTOP - STONEMASON.pdf"), job, en=True); banve.ban_ve(os.path.join(out, "DRAWINGS - EN.pdf"), job, en=True)
    except Exception as e: kiem.append(f"Bản vẽ 2D lỗi: {e}")
    ngoai = [p for p in kq["chi_tiet"] if p.get("ngoai")]
    if ngoai:      # cửa shaker: chưa tự ra chương trình phay -> danh sách để Huân làm
        with open(os.path.join(out, "CUA SHAKER - nho Huan ra file.csv"), "w", newline="", encoding="utf-8-sig") as f:
            w = csv.writer(f); w.writerow(["Tủ", "Tên tủ", "Chi tiết", "Cao", "Rộng", "Dày", "Bản lề (lỗ chén)", "Ghi chú"])
            for p in ngoai: w.writerow(["#" + p["cab"], p.get("tu_ten", ""), p["name"], p["w"], p["h"], VAT_LIEU[p["vl"]]["lz"], sum(1 for h in p["holes"] if h[2] == 35), p["note"]])
    return dict(thu_muc=out, nhom=tom, kiem=kiem, canh_bao=kq["canh_bao"], ghi_chu=kq.get("ghi_chu", []), ngoai=len(ngoai))
