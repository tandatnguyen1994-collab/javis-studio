"""Javis Studio – bản vẽ 2D (shop drawing) ra PDF A3: mặt bằng + mặt đứng từng hướng tủ, có số tủ, kích thước, bảng tủ.
Dùng dữ liệu khối (khoi) của dung_job nên vẽ đúng cái đã dựng 3D: cánh, mặt hộc, panel, thiết bị."""
import math, datetime
from engine import dung_job, THU_VIEN, TU_TREO
from xuat import _font

A3 = (1190.55, 841.89)
INK = (0.12, 0.12, 0.14); GREY = (0.45, 0.45, 0.48); LITE = (0.80, 0.80, 0.82)
MAU = {"mat": (0.72, 0.56, 0.40), "thung": (0.95, 0.94, 0.91), "da": (0.84, 0.83, 0.80), "tay": (0.15, 0.15, 0.15), "kl": (0.60, 0.62, 0.65), "chan": (0.25, 0.25, 0.27)}
HUONG = {0: "Mặt đứng A – hàng tủ nhìn từ trước (góc 0)", 90: "Mặt đứng B – tủ xoay 90", 180: "Mặt đứng C – tủ xoay 180 (đảo / nhìn từ phía sau)", 270: "Mặt đứng D – tủ xoay 270"}


def _xoay(t, x, z):
    """điểm (x, z) toạ độ tủ -> toạ độ phòng (tủ đặt tại t.x,t.z xoay t.goc quanh gốc tủ, như three.js rotation.y)"""
    a = math.radians(t["goc"]); c, s = math.cos(a), math.sin(a)
    return t["x"] + x * c + z * s, t["z"] - x * s + z * c


class _Ve:
    def __init__(self, c, F, FB): self.c, self.F, self.FB = c, F, FB

    def khung(self, job, tieu_de, trang, tong, en=False):
        c, W, H = self.c, A3[0], A3[1]
        c.setStrokeColorRGB(*INK); c.setLineWidth(1); c.rect(24, 24, W - 48, H - 48); c.line(24, 76, W - 24, 76)
        c.setFillColorRGB(*INK); c.setFont(self.FB, 16); c.drawString(38, 50, "TPW GROUP"); c.setFont(self.F, 8); c.drawString(38, 37, "Javis Studio – joinery drawing" if en else "Javis Studio – bản vẽ tủ")
        c.setFont(self.FB, 12); c.drawString(230, 54, tieu_de); c.setFont(self.F, 9)
        c.drawString(230, 38, f"Job {job.get('so', '')} – {job.get('ten', '')}   ·   {datetime.date.today().strftime('%d/%m/%Y')}   ·   " + ("all dimensions mm" if en else "kích thước mm, tủ đánh số như trong Studio"))
        c.setFont(self.FB, 13); c.drawRightString(W - 38, 44, f"{trang}/{tong}")

    def kich(self, x1, y1, x2, y2, txt, off=0, size=7):
        c = self.c; c.setStrokeColorRGB(*GREY); c.setLineWidth(0.5); c.line(x1, y1, x2, y2); hz = abs(y2 - y1) < 0.1
        for x, y in ((x1, y1), (x2, y2)):
            c.line(x - (0 if hz else 3), y - (3 if hz else 0), x + (0 if hz else 3), y + (3 if hz else 0))
        c.setFillColorRGB(*INK); c.setFont(self.F, size)
        if hz: c.drawCentredString((x1 + x2) / 2, y1 + 2.5 + off, txt)
        else:
            c.saveState(); c.translate(x1 - 3 - off, (y1 + y2) / 2); c.rotate(90); c.drawCentredString(0, 0, txt); c.restoreState()

    def hop(self, x, y, w, h, mau, vien=None, lw=0.5):
        c = self.c; c.setFillColorRGB(*mau); c.setStrokeColorRGB(*(vien or (1, 1, 1))); c.setLineWidth(lw); c.rect(x, y, w, h, stroke=1, fill=1)


def _mat_bang(v, job, kq, vung):
    """mặt bằng: vẽ từng tủ theo khối nhìn từ trên (x,z), số tủ, kích thước hàng góc 0 và góc 180"""
    c = v.c; tu = kq["tu"]
    if not tu: return
    pts = []
    for t in tu:
        for k in t["khoi"]:
            bx, by, bz, sx, sy, sz = k["b"]
            for x, z in ((bx, bz), (bx + sx, bz), (bx, bz + sz), (bx + sx, bz + sz)): pts.append(_xoay(t, x, z))
    x0 = min(p[0] for p in pts) - 150; x1 = max(p[0] for p in pts) + 150; z0 = min(p[1] for p in pts) - 150; z1 = max(p[1] for p in pts) + 150
    X, Y, W, H = vung; s = min(W / (x1 - x0), H / (z1 - z0))
    P = lambda x, z: (X + (x - x0) * s, Y + H - (z - z0) * s)       # z tăng = về phía trước = xuống dưới trang
    for t in sorted(tu, key=lambda t: -(t["y"] + t["h"])):               # tủ cao vẽ trước, tủ thấp đè lên
        for k in t["khoi"]:
            if k["k"] in ("tay", "khung", "khoet") or k["r"] == "chan": continue
            bx, by, bz, sx, sy, sz = k["b"]
            q = [P(*_xoay(t, x, z)) for x, z in ((bx, bz), (bx + sx, bz), (bx + sx, bz + sz), (bx, bz + sz))]
            p = c.beginPath(); p.moveTo(*q[0])
            for a in q[1:]: p.lineTo(*a)
            p.close(); c.setFillColorRGB(*MAU.get(k["r"], LITE)); c.setStrokeColorRGB(0.55, 0.55, 0.58); c.setLineWidth(0.3); c.drawPath(p, stroke=1, fill=1)
        cx, cz = _xoay(t, t["w"] / 2, t["d"] / 2); px, py = P(cx, cz)
        if t["loai"] in ("tam",) and t["w"] < 60 and t["h"] < 60: continue
        if t["loai"] in ("tam", "mat_da"): continue
        c.setFillColorRGB(1, 1, 1); c.circle(px, py, 6.5, stroke=0, fill=1); c.setFillColorRGB(*INK); c.setFont(v.FB, 6.5); c.drawCentredString(px, py - 2.3, str(t["so"]))
    for t in tu:                                                        # lỗ khoét bếp / chậu trên mặt đá: nét đứt + kích thước + dấu tâm
        for k in t["khoi"]:
            if k["k"] != "khoet": continue
            bx, by, bz, sx, sy, sz = k["b"]
            q = [P(*_xoay(t, x, z)) for x, z in ((bx, bz), (bx + sx, bz), (bx + sx, bz + sz), (bx, bz + sz))]
            p = c.beginPath(); p.moveTo(*q[0])
            for a_ in q[1:]: p.lineTo(*a_)
            p.close(); c.setFillColorRGB(1, 1, 1); c.setStrokeColorRGB(*INK); c.setLineWidth(0.7); c.setDash(3, 2); c.drawPath(p, stroke=1, fill=0); c.setDash()
            mx, my = P(*_xoay(t, bx + sx / 2, bz + sz / 2)); hz = abs(q[0][1] - q[3][1]) / 2      # nhãn ở nửa trên / dưới lỗ, chừa giữa cho số tủ
            c.setFillColorRGB(*INK); c.setFont(v.F, 6); c.drawCentredString(mx, my + hz * 0.55, ("CHẬU " if "chậu" in k["n"] else "BẾP ") + f"{sx:.0f}×{sz:.0f}")
            c.setFont(v.F, 5.5); c.drawCentredString(mx, my - hz * 0.65, f"tâm {bx + sx / 2:.0f} từ đầu đá")
    for goc, dy in ((0, 1), (180, -1)):
        hang = sorted([t for t in tu if t["goc"] == goc and t["loai"] not in ("tam", "mat_da") and t["loai"] not in TU_TREO], key=lambda t: t["x"])
        if not hang: continue
        zf = max((_xoay(t, 0, t["d"])[1] for t in hang)) if goc == 0 else min((_xoay(t, 0, t["d"])[1] for t in hang))
        yy = P(0, zf)[1] - 14 if goc == 0 else P(0, zf)[1] + 14
        xs = sorted({round(_xoay(t, 0, 0)[0], 1) for t in hang} | {round(_xoay(t, t["w"], 0)[0], 1) for t in hang})
        for a, b in zip(xs, xs[1:]):
            if b - a >= 60: v.kich(P(a, 0)[0], yy, P(b, 0)[0], yy, f"{b - a:.0f}", size=6)
        v.kich(P(xs[0], 0)[0], yy - 16 * dy, P(xs[-1], 0)[0], yy - 16 * dy, f"{xs[-1] - xs[0]:.0f}")
    c.setFillColorRGB(*GREY); c.setFont(v.F, 7); c.drawString(X, Y - 10, f"Tỷ lệ 1:{(1 / s) / (25.4 / 72):.0f}")


def _mat_dung(v, kq, goc, vung):
    """mặt đứng của các tủ cùng góc xoay: trục ngang = X cục bộ của tủ (chiếu lên hướng nhìn), trục dọc = cao"""
    c = v.c; tu = [t for t in kq["tu"] if t["goc"] == goc]
    if not tu: return False
    # toạ độ ngang trên mặt đứng: với góc 0 = x phòng; 90 = -z phòng; 180 = -x; 270 = z  (nhìn từ trước tủ)
    def hx(t, x):
        X, Z = _xoay(t, x, 0)
        return {0: X, 90: -Z, 180: -X, 270: Z}[goc]
    xa = min(min(hx(t, 0), hx(t, t["w"])) for t in tu) - 100; xb = max(max(hx(t, 0), hx(t, t["w"])) for t in tu) + 100
    ya = 0; yb = max(t["y"] + t["h"] for t in tu) + 150
    X, Y, W, H = vung; s = min(W / (xb - xa), H / (yb - ya))
    P = lambda x, y: (X + (x - xa) * s, Y + (y - ya) * s)
    c.setStrokeColorRGB(*GREY); c.setLineWidth(0.6); c.line(X - 20, P(0, 0)[1], X + (xb - xa) * s + 20, P(0, 0)[1])
    # thứ tự: thùng -> mặt -> đá -> tay
    thu = {"thung": 0, "kl": 1, "mat": 2, "da": 3, "chan": 0, "tay": 4}
    for t in sorted(tu, key=lambda t: t["z"]):
        kh = sorted(t["khoi"], key=lambda k: (thu.get(k["r"], 1), k["b"][2] + k["b"][5]))
        for k in kh:
            bx, by, bz, sx, sy, sz = k["b"]
            if k["k"] == "khung": continue
            if k["r"] == "thung" and k["k"] in ("hau", "ke", "hoc"): continue
            if sx <= 0 or sy <= 0: continue
            x1, x2 = sorted((hx(t, bx), hx(t, bx + sx))); yy = t["y"] + by
            px, py = P(x1, yy); w, h = (x2 - x1) * s, sy * s
            if k["r"] == "tay": v.hop(px, py, max(w, 1.5), max(h, 1.5), MAU["tay"], MAU["tay"])
            elif k["k"] == "thiet_bi": v.hop(px, py, w, h, (0.2, 0.2, 0.22), (0.4, 0.4, 0.4))
            else: v.hop(px, py, w, h, MAU.get(k["r"], LITE), (1, 1, 1) if k["r"] == "mat" else (0.6, 0.6, 0.62), 0.6 if k["r"] == "mat" else 0.3)
        if t["loai"] in ("tam", "mat_da"): continue
        cx = (hx(t, 0) + hx(t, t["w"])) / 2; px, py = P(cx, t["y"] + t["h"] + (120 if t["loai"] not in TU_TREO and t["h"] < 1200 else 40))
        c.setFillColorRGB(1, 1, 1); c.circle(px, py, 6.5, stroke=0, fill=1); c.setFillColorRGB(*INK); c.setFont(v.FB, 6.5); c.drawCentredString(px, py - 2.3, str(t["so"]))
    # kích thước ngang: hàng dưới + cao, hàng treo
    for la_treo, dy in ((False, -12), (True, -28)):
        hang = [t for t in tu if (t["loai"] in TU_TREO) == la_treo and t["loai"] not in ("tam", "mat_da")]
        if not hang: continue
        xs = sorted({round(hx(t, 0), 1) for t in hang} | {round(hx(t, t["w"]), 1) for t in hang})
        yy = P(0, 0)[1] + dy
        for a, b in zip(xs, xs[1:]):
            if b - a >= 60: v.kich(P(a, 0)[0], yy, P(b, 0)[0], yy, f"{b - a:.0f}", size=6)
        if not la_treo: v.kich(P(xs[0], 0)[0], yy - 32, P(xs[-1], 0)[0], yy - 32, f"{xs[-1] - xs[0]:.0f}")
    ys = sorted({0.0} | {round(t["y"], 1) for t in tu if t["loai"] != "tam"} | {round(t["y"] + t["h"], 1) for t in tu if t["loai"] != "tam"})
    xx = X - 14
    for a, b in zip(ys, ys[1:]):
        if b - a >= 40: v.kich(xx, P(0, a)[1], xx, P(0, b)[1], f"{b - a:.0f}", size=6)
    v.kich(xx - 16, P(0, 0)[1], xx - 16, P(0, ys[-1])[1], f"{ys[-1]:.0f}")
    return True


def _vat_lieu(v, jr, x, y, v_job=None):
    """ghi chú vật liệu dùng trong phòng (dưới bảng tủ)"""
    from engine import VAT_LIEU
    v_job = v_job or {}; c = v.c; dung = {}
    for t in jr.get("tu", []):
        for k, vai in (("vl_mat", "Cánh / mặt"), ("vl_thung", "Thùng")):
            vl = t.get(k)
            if vl: dung.setdefault(vai, set()).add(vl)
    c.setFont(v.FB, 7.5); c.setFillColorRGB(*INK); c.drawString(x, y, "Vật liệu"); y -= 10; c.setFont(v.F, 7)
    for vai, ds in dung.items():
        for vl in sorted(ds):
            m = (jr.get("mau") or v_job.get("mau") or {}).get({"HMR16": "thung", "MAU16B": "mat2"}.get(vl, "mat")) or {} if (vai != "Thùng" or vl == "HMR16") else {}
            ten_m = (" – màu " + str(m.get("ten"))) if m.get("ten") else ""
            c.drawString(x, y, f"{vai}: {VAT_LIEU.get(vl, {}).get('ten', vl)}{ten_m}"[:80]); y -= 9
    mo = {t.get("mo") for t in jr.get("tu", []) if t.get("mo")}
    if mo: c.drawString(x, y, "Mở: " + ", ".join({"tay_nam": "tay nắm", "shadowline": "shadowline (fingerpull)", "push": "bấm mở"}.get(m, m) for m in sorted(mo))); y -= 9
    return y


def _iso(v, kq, vung):
    """hình 3D isometric cả phòng (trang đầu, như bản vẽ CV của Huân): vẽ từ khối đã dựng, nhìn từ trước-phải-trên, mặt khuất vẽ trước"""
    c = v.c; X, Y, W, H = vung
    # hướng nhìn: phía trước trung bình của các tủ (mặt cánh quay về đâu thì đứng phía đó nhìn) + từ trên xuống
    fx = fz = 0.0
    for t in kq["tu"]:
        if t["loai"] in ("tam", "mat_da"): continue
        a = math.radians(t["goc"]); fx += math.sin(a); fz += math.cos(a)
    sx_ = (1 if fx > 0.15 else -1 if fx < -0.15 else 0.6); sz_ = (1 if fz > 0.15 else -1 if fz < -0.15 else 0.6)
    n0 = math.sqrt(sx_ * sx_ + 1 + sz_ * sz_); V = (sx_ / n0, 1 / n0, sz_ / n0)
    r = (V[2], 0.0, -V[0]); nr = math.hypot(r[0], r[2]) or 1; r = (r[0] / nr, 0.0, r[2] / nr)
    up = (V[1] * r[2] - V[2] * r[1], V[2] * r[0] - V[0] * r[2], V[0] * r[1] - V[1] * r[0])
    pj = lambda x, y, z: (x * r[0] + z * r[2], x * up[0] + y * up[1] + z * up[2])
    MAT = [(0, 1, 2, 3), (4, 5, 6, 7), (0, 1, 5, 4), (3, 2, 6, 7), (0, 3, 7, 4), (1, 2, 6, 5)]
    ds = []
    for t in kq["tu"]:
        a = math.radians(t["goc"]); ca, sa = math.cos(a), math.sin(a)
        for k in t["khoi"]:
            bx, by, bz, sx, sy, sz = k["b"]
            if k["k"] == "khung" or sx <= 0 or sy <= 0 or sz <= 0: continue
            if k["r"] == "thung" and k["k"] in ("hau", "ke", "hoc"): continue
            pts = []
            for (u, w, e) in ((0, 0, 0), (sx, 0, 0), (sx, sy, 0), (0, sy, 0), (0, 0, sz), (sx, 0, sz), (sx, sy, sz), (0, sy, sz)):
                wx, wz = _xoay(t, bx + u, bz + e); pts.append((wx, t["y"] + by + w, wz))
            mau = (0.2, 0.2, 0.22) if k["k"] == "thiet_bi" else MAU.get(k["r"], LITE)
            ds.append((sum(p[0] * V[0] + p[1] * V[1] + p[2] * V[2] for p in pts) / 8, pts, mau))
    if not ds: return False
    P2 = [pj(*p) for _, pts, _ in ds for p in pts]
    ua, ub = min(p[0] for p in P2), max(p[0] for p in P2); va, vb = min(p[1] for p in P2), max(p[1] for p in P2)
    s = min(W / max(ub - ua, 1), H / max(vb - va, 1)) * 0.95; ox = X + (W - (ub - ua) * s) / 2; oy = Y + (H - (vb - va) * s) / 2
    Q = lambda p: (ox + (pj(*p)[0] - ua) * s, oy + (pj(*p)[1] - va) * s)
    c.setLineWidth(0.25); c.setStrokeColorRGB(0.35, 0.35, 0.37)
    mats = []                                                   # vẽ theo TỪNG MẶT (gần cuối cùng), không theo tâm khối – đỡ đè sai
    for _, pts, mau in ds:
        cx = sum(p[0] for p in pts) / 8; cy = sum(p[1] for p in pts) / 8; cz = sum(p[2] for p in pts) / 8
        for f in MAT:
            q = [pts[i] for i in f]; mx = sum(p[0] for p in q) / 4; my = sum(p[1] for p in q) / 4; mz = sum(p[2] for p in q) / 4
            fx, fy, fz = mx - cx, my - cy, mz - cz
            if fx * V[0] + fy * V[1] + fz * V[2] <= 1e-6: continue          # mặt quay ra sau (khuất)
            n = math.sqrt(fx * fx + fy * fy + fz * fz) or 1; sang = 0.72 + 0.28 * (0.2 * fx * V[0] + 1.0 * fy + 0.6 * fz * V[2]) / n
            sau = mx * V[0] + my * V[1] + mz * V[2]; gan = max(p[0] * V[0] + p[1] * V[1] + p[2] * V[2] for p in q)
            mats.append((sau, gan, q, [min(1, m * sang) for m in mau]))
    for _, _, q, m in sorted(mats, key=lambda d: (d[0], d[1])):
        c.setFillColorRGB(*m)
        pa = c.beginPath(); x0, y0 = Q(q[0]); pa.moveTo(x0, y0)
        for p in q[1:]: pa.lineTo(*Q(p))
        pa.close(); c.drawPath(pa, stroke=1, fill=1)
    return True


def _khung_ten(v, jr, kq, x, y, v_job=None, en=False):
    """khung tên như bản vẽ CV của Huân: CABINET DOORS / CONSTRUCTION / DRAWER SYSTEM / HINGE SYSTEM / HANDLES / BENCHTOP"""
    from engine import VAT_LIEU, HE_HOC
    c = v.c; tu = [t for t in jr.get("tu", []) if not t.get("auto")]; md = (jr.get("mac_dinh") or (v_job or {}).get("mac_dinh") or {})
    mau = jr.get("mau") or (v_job or {}).get("mau") or {}
    def ten_vl(vl, vai):
        m = mau.get({"HMR16": "thung", "MAU16B": "mat2"}.get(vl, "mat")) or {}
        return VAT_LIEU.get(vl, {}).get("ten", vl) + ((" – " + str(m.get("ten"))) if m.get("ten") and (vai == "mat" or vl == "HMR16") else "")
    pk = kq.get("phu_kien") or {}
    pkd = pk if isinstance(pk, dict) else {}
    ray = sorted({HE_HOC.get(t.get("ray") or md.get("ray") or "tandembox", HE_HOC["tandembox"])["ten"] if (t.get("ray") or md.get("ray") or "tandembox") != "go" else "Hộc gỗ + ray âm"
                  for t in tu if t.get("loai") in ("duoi_hoc", "lo_nuong") or t.get("hoc_trong") or t.get("ray")})
    co_hoc = any("Ray hộc" in k or "SPACE CORNER" in k for k in (pkd or {k: 1 for k in pk}))
    ban_le = [f"{k} ×{n}" if pkd else k for k, n in ((pkd.items()) if pkd else ((k, 0) for k in pk)) if "Bản lề" in k or "Aventos" in k]
    dong = [
        ("CÁNH / MẶT (DOORS)", "; ".join(sorted({ten_vl(t.get("vl_mat"), "mat") + (" – shaker" if t.get("kieu_canh") == "shaker" else " – phẳng") for t in tu if t.get("vl_mat")})) or "–"),
        ("KIỂU MỞ (HANDLES)", ", ".join(sorted({{"tay_nam": "tay nắm", "shadowline": "shadowline / fingerpull 50", "push": "bấm mở (push)"}.get(t.get("mo"), t.get("mo")) for t in tu if t.get("mo")})) or "–"),
        ("THÙNG (CONSTRUCTION)", "; ".join(sorted({ten_vl(t.get("vl_thung"), "thung") for t in tu if t.get("vl_thung")})) or "–"),
        ("HỆ NGĂN KÉO (DRAWER SYSTEM)", ", ".join(ray) if (ray and co_hoc) else "không có ngăn kéo"),
        ("BẢN LỀ (HINGE SYSTEM)", "; ".join(ban_le[:4]) or "–"),
        ("CHÂN / KICK", ", ".join(sorted({f"{float(t.get('chan') or 0):.0f}" for t in tu if float(t.get("chan") or 0) > 0})) or "–"),
        ("MẶT ĐÁ (BENCHTOP)", ", ".join(sorted({f"{float(t.get('day_da') or t.get('h') or 0):.0f} dày" for t in tu if t.get("loai") == "mat_da"})) or "–"),
    ]
    kb = [f"{(t.get('spec') or {}).get('ten') or t.get('ma_may') or 'bếp'} {float(t.get('bep_rong') or (t.get('spec') or {}).get('khoet_rong') or 0):.0f}×{float(t.get('bep_sau') or (t.get('spec') or {}).get('khoet_sau') or 0):.0f}"
          for t in tu if t.get("loai") == "mat_da" and float(t.get("bep_rong") or (t.get("spec") or {}).get("khoet_rong") or 0) > 0]
    kb += [f"chậu {(t.get('spec') or {}).get('ten') or t.get('ma_may')} {float(t['spec']['khoet_rong']):.0f}×{float(t['spec']['khoet_sau']):.0f}" for t in tu
           if t.get("loai") in ("duoi_chau", "goc_l") and isinstance(t.get("spec"), dict) and t["spec"].get("loai_may") == "sink" and t["spec"].get("khoet_rong") and t["spec"].get("khoet_sau")]
    if kq.get("ghi_chu") and not en: kb = [g.split(":", 1)[-1].strip() for g in kq["ghi_chu"]]     # có vị trí (tâm cách đầu trái, cách mép trước)
    if en:                                                              # tiếng Anh: dựng từ số liệu
        kb = [f"#{t['so']} {'sink' if 'chậu' in k['n'] else 'cooktop'} {k['b'][3]:.0f}×{k['b'][5]:.0f}, centre {k['b'][0] + k['b'][3] / 2:.0f} from left end" for t in kq["tu"] if t["loai"] == "mat_da" for k in t["khoi"] if k["k"] == "khoet"]
        dong = [(lb[lb.index("(") + 1:lb.rindex(")")] if "(" in lb else {"CHÂN / KICK": "KICK HEIGHT"}.get(lb, lb), val) for lb, val in dong]
    if kb: dong.append(("CUT-OUTS" if en else "LỖ KHOÉT BẾP / CHẬU (CUT-OUTS)", "; ".join(kb)))
    def boc(txt, n=78, toi_da=3):                                  # xuống dòng theo "; " / ", " cho vừa khung
        out, cur = [], ""
        for w in str(txt).replace("; ", ";\x00").replace(", ", ",\x00").split("\x00"):
            if cur and len(cur) + 1 + len(w) > n: out.append(cur); cur = w
            else: cur = (cur + " " + w) if cur else w
        out.append(cur); return [o[:n + 6] for o in out][:toi_da]
    if en: dong = [(lb, dich_en(val)) for lb, val in dong]
    dd = [(lb, boc(val, n=66, toi_da=10) if "CUT-OUT" in lb else boc(val)) for lb, val in dong]; cao = 16 + sum(10 + 9.5 * len(ls) + 7 for _, ls in dd)
    c.setStrokeColorRGB(*INK); c.setLineWidth(0.8); c.rect(x - 6, y - cao + 8, 330, cao + 4)
    c.setFont(v.FB, 9); c.setFillColorRGB(*INK); c.drawString(x, y, "TITLE BLOCK – MATERIALS & HARDWARE" if en else "KHUNG TÊN – VẬT LIỆU & PHỤ KIỆN"); y -= 16
    for lb, ls in dd:
        c.setFont(v.FB, 7); c.setFillColorRGB(*GREY); c.drawString(x, y, lb); y -= 10
        c.setFont(v.F, 7.5); c.setFillColorRGB(*INK)
        for l in ls: c.drawString(x + 6, y, l); y -= 9.5
        y -= 7
    return y


def _bang_tu(v, kq, vung):
    c = v.c; X, Y, W, H = vung; y = Y + H
    c.setFont(v.FB, 7.5); c.setFillColorRGB(*INK)
    for i, (tx, t) in enumerate(((0, "#"), (16, "Tủ"), (150, "Rộng"), (182, "Cao"), (212, "Sâu"), (244, "Mở"), (292, "Ghi chú"))): c.drawString(X + tx, y, t)
    y -= 11; c.setFont(v.F, 7)
    for t in kq["tu"]:
        if y < Y: c.drawString(X, y, "…"); break
        if t["loai"] == "tam" and t.get("ten", "").startswith(("Kickface", "Bulkhead", "Filler", "Panel", "BC")): ten = t.get("ten", "")
        else: ten = t.get("ten") or THU_VIEN[t["loai"]]["ten"]
        c.drawString(X, y, str(t["so"])); c.drawString(X + 16, y, ten[:30]); c.drawRightString(X + 176, y, f"{t['w']:.0f}"); c.drawRightString(X + 206, y, f"{t['h']:.0f}"); c.drawRightString(X + 236, y, f"{t['d']:.0f}")
        c.drawString(X + 244, y, "" if t["loai"] in ("mat_da", "tam") else {"shadowline": "SL", "tay_nam": "tay", "push": "push"}.get(t.get("mo", ""), "")); y -= 9.5
    return y



def _da(kq, jr):
    """danh sách tấm đá: (t, raw, lỗ[(tên, x0, z0, rộng, sâu)])"""
    out = []
    for i, t in enumerate(kq["tu"]):
        if t["loai"] != "mat_da": continue
        raw = jr["tu"][i] if i < len(jr["tu"]) else {}
        lo = [(("Chậu" if "chậu" in k["n"] else "Bếp"), k["b"][0], k["b"][2], k["b"][3], k["b"][5]) for k in t["khoi"] if k["k"] == "khoet"]
        out.append((t, raw, lo))
    return out


def _trang_da(v, job, jr, kq, ghi_chu=(), en=False):
    """trang gửi thợ đá: mỗi tấm nhìn từ trên (mép TRƯỚC ở dưới), kích thước tổng, lỗ khoét có định vị tâm từ đầu trái + mép trước"""
    c = v.c; ds = _da(kq, jr); E = (lambda vi, en_: en_ if en else vi)
    DAU = {"sát tường": "against wall", "sát tủ cao": "against tall cabinet", "nối mặt đá dãy A ở góc": "joins run A at corner", "lộ – phủ panel hông, mài": "exposed, over panel – polish", "lộ – mài": "exposed – polish", "kiểm": "check"}
    if not ds: return
    X, Y, W, H = 70, 110, 1050, 640
    L = max(float(t["w"]) for t, _, _ in ds); n = len(ds)
    them = sum(110 + 12 * len(lo) for _, _, lo in ds) + 12 * (len(ghi_chu) + 2) + 30   # chỗ chữ + đường kích thước + ghi chú cuối trang (điểm trang, không theo tỷ lệ)
    s = min((W - 60) / L, max(0.02, (H - them) / sum(float(t["d"]) for t, _, _ in ds))); y = Y + H
    for t, raw, lo in ds:
        w, d, h = float(t["w"]), float(t["d"]), float(t["h"]); y -= 40
        c.setFont(v.FB, 9); c.setFillColorRGB(*INK)
        dA = max([float(u["d"]) for u, _, _ in ds if (u.get("day") or "A") == "A"] or [-1])
        noi = E(" – đầu trái NỐI mặt đá dãy A ở góc", " – left end JOINS run A benchtop at corner") if t.get("day") in ("B", "C") and abs(float(raw.get("x") or 0) - dA) < 1 else ""
        dao = t.get("day") == "D"
        c.drawString(X, y, E(f"Mặt đá #{t['so']} (dãy {t.get('day') or 'A'}): {w:.0f} dài × {d:.0f} sâu × {h:.0f} dày", f"Benchtop #{t['so']} (run {t.get('day') or 'A'}): {w:.0f} long × {d:.0f} deep × {h:.0f} thick") + noi)
        y -= 14 + d * s; x0 = X + 30
        v.hop(x0, y, w * s, d * s, MAU["da"], vien=INK, lw=0.8)
        c.setFont(v.F, 6.5); c.setFillColorRGB(*GREY); c.drawCentredString(x0 + w * s / 2, y + 3, E("MÉP TRƯỚC (cạnh lộ – mài / hoàn thiện)", "FRONT EDGE (exposed – polish / finish)"))
        c.drawCentredString(x0 + w * s / 2, y + d * s - 9, E("LƯNG ĐẢO (cạnh lộ – mài)", "ISLAND BACK (exposed – polish)") if dao else E("sát tường (sau)", "against wall (back)"))
        v.kich(x0, y - 14, x0 + w * s, y - 14, f"{w:.0f}")
        c.setFont(v.F, 6.5); c.setFillColorRGB(*INK)
        c.saveState(); c.translate(x0 - 22, y + d * s / 2); c.rotate(90); c.drawCentredString(0, 0, E("Đầu trái: ", "Left end: ") + (DAU.get(str(raw.get("da_trai") or "kiểm"), str(raw.get("da_trai"))) if en else str(raw.get("da_trai") or "kiểm"))); c.restoreState()
        c.saveState(); c.translate(x0 + w * s + 10, y + d * s / 2); c.rotate(90); c.drawCentredString(0, 0, E("Đầu phải: ", "Right end: ") + (DAU.get(str(raw.get("da_phai") or "kiểm"), str(raw.get("da_phai"))) if en else str(raw.get("da_phai") or "kiểm"))); c.restoreState()
        v.kich(x0 - 8, y, x0 - 8, y + d * s, f"{d:.0f}")
        for kk in t["khoi"]:                                            # mối nối đá đề xuất: nét chấm gạch đỏ
            if kk["k"] != "noi": continue
            xn = x0 + (kk["b"][0] + 1) * s; c.setStrokeColorRGB(0.75, 0.2, 0.15); c.setLineWidth(1); c.setDash([6, 2, 1, 2]); c.line(xn, y - 4, xn, y + d * s + 4); c.setDash()
            c.setFillColorRGB(0.75, 0.2, 0.15); c.setFont(v.FB, 6.5); c.drawCentredString(xn, y + d * s + 7, E("NỐI ", "JOINT ") + f"{kk['b'][0] + 1:.0f}")
        c.setStrokeColorRGB(*INK)
        for k, (ten, bx, bz, sx, sz) in enumerate(lo):
            px, py = x0 + bx * s, y + (d - bz - sz) * s
            c.setStrokeColorRGB(*INK); c.setLineWidth(0.8); c.setDash(4, 2); c.rect(px, py, sx * s, sz * s, stroke=1, fill=0); c.setDash()
            mx = px + sx * s / 2; c.setLineWidth(0.4); c.line(mx, py - 3, mx, py + sz * s + 3)
            c.setFont(v.FB, 7); c.setFillColorRGB(*INK); c.drawCentredString(mx, py + sz * s / 2 + 2, (E(ten.upper(), {"Bếp": "COOKTOP", "Chậu": "SINK"}.get(ten, ten.upper()))) + f" {sx:.0f}×{sz:.0f}")
            v.kich(x0, y - 30 - 12 * k, mx, y - 30 - 12 * k, E(f"tâm {ten.lower()} ", {"Bếp": "cooktop centre ", "Chậu": "sink centre "}.get(ten, "centre ")) + f"{bx + sx / 2:.0f}", size=6)
            v.kich(px + sx * s + 6, y, px + sx * s + 6, py, f"{d - bz - sz:.0f}", size=6)
        y -= 56 + 12 * len(lo)
    y -= 4
    c.setFont(v.F, 7.5); c.setFillColorRGB(*INK)
    sb = [p for p in kq.get("splash") or [] if p.get("loai") == "da"]
    if sb:
        c.setFont(v.FB, 8); c.drawString(X, y, E("SPLASHBACK ĐÁ (cùng thợ đá): ", "STONE SPLASHBACK (same stonemason): ") + "; ".join(E(f"dãy {p['day']} {p['b'][3]:.0f} dài × {p['b'][4]:.0f} cao × {p['b'][5]:.0f} dày", f"run {p['day']} {p['b'][3]:.0f} long × {p['b'][4]:.0f} high × {p['b'][5]:.0f} thick") for p in sb)); y -= 13
        c.setFont(v.F, 7.5)
    if en:                                                              # ghi chú dựng lại bằng tiếng Anh từ số liệu (không dịch câu)
        ghi_chu = []
        for t, raw, lo in ds:
            for ten, bx, bz, sx, sz in lo:
                ghi_chu.append(f"Benchtop #{t['so']}: {'sink' if ten == 'Chậu' else 'cooktop'} cut-out {sx:.0f} × {sz:.0f}, centre {bx + sx / 2:.0f} from left end, {float(t['d']) - bz - sz:.0f} from front edge")
            nn = [kk["b"][0] + 1 for kk in t["khoi"] if kk["k"] == "noi"]
            if nn: ghi_chu.append(f"Benchtop #{t['so']}: suggested joint at " + ", ".join(f"{x:.0f}" for x in nn) + " from left end (stonemason to confirm with slab / veining)")
    for g in ghi_chu[:12]: c.drawString(X, y, "✎ " + g[:180]); y -= 11
    c.setFillColorRGB(*GREY); c.drawString(X, y - 4, E("Số lỗ khoét theo tài liệu hãng (xem link trong Studio). Thợ đá đo máy / chậu thật trước khi cắt. Kích thước mm.", "Cut-out sizes from manufacturer documents. Stonemason to check the actual appliance / sink before cutting. All dimensions in mm."))


def ban_ve_da(path, job, en=False):
    """PDF riêng chỉ trang mặt đá – gửi thợ đá qua WhatsApp. Trả về số trang (0 = job không có mặt đá)."""
    from reportlab.pdfgen import canvas
    F, FB = _font()
    jr = dict(job, tu=job.get("tu", []), phong=job.get("phong") or {}); kq = dung_job(jr)
    if not _da(kq, jr): return 0
    c = canvas.Canvas(path, pagesize=A3); v = _Ve(c, F, FB)
    c.setTitle(f"Mat da {job.get('so', '')} {job.get('ten', '')}"); c.setAuthor("TPW GROUP – Javis Studio")
    v.khung(job, "BENCHTOP – FOR STONEMASON" if en else "MẶT ĐÁ – GỬI THỢ ĐÁ", 1, 1, en=en); _trang_da(v, job, jr, kq, kq.get("ghi_chu", []), en=en); c.showPage(); c.save(); return 1


# ---------------------------------------------------------------- bản vẽ tiếng Anh (builder / khách): dịch chữ khi vẽ
HUONG_EN = {0: "Elevation A – cabinets seen from the front (0°)", 90: "Elevation B – cabinets rotated 90°", 180: "Elevation C – cabinets rotated 180° (island / seen from behind)", 270: "Elevation D – cabinets rotated 270°"}
_EN_THEM = {
    "Panel hông": "End panel", "Panel hông tủ cao": "End panel – tall", "Panel hông tủ treo": "End panel – wall", "Panel hông tủ lạnh": "Fridge panel",
    "Panel hông nhánh dọc tủ góc L – sâu hết chữ L": "End panel – L-corner return", "Filler sát tường": "Wall filler", "Filler sát tường (tủ treo)": "Wall filler (wall cab)",
    "Filler góc": "Corner filler", "Filler góc (tủ treo)": "Corner filler (wall cab)", "Kickface": "Kickface", "Kickface góc L (nhánh dọc)": "Kickface L-corner return",
    "BC panel (đáy tủ treo)": "BC panel (under wall cabs)", "Bulkhead / nẹp trần": "Bulkhead / ceiling strip", "Panel lưng đảo": "Island back panel",
    "Tấm rời (hông / filler / kicker)": "Loose panel (end / filler / kick)", "Hộp trên tủ lạnh": "Fridge top box",
    "Ván màu 16 có vân (cánh, mặt hộc)": "16 mm woodgrain board (doors, drawer fronts)", "MDF 18 sơn PU": "18 mm MDF, PU painted", "HMR trắng 16.4 (thùng tủ)": "16.4 mm white HMR (carcass)",
    "MDF 21 (cửa shaker sơn PU)": "21 mm MDF (shaker doors, PU)", "Ván MDF màu trơn 16 (màu 2 – trắng / be)": "16 mm plain MDF board (colour 2 – white / beige)",
    "Vật liệu": "Materials", "tay": "handle", "Tủ treo": "Wall cabinet", "Tủ": "Cabinet", "Rộng": "W", "Cao": "H", "Sâu": "D", "Mở": "Open", "Ghi chú": "Notes",
}
_EN_CUM = [("Bản lề giảm chấn + đế", "Soft-close hinge + plate"), ("Hộc gỗ + ray âm", "Timber drawer + undermount runner"), ("không có ngăn kéo", "no drawers"),
           (" dày", " thick"), ("Thùng:", "Carcass:"), ("Cánh / mặt:", "Doors / fronts:"), (" – màu ", " – colour "), ("Mở: ", "Opening: "), ("tay nắm", "handle"),
           ("bấm mở", "push to open"), (" – phẳng", " – flat"), ("Tỷ lệ", "Scale"), ("CHẬU ", "SINK "), ("BẾP ", "COOKTOP "), ("tâm ", "centre "), (" từ đầu đá", " from benchtop end"),
           ("Ván màu 16 có vân (cánh, mặt hộc)", "16 mm woodgrain board"), ("HMR trắng 16.4 (thùng tủ)", "16.4 mm white HMR"), ("MDF 18 sơn PU", "18 mm MDF, PU painted"),
           ("MDF 21 (cửa shaker sơn PU)", "21 mm MDF shaker, PU"), ("Ván MDF màu trơn 16 (màu 2 – trắng / be)", "16 mm plain MDF (colour 2)"),
           ("đế bắt lưng mặt mù", "plate on blind panel back"), ("Ray hộc", "Drawer runner"), ("Bản lề", "Hinge"), ("(bộ)", "(set)"), ("mặt đá", "benchtop")]


def _bang_en():
    import re, os
    d = {}
    try:
        u = open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "ui.html"), encoding="utf-8").read(); i = u.index("const EN={"); j = u.index("};", i)
        d = {k.replace("\\'", "'"): v.replace("\\'", "'") for k, v in re.findall(r"'((?:[^'\\]|\\.)*)':'((?:[^'\\]|\\.)*)'", u[i:j])}
    except Exception: pass
    d.update(_EN_THEM); return d


def dich_en(s, bang=None):
    s = str(s); bang = bang if bang is not None else _bang_en()
    if s in bang: return bang[s]
    for a, b_ in _EN_CUM: s = s.replace(a, b_)
    return s


def _dich_en(c):
    """bọc canvas: mọi chữ vẽ ra được dịch sang tiếng Anh (khớp nguyên câu trước, rồi thay cụm)"""
    bang = _bang_en()
    dich = lambda s: dich_en(s, bang)
    for ten in ("drawString", "drawCentredString", "drawRightString"):
        goc = getattr(c, ten)
        setattr(c, ten, (lambda g: lambda x, y, s, *a, **k: g(x, y, dich(s), *a, **k))(goc))
    return c

def ban_ve(path, job, en=False):
    """ghi PDF A3: mỗi PHÒNG: trang mặt bằng + bảng tủ, rồi mỗi hướng tủ 1 trang mặt đứng. Job nhiều phòng: gộp hết vào 1 file. Trả về số trang."""
    from reportlab.pdfgen import canvas
    F, FB = _font()
    rooms = [r for r in (job.get("rooms") or []) if r.get("tu")] if len(job.get("rooms") or []) > 1 else [dict(ten="", tu=job.get("tu", []), phong=job.get("phong") or {})]
    bo = []; BANG_EN = _bang_en() if en else {}
    for r in rooms:
        jr = dict(job, tu=r.get("tu") or [], phong=r.get("phong") or {}); kq = dung_job(jr)
        for i, t in enumerate(kq["tu"]):
            raw = jr["tu"][i] if i < len(jr["tu"]) else {}
            t["ten"] = raw.get("ten") or THU_VIEN[t["loai"]]["ten"]; t["mo"] = raw.get("mo", "")
            if en and t["ten"] not in BANG_EN and not t.get("auto") and not raw.get("auto"):      # tên tự đặt (từ bản vẽ) → tên loại tủ tiếng Anh + giữ tên gốc nếu không có dấu
                goc = THU_VIEN[t["loai"]]["ten"]; t["ten"] = BANG_EN.get(goc, goc)
        bo.append((r.get("ten") or "", jr, kq, [g for g in (0, 90, 180, 270) if any(t["goc"] == g for t in kq["tu"])]))
    tong = sum(2 + len(g) + (1 if _da(kq, jr) else 0) for _, jr, kq, g in bo); c = canvas.Canvas(path, pagesize=A3); v = _Ve(c, F, FB); so = 0
    c.setTitle(f"Ban ve {job.get('so', '')} {job.get('ten', '')}"); c.setAuthor("TPW GROUP – Javis Studio")
    if en: _dich_en(c)
    HG = HUONG_EN if en else HUONG
    for ten, jr, kq, gocs in bo:
        tp = (ten.upper() + " – ") if ten else ""
        so += 1; v.khung(job, tp + ("3D OVERVIEW + TITLE BLOCK" if en else "TỔNG QUAN 3D + KHUNG TÊN"), so, tong, en=en); _iso(v, kq, (50, 110, 760, 690)); _khung_ten(v, jr, kq, 846, 780, job, en=en); c.showPage()
        so += 1; v.khung(job, tp + ("PLAN + CABINET SCHEDULE" if en else "MẶT BẰNG + BẢNG TỦ"), so, tong, en=en); _mat_bang(v, jr, kq, (50, 110, 760, 690)); yb = _bang_tu(v, kq, (840, 160, 320, 640)); _vat_lieu(v, jr, 840, min(yb, 150) - 6, job); c.showPage()
        for g in gocs:
            so += 1; v.khung(job, tp + HG[g], so, tong, en=en); _mat_dung(v, kq, g, (90, 120, 1050, 660)); c.showPage()
        if _da(kq, jr): so += 1; v.khung(job, tp + ("BENCHTOP – FOR STONEMASON" if en else "MẶT ĐÁ – GỬI THỢ ĐÁ"), so, tong, en=en); _trang_da(v, job, jr, kq, kq.get("ghi_chu", []), en=en); c.showPage()
    c.save(); return tong
