"""Javis Studio - lõi dựng tủ: thư viện tủ tham số -> chi tiết (miếng ván, lỗ khoan, nẹp), khối 3D, phụ kiện.
Quy tắc lấy từ file Cabinet Vision của Huân (Puja Carmondy R4901, job 61, job 75) và lời dặn của anh Tan 19/11/2026.

Hệ toạ độ trong 1 tủ (mm): X ngang (0 = hông trái), Y cao (0 = đáy thùng), Z sâu (0 = lưng tủ sát tường, D = mép trước thùng).
Miếng ván 2D: x,y của miếng khi nằm trên bàn máy; cạnh 'L' x=0, 'R' x=w, 'B' y=0, 'T' y=h.
"""
from collections import Counter
import math, re

VAT_LIEU = {
    "HMR16": dict(ten="HMR trắng 16.4 (thùng tủ)", lz=16.4, lx=2410, ly=1210, mat="16MM WHITE HMR 24X12 PARTICLE BOARD ",
                  tnm="10_HMR", crc=1, c9=0, van=False, mau="#f3f0e9", ma="H"),
    "MAU16": dict(ten="Ván màu 16 có vân (cánh, mặt hộc)", lz=16.0, lx=2410, ly=1210, mat="16MM GRAIN 1 -  24X12 MR MDF",
                  tnm="10_HMR", crc=2, c9=1, van=True, mau="#a9794f", ma="P"),
    "MAU16B": dict(ten="Ván MDF màu trơn 16 (màu 2 – trắng / be)", lz=16.0, lx=2410, ly=1210, mat="16MM COLOUR 2 -  24X12 MR MDF",
                  tnm="10_HMR", crc=2, c9=1, van=False, mau="#e6e1d7", ma="W"),
    "MDF18": dict(ten="MDF 18 sơn PU", lz=18.0, lx=3100, ly=1200, mat="go mdf",
                  tnm="10_MDF", crc=2, c9=0, van=False, mau="#e8e4dc", ma="M"),
    # cửa shaker: Studio CHƯA tự ra chương trình phay lòng -> không xuất .cix, chỉ ra danh sách để Huân làm
    "MDF21": dict(ten="MDF 21 (cửa shaker sơn PU)", lz=21.0, lx=3100, ly=1200, mat="21MM WHITE MDF",
                  tnm="10_HMR", crc=2, c9=0, van=False, mau="#eceae5", ma="S", cnc=False),
}
DA_DAY = (12, 18, 20, 30, 33, 40, 60, 100)          # 12 compact laminate, 18 / 33 laminate, 20–100 đá
RAY_NL = (270, 300, 350, 400, 450, 500, 550, 600)
DR = 12.002                # độ sâu lỗ ray hộc (đánh dấu để đổi hãng ray; khi xuất = 12)
# HỆ NGĂN KÉO THEO HÃNG (anh Tan 21/11: "cho đổi phụ kiện ngăn kéo theo hãng"). Số cắt ván 16 cho đáy / hậu:
# bb: đáy rộng = lòng tủ (LW) − bb; bl: đáy dài = ray (NL) − bl; rb: hậu rộng = LW − rb; hau: cao hậu theo 4 cỡ hộc (thấp / vừa / cao / rất cao)
# lo: True = mẫu lỗ ray + pát mặt giống Tandembox (CNC khoan); False = không khoan, thợ khoan theo dưỡng hãng. kiem: số đã đối chiếu catalog hãng
HE_HOC = {
    "tandembox": dict(ten="Blum Tandembox", bb=75.0, bl=24.4, rb=87.0, hau=(83.0, 134.0, 166.0, 198.0), lo=True, kiem=True,
                      nguon="Blum catalogue 2024: đáy LW−75 × NL−24, hậu LW−87 (CV MN Joinery dùng NL−24.4)"),
    "legrabox": dict(ten="Blum Legrabox", bb=35.0, bl=10.0, rb=38.0, hau=(63.0, 101.0, 148.0, 218.0), lo=False, kiem=True,
                     nguon="Blum catalogue 2022/24: đáy LW−35 × NL−10, hậu LW−38, cao hậu M 63 / K 101 / C 148 (F 218 chưa đối chiếu)"),
    "avantech": dict(ten="Hettich AvanTech YOU", bb=24.0, bl=26.0, rb=24.0, hau=(85.0, 123.0, 171.0, 235.0), lo=False, kiem=False,
                     nguon="Hettich AvanTech YOU 2020 (HAU): đáy LB−24 × NL−26, hậu LB−24; cao hậu Studio ước – CẦN KIỂM"),
    "nova_pro": dict(ten="Grass Nova Pro Scala", bb=58.0, bl=19.0, rb=58.0, hau=(70.0, 102.0, 169.0, 169.0), lo=False, kiem=False,
                     nguon="Grass Nova Pro Scala (catalogue + hướng dẫn lắp): hông 16 → EB 29, đáy = hậu = LWK − 2×29, đáy dài NL − 19 (hậu gỗ); cao hậu H90 70, H186 169; H122 Studio tạm 102 – CẦN KIỂM"),
    "atira": dict(ten="Hettich InnoTech Atira", bb=76.5, bl=3.0, rb=88.0, hau=(58.0, 100.0, 150.0, 150.0), lo=False, kiem=False,
                  nguon="Hettich: hậu LB − 2×12.5 − 63, đáy LB − 2×12.5 − 51.5, đáy dài NL − 3; cao hậu Studio ước – CẦN KIỂM"),
}


def ap_he_hoc(t, so, parts, aos, pk, cb):
    """đổi hộc kim loại đã dựng theo Tandembox sang hãng anh chọn ("ray"): sửa đáy / hậu / lỗ ray / pát mặt + tên phụ kiện"""
    k = t.get("ray") or "tandembox"
    if k == "go": k = "tandembox"           # hộc gỗ đã dựng riêng; phần còn lại (hộc trong, tủ lò…) vẫn Tandembox
    he = HE_HOC.get(k) or HE_HOC["tandembox"]
    co_hoc = any(p.get("loai") == "hoc" for p in parts)
    if k == "tandembox" or not co_hoc:
        for p in parts: p["holes"] = [(a, b, c, 12.0 if d == DR else d) for a, b, c, d in p["holes"]]
        return parts, pk
    dbl = he["bl"] - 24.4
    cap = {83.0: 0, 134.0: 1, 166.0: 2, 198.0: 3}
    for p in parts:
        if p.get("loai") == "hoc" and p["name"].startswith("Đáy hộc"):
            LW = p["w"] + 75.0; w2 = r1(LW - he["bb"]); x, y, z, dx, dy, dz = p["box"]; h2 = r1(p["h"] - dbl)
            p.update(w=w2, h=h2, holes=[], poly=[(w2, h2), (w2, 0.0), (0.0, 0.0), (0.0, h2)] if w2 >= h2 else [(w2, 0.0), (0.0, 0.0), (0.0, h2), (w2, h2)],
                     box=[round(v, 2) for v in (x - 37.5 + (LW - w2) / 2, y, z + dbl, w2, dy, h2)], note=f"{he['ten']}: bắt đáy theo hướng dẫn hãng")
        elif p.get("loai") == "hoc" and p["name"].startswith("Hậu hộc"):
            LW = p["w"] + 87.0; w2 = r1(LW - he["rb"]); h2 = he["hau"][cap.get(p["h"], 0)]; x, y, z, dx, dy, dz = p["box"]
            p.update(w=w2, h=h2, holes=[], poly=[(w2, h2), (w2, 0.0), (0.0, 0.0), (0.0, h2)] if w2 >= h2 else [(w2, 0.0), (0.0, 0.0), (0.0, h2), (w2, h2)],
                     box=[round(v, 2) for v in (x - 43.5 + (LW - w2) / 2, y, z + dbl, w2, h2, dz)])
        elif p.get("loai") == "mat_hoc" and not he["lo"]:
            if any(c == 10.0 for a, b, c, d in p["holes"]):
                p["holes"] = [q for q in p["holes"] if q[2] != 10.0]; p["note"] = ((p.get("note") or "") + " | " if p.get("note") else "") + f"Pát mặt {he['ten']}: khoan theo dưỡng hãng"
        if not he["lo"]: p["holes"] = [q for q in p["holes"] if q[3] != DR]
        else: p["holes"] = [(a, b, c, 12.0 if d == DR else d) for a, b, c, d in p["holes"]]
    for a in aos:
        if a.get("name") == "Thành hộc kim loại": a["name"] = f"Thành hộc {he['ten']}"
    pk2 = Counter()
    for kk, v in pk.items(): pk2[kk.replace("Tandembox", he["ten"])] += v
    if not he["lo"]: cb.append(f"#{so}: {he['ten']} – Studio chưa có mẫu lỗ ray / pát mặt của hãng: CNC KHÔNG khoan, thợ khoan theo dưỡng")
    if not he["kiem"]: cb.append(f"#{so}: số cắt đáy / hậu hộc {he['ten']} CHƯA đối chiếu catalog – nhờ Huân kiểm ({he['nguon']})")
    return parts, pk2
SL_H = 50.0          # shadowline cao 50 (khoét hông + thanh màu)
SL_CUA = 25.0        # cánh/mặt hộc shadowline lên cao chừa 25 dưới mặt đá (CV: SHDWLNE door top reveal 25, anh Tan 20/11)
HO = 1.5             # hở quanh cánh / mặt hộc
KHE = 3.0            # khe giữa 2 cánh / 2 mặt hộc

# ---------------------------------------------------------------- thư viện
THU_VIEN = {
    "duoi_canh": dict(ten="Tủ dưới – cánh", nhom="Tủ dưới", w=600, h=730, d=560, chan=130, canh=2, ban_le="L", ke=1, hoc_trong=0),
    "duoi_hoc": dict(ten="Tủ dưới – ngăn kéo", nhom="Tủ dưới", w=600, h=730, d=560, chan=130, hoc=3, ray="tandembox", sl_giua=False),
    "duoi_keo": dict(ten="Tủ kéo phụ kiện (BIN / spice rack)", nhom="Tủ dưới", w=450, h=730, d=560, chan=130, phu_kien="thung_rac"),
    "duoi_chau": dict(ten="Tủ chậu rửa", nhom="Tủ dưới", w=900, h=730, d=560, chan=130, canh=2, ban_le="L", ke=0),
    "treo": dict(ten="Tủ treo", nhom="Tủ treo", w=600, h=900, d=300, chan=0, y=1500, canh=2, ban_le="L", ke=1, lat=""),
    "hut_mui": dict(ten="Tủ treo hút mùi (rangehood)", nhom="Tủ treo", w=900, h=800, d=350, chan=0, y=1500, canh=2, ban_le="L", ke=1, kieu_hm="undermount", ma_may="", cat_w=862, cat_d=262, cat_truoc=40, buong=350),
    "cao": dict(ten="Tủ cao / pantry", nhom="Tủ cao", w=600, h=2270, d=579, chan=130, canh=2, ban_le="L", ke=4, ke_cd=1),
    "lo_nuong": dict(ten="Tủ lò nướng (oven tower)", nhom="Tủ cao", w=600, h=2270, d=579, chan=130, canh=1, ban_le="L", ke=2, hoc_duoi=2, lo_y=330, lo_cao=595, lo2_cao=380),
    "tu_ao": dict(ten="Tủ áo", nhom="Tủ cao", w=900, h=2270, d=579, chan=130, canh=2, ban_le="L", ke=1, ke_cd=1, thanh_treo=True, kieu_ao="1_treo"),
    "ke_mo": dict(ten="Kệ mở", nhom="Khác", w=600, h=900, d=300, chan=0, y=1500, ke=0, ke_cd=1, vl_thung="MAU16"),
    "tam": dict(ten="Tấm rời (hông / filler / kicker)", nhom="Khác", w=16, h=860, d=580, chan=0, huong="hong", vl_thung="MAU16"),
    "mat_da": dict(ten="Mặt đá / benchtop", nhom="Khác", w=2400, h=40, d=600, chan=0, y=860, day_da=40),
    "may_rua": dict(ten="Máy rửa chén (dishwasher)", nhom="Thiết bị", w=600, h=730, d=560, chan=130, mr_kieu="am", mr_bang=120),
    "tu_lanh": dict(ten="Tủ lạnh (fridge)", nhom="Thiết bị", w=600, h=2270, d=579, chan=130, tl_kieu="am", tl_cao=1780, tl_chia=0, tl_ban_le="co_dinh", canh=1, ban_le="L", ke=0),
    "thiet_bi": dict(ten="Thiết bị khác (khối chừa chỗ)", nhom="Thiết bị", w=600, h=860, d=580, chan=0),
    "tu_do": dict(ten="Đồ rời (nhập từ file chi tiết)", nhom="Khác", w=100, h=100, d=100, chan=0, an=True, chi_tiet=[]),
    "treo_goc": dict(ten="Tủ treo góc L (corner)", nhom="Tủ treo", w=600, h=850, d=600, chan=0, y=1500, ke=2, sau_nhanh=300),
    "goc45": dict(ten="Tủ góc chéo 45° (dưới)", nhom="Tủ dưới", w=900, h=730, d=900, chan=130, ke=1, sau_nhanh=580),
    "treo_goc45": dict(ten="Tủ treo góc chéo 45°", nhom="Tủ treo", w=600, h=850, d=600, chan=0, y=1500, ke=2, sau_nhanh=300),
    "cao_goc45": dict(ten="Tủ cao góc chéo 45° (pantry)", nhom="Tủ cao", w=900, h=2270, d=900, chan=130, ke=5, sau_nhanh=580),
    "cao_goc": dict(ten="Tủ cao góc L (corner pantry)", nhom="Tủ cao", w=900, h=2270, d=900, chan=130, ke=5, sau_nhanh=580),
    "cao_mu": dict(ten="Tủ cao góc mù (blind pantry)", nhom="Tủ cao", w=1100, h=2270, d=579, chan=130, canh=1, ke=4, ke_cd=1, cua_w=500, mu_ben="L"),
    "treo_mu": dict(ten="Tủ treo góc mù (blind)", nhom="Tủ treo", w=650, h=850, d=300, chan=0, y=1500, canh=1, ke=2, cua_w=310, mu_ben="L"),
    "goc_l": dict(ten="Tủ góc L (corner)", nhom="Tủ dưới", w=900, h=730, d=900, chan=130, canh=2, ke=1),
    "goc_mu": dict(ten="Tủ góc mù (blind corner)", nhom="Tủ dưới", w=1100, h=730, d=560, chan=130, canh=1, ke=1, cua_w=500, mu_ben="L"),
    "cong": dict(ten="Tủ cong bo cạnh (đầu hàng)", nhom="Tủ dưới", w=450, h=730, d=560, chan=130, ke=1, cong_ben="R"),
}
# MẪU NHANH (như catalog CV): cùng loại tủ gốc nhưng đặt sẵn tuỳ chọn – "_loai" = loại thật
THU_VIEN.update({
    "m_treo_hf": dict(_loai="treo", ten="Tủ treo cánh lật HF (Aventos)", nhom="Tủ treo", w=900, h=850, d=300, chan=0, y=1500, canh=0, ban_le="L", ke=1, lat="HF"),
    "m_vi_song": dict(_loai="duoi_canh", ten="Tủ dưới lò vi sóng + 1 hộc", nhom="Tủ dưới", w=600, h=730, d=560, chan=130, canh=0, ban_le="L", ke=0, vi_song=True, vs_hoc=300),
    "m_lo_duoi": dict(_loai="duoi_canh", ten="Hộc lò âm dưới bếp (oven)", nhom="Tủ dưới", w=600, h=730, d=560, chan=130, canh=0, ban_le="L", ke=0, lo_duoi=True),
    "m_hoc_trong": dict(_loai="duoi_canh", ten="Tủ dưới cánh + ngăn kéo trong", nhom="Tủ dưới", w=600, h=730, d=560, chan=130, canh=2, ban_le="L", ke=0, hoc_trong=2),
    "m_ao_chia": dict(_loai="tu_ao", ten="Tủ áo chia (hộc + kệ | treo)", nhom="Tủ cao", w=900, h=2270, d=579, chan=130, canh=2, ban_le="L", ke=2, ke_cd=1, thanh_treo=True, kieu_ao="chia", hoc_ao=4),
    "m_ruou": dict(_loai="duoi_canh", ten="Kệ rượu dưới (wine rack)", nhom="Tủ dưới", w=400, h=730, d=560, chan=130, canh=0, ruou=True, vl_thung="MAU16"),
    "m_ruou_cao": dict(_loai="cao", ten="Kệ rượu cao (wine rack)", nhom="Tủ cao", w=400, h=2270, d=400, chan=130, canh=0, ke=0, ke_cd=0, ruou=True, vl_thung="MAU16"),
    "m_pantry_hoc": dict(_loai="cao", ten="Pantry + ngăn kéo trong", nhom="Tủ cao", w=800, h=2270, d=579, chan=130, canh=2, ban_le="L", ke=3, ke_cd=1, hoc_trong=4),
})
CHUNG = dict(vl_thung="HMR16", vl_mat="MAU16", mo="tay_nam", kieu_canh="phang", sl_thanh=True, x=0, y=0, z=0, goc=0)
CO_CANH = ("duoi_canh", "duoi_hoc", "duoi_chau", "duoi_keo", "treo", "treo_goc", "treo_mu", "cao_mu", "cao_goc", "goc45", "treo_goc45", "cao_goc45", "hut_mui", "cao", "tu_ao", "lo_nuong", "may_rua", "tu_lanh", "goc_l", "goc_mu", "cong")
TU_CAO = ("cao", "tu_ao", "lo_nuong", "tu_lanh", "cao_mu", "cao_goc", "cao_goc45"); TU_TREO = ("treo", "hut_mui", "ke_mo", "treo_goc", "treo_mu", "treo_goc45"); TU_DUOI = ("duoi_canh", "duoi_hoc", "duoi_chau", "duoi_keo", "may_rua", "goc_l", "goc_mu", "cong", "goc45")
tl_roi = lambda t: t.get("loai") == "tu_lanh" and t.get("tl_kieu") == "roi"          # tủ lạnh rời: chỉ là khoảng chừa, không có thùng
PHU_KIEN_KEO = {"thung_rac": "Thùng rác kéo (BIN)", "ke_gia_vi": "Kệ gia vị kéo (spice rack)", "ke_keo": "Rổ / kệ kéo"}
THAM_SO = [  # (khoá, nhãn, kiểu, áp dụng cho)
    ("ten", "Tên", "text", None), ("w", "Rộng", "mm", None), ("h", "Cao", "mm", None), ("d", "Sâu", "mm", None),
    ("x", "Vị trí X", "mm", None), ("y", "Cao sàn", "mm", None), ("z", "Cách tường", "mm", None),
    ("goc", "Xoay", [0, 90, 180, 270], None), ("chan", "Chân tủ", "mm", ("duoi_canh", "duoi_hoc", "duoi_chau", "duoi_keo", "cao", "cao_mu", "cao_goc", "goc45", "cao_goc45", "tu_ao", "lo_nuong", "may_rua", "tu_lanh", "goc_l", "goc_mu", "cong")),
    ("tach", "Tách 2 thùng – thùng dưới cao (0 = 1 thùng)", "mm", ("cao", "tu_ao", "lo_nuong")),
    ("cua_w", "Cửa rộng (phần còn lại là mặt mù)", "mm", ("goc_mu", "treo_mu", "cao_mu")), ("mu_ben", "Mặt mù bên", ["L", "R"], ("goc_mu", "treo_mu", "cao_mu")),
    ("cong_ben", "Bo cong bên", ["L", "R"], ("cong",)),
    ("mr_kieu", "Kiểu máy rửa chén", ["am", "ban_am", "roi"], ("may_rua",)), ("mr_bang", "Bảng điều khiển cao (bán âm)", "mm", ("may_rua",)),
    ("tl_kieu", "Kiểu tủ lạnh", ["am", "roi"], ("tu_lanh",)), ("tl_cao", "Hộc tủ lạnh cao", "mm", ("tu_lanh",)), ("tl_chia", "Cửa dưới cao (0 = 1 cửa suốt)", "mm", ("tu_lanh",)),
    ("tl_ban_le", "Bản lề cửa tủ lạnh", ["co_dinh", "truot"], ("tu_lanh",)),
    ("tl_hop", "Tủ lạnh rời: hộp trên cao (0 = không; Eastwood 790, chừa khe 20 trên tủ lạnh)", "mm", ("tu_lanh",)), ("tl_panel", "Tủ lạnh rời: panel 2 bên sâu (mặc định 750)", "mm", ("tu_lanh",)),
    ("phu_kien", "Phụ kiện bên trong", ["thung_rac", "ke_gia_vi", "ke_keo"], ("duoi_keo",)),
    ("canh", "Số cánh", [0, 1, 2, 3, 4], ("duoi_canh", "duoi_chau", "treo", "hut_mui", "cao", "tu_ao", "lo_nuong", "tu_lanh")), ("canh", "Số cánh", [1, 2], ("treo_mu", "cao_mu")),
    ("canh", "Số cánh (3 = nhánh dài 2 cánh như CV 3 Door)", [2, 3], ("goc_l",)),
    ("ban_le", "Bản lề (1 cánh)", ["L", "R"], ("duoi_canh", "duoi_chau", "treo", "hut_mui", "cao", "tu_ao", "lo_nuong", "tu_lanh")),
    ("hoc_duoi", "Ngăn kéo dưới lò (0 = cánh)", [0, 1, 2, 3], ("lo_nuong",)), ("lo_y", "Đáy hộc lò (từ đáy tủ)", "mm", ("lo_nuong",)), ("lo_cao", "Hộc lò cao", "mm", ("lo_nuong",)), ("lo2_cao", "Hộc vi sóng cao (0 = không)", "mm", ("lo_nuong",)),
    ("kieu_hm", "Kiểu hút mùi", ["undermount", "slide", "fixed", "canopy"], ("hut_mui",)), ("ma_may", "Mã model thiết bị (bấm Tra spec)", "txt", ("hut_mui", "lo_nuong", "tu_lanh", "may_rua", "thiet_bi", "duoi_canh", "duoi_chau", "mat_da")), ("bep_rong", "Lỗ khoét bếp rộng (0 = không khoét)", "mm", ("mat_da",)), ("bep_sau", "Lỗ khoét bếp sâu", "mm", ("mat_da",)), ("bep_x", "Tâm lỗ bếp cách đầu trái mặt đá (0 = giữa)", "mm", ("mat_da",)), ("bep_truoc", "Lỗ bếp cách mép trước (0 = giữa chiều sâu)", "mm", ("mat_da",)), ("bep_gas", "Bếp GAS (kiểm khoảng cách hút mùi / tủ treo AS/NZS 5601)", "bool", ("mat_da",)), ("cat_w", "Lỗ khoét đáy rộng", "mm", ("hut_mui",)), ("cat_d", "Lỗ khoét đáy sâu", "mm", ("hut_mui",)),
    ("cat_truoc", "Lỗ khoét cách mặt trước", "mm", ("hut_mui",)), ("hm_cao", "Slide-out: cao máy dưới thùng", "mm", ("hut_mui",)), ("buong", "Buồng máy cao (tới kệ cố định)", "mm", ("hut_mui",)),
    ("hoc", "Số ngăn kéo", [1, 2, 3, 4, 5], ("duoi_hoc",)), ("hoc_cao", "Cao mặt hộc từ trên xuống (vd 145,255 – còn lại tự chia)", "text", ("duoi_hoc",)), ("ray", "Hệ ngăn kéo (hãng ray)", ["tandembox", "legrabox", "avantech", "nova_pro", "atira", "go"], ("duoi_hoc", "duoi_canh", "cao", "tu_ao", "lo_nuong")),
    ("sl_giua", "Shadowline giữa hộc", "bool", ("duoi_hoc",)),
    ("hoc_trong", "Ngăn kéo trong sau cánh (CV Inner Drawer)", [0, 1, 2, 3], ("duoi_canh",)), ("hoc_trong", "Ngăn kéo trong sau mặt hộc lớn (CV Drawer + Inner Drawer)", [0, 1, 2], ("duoi_hoc",)), ("hoc_trong", "Ngăn kéo trong sau cánh (CV Pantry INT Drawers)", [0, 1, 2, 3, 4, 5, 6], ("cao", "tu_ao")),
    ("vi_song", "Hộc lò vi sóng + 1 ngăn kéo dưới (CV UB Microwave Cab)", "bool", ("duoi_canh",)), ("vs_hoc", "Vi sóng: cao mặt hộc dưới", "mm", ("duoi_canh",)),
    ("lo_duoi", "Hộc lò âm dưới bếp (CV Underbench Oven – không cánh, không hậu)", "bool", ("duoi_canh",)),
    ("khong_day", "Không đáy (CV NO BOTTOM – tủ đứng trên mặt đá)", "bool", ("treo",)),
    ("keo_cao", "Pantry kéo (pull-out pantry – 1 mặt kéo suốt, khung kệ của hãng)", "bool", ("cao",)),
    ("vat", "Tủ vát 45° đầu hàng (CV 45 Deg) – bên ngắn", ["", "L", "R"], ("duoi_canh", "treo", "cao")),
    ("cua_lua", "Cửa lùa (sliding) – 2 ray, cánh chồng 30", "bool", ("treo", "cao", "duoi_canh", "tu_ao")),
    ("gap_doi", "Cánh gập (bi-fold) – mỗi bên 2 lá", "bool", ("treo", "cao", "duoi_canh", "tu_ao")),
    ("stack", "Né ống / cột sau tủ (CV WITH STACK)", ["", "L", "M", "R"], ("treo", "cao", "duoi_canh", "duoi_chau")), ("stack_w", "Né ống: rộng lỗ", "mm", ("treo", "cao", "duoi_canh", "duoi_chau")), ("stack_d", "Né ống: sâu từ tường", "mm", ("treo", "cao", "duoi_canh", "duoi_chau")),
    ("ruou", "Kệ rượu (wine rack) – lưới ô ~110 ráp rãnh, mặt trước để mở", "bool", ("duoi_canh", "treo", "cao", "ke_mo")),
    ("lat", "Cánh lật lên (Aventos HF 2 cánh gập / HK 1 cánh)", ["", "HF", "HK", "HS", "HL"], ("treo",)),
    ("ke", "Kệ di động", [0, 1, 2, 3, 4, 5, 6], ("duoi_canh", "duoi_chau", "treo", "treo_goc", "hut_mui", "cao", "tu_ao", "lo_nuong", "ke_mo", "tu_lanh", "goc_l", "goc_mu", "cong", "treo_mu", "cao_mu", "cao_goc", "goc45", "treo_goc45", "cao_goc45")),
    ("ke_cd", "Kệ cố định", [0, 1, 2, 3, 4], ("cao", "tu_ao", "ke_mo", "cao_mu")),
    ("ke_lui", "Kệ lùi so với mặt trước (CV Shelf Setback)", "mm", ("duoi_canh", "duoi_chau", "treo", "treo_goc", "treo_mu", "cao_mu", "cao_goc", "goc45", "treo_goc45", "cao_goc45", "hut_mui", "cao", "tu_ao", "lo_nuong", "tu_lanh", "goc_l", "goc_mu")),
    ("ke_bo", "Bo góc trong kệ / đáy chữ L (CV Shelf Radius)", "mm", ("goc_l", "treo_goc", "cao_goc")),
    ("sau_nhanh", "Sâu mỗi nhánh (tủ góc L / chéo)", "mm", ("treo_goc", "cao_goc", "goc45", "treo_goc45", "cao_goc45")),
    ("thanh_treo", "Thanh treo đồ", "bool", ("tu_ao",)),
    ("noc_lien", "Nóc liền (CV Add Full Top – tủ không mặt đá)", "bool", ("duoi_canh", "duoi_hoc", "duoi_chau", "duoi_keo")),
    ("kieu_ao", "Kiểu tủ áo (như CV)", ["1_treo", "2_treo", "ke", "chia"], ("tu_ao",)),
    ("hoc_ao", "Tủ áo chia: số ngăn kéo trong (bên trái)", [2, 3, 4, 5], ("tu_ao",)),
    ("ke_giay", "Kệ giày nghiêng dưới khoang treo (CV + Shoe)", [0, 1, 2], ("tu_ao",)),
    ("mo", "Kiểu mở", ["tay_nam", "shadowline", "push"], CO_CANH),
    ("space_corner", "Blum SPACE CORNER – ngăn kéo góc (CV 1 + 2 / 2 Equal / 3 Equal)", ["", "1+2", "2deu", "3deu"], ("goc_l",)), ("kieu_canh", "Kiểu cánh", ["phang", "shaker"], CO_CANH),
    ("sl_thanh", "Thanh shadowline 50 cùng màu cánh", "bool", ("duoi_canh", "duoi_hoc", "duoi_chau", "duoi_keo", "cao", "cao_mu", "tu_ao", "lo_nuong", "may_rua", "tu_lanh", "goc_l", "goc_mu", "cong")),
    ("day_da", "Dày mặt đá (mm – 12 compact, 18 / 33 laminate, 20 / 40 đá)", "mm", ("mat_da",)),
    ("huong", "Hướng tấm", ["hong", "dung", "nam"], ("tam",)),
    ("vl_thung", "Ván thùng", "vl", ("duoi_canh", "duoi_hoc", "duoi_chau", "duoi_keo", "treo", "treo_goc", "treo_mu", "cao_mu", "cao_goc", "goc45", "treo_goc45", "cao_goc45", "hut_mui", "cao", "tu_ao", "lo_nuong", "ke_mo", "tam", "tu_lanh", "goc_l", "goc_mu", "cong")),
    ("vl_mat", "Ván cánh/mặt", "vl", CO_CANH),
]


def tu_moi(loai, **kw):
    t = dict(CHUNG); t.update(THU_VIEN[loai]); t["loai"] = THU_VIEN[loai].get("_loai", loai); t.pop("_loai", None)
    for k in ("nhom",): t.pop(k, None)
    t.update(kw)
    if "mo" not in kw and ("shadowline" in kw or "tay_nam" in kw):
        t["mo"] = "shadowline" if kw.get("shadowline") else ("push" if kw.get("tay_nam") is False else "tay_nam")
    t.pop("shadowline", None); t.pop("tay_nam", None)
    return t


# ---------------------------------------------------------------- tiện ích miếng ván
def r1(v): return round(v + 0.0, 1)


# máy hút mùi âm tủ: mã -> lỗ khoét đáy + yêu cầu lòng tủ (lấy từ tờ hướng dẫn lắp của hãng; thêm model mới vào đây)
MAY_HUT_MUI = {
    "KSGAU9P4MB": dict(ten="Smeg KSGAU9P4MB 90cm undermount", cat_w=861, cat_d=255, cat_truoc=50, long_min=861, sau_min=310, ong=150, nguon="doc.smeg.it 914780208 (KSG9)"),
    "CV-MAC-DINH": dict(ten="Mặc định Cabinet Vision #14 (pocket 862 x 262)", cat_w=862, cat_d=262, cat_truoc=40, long_min=0, sau_min=0, ong=150, nguon="MN Joinery.cvc #416"),
    # đo trực tiếp trong Cabinet Vision (Part Sheet) 20/11/2026 – thư mục MN Joinery > RANGEHOODS
    #   kin=True: đáy là 1 TẤM LIỀN khoét lỗ kín (như CV), không cắt thanh trước / thanh sau
    #   khong_khoet=True: máy không ống gió, đáy liền không khoét
    #   u_w / u_fs: nóc + kệ cố định khoét chữ U rộng u_w, chừa dải trước u_fs (mặc định CV #14: 250 / 79)
    "P591": dict(ten="Smeg P591 60cm undermount", cat_w=497, cat_d=262, cat_truoc=10.8, long_min=497, sau_min=290, ong=150, kin=True,
                 nguon="CV MN Joinery 'SMEG P591 UNDERMOUNT': tủ 600x850x300, đáy 282.6x567.2 khoét 497x262 chừa 35.1 hai bên, 10.8 trước/sau"),
    "TH603S": dict(ten="TH603S non-duct (không ống gió)", cat_w=0, cat_d=0, cat_truoc=0, long_min=0, sau_min=0, ong=0, khong_khoet=True,
                   nguon="CV MN Joinery 'TH603S NON DUCT': đáy liền 283.6x437.2, không khoét"),
    # tra tài liệu hãng 21/11 03:15 (lỗ khoét đáy tủ W × D). Cách mặt trước chưa có trong tài liệu → để 40 như mặc định CV, KIỂM tờ lắp đi kèm máy
    "WRI515SC": dict(ten="Westinghouse WRI515SC 52cm integrated", cat_w=493, cat_d=262, cat_truoc=40, long_min=493, sau_min=0, ong=150,
                     cao_dien=600, cao_gas=650, cao_max=800, nguon_cao="sách lắp Westinghouse integrated (WRI514BB/WRI814BB cùng dòng): ≥600 trên bếp điện, ≥650 bếp gas, ≤800 – kiểm sách đúng mã", nguon="Westinghouse dimension & installation guide WRI515SC: cut-out 493 x 262, ống 150 (đáy tủ 12–23 dày)"),
    "WRI525BC": dict(ten="Westinghouse WRI525BC 52cm integrated", cat_w=493, cat_d=262, cat_truoc=40, long_min=493, sau_min=0, ong=150,
                     cao_dien=600, cao_gas=650, cao_max=800, nguon_cao="sách lắp Westinghouse integrated (WRI514BB/WRI814BB cùng dòng): ≥600 điện, ≥650 gas, ≤800 – kiểm sách đúng mã", nguon="Westinghouse WRI525BC: tờ kích thước ghi cut-out 493 x 362 – 362 > sâu máy 292 nên coi là in sai, Studio dùng 262 như WRI515SC (cùng khung 52cm) – PHẢI đo máy thật"),
    "WRI825BC": dict(ten="Westinghouse WRI825BC 86cm integrated", cat_w=833, cat_d=262, cat_truoc=40, long_min=833, sau_min=0, ong=150,
                     cao_dien=600, cao_gas=650, cao_max=800, nguon_cao="sách lắp Westinghouse integrated (WRI514BB/WRI814BB cùng dòng): ≥600 điện, ≥650 gas, ≤800 – kiểm sách đúng mã", nguon="Westinghouse dimension & installation guide WRI825BC: cut-out 833 x 262, ống 150 (đáy tủ 12–23 dày)"),
    "WRI700SB": dict(ten="Westinghouse WRI700SB 71cm integrated", cat_w=655, cat_d=276, cat_truoc=40, long_min=655, sau_min=0, ong=120,
                     nguon="Westinghouse factsheet WRI700SB: cut-out 655 x 276 (cao 200), ống 120"),
    "HP60IDCHX4": dict(ten="Fisher & Paykel HP60IDCHX4 60cm insert", cat_w=500, cat_d=260, cat_truoc=40, long_min=500, sau_min=0, ong=150,
                       cao_dien=600, cao_max=750, nguon_cao="F&P spec guide HP60IDCHX4: 600–750 từ mặt bếp tới đáy máy", nguon="F&P data sheet HP60IDCHX4: cutout 500 x 260, đáy tủ dày 15–40"),
    "HP60IDCHEX4": dict(ten="Fisher & Paykel HP60IDCHEX4 60cm insert (motor ngoài)", cat_w=500, cat_d=260, cat_truoc=40, long_min=500, sau_min=0, ong=200,
                        cao_dien=600, nguon_cao="F&P data sheet HP60IDCHEX4: tối thiểu 600 từ mặt bếp tới đáy máy (bếp yêu cầu cao hơn thì theo bếp)", nguon="F&P data sheet HP60IDCHEX4: cutout 500 x 260, ống 200, đáy tủ dày 15–40"),
    "HP60ICSX4": dict(ten="Fisher & Paykel HP60ICSX4 60cm insert", cat_w=460, cat_d=260, cat_truoc=40, long_min=460, sau_min=0, ong=150,
                      cao_dien=600, cao_max=750, nguon_cao="F&P spec guide HP60ICSX4: 600–750", nguon="F&P spec guide HP60ICSX4: cutout 460 x 260"),
    "HP90ICSX4": dict(ten="Fisher & Paykel HP90ICSX4 90cm insert", cat_w=760, cat_d=260, cat_truoc=40, long_min=760, sau_min=0, ong=150,
                      cao_dien=600, cao_max=750, nguon_cao="F&P spec guide HP90ICSX4: 600–750", nguon="F&P spec guide HP90ICSX4: cutout 760 x 260"),
    "CK2000LED": dict(ten="Smeg CK2000LED 76cm concealed", cat_w=725, cat_d=381, cat_truoc=10, long_min=725, sau_min=400, ong=200,
                      nguon="Smeg spec sheet CK2000LED: máy 760 x 400 x 357, cutout 725 x 381, ống 200 – tủ cần sâu >= 400"),
    "DFS097A50A": dict(ten="DFS097A50A 90cm", cat_w=None, cat_d=None, cat_truoc=None, long_min=0, sau_min=0, ong=150, u_w=266.4, u_fs=50.0,
                       nguon="CV MN Joinery 'DFS097A50A' (900x963x320): kệ cố định khoét U 266.4 x 253.6, dải trước 50. Lỗ đáy CHƯA đo – kiểm tờ lắp"),
}
MAY_BI_DANH = {"SMEGP591UNDERMOUNT": "P591", "SMEGP591": "P591", "TH603SNONDUCT": "TH603S", "DFS097450A": "DFS097A50A"}


def tra_may(ma):
    m = re.sub(r"[^0-9A-Za-z-]", "", str(ma or "")).upper()
    if not m: return ("", None)
    if m in MAY_HUT_MUI: return (m, MAY_HUT_MUI[m])
    k = MAY_BI_DANH.get(m) or next((k for k in MAY_HUT_MUI if k != "CV-MAC-DINH" and k in m), None)   # gõ "Smeg P591 undermount" vẫn ra P591
    return (m, MAY_HUT_MUI[k]) if k else (m, None)


def mieng(name, vl, w, h, box, holes=(), edges=(), e45=(), note="", poly=None, loai="thung", anim=None, rot=None):
    w, h = round(w, 2), round(h, 2)
    if poly is None:
        poly = [(w, h), (w, 0.0), (0.0, 0.0), (0.0, h)] if w >= h else [(w, 0.0), (0.0, 0.0), (0.0, h), (w, h)]
    return dict(name=name, vl=vl, w=w, h=h, holes=[(r1(a), r1(b), c, d) for a, b, c, d in holes], grooves=[], poly=poly,
                edges=[e for e in edges if e not in e45], e45=list(e45), note=note,
                rot=(not VAT_LIEU[vl]["van"]) if rot is None else rot, box=[round(v, 2) for v in box], loai=loai, anim=anim, cut=True)


def ao(name, box, mau, anim=None, loai="ao"):
    """khối chỉ để nhìn (không cắt): chân tủ, ray kim loại, thiết bị, mặt đá"""
    return dict(name=name, box=[round(v, 2) for v in box], mau=mau, anim=anim, loai=loai, cut=False)


def tach_khoi_hong(p):
    """3D: hông có khoét shadowline -> tách thành nhiều khối để hình 3D thấy chỗ khoét (trước đây vẽ nguyên khối nên lộ cạnh trắng trong rãnh)."""
    x, y, z, dx, dy, dz = p["box"]; poly = p.get("poly") or []
    if len(poly) <= 4 or abs(dy - p["w"]) > .5 or abs(dz - p["h"]) > .5: return [p["box"]]
    mir = abs(poly[0][0] - p["w"]) < .01
    us = sorted({round(u, 3) for u, v in poly})
    out = []
    for a, b in zip(us, us[1:]):
        um = (a + b) / 2; vs = []
        for (u1, v1), (u2, v2) in zip(poly, poly[1:] + poly[:1]):
            if (u1 - um) * (u2 - um) < 0: vs.append(v1 + (v2 - v1) * (um - u1) / (u2 - u1))
        if len(vs) < 2: continue
        v0, v1_ = min(vs), max(vs)
        y0 = (p["w"] - b) if mir else a
        out.append([x, round(y + y0, 2), round(z + v0, 2), dx, round(b - a, 2), round(v1_ - v0, 2)])
    return out or [p["box"]]


def poly_hong(H, D, T, notches, mirror):
    """hông tủ có khoét shadowline ở mép trước (y = D): notches = [(x0, x1)], khoét sâu T, cắt suốt."""
    pts = [(0.0, 0.0), (0.0, D)]
    for a, b in sorted(notches):
        if a <= 0.01: pts[-1] = (0.0, D - T)
        else: pts += [(a, D), (a, D - T)]
        pts += [(b, D - T)] if b >= H - 0.01 else [(b, D - T), (b, D)]
    if not notches or sorted(notches)[-1][1] < H - 0.01: pts.append((H, D))
    pts.append((H, 0.0))
    if mirror: pts = [(round(H - x, 3), y) for x, y in pts]
    return [(round(x, 3), round(y, 3)) for x, y in pts]


def so_ban_le(hd):
    return 2 if hd <= 900 else 3 if hd <= 1500 else 4 if hd <= 2000 else 5


def tam_ban_le(hd):
    n = so_ban_le(hd)
    return [r1(100 + k * (hd - 200) / (n - 1)) for k in range(n)]


def lo_canh(hd, wd, vl, ban_le):
    """chén bản lề Ø35 + 2 chốt Ø8 (job 75: ván màu 16 tâm 21.2 / chốt 30.8; MDF 18 tâm 22.5 / chốt 32)"""
    cy, dy = (22.5, 32.0) if vl == "MDF18" else (21.2, 30.8)
    hs = []
    for x in tam_ban_le(hd):
        hs += [(x, cy, 35.0, 14.0), (x - 22.5, dy, 8.0, 12.0), (x + 22.5, dy, 8.0, 12.0)]
    if ban_le == "R": hs = [(x, wd - y, d, p) for x, y, d, p in hs]
    return hs


def canh_gap(t, so, parts, pk, cb, lo_trai, lo_phai, y0, hd, out_ao, n):
    """CÁNH GẬP (bi-fold) cho tủ thẳng – CV "Bi-Fold Wall Cabinets / Bi-fold Pantry": mỗi bên 2 lá, lá ngoài bắt bản lề vào hông,
    lá trong nối lá ngoài bằng bản lề cánh đôi (đế bắt lưng lá ngoài cách mép 39 – như tủ treo góc L)."""
    W, H, D = t["w"], t["h"], t["d"]; vm, shaker, ghi = mat_ngoai(t); tf = VAT_LIEU[vm]["lz"]; sl = bool(t.get("shadowline"))
    y0 = HO if y0 is None else y0
    hd = (H - y0 - (SL_CUA if sl else HO)) if hd is None else hd
    sides = ["L", "R"] if n >= 2 else [t.get("ban_le", "L")]
    ws = (W - 2 * HO - (KHE if len(sides) == 2 else 0)) / len(sides)
    wa = (ws - KHE) / 2
    if wa < 150: cb.append(f"#{so}: lá cánh gập chỉ rộng {wa:.0f} – tủ quá hẹp cho cánh gập")
    nb = so_ban_le(hd)
    for k, bl in enumerate(sides):
        x_side = HO if (len(sides) == 1 or k == 0) else HO + ws + KHE
        xA = x_side if bl == "L" else x_side + ws - wa; xB = xA + wa + KHE if bl == "L" else xA - KHE - wa
        _canh_rieng(t, so, parts, pk, cb, (xA, y0, D, wa, hd, tf), bl, "z", lo_trai if bl == "L" else lo_phai, out_ao, "Cánh gập ngoài")
        cA = parts[-1]; gid = "G" + bl; cA["anim"]["id"] = gid
        cA["holes"] += [(r1(c + s_), r1(wa - 39.0) if bl == "L" else 39.0, 5.0, 10.0) for c in tam_ban_le(hd) for s_ in (-16, 16)]
        _canh_rieng(t, so, parts, pk, cb, (xB, y0, D, wa, hd, tf), bl, "z", [], out_ao, "Cánh gập trong")
        an = parts[-1]["anim"]; an.clear(); an.update(kieu="gap", cha=gid, px=xA + wa if bl == "L" else xA, pz=D + tf, s=1 if bl == "L" else -1, g=2.9)
        pk["Bản lề giảm chấn + đế"] -= nb; pk["Bản lề cánh đôi + đế cánh đôi (bi-fold – CV S_HNGDD)"] += nb


def cua_lua(t, so, parts, pk, cb, y0, hd, out_ao, n):
    """CỬA LÙA (CV "Sliding Door Floor / Wall / Pantry Cabinets"): n cánh trên 2 ray (trong / ngoài xen kẽ), cánh chồng nhau 30, không bản lề."""
    W, H, D = t["w"], t["h"], t["d"]; vm, shaker, ghi = mat_ngoai(t); tf = VAT_LIEU[vm]["lz"]; sl = bool(t.get("shadowline"))
    y0 = HO if y0 is None else y0
    hd = (H - y0 - (SL_CUA if sl else HO)) if hd is None else hd
    OV = 30.0; wd = (W - 2 * HO + OV * (n - 1)) / n
    edges = () if vm in ("MDF18", "MDF21") else ("T", "B", "L", "R")
    for i in range(n):
        x0 = HO + i * (wd - OV); z0 = D + (tf + 6 if i % 2 else 0)
        an = dict(kieu="truot", dx=(-(wd - OV) if i else (wd - OV)) if n == 2 else (wd - OV) * (1 if i % 2 == 0 else -1))
        parts.append(mieng(f"Cánh lùa {i + 1} ({'ray ngoài' if i % 2 else 'ray trong'})", vm, hd, wd, (x0, y0, z0, wd, hd, tf), [], edges, (),
                           (ghi + " | " if ghi else "") + "Cửa lùa – bắt bánh xe / dẫn hướng theo bộ ray (không khoan bản lề)", loai="canh", anim=an, rot=False))
        if out_ao is not None: trang_tri(out_ao, (x0, y0, z0, wd, hd, tf), shaker, ("L" if i % 2 else "R") if t.get("tay_nam") else None, an, vi_tri="giua")
        if t.get("tay_nam"): pk["Tay nắm âm cửa lùa"] += 1
    pk[f"Bộ ray cửa lùa {n} cánh cho tủ {W:.0f} (bộ)"] += 1
    if wd > 1200: cb.append(f"#{so}: cánh lùa rộng {wd:.0f} – nên tăng số cánh")


def mat_ngoai(t):
    """(vật liệu mặt, shaker?, ghi chú shaker)"""
    if t.get("kieu_canh") == "shaker":
        return "MDF21", True, "SHAKER 21mm sơn PU – nhờ Huân ra chương trình phay lòng (Studio chưa tự phay)"
    return t["vl_mat"], False, ""


def trang_tri(out_ao, box, shaker, tay, an, ngang=False, vi_tri="tren"):
    """khối chỉ để nhìn trên 1 cánh / mặt hộc: khung shaker nổi 3mm, tay nắm thanh"""
    x, y, z, sx, sy, sz = box; zf = z + sz
    if shaker and sx > 190 and sy > 190:
        k = 65.0
        for bx in ((x, y, zf, k, sy, 3), (x + sx - k, y, zf, k, sy, 3), (x + k, y, zf, sx - 2 * k, k, 3), (x + k, y + sy - k, zf, sx - 2 * k, k, 3)):
            out_ao.append(ao("Khung shaker", bx, None, anim=an, loai="khung"))
    if tay:
        if ngang: bx = (x + sx / 2 - 80, y + sy - 52, zf, 160, 12, 30)
        else:
            hx = (x + sx - 42) if tay == "R" else (x + 30)
            hy = y + (60 if vi_tri == "duoi" else (sy * 0.46 if vi_tri == "giua" else sy - 60 - 150))
            bx = (hx, hy, zf, 12, 150, 30)
        out_ao.append(ao("Tay nắm", bx, "#3b3d42", anim=an, loai="tay"))


def cac_canh(t, so, parts, pk, cb, lo_trai, lo_phai, y0=None, hd=None, out_ao=None):
    """cánh phủ ngoài: hở 1.5 quanh, khe 3 giữa 2 cánh. Trả về lỗ đế bản lề cho hông trái / phải."""
    n = int(t.get("canh", 0) or 0)
    if n <= 0: return
    if t.get("gap_doi") and t.get("loai") in ("treo", "cao", "duoi_canh", "tu_ao"): return canh_gap(t, so, parts, pk, cb, lo_trai, lo_phai, y0, hd, out_ao, n)
    if t.get("cua_lua") and t.get("loai") in ("treo", "cao", "duoi_canh", "tu_ao"): return cua_lua(t, so, parts, pk, cb, y0, hd, out_ao, max(2, n))
    if n > 2: cb.append(f"#{so}: {n} cánh bản lề cần vách đứng – dùng Chia ô mặt; tạm làm 2 cánh"); n = 2
    W, H, D = t["w"], t["h"], t["d"]; vm, shaker, ghi = mat_ngoai(t); tf = VAT_LIEU[vm]["lz"]
    sl = bool(t.get("shadowline"))
    y0 = HO if y0 is None else y0
    hd = (H - y0 - (SL_CUA if sl else HO)) if hd is None else hd
    wd = (W - 2 * HO) if n == 1 else (W - 2 * HO - KHE) / 2
    if wd > 620: cb.append(f"#{so}: cánh rộng {wd:.0f} > 600, nên chia 2 cánh hoặc giảm bề rộng")
    for i in range(n):
        bl = t.get("ban_le", "L") if n == 1 else ("L" if i == 0 else "R")
        holes = lo_canh(hd, wd, vm, bl); e45 = (); note = ghi
        if sl:
            if vm in ("MDF18", "MDF21"): note = (note + " | " if note else "") + "CẮT 45° CẠNH TRÊN (shadowline) – chưa tự phay, kiểm tay"
            else:
                e45 = ("R",); holes.append((hd - 10, wd / 2, 5.0, 1.0)); note = "Nẹp 45° cạnh có chấm Ø5 (cạnh trên)"
        edges = () if vm in ("MDF18", "MDF21") else ("T", "B", "L", "R")
        x0 = HO + i * (wd + KHE); box = (x0, y0, D, wd, hd, tf)
        an = dict(kieu="cua", ban_le=bl, px=x0 if bl == "L" else x0 + wd, pz=D)
        parts.append(mieng(f"Cánh {'shaker ' if shaker else ''}{'trái' if bl == 'L' else 'phải'}", vm, hd, wd, box, holes, edges, e45, note, loai="canh", anim=an, rot=False))
        if out_ao is not None:
            trang_tri(out_ao, box, shaker, ("R" if bl == "L" else "L") if t.get("tay_nam") else None, an,
                      vi_tri="duoi" if (t["loai"] in TU_TREO or (t["loai"] in ("lo_nuong", "tu_lanh") and y0 > 300)) else "giua" if t["loai"] in ("cao", "tu_ao") else "tren")
        plates = [(y0 + c - 16, D - 37, 5.0, 12.0) for c in tam_ban_le(hd)] + [(y0 + c + 16, D - 37, 5.0, 12.0) for c in tam_ban_le(hd)]
        (lo_trai if bl == "L" else lo_phai).extend(plates)
        pk["Bản lề giảm chấn + đế"] += so_ban_le(hd)
        if t.get("tay_nam"): pk["Tay nắm"] += 1
        if t.get("mo") == "push": pk["Nhấn mở (push latch)"] += 1


def vl_phu(t):
    """vật liệu cho panel / kickface / thanh shadowline: cùng màu cánh. Cánh shaker (MDF21 sơn) -> tấm phụ MDF18 sơn cùng màu."""
    return "MDF18" if t.get("kieu_canh") == "shaker" else t.get("vl_mat", "MAU16")


def thanh_shadowline(t, parts, notches, x0=None, x1=None):
    """anh Tan 19/11: chỗ khoét shadowline phải có thanh 50mm cùng màu cánh chèn vào (hoặc anh chọn chèn loại khác -> tắt).
    anh Tan 20/11: thanh phải CHẠM 2 HÔNG (nằm lọt giữa 2 hông, ngay sau mặt khoét) để bắn vít từ hông vào đầu thanh – như top stretcher SHDWLNE của CV."""
    if not notches or t.get("sl_thanh") is False: return
    vm = vl_phu(t); tf = VAT_LIEU[vm]["lz"]; T = VAT_LIEU[t["vl_thung"]]["lz"]; X = T + 0.5
    x0 = T if x0 is None else x0; x1 = t["w"] - T if x1 is None else x1; D = t["d"]
    zr = D - T - tf                                             # mặt trước thanh = đáy rãnh khoét (lùi T so với mặt trước hông)
    for a, b in notches:
        parts.append(mieng("Thanh shadowline 50 (cùng màu cánh)", vm, x1 - x0, b - a, (x0, a, zr, x1 - x0, b - a, tf), (), ("B",) if vm not in ("MDF18", "MDF21") else (),
                           note="Lọt giữa 2 hông, ngay sau mặt khoét shadowline – bắt vít từ 2 hông vào đầu thanh", loai="tam", rot=True))
        H = t["h"]; vit = [((a + b) / 2, zr + tf / 2, 5.0, X)]
        for p in parts:                                         # lỗ vít trên 2 hông bắt vào đầu thanh
            if p["name"].startswith("Hông trái") and abs(p["box"][0]) < 1 and abs(x0 - T) < 1: p["holes"] += [(r1(u), r1(v), d, q) for u, v, d, q in vit]
            elif p["name"].startswith("Hông phải") and abs(x1 - (t["w"] - T)) < 1: p["holes"] += [(r1(H - u), r1(v), d, q) for u, v, d, q in vit]


def lo_chot_ke(tam_x, D, T):
    hs = []
    for c in tam_x:
        for j in range(-2, 3):
            hs += [(c + 32 * j, T + 40.0, 5.0, 12.0), (c + 32 * j, D - 49.0, 5.0, 12.0)]
    return hs


# ---------------------------------------------------------------- thùng kiểu A: tủ dưới (deck + hậu đứng trên deck + thanh giằng trước)
def thung_duoi(t, so, parts, pk, cb, lo_trai, lo_phai, notches, giang_giua=()):
    W, H, D = t["w"], t["h"], t["d"]; vl = t["vl_thung"]; T = VAT_LIEU[vl]["lz"]; X = T + 0.5; iw = W - 2 * T
    sl = bool(t.get("shadowline")); sld = T if sl else 0.0
    GW = 63.0 if t.get("loai") == "duoi_chau" else 48.0                                           # CV MN Joinery: tủ chậu giằng trên 63 (cứng hơn, khoét chậu), tủ thường 48
    base = [(T / 2, y, 5.0, X) for y in (50.0, r1(D / 2 - 0.5), D - 49.0)]                       # deck
    base += [(x, T / 2, 5.0, X) for x in (66.4, r1((66.4 + H - 50) / 2), H - 50.0)]              # hậu
    noc = bool(t.get("noc_lien"))                                                                # CV "Add Full Top": nóc liền thay thanh giằng (tủ không mặt đá: laundry, bàn làm việc, tủ đứng riêng)
    base += ([(H - T / 2, y, 5.0, X) for y in (50.0, r1(D / 2 - 0.5), D - sld - 49.0)] if noc else [(H - GW / 2 - 1.0, D - sld - 25.2, 5.0, X)])   # nóc liền / thanh giằng trước
    base += [(g + 24.0, D - sld - 25.2, 5.0, X) for g in giang_giua]                             # giằng giữa hộc
    left = base + lo_trai
    right = [(H - x, y, d, p) for x, y, d, p in base + lo_phai]
    note = ("Shadowline: khoét 50 x %.1f mép trước" % T) if notches else ""
    ed = ("T",)
    parts.append(mieng("Hông trái", vl, H, D, (0, 0, 0, T, H, D), left, ed, note=note, poly=poly_hong(H, D, T, notches, False) if notches else None))
    parts.append(mieng("Hông phải", vl, H, D, (W - T, 0, 0, T, H, D), right, ed, note=note, poly=poly_hong(H, D, T, notches, True) if notches else None))
    parts.append(mieng("Đáy (deck)", vl, D, iw, (T, 0, 0, iw, T, D), [(T / 2, y, 5.0, 12.0) for y in (50.0, r1(iw / 2), iw - 50.0)], ("R",)))
    parts.append(mieng("Hậu", vl, H - T, iw, (T, T, 0, iw, H - T, T), (), (), loai="hau"))
    zg = D - sld - 25.2 - T / 2
    if noc: parts.append(mieng("Nóc liền", vl, D - sld, iw, (T, H - T, 0, iw, T, D - sld), [(T / 2, y, 5.0, 12.0) for y in (50.0, r1(iw / 2), iw - 50.0)], ("R",), note="CV Add Full Top – nóc liền thay thanh giằng"))
    else: parts.append(mieng("Thanh giằng trên", vl, GW, iw, (T, H - GW, zg, iw, GW, T), (), ("R",)))
    for g in giang_giua:
        parts.append(mieng("Thanh giằng giữa hộc", vl, 48, iw, (T, g, zg, iw, 48, T), (), ("R",)))
    pk["Vít 4x50 (ráp thùng)"] += 14 + 2 * len(giang_giua)
    thanh_shadowline(t, parts, notches)
    return T, iw


def chan_tu(t, out_ao, pk):
    c = float(t.get("chan", 0) or 0)
    if c > 0:
        out_ao.append(ao("Chân tủ", (0, -c, 0, t["w"], c, t["d"] - 50), "#2f2f31", loai="chan"))


def ke_lui(t):
    """kệ di động lùi so với mặt trước thùng (CV Shelf Setback, mặc định 10)"""
    try: return max(0.0, min(float(t.get("ke_lui", 10) if t.get("ke_lui") not in (None, "") else 10), 200.0))
    except (TypeError, ValueError): return 10.0


def ke_di_dong(t, so, parts, pk, T, iw, y_lo, y_hi, sau, lo_trai, lo_phai):
    n = int(t.get("ke", 0) or 0)
    if n <= 0: return
    vl = t["vl_thung"]; D = t["d"]; xs = []; sau = sau + 10.0 - ke_lui(t)          # người gọi đã trừ 10 (mặc định) -> đổi theo ô Kệ lùi
    for k in range(n):
        yc = y_lo + (k + 1) * (y_hi - y_lo) / (n + 1); xs.append(yc)
        parts.append(mieng("Kệ di động", vl, sau, iw - 2, (T + 1, yc - T / 2, T, iw - 2, T, sau), (), ("R",), loai="ke"))
    pins = lo_chot_ke(xs, D, T)
    lo_trai.extend(pins); lo_phai.extend(pins)
    pk["Chốt kệ"] += 4 * n


def tu_lo_duoi(t, so):
    """HỘC LÒ ÂM DƯỚI BẾP theo CV "600mm x 600mm Std Oven Cab" (MN Joinery, học 20/11, 600 × 750 × 580):
    chỉ 2 hông + kệ lò cố định 563.6 × 567.2 (tâm cách đáy 46.1, khoét thông gió 250 × 200 giữa cạnh sau) + thanh treo tường (nailer) 61.5 sau nóc.
    Không deck, không hậu, không cánh – lò bắt vít vào 2 hông."""
    parts, aos, pk, cb = [], [], Counter(), []
    W, H, D = t["w"], t["h"], t["d"]; vl = t["vl_thung"]; T = VAT_LIEU[vl]["lz"]; X = T + 0.5; iw = W - 2 * T
    yk = 46.1; dk = D - T                                  # kệ lò: tâm cách đáy 46.1, sâu D − T (CV 563.6)
    if iw < 560: cb.append(f"#{so}: lòng {iw:.0f} < 560 – lò âm 60cm không vừa (cần lòng ≥ 560)")
    if D < 550: cb.append(f"#{so}: sâu {D:.0f} < 550 – lò âm cần sâu tối thiểu 550")
    if H - yk - T / 2 < 590: cb.append(f"#{so}: chiều cao hộc lò {H - yk - T / 2:.0f} < 590 – lò 60cm không vừa")
    ys = (50.0, r1((50 + D - 49) / 2), D - 49.0)
    base = [(yk, y, 5.0, X) for y in ys] + [(H - 15.0, T / 2, 5.0, X), (H - 46.5, T / 2, 5.0, X)]
    ed = ("T",)
    parts.append(mieng("Hông trái", vl, H, D, (0, 0, 0, T, H, D), base, ed))
    parts.append(mieng("Hông phải", vl, H, D, (W - T, 0, 0, T, H, D), [(H - x, y, d, p) for x, y, d, p in base], ed))
    vx = min(250.0, iw - 120); a = (iw - vx) / 2
    parts.append(mieng("Kệ lò cố định (khoét thông gió)", vl, iw, dk, (T, yk - T / 2, T, iw, T, dk), [(T / 2 + 0.0, y - T, 5.0, 12.0) for y in ys if False], ("T",),
                       poly=poly_khoet(iw, dk, a, a + vx, min(199.9, dk - 300)), loai="ke", note="Lò đặt trên kệ này; khoét sau cho thông gió theo hướng dẫn hãng"))
    parts.append(mieng("Thanh treo tường (nailer)", vl, iw, 61.5, (T, H - 61.5, 0, iw, 61.5, T), (), (), note="Bắt vít vào tường + hông"))
    aos.append(ao("Lò âm dưới bếp", (T + 2, yk + T / 2 + 2, D - 20, iw - 4, min(595.0, H - yk - T), 30), "#17181b", loai="thiet_bi"))
    pk["Vít 4x50 (ráp thùng)"] += 10
    chan_tu(t, aos, pk)
    return parts, aos, pk, cb


def tu_vi_song(t, so):
    """TỦ DƯỚI LÒ VI SÓNG + 1 NGĂN KÉO theo CV "UB Microwave Cab + 1 Drawer" (học 20/11, 600 × 750 × 580):
    mặt hộc dưới 598 × 300, khung viền vi sóng cùng màu cánh 598 × 400 KHOÉT lỗ (viền 20 hai bên, 25 trên dưới), kệ cố định đỡ lò ngang mép dưới lỗ.
    Hộc Tandembox như tủ hộc (mặt 300 → hậu 198, đáy 492.2 × 475.6 với ray 500)."""
    parts, aos, pk, cb = [], [], Counter(), []
    W, H, D = t["w"], t["h"], t["d"]; vl = t["vl_thung"]; T = VAT_LIEU[vl]["lz"]; iw = W - 2 * T
    vm, shaker, ghi = mat_ngoai(t); tf = VAT_LIEU[vm]["lz"]; sl = bool(t.get("shadowline"))
    edges = () if vm in ("MDF18", "MDF21") else ("T", "B", "L", "R")
    wf = W - 2 * HO; hf = float(t.get("vs_hoc") or 300); top = SL_CUA if sl else HO
    hm = H - HO - top - hf - KHE
    if hm < 330: cb.append(f"#{so}: khung vi sóng chỉ cao {hm:.0f} – giảm mặt hộc dưới (vs_hoc)"); hf = max(150.0, H - HO - top - KHE - 380); hm = H - HO - top - hf - KHE
    lt, lp = [], []
    # ngăn kéo dưới
    an = dict(kieu="hoc", k=0); yb = HO
    up = 96.0 if hf < 250 else 128.0 if hf < 310 else 160.0
    hl = [(x, y, 10.0, 12.0) for x in [46.4, 78.4] + ([46.4 + up] if hf >= 46.4 + up + 30 else []) for y in (29.9, wf - 29.9)]
    parts.append(mieng(f"Mặt hộc {'shaker ' if shaker else ''}1", vm, hf, wf, (HO, yb, D, wf, hf, tf), hl, edges, (), ghi, loai="mat_hoc", anim=an, rot=False))
    trang_tri(aos, (HO, yb, D, wf, hf, tf), shaker, "N" if t.get("tay_nam") else None, an, ngang=True)
    NL = max([v for v in RAY_NL if v <= D - T - 3] or [270])
    lt += [(yb + 50.9, y, 5.0, DR) for y in (D - 36, D - 132, D - 260, D - (NL - 48)) if y > T + 10]; lp += lt[-4:]
    bw, bd = iw - 75, NL - 24.4; BH = 198.0 if hf >= 255 else 166.0 if hf >= 215 else 134.0 if hf >= 180 else 83.0
    parts.append(mieng("Đáy hộc 1", vl, bw, bd, (T + 37.5, yb + 28, D - bd, bw, T, bd), [(x, y, 5.0, 12.0) for x in (9.0, bw - 9.0) for y in (16.2, bd - 189.4, bd - 43.4) if y > 0], (), loai="hoc", anim=an))
    parts.append(mieng("Hậu hộc 1", vl, iw - 87, BH, (T + 43.5, yb + 28 + T, D - bd, iw - 87, BH, T), [(x, y, 5.0, 12.0) for x in (9.0, iw - 87 - 9.0) for y in (7.0, 39.0, 103.0, 135.0, 167.0) if y <= BH - 31], ("T",), loai="hoc", anim=an))
    for sx in (T + 21, W - T - 21 - 13): aos.append(ao("Thành hộc kim loại", (sx, yb + 28, D - bd, 13, min(BH, hf - 40), bd), "#c9ccd1", anim=an))
    pk[f"Ray hộc Tandembox {NL} (bộ)"] += 1
    if t.get("tay_nam"): pk["Tay nắm"] += 1
    if t.get("mo") == "push": pk["Nhấn mở (push latch)"] += 1
    # khung viền vi sóng (khoét lỗ) + kệ đỡ lò
    ym = HO + hf + KHE; bl, bt = 20.0, 25.0
    cut = [(bt, bl), (bt, wf - bl - 1), (hm - bt, wf - bl - 1), (hm - bt, bl)]          # toạ độ miếng: x = cao, y = rộng
    k = mieng("Khung viền lò vi sóng (khoét)", vm, hm, wf, (HO, ym, D, wf, hm, tf), [], edges, (), (ghi + " | " if ghi else "") + f"Lỗ khoét {wf - 2 * bl - 1:.0f} × {hm - 2 * bt:.0f} – kiểm theo model lò trước khi cắt", loai="tam", rot=False)
    k["cutouts"] = [cut]
    k["k3d"] = [(HO, ym, D, wf, bt, tf), (HO, ym + hm - bt, D, wf, bt, tf), (HO, ym + bt, D, bl, hm - 2 * bt, tf), (HO + wf - bl, ym + bt, D, bl, hm - 2 * bt, tf)]   # 3D thấy lỗ khoét
    parts.append(k)
    yk = ym + bt - T / 2
    parts.append(mieng("Kệ cố định đỡ lò vi sóng", vl, iw, D - T, (T, yk - T / 2, T, iw, T, D - T), (), ("T",), loai="ke"))
    hs = [(yk, y, 5.0, T + 0.5) for y in (50.0, r1((50 + D - 49) / 2), D - 49.0)]; lt += hs; lp += hs
    aos.append(ao("Lò vi sóng", (T + 10, yk + T / 2 + 2, D - 360, iw - 20, hm - 2 * bt - 4, 340), "#1f2023", loai="thiet_bi"))
    thung_duoi(t, so, parts, pk, cb, lt, lp, [(H - SL_H, H)] if sl else [])
    chan_tu(t, aos, pk)
    return parts, aos, pk, cb


def tu_duoi_canh(t, so):
    if t.get("vat") in ("L", "R") and t.get("loai") == "duoi_canh": return tu_vat(t, so)
    if t.get("lo_duoi") and t.get("loai") == "duoi_canh": return tu_lo_duoi(t, so)
    if t.get("vi_song") and t.get("loai") == "duoi_canh": return tu_vi_song(t, so)
    if t.get("ruou") and t.get("loai") == "duoi_canh": return tu_hop(t, so)          # kệ rượu dưới: thùng hộp kín nóc, lưới ô bên trong
    parts, aos, pk, cb = [], [], Counter(), []
    lt, lp = [], []
    sl = bool(t.get("shadowline")); T0 = VAT_LIEU[t["vl_thung"]]["lz"]
    cac_canh(t, so, parts, pk, cb, lt, lp, out_ao=aos)
    doors = parts[:]; parts = []
    ke_parts = []
    if not int(t.get("hoc_trong", 0) or 0): ke_di_dong(t, so, ke_parts, pk, T0, t["w"] - 2 * T0, T0, t["h"] - 60, t["d"] - T0 - 10, lt, lp)   # có ngăn kéo trong thì bỏ kệ (như CV)
    hoc_trong(t, so, ke_parts, aos, pk, cb, lt, lp)
    thung_duoi(t, so, parts, pk, cb, lt, lp, [(t["h"] - SL_H, t["h"])] if sl else [])
    ne_ong_duoi(t, so, parts, ke_parts, aos, pk, cb)
    chan_tu(t, aos, pk)
    return parts + ke_parts + doors, aos, pk, cb


def ne_ong_duoi(t, so, parts, kes, aos, pk, cb):
    """tủ dưới né ống / cột sau tủ (CV "1/2/3 Door Floor – LEFT/MIDDLE/RIGHT STACK"): khoét deck + kệ ở cạnh sau, tách hậu 2 bên, hộp 2 vách + mặt hộp."""
    no = ne_ong(t, cb, so)
    if not no: return
    W, H, D = t["w"], t["h"], t["d"]; vl = t["vl_thung"]; T = VAT_LIEU[vl]["lz"]; iw = W - 2 * T
    xa, xb, sd = no; xl, xr = xa - T, xb + T
    sw = lambda P: [(round(y, 2), round(x, 2)) for x, y in P]
    for q in parts:
        if q["name"] == "Đáy (deck)":            # deck: x = sâu từ sau, y = ngang từ hông trái trong
            q["poly"] = sw(poly_khoet(iw, D, xl - T, xr - T, sd + T)); q["name"] = "Đáy (deck) (khoét né ống)"
            q["holes"] = [h for h in q["holes"] if not (xl - T - 5 <= h[1] <= xr - T + 5 and h[0] <= sd + T + 5)]
    for q in kes:
        if q["name"] == "Kệ di động":             # kệ: x = sâu (từ sau, bắt đầu sau hậu), y = ngang
            if sd + 1 >= q["w"] - 60: kes.remove(q); cb.append(f"#{so}: kệ không đủ sâu sau khi né ống – bỏ kệ"); continue
            q["poly"] = sw(poly_khoet(q["h"], q["w"], xl - T - 2, xr - T, sd + 1)); q["name"] = "Kệ di động (khoét né ống)"
    hau = next((q for q in parts if q["name"] == "Hậu"), None)
    if hau: parts.remove(hau)
    hh = H - T
    if xl - T > 20: parts.append(mieng("Hậu trái (né ống)", vl, hh, xl - T, (T, T, 0, xl - T, hh, T), (), (), loai="hau"))
    if W - T - xr > 20: parts.append(mieng("Hậu phải (né ống)", vl, hh, W - T - xr, (xr, T, 0, W - T - xr, hh, T), (), (), loai="hau"))
    for xv in ([xl] if xl > T + 1 else []) + ([xb] if xr < W - T - 1 else []):
        parts.append(mieng("Vách hộp né ống", vl, hh, sd, (xv, T, 0, T, hh, sd), (), ("T",), note="Đứng trên deck tới mặt trên tủ, áp tường"))
    x0, x1 = max(xl, T), min(xr, W - T)
    parts.append(mieng("Mặt hộp né ống", vl, hh, x1 - x0, (x0, T, sd, x1 - x0, hh, T), (), (), note=f"Hộp né ống / cột {xb - xa:.0f} × {sd:.0f} – kiểm đo thực tế trước khi cắt"))
    aos.append(ao("Ống / cột (né)", (xa + 20, -150, 0, xb - xa - 40, H + 300, sd - 20), "#9aa0a8", loai="thiet_bi"))
    pk["Vít 4x50 (ráp thùng)"] += 8


def hoc_trong(t, so, parts, aos, pk, cb, lt, lp, y0=None, buoc=None):
    """ngăn kéo trong sau cánh (CV "Inner Drawer Floor Cabinets", học 20/11 từ part sheet CV):
    Tandembox inner BH 83: đáy = lòng - 75 x (ray - 24.4), hậu = lòng - 87 x 83; ray lùi sau mặt sau cánh 25 để cánh đóng kín."""
    n = int(t.get("hoc_trong", 0) or 0)
    if n <= 0 or t.get("loai") not in ("duoi_canh", "cao", "tu_ao"): return
    W, H, D = t["w"], t["h"], t["d"]; vl = t["vl_thung"]; T = VAT_LIEU[vl]["lz"]; iw = W - 2 * T
    LUI = 25.0
    NL = max([v for v in RAY_NL if v <= D - T - 3 - LUI] or [0])
    if not NL: cb.append(f"#{so}: tủ sâu {D:.0f} không đủ cho ngăn kéo trong"); return
    if iw < 200: cb.append(f"#{so}: lòng tủ {iw:.0f} quá hẹp cho ngăn kéo trong"); return
    bw, bd = iw - 75, NL - 24.4
    if buoc is None: buoc = (H - 60 - T - 40) / n
    if y0 is None: y0 = T
    if buoc < 120: cb.append(f"#{so}: {n} ngăn kéo trong quá sát nhau (khoảng {buoc:.0f})")
    BH = 166.0 if buoc >= 230 else 134.0 if buoc >= 190 else 83.0                    # tủ cao: hộc trong cách 230 -> thành 166 (CV "Pot" sâu hơn)
    if t.get("loai") == "duoi_canh": BH = 83.0
    zf = D - LUI
    for k in range(n):
        yb = y0 + 40 + k * buoc; an = dict(kieu="hoc", k=k)
        parts.append(mieng(f"Đáy hộc trong {k + 1}", vl, bw, bd, (T + 37.5, yb, zf - bd, bw, T, bd),
                           [(x, y, 5.0, 12.0) for x in (9.0, bw - 9.0) for y in (16.2, bd - 189.4, bd - 43.4) if y > 0], (), loai="hoc", anim=an))
        parts.append(mieng(f"Hậu hộc trong {k + 1}", vl, iw - 87, BH, (T + 43.5, yb + T, zf - bd, iw - 87, BH, T),
                           [(x, y, 5.0, 12.0) for x in (9.0, iw - 87 - 9.0) for y in (7.0, 39.0)], ("T",), loai="hoc", anim=an))
        for sx in (T + 21, W - T - 21 - 13):
            aos.append(ao("Thành hộc kim loại", (sx, yb, zf - bd, 13, BH, bd), "#c9ccd1", anim=an))
        aos.append(ao("Mặt trước hộc trong (kim loại)", (T + 21, yb, zf - 16, iw - 42, BH + 20, 16), "#b9bdc4", anim=an))
        run = [(yb + 22.9, y, 5.0, DR) for y in (zf - 36, zf - 132, zf - 260, zf - (NL - 48)) if y > T + 10]
        lt += run; lp += run
        pk[f"Ray hộc Tandembox {NL} (bộ)"] += 1; pk["Mặt trước hộc trong Tandembox (bộ)"] += 1


def _canh_rieng(t, so, parts, pk, cb, box, bl, huong, lo_hong, out_ao, ten="Cánh"):
    """1 cánh đơn tại box (x,y,z,sx,sy,sz); huong 'z' = mặt quay ra +z (bình thường), 'x' = mặt quay ra +x (tủ góc).
    Trả lỗ đế bản lề (toạ độ trên hông đứng cạnh bản lề)."""
    vm, shaker, ghi = mat_ngoai(t); x, y, z, sx, sy, sz = box
    hd, wd = sy, (sx if huong == "z" else sz)
    holes = lo_canh(hd, wd, vm, bl); edges = () if vm in ("MDF18", "MDF21") else ("T", "B", "L", "R")
    if huong == "z": an = dict(kieu="cua", ban_le=bl, px=x if bl == "L" else x + sx, pz=z)
    else: an = dict(kieu="cua", ban_le="R" if bl == "L" else "L", px=x, pz=z if bl == "L" else z + sz)
    parts.append(mieng(f"{ten} {'shaker ' if shaker else ''}{'trái' if bl == 'L' else 'phải'}", vm, hd, wd, box, holes, edges, (), ghi, loai="canh", anim=an, rot=False))
    if out_ao is not None and huong == "z": trang_tri(out_ao, box, shaker, ("R" if bl == "L" else "L") if t.get("tay_nam") else None, an, vi_tri="tren")
    # đế bản lề cách MÉP TRƯỚC thùng 37 (mép trước thùng = mặt sau cánh: z với cánh quay +z, x với cánh quay +x) – như cac_canh (D - 37).
    # bản cũ lấy mặt TRƯỚC cánh (z + sz) nên lỗ đế lệch vào trong 16 mm (cách mép 21)
    lo_hong.extend([(y + c + s_, (z if huong == "z" else x) - 37, 5.0, 12.0) for c in tam_ban_le(hd) for s_ in (-16, 16)])
    pk["Bản lề giảm chấn + đế"] += so_ban_le(hd)
    if t.get("tay_nam"): pk["Tay nắm"] += 1


def tu_goc_l(t, so):
    """TỦ GÓC L: thùng chữ L (sâu 560 hai nhánh), 2 cánh GẬP (bi-fold) vuông góc gặp nhau ở góc trong – theo CV "90 Deg Floor Corner" (MN Joinery)."""
    parts, aos, pk, cb = [], [], Counter(), []
    W, H, D = t["w"], t["h"], t["d"]; vl = t["vl_thung"]; T = VAT_LIEU[vl]["lz"]; X = T + 0.5; S = 560.0 - T
    if W < 900 or D < 900: cb.append(f"#{so}: tủ góc L cần tối thiểu 900 x 900 (đang {W:.0f} x {D:.0f}) – đã dựng theo 900"); W = max(W, 900.0); D = max(D, 900.0); t = dict(t, w=W, d=D)
    sl = bool(t.get("shadowline")); nt = [(H - SL_H, H)] if sl else []
    # cánh: mặt 1 quay ra +z tại z = 560 (x từ 560+tru..W), mặt 2 quay ra +x tại x = 560 (z từ 560+tru..D)
    vm, shaker, ghi = mat_ngoai(t); tf = VAT_LIEU[vm]["lz"]; hd = H - HO - (SL_CUA if sl else HO)
    # CÁNH GẬP (bi-fold) theo Cabinet Vision "90 Deg Floor Corner": không có trụ góc, 2 cánh gặp nhau ở góc trong.
    #  cánh A (mặt nhánh dọc) bắt vào HÔNG CUỐI bằng bản lề góc 90 + đế 90; cánh B (mặt nhánh dài) bắt vào lưng cánh A bằng bản lề cánh đôi + đế cánh đôi
    w2 = D - HO - 560; w1 = W - HO - (560 + tf + KHE)
    doors = []; lo_cuoi = []; lo_phai_c = []
    sc = str(t.get("space_corner") or "")
    if sc in ("1+2", "2deu", "3deu"):
        # BLUM SPACE CORNER (CV "Blum Space Corner - 1 + 2 / 2 Equal / 3 Equal", 1000 × 710 × 1000): ngăn kéo góc – mỗi tầng 2 mặt vuông góc,
        # mặt nhánh dọc gập vào trong khi kéo (SYNCROMOTION). Blum: tủ nên rộng 900–1200, dùng hộp TANDEMBOX / LEGRABOX hoặc hộc gỗ MOVENTO.
        n = 3 if sc in ("1+2", "3deu") else 2; z = hd
        hs = ([180.0] + [(z - 180.0 - 2 * KHE) / 2] * 2) if sc == "1+2" else [(z - (n - 1) * KHE) / n] * n
        hs = hs[::-1]                                  # từ dưới lên: ngăn trên thấp nhất
        yb = HO
        for k, hf in enumerate(hs):
            an = dict(kieu="hoc", k=k)
            doors.append(mieng(f"Mặt hộc góc {k + 1} – nhánh dài", vm, hf, w1, (xb0 := 560 + tf + KHE, yb, 560, w1, hf, tf), [], () if vm in ("MDF18", "MDF21") else ("T", "B", "L", "R"), (),
                               (ghi + " | " if ghi else "") + "Blum SPACE CORNER – khoan pát mặt theo dưỡng Blum", loai="mat_hoc", anim=an, rot=False))
            doors.append(mieng(f"Mặt hộc góc {k + 1} – nhánh dọc (gập)", vm, hf, w2, (560, yb, 560, tf, hf, w2), [], () if vm in ("MDF18", "MDF21") else ("T", "B", "L", "R"), (),
                               (ghi + " | " if ghi else "") + "Mặt gập SYNCROMOTION – nối mặt nhánh dài theo Blum", loai="mat_hoc", anim=an, rot=False))
            trang_tri(aos, (xb0, yb, 560, w1, hf, tf), shaker, "N" if t.get("tay_nam") else None, an, ngang=True)
            yb += hf + KHE
        pk["Blum SPACE CORNER – bộ ngăn kéo góc (SYNCROMOTION)"] += n
        if t.get("mo") == "push": pk["Nhấn mở (push latch)"] += n
        cb.append(f"#{so}: Blum SPACE CORNER {sc}: Studio dựng thùng + {2 * n} mặt hộc; HỘP NGĂN KÉO (đáy / hậu / lỗ ray) lấy theo bảng cắt Blum (Cabinet Configurator) – CNC chưa có")
        if not (900 <= W <= 1200): cb.append(f"#{so}: Blum khuyên tủ SPACE CORNER rộng 900–1200 (đang {W:.0f})")
        t = dict(t, ke=0)
    else:
        w2 = D - HO - 560; w1 = W - HO - (560 + tf + KHE)
        if w1 < 250 or w2 < 250: cb.append(f"#{so}: cánh tủ góc quá hẹp ({w1:.0f} / {w2:.0f}) – tăng kích thước tủ")
        doors = []; lo_cuoi = []
        _canh_rieng(t, so, doors, pk, cb, (560, HO, 560, tf, hd, w2), "R", "x", [], aos, "Cánh góc A (bắt hông)")
        cA = doors[-1]; cA["anim"]["id"] = "A"
        lo_cuoi += [(HO + c + s_, 560 - 37.0, 5.0, 12.0) for c in tam_ban_le(hd) for s_ in (-16, 16)]          # đế 90 trên hông cuối
        cA["holes"] += [(r1(c + s_), 39.0, 5.0, 10.0) for c in tam_ban_le(hd) for s_ in (-16, 16)]            # đế cánh đôi bắt lưng cánh A
        xb = 560 + tf + KHE
        # CV "90 Deg FloorCorner-3 Door" (W1200 x D900, đo 20/11): nhánh dài chia 2 cánh – cánh B gập vào A + cánh C thường bản lề hông phải
        ba = (int(t.get("canh") or 2) >= 3 and w1 >= 2 * 250 + KHE) or w1 > 620
        wB = (w1 - KHE) / 2 if ba else w1
        _canh_rieng(t, so, doors, pk, cb, (xb, HO, 560, wB, hd, tf), "L", "z", [], aos, "Cánh góc B (gập vào cánh A)")
        an = doors[-1]["anim"]; an.clear(); an.update(kieu="gap", cha="A", px=560 + tf, pz=560 + tf, s=-1)     # tay nắm dùng chung dict -> gập theo
        lo_phai_c = []
        if ba:
            _canh_rieng(t, so, doors, pk, cb, (xb + wB + KHE, HO, 560, wB, hd, tf), "R", "z", lo_phai_c, aos, "Cánh C (nhánh dài)")
        elif int(t.get("canh") or 2) >= 3: cb.append(f"#{so}: tủ góc 3 cánh cần nhánh dài đủ rộng (cánh B chỉ {w1:.0f}) – đã dựng 2 cánh")
        nb = so_ban_le(hd); pk["Bản lề giảm chấn + đế"] -= 2 * nb
        if pk["Bản lề giảm chấn + đế"] <= 0: del pk["Bản lề giảm chấn + đế"]
        pk["Bản lề góc 90° + đế 90 (cánh A bắt hông – CV HNG90)"] += nb
        pk["Bản lề cánh đôi + đế cánh đôi (bi-fold, cánh B – CV S_HNGDD)"] += nb
    # thùng
    base = [(T / 2, y, 5.0, X) for y in (50.0, 280.0, 510.0)] + [(x, T / 2, 5.0, X) for x in (66.4, (66.4 + H - 50) / 2, H - 50.0)] + [(H - 25.0, S - 25.2 + T - (T if sl else 0), 5.0, X)]
    parts.append(mieng("Hông trái (sát tường)", vl, H, D, (0, 0, 0, T, H, D), base + [(x, D - 560 + y, d, p) for x, y, d, p in base if y <= 560], ("T",), note="Hông dài theo tường bên", poly=poly_hong(H, D, T, nt, False) if nt else None))
    parts.append(mieng("Hông phải", vl, H, 560, (W - T, 0, 0, T, H, 560), [(H - x, y, d, p) for x, y, d, p in base + lo_phai_c], ("T",), poly=poly_hong(H, 560, T, nt, True) if nt else None,
                       note="Có đế bản lề cánh C" if lo_phai_c else ""))
    parts.append(mieng("Hông cuối", vl, H, 560, (0, 0, D - T, 560, H, T), [(H - x, y, d, p) for x, y, d, p in base + lo_cuoi], ("T",), note="Hông đầu nhánh dọc – có đế bản lề góc 90 cho cánh A", poly=poly_hong(H, 560, T, nt, True) if nt else None))
    parts.append(mieng("Hậu dài", vl, H - T, W - 2 * T, (T, T, 0, W - 2 * T, H - T, T), (), (), loai="hau"))
    parts.append(mieng("Hậu nhánh", vl, H - T, D - 560 - T, (0, T, 560, T, H - T, D - 560 - T), (), (), loai="hau", note="Hậu nhánh dọc, bắt mặt trong hông trái"))
    # ĐÁY + KỆ = 1 MIẾNG CHỮ L LIỀN (CV "90 Deg Floor Corner": Deck 867.6 x 867.6 một miếng) – anh Tan 20/11
    wl, hl, ul = W - 2 * T, D - T, 560 - 2 * T
    RG = max(float(t.get("ke_bo", 20) or 0), 0.0)                 # góc trong bo R20 như CV (dễ dán nẹp) – anh Tan 20/11; 0 = góc vuông
    def chu_l(u_, s_, w_, h_, RG=RG):
        if RG <= 0: return [(u_, h_), (u_, s_), (w_, s_), (w_, 0.0), (0.0, 0.0), (0.0, h_)]
        arc = [(round(u_ + RG + RG * math.cos(a), 3), round(s_ + RG + RG * math.sin(a), 3)) for a in [math.pi + k * (math.pi / 2) / 8 for k in range(9)]]
        return [(u_, h_)] + arc + [(w_, s_), (w_, 0.0), (0.0, 0.0), (0.0, h_)]
    pl = chu_l(ul, S, wl, hl)
    p = mieng("Đáy chữ L (1 miếng liền)", vl, wl, hl, (T, 0, 0, wl, T, hl), (), ("R",), poly=pl, note=f"Cắt 1 miếng chữ L như CV – không ghép, góc trong bo R{RG:g}")
    p["pl3d"] = dict(ax="y", o=[T, 0, 0], pts=pl, d=T); parts.append(p)
    parts.append(mieng("Thanh giằng trên 1", vl, 48, W - 560 - T, (560, H - 48, S - 25.2 - T / 2 + T - (T if sl else 0), W - 560 - T, 48, T), (), ("R",)))
    parts.append(mieng("Thanh giằng trên 2", vl, 48, D - 560 - T, (S - 25.2 - T / 2 + T - (T if sl else 0), H - 48, 560, T, 48, D - 560 - T), (), ("R",)))
    n = int(t.get("ke", 0) or 0)
    for k in range(n):
        yc = T + (k + 1) * (H - 60 - T) / (n + 1)
        LU = ke_lui(t)                                            # CV Shelf Setback 10: kệ lùi so với mặt trước CẢ 2 nhánh
        wk, hk, uk, sk = W - 2 * T - 2, D - 2 * T - LU, 560 - LU - T - 1, S - LU
        p = mieng(f"Kệ chữ L {k + 1} (1 miếng liền)", vl, wk, hk, (T + 1, yc, T, wk, T, hk), (), ("R",), loai="ke",
                  poly=chu_l(uk, sk, wk, hk), note=f"Cắt 1 miếng chữ L như CV, lùi {LU:g}, góc trong bo R{RG:g}")
        p["pl3d"] = dict(ax="y", o=[T + 1, yc, T], pts=p["poly"], d=T); parts.append(p)
    pk["Chốt kệ"] += 8 * n; pk["Vít 4x50 (ráp thùng)"] += 28
    thanh_shadowline(dict(t, d=560.0), parts, nt, x0=560.0, x1=W - T)
    if sl: cb.append(f"#{so}: tủ góc shadowline – thanh 50 cần cắt cho cả 2 mặt, kiểm tay")
    aos.append(ao("Chân tủ", (0, -float(t.get("chan") or 0), 0, W, float(t.get("chan") or 0), 560 - 50), "#2f2f31", loai="chan"))
    aos.append(ao("Chân tủ", (0, -float(t.get("chan") or 0), 560, 560 - 50, float(t.get("chan") or 0), D - 560), "#2f2f31", loai="chan"))
    return parts + doors, aos, pk, cb


def tu_treo_goc(t, so):
    """TỦ TREO GÓC L theo CV "90 Deg Wall Corner – LEFT" (MN Joinery, đo 20/11: 600 × 850 × 600, nhánh 300):
    2 hông đầu nhánh (sâu nhánh), 2 hậu (dài W − T, nhánh D − 2T), nóc + đáy + kệ = 1 MIẾNG CHỮ L LIỀN bo R20, 2 cánh GẬP (bi-fold)."""
    parts, aos, pk, cb = [], [], Counter(), []
    W, H, D = t["w"], t["h"], t["d"]; vl = t["vl_thung"]; T = VAT_LIEU[vl]["lz"]; X = T + 0.5
    A = float(t.get("sau_nhanh") or 300)
    if W < A + 250 or D < A + 250:
        cb.append(f"#{so}: tủ treo góc cần mỗi chiều ≥ sâu nhánh + 250 (đang {W:.0f} × {D:.0f}, nhánh {A:.0f}) – đã nới"); W = max(W, A + 250); D = max(D, A + 250); t = dict(t, w=W, d=D)
    vm, shaker, ghi = mat_ngoai(t); tf = VAT_LIEU[vm]["lz"]
    du = float(t.get("_du") or 0); y0 = -du if du else HO; hd = (H - HO + du) if du else (H - 2 * HO)
    doors = []; lo_cuoi = []
    w2 = D - HO - A; w1 = W - HO - (A + tf + KHE)
    _canh_rieng(t, so, doors, pk, cb, (A, y0, A, tf, hd, w2), "R", "x", [], aos, "Cánh góc A (bắt hông)")
    cA = doors[-1]; cA["anim"]["id"] = "A"
    lo_cuoi += [(y0 + c + s_, A - 37.0, 5.0, 12.0) for c in tam_ban_le(hd) for s_ in (-16, 16)]
    cA["holes"] += [(r1(c + s_), 39.0, 5.0, 10.0) for c in tam_ban_le(hd) for s_ in (-16, 16)]
    _canh_rieng(t, so, doors, pk, cb, (A + tf + KHE, y0, A, w1, hd, tf), "L", "z", [], aos, "Cánh góc B (gập vào cánh A)")
    an = doors[-1]["anim"]; an.clear(); an.update(kieu="gap", cha="A", px=A + tf, pz=A + tf, s=-1)
    nb = so_ban_le(hd); pk["Bản lề giảm chấn + đế"] -= 2 * nb
    pk["Bản lề góc 90° + đế 90 (cánh A bắt hông – CV HNG90)"] += nb
    pk["Bản lề cánh đôi + đế cánh đôi (bi-fold, cánh B – CV S_HNGDD)"] += nb
    base = [(x, y, 5.0, X) for x in (T / 2, H - T / 2) for y in (50.0, A - 49.0)]
    parts.append(mieng("Hông phải (đầu nhánh dài)", vl, H, A, (W - T, 0, 0, T, H, A), [(H - x, y, d, p) for x, y, d, p in base], ("T",)))
    parts.append(mieng("Hông cuối (đầu nhánh dọc)", vl, H, A, (0, 0, D - T, A, H, T), [(H - x, y, d, p) for x, y, d, p in base + lo_cuoi], ("T",), note="Có đế bản lề góc 90 cho cánh A"))
    parts.append(mieng("Hậu dài", vl, W - T, H, (0, 0, 0, W - T, H, T), (), (), loai="hau", note="Chạy hết góc – hậu nhánh bắt vào mặt trong"))
    parts.append(mieng("Hậu nhánh", vl, D - 2 * T, H, (0, 0, T, T, H, D - 2 * T), (), (), loai="hau"))
    RG = max(float(t.get("ke_bo", 20) or 0), 0.0)
    def chu_l(u_, s_, w_, h_):
        if RG <= 0: return [(u_, h_), (u_, s_), (w_, s_), (w_, 0.0), (0.0, 0.0), (0.0, h_)]
        arc = [(round(u_ + RG + RG * math.cos(a), 3), round(s_ + RG + RG * math.sin(a), 3)) for a in [math.pi + k * (math.pi / 2) / 8 for k in range(9)]]
        return [(u_, h_)] + arc + [(w_, s_), (w_, 0.0), (0.0, 0.0), (0.0, h_)]
    wl, hl, ul = W - 2 * T, D - 2 * T, A - T
    for ten, yy in (("Đáy chữ L (1 miếng liền)", 0.0), ("Nóc chữ L (1 miếng liền)", H - T)):
        pl = chu_l(ul, ul, wl, hl)
        p = mieng(ten, vl, wl, hl, (T, yy, T, wl, T, hl), (), ("R",), poly=pl, note=f"1 miếng chữ L như CV, góc trong bo R{RG:g}")
        p["pl3d"] = dict(ax="y", o=[T, yy, T], pts=pl, d=T); parts.append(p)
    n = int(t.get("ke", 0) or 0); LU = ke_lui(t)
    for k in range(n):
        yc = T + (k + 1) * (H - 2 * T) / (n + 1)
        wk, hk, uk = wl - 1, hl - 1, ul - LU
        p = mieng(f"Kệ chữ L {k + 1} (1 miếng liền)", vl, wk, hk, (T, yc, T, wk, T, hk), (), ("R",), loai="ke", poly=chu_l(uk, uk, wk, hk), note=f"1 miếng chữ L như CV, lùi {LU:g}, bo R{RG:g}")
        p["pl3d"] = dict(ax="y", o=[T, yc, T], pts=p["poly"], d=T); parts.append(p)
    pk["Chốt kệ"] += 8 * n; pk["Vít 4x50 (ráp thùng)"] += 20
    if t.get("loai") == "cao_goc" or float(t.get("chan") or 0) > 0: chan_tu(t, aos, pk)            # pantry góc L đứng trên chân
    else: pk["Pát treo tủ (cặp)"] += 2
    if H > 1500 and t.get("loai") == "cao_goc" and n < 3: cb.append(f"#{so}: pantry góc cao {H:.0f} chỉ {n} kệ – nên 4–5 kệ")
    return parts + doors, aos, pk, cb


def tu_goc_mu(t, so):
    """TỦ GÓC MÙ (blind corner) theo CV "Blum - 1 Door Floor - BLIND - Left/Right" (MN Joinery #415 / #40):
    mặt mù cùng màu cánh bắt chết phía bên mù, cánh BẢN LỀ VỀ PHÍA MẶT MÙ, đế bản lề bắt vào LƯNG MẶT MÙ (không khoan hông);
    sau mặt mù có tấm lót (ván thùng) để bắt vít mặt mù, chừa 100 trước mép cánh."""
    parts, aos, pk, cb = [], [], Counter(), []
    W, H, D = t["w"], t["h"], t["d"]; T0 = VAT_LIEU[t["vl_thung"]]["lz"]; sl = bool(t.get("shadowline"))
    cw = float(t.get("cua_w") or 500); mu = W - cw; ben = t.get("mu_ben", "L")
    if mu < 150: cb.append(f"#{so}: phần mù chỉ {mu:.0f} – tủ góc mù nên rộng hơn (CV: 1100 với cửa 500)")
    vm, shaker, ghi = mat_ngoai(t); tf = VAT_LIEU[vm]["lz"]; hd = H - HO - (SL_CUA if sl else HO)
    edges = () if vm in ("MDF18", "MDF21") else ("T", "B", "L", "R")
    xmep = mu if ben == "L" else cw                        # đường chia mặt mù / cánh
    ws = mu - HO - KHE / 2; xs = HO if ben == "L" else cw + KHE / 2
    doors = []
    bl = "L" if ben == "L" else "R"                        # bản lề luôn ở cạnh giáp mặt mù
    x0 = xmep + KHE / 2 if ben == "L" else HO
    lt, lp = [], []
    if int(t.get("canh", 1) or 1) >= 2:                   # 2 cánh: cánh sát mặt mù bản lề vào mặt mù, cánh kia bản lề vào hông
        wd2 = (cw - HO - KHE / 2 - KHE) / 2
        _canh_rieng(t, so, doors, pk, cb, (x0, HO, D, wd2, hd, tf), "L", "z", [] if ben == "L" else lt, aos)
        _canh_rieng(t, so, doors, pk, cb, (x0 + wd2 + KHE, HO, D, wd2, hd, tf), "R", "z", lp if ben == "L" else [], aos)
        pk["Bản lề giảm chấn + đế"] += 0
    else:
        _canh_rieng(t, so, doors, pk, cb, (x0, HO, D, cw - HO - KHE / 2, hd, tf), bl, "z", [], aos)
    dx = (xmep - 22.5) - xs if ben == "L" else (xmep + 22.5) - xs           # tâm đế, đo trên mặt mù (CV: cách đường chia 22.5)
    lo_de = [(r1(c + s_), r1(dx), 5.0, 10.0) for c in tam_ban_le(hd) for s_ in (-16, 16)]
    parts.append(mieng("Mặt mù (cùng màu cánh)", vm, hd, ws, (xs, HO, D, ws, hd, tf), lo_de, edges, (),
                       "Bắt chết vào tấm lót mù. Lưng mặt mù có đế bản lề cho cánh (theo CV)", loai="tam", rot=False))
    pk["Bản lề giảm chấn + đế"] -= so_ban_le(hd); pk["Bản lề + đế bắt lưng mặt mù (blind corner – CV)"] += so_ban_le(hd)
    if not pk["Bản lề giảm chấn + đế"]: del pk["Bản lề giảm chấn + đế"]
    lw = mu - 100 - T0
    if lw > 50:
        xl = T0 if ben == "L" else W - T0 - lw
        parts.append(mieng("Tấm lót mù (sau mặt mù)", t["vl_thung"], H - T0, lw, (xl, T0, D - T0, lw, H - T0, T0), (), ("T",),
                           note="Đứng sát mặt trước thùng, từ hông bên mù tới cách đường chia 100 (CV Blind Panel)", loai="tam"))
    ke = []
    ke_di_dong(t, so, ke, pk, T0, W - 2 * T0, T0, H - 60, D - T0 - 10 - T0, lt, lp)
    thung_duoi(t, so, parts, pk, cb, lt, lp, [(H - SL_H, H)] if sl else [])
    chan_tu(t, aos, pk)
    return parts + ke + doors, aos, pk, cb


def tu_treo_mu(t, so):
    """TỦ TREO GÓC MÙ theo CV "Blum - 1 Door Wall - BLIND - Left/Right" (MN Joinery, đo 20/11: 650 × 850 × 300):
    thùng tủ treo thường (kệ chạy suốt 615.2), mặt mù cùng màu cánh 340 bắt chết, cánh 306 BẢN LỀ VỀ PHÍA MẶT MÙ (đế bắt lưng mặt mù),
    tấm lót mù (ván thùng) đứng sau mặt mù cao giữa nóc-đáy (CV Blind Panel 224.6 × 817.2)."""
    T0 = VAT_LIEU[t["vl_thung"]]["lz"]; W, H, D = t["w"], t["h"], t["d"]
    parts, aos, pk, cb = tu_hop(dict(t, canh=0, ke_lui=max(ke_lui(t), T0 + 1.6)), so)        # kệ chừa tấm lót mù phía trước (CV kệ 265.6 với sâu 300)
    for q in parts:                                # kệ cố định cũng lùi sau tấm lót mù (tấm lót đứng suốt giữa nóc–đáy)
        if q["name"] == "Kệ cố định":
            q["h"] = r1(q["h"] - T0 - 1); b = list(q["box"]); b[5] = q["h"]; q["box"] = b
            q["poly"] = [(x, min(y, q["h"])) for x, y in q["poly"]]
    cw = float(t.get("cua_w") or 310); mu = W - cw; ben = t.get("mu_ben", "L")
    if mu < 150 or cw < 200: cb.append(f"#{so}: tủ treo góc mù: phần mù {mu:.0f} / cửa {cw:.0f} – kiểm lại (CV: 650 với cửa ~310)")
    vm, shaker, ghi = mat_ngoai(t); tf = VAT_LIEU[vm]["lz"]
    du = float(t.get("_du") or 0); y0 = -du if du else HO; hd = (H - HO + du) if du else (H - 2 * HO)
    edges = () if vm in ("MDF18", "MDF21") else ("T", "B", "L", "R")
    xmep = mu if ben == "L" else cw
    ws = mu - HO - KHE / 2; xs = HO if ben == "L" else cw + KHE / 2
    x0 = xmep + KHE / 2 if ben == "L" else HO
    doors = []
    if int(t.get("canh", 1) or 1) >= 2:                 # CV "2 Door Wall - BLIND": cánh sát mặt mù bản lề vào mặt mù, cánh kia bản lề vào hông tủ
        wd2 = (cw - HO - KHE / 2 - KHE) / 2; lo_h = []
        if ben == "L":
            _canh_rieng(t, so, doors, pk, cb, (x0, y0, D, wd2, hd, tf), "L", "z", [], aos)
            _canh_rieng(t, so, doors, pk, cb, (x0 + wd2 + KHE, y0, D, wd2, hd, tf), "R", "z", lo_h, aos)
        else:
            _canh_rieng(t, so, doors, pk, cb, (x0, y0, D, wd2, hd, tf), "L", "z", lo_h, aos)
            _canh_rieng(t, so, doors, pk, cb, (x0 + wd2 + KHE, y0, D, wd2, hd, tf), "R", "z", [], aos)
        hong = next(q for q in parts if q["name"] == ("Hông phải" if ben == "L" else "Hông trái"))
        hong["holes"] += [(r1(H - a) if ben == "L" else r1(a), r1(b), c, d) for a, b, c, d in lo_h]
    else:
        _canh_rieng(t, so, doors, pk, cb, (x0, y0, D, cw - HO - KHE / 2, hd, tf), "L" if ben == "L" else "R", "z", [], aos)
    dx = (xmep - 22.5) - xs if ben == "L" else (xmep + 22.5) - xs
    lo_de = [(r1(c + s_), r1(dx), 5.0, 10.0) for c in tam_ban_le(hd) for s_ in (-16, 16)]
    parts.append(mieng("Mặt mù (cùng màu cánh)", vm, hd, ws, (xs, y0, D, ws, hd, tf), lo_de, edges, (),
                       "Bắt chết vào tấm lót mù. Lưng mặt mù có đế bản lề cho cánh (theo CV)", loai="tam", rot=False))
    pk["Bản lề + đế bắt lưng mặt mù (blind corner – CV)"] += so_ban_le(hd)
    pk["Bản lề giảm chấn + đế"] = so_ban_le(hd) if int(t.get("canh", 1) or 1) >= 2 else 0     # chỉ cánh bắt hông mới dùng bản lề + đế thường
    if pk["Bản lề giảm chấn + đế"] <= 0: del pk["Bản lề giảm chấn + đế"]
    lw = mu - 100 - T0
    if lw > 50:
        xl = T0 if ben == "L" else W - T0 - lw
        parts.append(mieng("Tấm lót mù (sau mặt mù)", t["vl_thung"], H - 2 * T0, lw, (xl, T0, D - T0, lw, H - 2 * T0, T0), (), ("T",),
                           note="Đứng sát mặt trước thùng giữa nóc và đáy, từ hông bên mù tới cách đường chia 100 (CV Blind Panel)", loai="tam"))
    if t.get("tay_nam"): pk["Tay nắm"] += 0
    return parts + doors, aos, pk, cb


def tu_cong(t, so):
    """TỦ CONG BO CẠNH đầu hàng: 1/4 tròn bán kính = rộng tủ, mặt cong uốn từ ván màu xẻ rãnh (QUY-TAC mục 10), nóc/đáy/kệ cắt cung."""
    parts, aos, pk, cb = [], [], Counter(), []
    W, H, D = t["w"], t["h"], t["d"]; vl = t["vl_thung"]; T = VAT_LIEU[vl]["lz"]; R = min(W, D); ben = t.get("cong_ben", "R")
    vm, shaker, ghi = mat_ngoai(t); tf = VAT_LIEU[vm]["lz"]
    if shaker: cb.append(f"#{so}: tủ cong không làm cánh shaker – đổi sang cánh phẳng ván màu")
    if R < 150: cb.append(f"#{so}: bán kính {R:.0f} nhỏ – uốn ván 16 dễ gãy, nên R ≥ 200")
    sl = bool(t.get("shadowline")); hd = H - HO - (SL_CUA if sl else HO)
    cung = dict(cx=0.0 if ben == "R" else W, cz=D - R, r=R, ben=ben)                # tâm cung ở góc sau, phía trong
    # MẶT CONG = 1 tấm ván màu quấn: đoạn thẳng hông (D-R) + cung R, rãnh CHỈ trong vùng cung (cách thư viện Huân "CUC CONG": mũi 10, bước 13, chừa da 1.5)
    # đầu tấm phía trước (cạnh lộ, sát cánh) chừa DUOI mm ván đặc để dán nẹp – anh Tan 20/11
    PITCH, WEB, DUOI = 13.0, 1.5, 19.0
    S = max(D - R, 0.0); La = math.pi / 2 * (R + tf - WEB / 2); L = S + La
    n = max(int((La - DUOI - 5) / PITCH) + 1, 1)
    us = [L - DUOI - 5 - k * PITCH for k in range(n)]                 # tâm rãnh, đo từ đầu sau (u=0 sát tường)
    if ben == "L": us = [L - u for u in us]                           # tủ cong trái: lật tấm, rãnh vẫn ở mặt trong
    p = mieng("Mặt cong (ván màu quấn hông + cung, xẻ rãnh uốn)", vm, L, hd, (0, HO, D - R, W, hd, R), (), ("T", "B", "R" if ben == "R" else "L"), (),
              f"UỐN CONG R{R:.0f}: {n} rãnh Ø10 sâu {tf - WEB:.1f} bước {PITCH:.0f} mặt trong, chỉ trong vùng cung; đoạn thẳng {S:.0f} quấn luôn hông ngoài; "
              f"đầu trước chừa {DUOI:.0f} đặc để dán nẹp; vân theo chiều quấn", loai="canh", rot=False)
    p["grooves"] = [([(round(u, 2), -0.15), (round(u, 2), hd + 0.15)], tf - WEB) for u in us]
    p["cung"] = dict(cung, s=S); p["ngoai"] = False; parts.append(p)        # 3D vẽ 1 khối liền: đoạn thẳng hông + cung (đúng 1 tấm CNC)
    # cốt cong: nóc + đáy + kệ cắt cung (HMR), hông thẳng phía sau và bên trong
    arc = [(R * math.cos(a), R * math.sin(a)) for a in [i * math.pi / 2 / 12 for i in range(13)]]
    poly = [(0.0, 0.0)] + [(round(x, 3), round(y, 3)) for x, y in arc]
    for ten, y in (("Đáy cong", 0.0), ("Nóc cong", H - T)):
        q = mieng(ten, vl, R, R, (0, y, D - R, W, T, R), (), ("R",), poly=poly, note="Cắt cung R%.0f – cốt uốn" % R); q["cung"] = cung; parts.append(q)
    n_ke = int(t.get("ke", 0) or 0)
    for k in range(n_ke):
        yc = T + (k + 1) * (H - 60 - T) / (n_ke + 1)
        q = mieng(f"Kệ cong {k + 1}", vl, R - 10, R - 10, (0, yc, D - R, W - 10, T, R - 10), (), ("R",), poly=[(0.0, 0.0)] + [(round(x * (R - 10) / R, 3), round(y * (R - 10) / R, 3)) for x, y in arc], loai="ke"); q["cung"] = dict(cung, r=R - 10); parts.append(q)
    xs = 0.0 if ben == "R" else W - T
    parts.append(mieng("Hông thẳng", vl, H, D, (xs, 0, 0, T, H, D), [(T / 2, y, 5.0, T + 0.5) for y in (50.0, D / 2, D - 49)] + [(x, T / 2, 5.0, T + 0.5) for x in (66.4, H - 50)], ("T",)))
    parts.append(mieng("Hậu", vl, H - T, W - T, (T if ben == "R" else 0, T, 0, W - T, H - T, T), (), (), loai="hau"))
    if D > R: parts.append(mieng("Hông ngoài HMR (phần thẳng, trong tấm quấn)", vl, H, D - R, (W - T if ben == "R" else 0, 0, 0, T, H, D - R), (), ()))
    pk["Vít 4x50 (ráp thùng)"] += 12; pk["Chốt kệ"] += 4 * n_ke
    if sl: cb.append(f"#{so}: tủ cong shadowline – thanh 50 phải uốn theo, chưa tự tính")
    chan_tu(dict(t, d=D), aos, pk)
    return parts, aos, pk, cb


def tu_duoi_hoc(t, so):
    parts, aos, pk, cb = [], [], Counter(), []
    W, H, D = t["w"], t["h"], t["d"]; vl = t["vl_thung"]; T = VAT_LIEU[vl]["lz"]; iw = W - 2 * T
    vm, shaker, ghi = mat_ngoai(t); tf = VAT_LIEU[vm]["lz"]
    sl = bool(t.get("shadowline")); slg = bool(t.get("sl_giua")) and sl
    n = max(1, int(t.get("hoc", 3) or 3))
    gap = SL_CUA if slg else KHE; top = SL_CUA if sl else HO
    # chiều cao từng mặt hộc: mặc định chia đều; "hoc_cao" = số đo các hộc TRÊN CÙNG trở xuống (vd "145,255"), các hộc còn lại tự chia phần còn lại (anh Tan 20/11)
    rieng = []
    for x in str(t.get("hoc_cao") or "").replace(";", ",").replace("/", ",").split(","):
        try:
            v = float(x)
            if v > 0: rieng.append(v)
        except ValueError: pass
    if len(rieng) > n: n = len(rieng)
    tong = H - HO - top - (n - 1) * gap
    if len(rieng) >= n: rieng = rieng[:n - 1]                          # hộc dưới cùng luôn nhận phần còn lại để tổng khớp chiều cao tủ
    con = tong - sum(rieng)
    if rieng and con / (n - len(rieng)) < 110:
        cb.append(f"#{so}: chiều cao mặt hộc đã nhập ({', '.join(f'{v:g}' for v in rieng)}) quá lớn so với tủ – đã chia đều lại"); rieng = []; con = tong
    hfs = ([con / (n - len(rieng))] * (n - len(rieng))) + rieng[::-1]      # từ dưới lên
    hf = min(hfs)
    if hf < 110: cb.append(f"#{so}: mặt hộc chỉ cao {hf:.0f} – quá thấp, giảm số ngăn kéo")
    NL = max([v for v in RAY_NL if v <= D - T - 3] or [0])
    if not NL: cb.append(f"#{so}: tủ sâu {D:.0f} không đủ cho ray ngắn nhất (270)"); NL = 270
    lt, lp, notches, giang = [], [], ([(H - SL_H, H)] if sl else []), []
    fronts, boxes = [], []
    nin = int(t.get("hoc_trong", 0) or 0); kin = max(range(n), key=lambda i: hfs[i]) if nin else -1      # ngăn kéo trong nằm sau mặt hộc cao nhất
    wf = W - 2 * HO
    for k in range(n):
        hf = hfs[k]; yb = HO + sum(hfs[:k]) + k * gap
        if slg and k < n - 1:
            notches.append((yb + hf - (SL_H - SL_CUA), yb + hf + SL_CUA)); giang.append(yb + hf - (SL_H - SL_CUA) + 1)
        # mặt hộc: x = chiều cao, y = chiều rộng; pát Tandembox Ø10x12 cách 2 cạnh bên 29.9
        up = 96.0 if hf < 250 else 128.0 if hf < 310 else 160.0
        xs = [46.4, 78.4] + ([46.4 + up] if hf >= 46.4 + up + 30 else [])
        holes = [(x, y, 10.0, 12.0) for x in xs for y in (29.9, wf - 29.9)] if t.get("ray", "tandembox") != "go" else []
        e45 = (); note = ghi
        if sl and (slg or k == n - 1):
            if vm in ("MDF18", "MDF21"): note = (note + " | " if note else "") + "CẮT 45° CẠNH TRÊN (shadowline) – chưa tự phay, kiểm tay"
            else: e45 = ("R",); holes.append((hf - 10, wf / 2, 5.0, 1.0)); note = "Nẹp 45° cạnh có chấm Ø5 (cạnh trên)"
        an = dict(kieu="hoc", k=k)
        fronts.append(mieng(f"Mặt hộc {'shaker ' if shaker else ''}{k + 1}", vm, hf, wf, (HO, yb, D, wf, hf, tf), holes, () if vm in ("MDF18", "MDF21") else ("T", "B", "L", "R"), e45, note,
                            loai="mat_hoc", anim=an, rot=False))
        trang_tri(aos, (HO, yb, D, wf, hf, tf), shaker, "N" if t.get("tay_nam") else None, an, ngang=True)
        if t.get("mo") == "push": pk["Nhấn mở (push latch)"] += 1
        run = [(yb + 50.9, y, 5.0, DR) for y in (D - 36, D - 132, D - 260, D - (NL - 48)) if y > T + 10]
        lt += run; lp += run
        if t.get("ray", "tandembox") != "go":
            bw, bd = iw - 75, NL - 24.4
            BH = 198.0 if hf >= 255 else 166.0 if hf >= 215 else 134.0 if hf >= 180 else 83.0
            if nin and k == kin:                    # hộc có ngăn kéo trong phía trên (CV "Drawer + Inner Drawer"): hộc chính thành thấp 83
                BH = 83.0; NLi = max([v for v in RAY_NL if v <= D - T - 3 - 25] or [270]); bdi = NLi - 24.4; zfi = D - 25.0
                for j in range(nin):
                    yi = yb + 28 + 83 + 60 + j * 130.0
                    if yi + 100 > yb + hf - 10: cb.append(f"#{so}: mặt hộc {k + 1} chỉ cao {hf:.0f} – không đủ chỗ {nin} ngăn kéo trong"); break
                    ai = dict(kieu="hoc", k=k + 0.5 + j)
                    boxes.append(mieng(f"Đáy hộc trong {j + 1} (sau mặt hộc {k + 1})", vl, bw, bdi, (T + 37.5, yi, zfi - bdi, bw, T, bdi), [(x, y, 5.0, 12.0) for x in (9.0, bw - 9.0) for y in (16.2, bdi - 189.4, bdi - 43.4) if y > 0], (), loai="hoc", anim=ai))
                    boxes.append(mieng(f"Hậu hộc trong {j + 1} (sau mặt hộc {k + 1})", vl, iw - 87, 83.0, (T + 43.5, yi + T, zfi - bdi, iw - 87, 83.0, T), [(x, y, 5.0, 12.0) for x in (9.0, iw - 87 - 9.0) for y in (7.0, 39.0)], ("T",), loai="hoc", anim=ai))
                    aos.append(ao("Mặt trước hộc trong (kim loại)", (T + 21, yi, zfi - 16, iw - 42, 103, 16), "#b9bcc2", anim=ai))
                    r2 = [(yi - 28 + 50.9, z, 5.0, DR) for z in (zfi - 36, zfi - 132, zfi - 260, zfi - (NLi - 48)) if z > T + 10]; lt += r2; lp += r2
                    pk[f"Ray hộc Tandembox {NLi} (bộ)"] += 1; pk["Mặt trước hộc trong Tandembox (bộ)"] += 1
            boxes.append(mieng(f"Đáy hộc {k + 1}", vl, bw, bd, (T + 37.5, yb + 28, D - bd, bw, T, bd),
                               [(x, y, 5.0, 12.0) for x in (9.0, bw - 9.0) for y in (16.2, bd - 189.4, bd - 43.4) if y > 0], (), loai="hoc", anim=an))
            boxes.append(mieng(f"Hậu hộc {k + 1}", vl, iw - 87, BH, (T + 43.5, yb + 28 + T, D - bd, iw - 87, BH, T),
                               [(x, y, 5.0, 12.0) for x in (9.0, iw - 87 - 9.0) for y in (7.0, 39.0, 103.0, 135.0, 167.0) if y <= BH - 31], ("T",), loai="hoc", anim=an))
            for sx in (T + 21, W - T - 21 - 13):
                aos.append(ao("Thành hộc kim loại", (sx, yb + 28, D - bd, 13, min(BH, hf - 40), bd), "#c9ccd1", anim=an))
            pk[f"Ray hộc Tandembox {NL} (bộ)"] += 1
        else:  # hộc gỗ trên ray âm LEK SSC09: lòng hộc = lòng tủ - 42, dài = NL - 10, hông hộc dày 16
            hs = float(min(200, max(80, int((hf - 45) // 10) * 10))); ow = iw - 10; ln = NL - 10.0; z0 = D - ln
            sx = T + 5
            boxes.append(mieng(f"Hông hộc {k + 1} trái", vl, ln, hs, (sx, yb + 20, z0, T, hs, ln), (), ("T",), loai="hoc", anim=an))
            boxes.append(mieng(f"Hông hộc {k + 1} phải", vl, ln, hs, (sx + ow - T, yb + 20, z0, T, hs, ln), (), ("T",), loai="hoc", anim=an))
            boxes.append(mieng(f"Đầu hộc {k + 1} trước", vl, ow - 2 * T, hs, (sx + T, yb + 20, D - T, ow - 2 * T, hs, T), (), ("T",), loai="hoc", anim=an))
            boxes.append(mieng(f"Đầu hộc {k + 1} sau", vl, ow - 2 * T, hs - 13, (sx + T, yb + 33, z0, ow - 2 * T, hs - 13, T), (), ("T",), loai="hoc", anim=an,
                               note="Khoét góc dưới 33x13 + lỗ móc ray Ø6 (khoan tay)"))
            boxes.append(mieng(f"Đáy hộc {k + 1}", vl, ow - 2 * T, ln - T, (sx + T, yb + 33 - T, z0, ow - 2 * T, T, ln - T), (), (), loai="hoc", anim=an))
            pk[f"Ray âm LEK SSC09-{NL} (bộ)"] += 1; pk["Vít 4x50 (ráp thùng)"] += 12
        if t.get("tay_nam"): pk["Tay nắm"] += 1
    thung_duoi(t, so, parts, pk, cb, lt, lp, notches, giang)
    chan_tu(t, aos, pk)
    return parts + boxes + fronts, aos, pk, cb


def tu_duoi_keo(t, so):
    """tủ kéo phụ kiện: 1 mặt cao hết tủ bắt vào khung phụ kiện (thùng rác, kệ gia vị) – không bản lề, không kệ.
    Tài liệu hãng: tủ 450 cần lòng 418 (Blum / Hafele / Hailo), mặt cao tối thiểu ~600, sâu tủ tối thiểu 560 với thùng rác."""
    parts, aos, pk, cb = [], [], Counter(), []
    W, H, D = t["w"], t["h"], t["d"]; T = VAT_LIEU[t["vl_thung"]]["lz"]; iw = W - 2 * T
    vm, shaker, ghi = mat_ngoai(t); tf = VAT_LIEU[vm]["lz"]; sl = bool(t.get("shadowline"))
    pk_ten = PHU_KIEN_KEO.get(t.get("phu_kien"), PHU_KIEN_KEO["thung_rac"])
    hf = H - HO - (SL_CUA if sl else HO); wf = W - 2 * HO; an = dict(kieu="hoc", k=0)
    holes = []; e45 = (); note = (ghi + " | " if ghi else "") + f"Bắt mặt vào {pk_ten} theo dưỡng của hãng"
    if sl and vm not in ("MDF18", "MDF21"): e45 = ("R",); holes.append((hf - 10, wf / 2, 5.0, 1.0)); note += " | Nẹp 45° cạnh có chấm Ø5"
    front = mieng(f"Mặt kéo {'shaker ' if shaker else ''}({pk_ten.split(' (')[0]})", vm, hf, wf, (HO, HO, D, wf, hf, tf), holes, () if vm in ("MDF18", "MDF21") else ("T", "B", "L", "R"), e45, note,
                  loai="mat_hoc", anim=an, rot=False)
    trang_tri(aos, (HO, HO, D, wf, hf, tf), shaker, "N" if t.get("tay_nam") else None, an, ngang=True)
    aos.append(ao(pk_ten, (T + 12, 60, D - 500, iw - 24, min(H - 160, 480), 480), "#8d9197", anim=an, loai="thiet_bi"))
    thung_duoi(t, so, parts, pk, cb, [], [], [(H - SL_H, H)] if sl else [])
    chan_tu(t, aos, pk)
    pk[f"{pk_ten} cho tủ {W:.0f} (bộ)"] += 1
    if t.get("tay_nam"): pk["Tay nắm"] += 1
    if t.get("mo") == "push": pk["Nhấn mở (push latch)"] += 1
    if t.get("phu_kien") == "thung_rac":
        if hf < 600: cb.append(f"#{so}: mặt thùng rác cao {hf:.0f} < 600 – nhiều loại thùng rác kéo cần mặt cao tối thiểu 600")
        if D < 560: cb.append(f"#{so}: tủ sâu {D:.0f} < 560 – thùng rác kéo thường cần sâu tối thiểu 560")
    if iw < W - 34: cb.append(f"#{so}: lòng tủ {iw:.1f} – phụ kiện cho tủ {W:.0f} thường cần lòng {W - 32:.0f}, kiểm lại model")
    return parts + [front], aos, pk, cb


# ---------------------------------------------------------------- thùng kiểu B: tủ treo / tủ cao (hậu nằm giữa 2 hông, nóc-đáy-kệ nằm trước hậu)
def tu_hut_mui(t, so):
    """TỦ HÚT MÙI ÂM (undermount, ducted) theo Cabinet Vision "2 Door Rangehood Cab - Undermount - DUCTED" (MN Joinery #416 / CV #14):
    buồng máy cao `buong` dưới kệ cố định; che buồng máy (khấc 50x150 né bản lề); nóc + kệ cố định khoét chữ U rộng 250 cho ống gió,
    chừa dải trước 79; 2 vách ngăn + tấm che ống gió; kệ di động 2 bên; đáy = thanh trước + thanh sau (+ 2 miếng bên) chừa lỗ khoét
    đúng thông số máy (nhập mã máy -> tự tra)."""
    if t.get("kieu_hm") == "slide": return tu_hut_mui_slide(t, so)
    if t.get("kieu_hm") == "fixed":                                   # CV "2 Door Rangehood Cab - Fixed - DUCTED": tủ treo thường + hộp ống gió giữa sau (nóc/đáy/kệ khoét U), máy gắn dưới đáy
        q = dict(t, loai="treo", stack="M", stack_w=151.4, stack_d=188.6, _ong_trong=True)
        p_, a_, k_, c_ = tu_hop(q, so)
        a_.append(ao("Máy hút mùi cố định (gắn dưới đáy)", (VAT_LIEU[t["vl_thung"]]["lz"] + 10, -70, 20, t["w"] - 2 * VAT_LIEU[t["vl_thung"]]["lz"] - 20, 70, t["d"] - 40), "#3a3b3f", loai="thiet_bi"))
        return p_, a_, k_, c_
    if t.get("kieu_hm") in ("canopy",):                               # canopy: hộp thường + lỗ khoét (chưa dựng riêng)
        if float(t.get("cat_w") or 0) > t["w"] - 100: t = dict(t, cat_w=490, cat_d=265)        # máy slide-out 60cm (mặc định cũ)
        p_, a_, k_, c_ = tu_hop(t, so); c_.append(f"#{so}: rangehood kiểu {t['kieu_hm']} – Studio dựng hộp + lỗ khoét gần đúng, kiểm với CV"); return p_, a_, k_, c_
    parts, aos, pk, cb = [], [], Counter(), []
    W, H, D = t["w"], t["h"], t["d"]; vl = t["vl_thung"]; T = VAT_LIEU[vl]["lz"]; X = T + 0.5; iw = W - 2 * T; DT = D - T
    vd = vl_phu(t); TD = VAT_LIEU[vd]["lz"]                          # đáy lộ ra dưới -> ván màu cánh
    ma, may = tra_may(t.get("ma_may"))
    cat_w, cat_d, cat_tr = float(t.get("cat_w") or 862), float(t.get("cat_d") or 262), float(t.get("cat_truoc") or 50)
    if may:
        if may.get("cat_w") is not None: cat_w, cat_d, cat_tr = may["cat_w"], may["cat_d"], may["cat_truoc"]   # None = lỗ đáy chưa đo -> dùng số nhập tay
        if iw < may["long_min"]: cb.append(f"#{so}: {may['ten']} cần lòng tủ ≥ {may['long_min']:.0f}, đang {iw:.0f} – tăng rộng tủ")
        if D < may["sau_min"]: cb.append(f"#{so}: {may['ten']} cần tủ sâu ≥ {may['sau_min']:.0f}, đang {D:.0f}")
    elif ma: cb.append(f"#{so}: chưa có thông số máy '{ma}' trong thư viện – đang dùng lỗ {cat_w:.0f} x {cat_d:.0f} nhập tay, KIỂM tờ lắp của hãng")
    khong = bool(may and may.get("khong_khoet"))                            # máy không ống gió (TH603S): đáy liền
    kin = bool(may and may.get("kin")) or bool(t.get("day_lien"))           # đáy 1 tấm khoét lỗ kín như CV (P591)
    if khong: cat_w = cat_d = cat_tr = 0.0
    cat_w = min(cat_w, iw)
    het_ngang = (iw - cat_w) / 2 < 20                                          # 2 bên chừa < 20: lỗ chạy hết lòng
    if kin and het_ngang:
        cb.append(f"#{so}: lỗ {cat_w:.0f} gần bằng lòng tủ {iw:.0f} – không khoét lỗ kín được, cắt thanh trước / sau"); kin = False
    if not kin and het_ngang: cat_w = iw                                       # miếng bên < 20: bỏ, khoét hết lòng
    RS = DT - cat_tr - cat_d
    rs_min = 5.0 if kin else 15.0
    if not khong and RS < rs_min and DT - cat_d - rs_min >= 10:           # lùi lỗ ra trước (cách trước 40 chỉ là mặc định), giữ đúng lỗ của hãng
        tr0 = cat_tr; cat_tr = round(DT - cat_d - rs_min, 1); RS = rs_min
        cb.append(f"#{so}: lỗ máy {cat_d:.0f} sâu – dời lỗ ra, cách trước {tr0:.0f} → {cat_tr:.0f} để còn {rs_min:.0f} phía sau (kiểm tờ lắp của hãng)")
    if not khong and RS < rs_min:
        cb.append(f"#{so}: tủ sâu {D:.0f} quá nông cho lỗ máy {cat_d:.0f} – cần tủ sâu hơn ≥ {D + rs_min - RS + max(0.0, 10 - cat_tr):.0f}; đang thu lỗ lại (máy có thể KHÔNG lọt)"); RS = rs_min; cat_d = DT - cat_tr - RS
    if not khong and not kin and not het_ngang and min(cat_tr, RS) < 30: kin = True   # thanh đáy < 30 không cắt rời được -> 1 tấm khoét lỗ kín (như CV)
    CH = float(t.get("buong") or 350)
    FS = float((may or {}).get("u_fs") or 79.0); UW = float((may or {}).get("u_w") or 250.0)   # khoét U theo máy (DFS097A50A: 266.4 / 50)
    zk = TD + CH                                                               # mặt dưới kệ cố định
    if zk + T + 150 > H - T: cb.append(f"#{so}: buồng máy {CH:.0f} quá cao so với tủ {H:.0f}"); zk = H - T - 150 - T; CH = zk - TD
    zb = zk + T; tren = H - T - zb; VD = DT - FS
    bay = (iw - UW - 2 * T) / 2
    if bay < 100: cb.append(f"#{so}: tủ hẹp – 2 khoang bên chỉ {bay:.0f} (CV: tủ 950)")
    # ---- cánh (kể cả fingerpull dư xuống)
    lt, lp, doors = [], [], []
    du = float(t.get("_du") or 0)
    if du > 0: cac_canh(t, so, doors, pk, cb, lt, lp, y0=-du, hd=H - HO + du, out_ao=aos)
    else: cac_canh(t, so, doors, pk, cb, lt, lp, out_ao=aos)
    # ---- lỗ vít trên 2 hông (u = cao từ đáy, v = sâu từ lưng)
    v3 = (50.0, DT / 2, DT - 49.0)
    base = [(zk + T / 2, T + v, 5.0, X) for v in v3] + [(H - T / 2, T + v, 5.0, X) for v in v3]
    if khong or kin: base += [(TD / 2, T + v, 5.0, X) for v in (50.0, DT / 2, DT - 49.0)]            # đáy 1 tấm
    else: base += [(TD / 2, T + v, 5.0, X) for v in (15.0, RS - 15.0)] + [(TD / 2, D - cat_tr + v, 5.0, X) for v in (13.0, cat_tr - 13.0)]
    base += [(TD + 150 + 49.0, D - T / 2, 5.0, X), (zk - 51.0, D - T / 2, 5.0, X)]           # che buồng máy
    base += [(66.4 + k * (H - 132.8) / 2, T / 2, 5.0, X) for k in range(3)]                 # hậu
    n_ke = int(t.get("ke", 1) or 0); yke = [zb + (k + 1) * tren / (n_ke + 1) for k in range(n_ke)]
    pins = lo_chot_ke(yke, D, T)
    ed = ("T",)
    parts.append(mieng("Hông trái", vl, H, D, (0, 0, 0, T, H, D), base + pins + lt, ed))
    parts.append(mieng("Hông phải", vl, H, D, (W - T, 0, 0, T, H, D), [(H - x, y, d, p) for x, y, d, p in base + pins + lp], ed))
    parts.append(mieng("Hậu", vl, H, iw, (T, 0, 0, iw, H, T), (), (), loai="hau"))
    # ---- nóc + kệ cố định khoét U (u = ngang, v = sâu từ lưng)
    a = bay + T; b = a + UW
    u_poly = [(iw, DT), (iw, 0.0), (b, 0.0), (b, VD), (a, VD), (a, 0.0), (0.0, 0.0), (0.0, DT)]
    k3 = lambda y: [(T, y, T + VD, iw, T, FS), (T, y, T, a, T, VD), (T + b, y, T, iw - b, T, VD)]
    vv = [(u, v, 5.0, X) for u in (bay + T / 2, iw - bay - T / 2) for v in (50.0, VD - 50.0)]
    for ten, y, extra in ((f"Nóc (khoét U {UW:g} cho ống gió)", H - T, []), (f"Kệ cố định – trần buồng máy (khoét U {UW:g})", zk, [(50.0 + k * (iw - 100.0) / 3, DT - T / 2, 5.0, X) for k in range(4)])):
        p = mieng(ten, vl, iw, DT, (T, y, T, iw, T, DT), vv + extra, ("B",), poly=u_poly, note=f"Khoét U {UW:.0f} x {VD:.0f} từ lưng vào, chừa dải trước {FS:.0f} (CV)")
        p["pl3d"] = dict(ax="y", o=[T, y, T], pts=u_poly, d=T); parts.append(p)
    # ---- đáy: thanh trước + thanh sau (+ 2 miếng bên) -> lỗ khoét đúng máy
    ten_may = may["ten"] if may else f"lỗ {cat_w:.0f} x {cat_d:.0f}"
    if khong:
        parts.append(mieng("Đáy (liền – máy không ống gió)", vd, iw, DT, (T, 0, T, iw, TD, DT), (), ("T",), note=f"{ten_may}: không khoét (CV)", loai="tam"))
    elif kin:
        # 1 TẤM LIỀN khoét lỗ kín như CV (vd P591: 497 x 262 giữa tấm, chừa 35.1 hai bên, 10.8 trước / sau). u = ngang, v = sâu từ lưng
        u0 = (iw - cat_w) / 2; v0 = RS
        lo = [(u0, v0), (u0, v0 + cat_d), (u0 + cat_w, v0 + cat_d), (u0 + cat_w, v0)]
        p = mieng(f"Đáy (1 tấm khoét lỗ {cat_w:.0f} x {cat_d:.0f})", vd, iw, DT, (T, 0, T, iw, TD, DT), (), ("T",), loai="tam",
                  note=f"Khoét lỗ kín cho máy ({ten_may}): cách 2 hông {u0:.1f}, cách trước {cat_tr:.1f}, cách sau {RS:.1f} – như CV")
        p["cutouts"] = [lo]
        p["pl3d"] = dict(ax="y", o=[T, 0, T], pts=[(0.0, 0.0), (iw, 0.0), (iw, DT), (0.0, DT)], d=TD, lo=[lo]); parts.append(p)
    else:
        parts.append(mieng(f"Đáy – thanh trước {cat_tr:.0f}", vd, iw, cat_tr, (T, 0, D - cat_tr, iw, TD, cat_tr), (), ("T", "B"), note=f"Giữa 2 thanh đáy = lỗ máy ({ten_may})", loai="tam"))
        parts.append(mieng(f"Đáy – thanh sau {RS:.0f}", vd, iw, RS, (T, 0, T, iw, TD, RS), (), ("T",), note="Sát hậu", loai="tam"))
        if cat_w < iw - 0.5:
            sw = (iw - cat_w) / 2
            for k, x in enumerate((T, T + iw - sw)):
                parts.append(mieng(f"Đáy – miếng bên {'trái' if k == 0 else 'phải'}", vd, sw, cat_d, (x, 0, T + RS, sw, TD, cat_d), (), ("L" if k else "R",), note="Ép giữa 2 thanh đáy", loai="tam"))
        pk["Bát / vít ghép thanh đáy"] += 4
    # ---- che buồng máy, vách ngăn, che ống gió, kệ
    che = [(iw, CH), (iw, 150.0), (iw - 50.0, 150.0), (iw - 50.0, 0.0), (50.0, 0.0), (50.0, 150.0), (0.0, 150.0), (0.0, CH)]
    p = mieng("Tấm che buồng máy (khấc 50x150 né bản lề)", vl, iw, CH, (T, TD, D - T, iw, CH, T), [(u, CH - T / 2, 5.0, 1.0) for u in ()], ("T",), poly=che, note="Đứng sát mặt trước thùng, trên thanh đáy trước, dưới kệ cố định (CV)")
    p["pl3d"] = dict(ax="z", o=[T, TD, D - T], pts=che, d=T); parts.append(p)
    pv = [(tren / 2 + 32 * j, v, 5.0, 12.0) for j in range(-2, 3) for v in (40.0, VD - 37.0)]
    parts.append(mieng("Vách ngăn ống gió trái", vl, tren, VD, (T + bay, zb, T, T, tren, VD), pv, ("T",), note=f"Giữa 2 vách = {UW:.0f}"))
    parts.append(mieng("Vách ngăn ống gió phải", vl, tren, VD, (T + bay + T + UW, zb, T, T, tren, VD), [(tren - x, y, d, q) for x, y, d, q in pv], ("T",)))
    cw2 = UW + 2 * T - 2
    parts.append(mieng("Tấm che ống gió (trước 2 vách)", vl, tren, cw2, (T + bay + 1, zb, T + VD, cw2, tren, T), [(u, v, 5.0, X) for u in (50.0, tren / 2, tren - 50.0) for v in (T / 2 - 1, cw2 - T / 2 + 1)], ("T", "B"),
                       note="Bắt 6 vít vào mép 2 vách (CV loose duct cover)"))
    kes = []
    for yc in yke:
        for x in (T + 1, T + bay + T + UW + T + 1):
            kes.append(mieng("Kệ di động (khoang bên)", vl, DT - ke_lui(t), bay - 2, (x, yc - T / 2, T, bay - 2, T, DT - ke_lui(t)), (), ("R",), loai="ke"))
    pk["Chốt kệ"] += 8 * n_ke; pk["Vít 4x50 (ráp thùng)"] += 30
    if not t.get("chan"): pk["Pát treo tủ (cặp)"] += 1
    # ---- máy (chỉ để nhìn)
    xm = T + (iw - cat_w) / 2
    if cat_w > 0:
        aos.append(ao(f"Máy hút mùi ({ten_may})", (xm, TD - 4, T + RS, cat_w, min(CH - 20, 200), cat_d), "#2a2b2e", loai="thiet_bi"))
        aos.append(ao("Mặt máy hút mùi", (max(xm - 18, T), -6, max(T + RS - 17, T), min(cat_w + 36, iw), 6, cat_d + 34), "#3a3b3f", loai="thiet_bi"))
    else:
        aos.append(ao(f"Máy hút mùi ({ten_may}) – gắn dưới đáy", (T + 20, -60, T + 20, iw - 40, 60, DT - 40), "#3a3b3f", loai="thiet_bi"))
    aos.append(ao("Ống gió Ø150", (T + bay + T + UW / 2 - 75, zk, T + VD / 2 - 75, 150, H - zk, 150), "#b9bcc2", loai="thiet_bi"))
    return parts + kes + doors, aos, pk, cb


def tu_hut_mui_slide(t, so):
    """TỦ HÚT MÙI SLIDE-OUT (ducted) theo CV "2 Door Rangehood Cab - Slide Out - DUCTED" (học 20/11, 600 × 850 × 300):
    máy slide-out cao ~175 nằm DƯỚI thùng (thùng chỉ cao H − 175 = 675, CV hông 299 × 673); đáy + nóc khoét U 216.4 từ lưng (chừa dải trước 50)
    cho ống gió; 2 vách 265.6 × 642.2 + tấm che ống gió 231 phía trước; kệ di động 2 khoang bên; cánh dài suốt che cả máy (CV 298 × 808)."""
    parts, aos, pk, cb = [], [], Counter(), []
    W, H, D = t["w"], t["h"], t["d"]; vl = t["vl_thung"]; T = VAT_LIEU[vl]["lz"]; X = T + 0.5; iw = W - 2 * T; DT = D - T
    HZ = float(t.get("hm_cao") or 175); hc = H - HZ
    if hc < 300: cb.append(f"#{so}: thùng trên máy slide-out chỉ cao {hc:.0f} – tăng cao tủ"); HZ = H - 300; hc = 300.0
    UW = min(216.4, iw - 2 * T - 140); FS = 50.0; VD = DT - FS; bay = (iw - UW - 2 * T) / 2
    if iw < 560: cb.append(f"#{so}: lòng {iw:.0f} < 560 – máy slide-out 60cm cần lòng ≥ 560")
    # cánh: dài suốt (che cả máy), bản lề dồn vào phần có hông (HZ..H)
    vm, shaker, ghi = mat_ngoai(t); tf = VAT_LIEU[vm]["lz"]; edges = () if vm in ("MDF18", "MDF21") else ("T", "B", "L", "R")
    du = float(t.get("_du") or 0); y0 = -du if du else HO; hd = (H - HO + du) if du else (H - 2 * HO)
    n = int(t.get("canh", 2) or 0); wd = (W - 2 * HO) if n == 1 else (W - 2 * HO - KHE) / 2
    cy, dy = (22.5, 32.0) if vm == "MDF18" else (21.2, 30.8)
    tam = [HZ + 80.0 - y0, hd - 100.0] + ([((HZ + 80.0 - y0) + (hd - 100.0)) / 2] if hd > 900 else [])
    doors = []; lt, lp = [], []
    for i in range(n):
        bl = t.get("ban_le", "L") if n == 1 else ("L" if i == 0 else "R"); x0 = HO + i * (wd + KHE)
        hs = [q for x in tam for q in ((x, cy, 35.0, 14.0), (x - 22.5, dy, 8.0, 12.0), (x + 22.5, dy, 8.0, 12.0))]
        if bl == "R": hs = [(a, wd - b, c, d) for a, b, c, d in hs]
        an = dict(kieu="cua", ban_le=bl, px=x0 if bl == "L" else x0 + wd, pz=D)
        doors.append(mieng(f"Cánh {'shaker ' if shaker else ''}{'trái' if bl == 'L' else 'phải'}", vm, hd, wd, (x0, y0, D, wd, hd, tf), hs, edges, (), ghi, loai="canh", anim=an, rot=False))
        trang_tri(aos, (x0, y0, D, wd, hd, tf), shaker, ("R" if bl == "L" else "L") if t.get("tay_nam") else None, an, vi_tri="duoi")
        (lt if bl == "L" else lp).extend([(r1(y0 + c - HZ + s_), D - 37.0, 5.0, 12.0) for c in tam for s_ in (-16, 16)])
        pk["Bản lề giảm chấn + đế"] += len(tam)
        if t.get("tay_nam"): pk["Tay nắm"] += 1
    # hông (chỉ phần thùng HZ..H): toạ độ u = cao từ đáy hông
    v3 = (50.0, DT / 2, DT - 49.0)
    base = [(T / 2, T + v, 5.0, X) for v in v3] + [(hc - T / 2, T + v, 5.0, X) for v in v3] + [(66.4 + k * (hc - 132.8) / 2, T / 2, 5.0, X) for k in range(3)]
    n_ke = int(t.get("ke", 1) or 0); yke = [T + (k + 1) * (hc - 2 * T) / (n_ke + 1) for k in range(n_ke)]
    pins = lo_chot_ke(yke, D, T)
    parts.append(mieng("Hông trái", vl, hc, D, (0, HZ, 0, T, hc, D), base + pins + lt, ("T",), note=f"Thùng nằm trên máy slide-out (máy cao {HZ:.0f})"))
    parts.append(mieng("Hông phải", vl, hc, D, (W - T, HZ, 0, T, hc, D), [(hc - x, y, d, p) for x, y, d, p in base + pins + lp], ("T",)))
    parts.append(mieng("Hậu", vl, hc, iw, (T, HZ, 0, iw, hc, T), (), (), loai="hau"))
    a = bay + T; b = a + UW
    u_poly = [(iw, DT), (iw, 0.0), (b, 0.0), (b, VD), (a, VD), (a, 0.0), (0.0, 0.0), (0.0, DT)]
    vv = [(u, v, 5.0, X) for u in (bay + T / 2, iw - bay - T / 2) for v in (50.0, VD - 50.0)]
    for ten, y in ((f"Đáy (khoét U {UW:g} cho ống gió)", HZ), (f"Nóc (khoét U {UW:g} cho ống gió)", H - T)):
        p = mieng(ten, vl, iw, DT, (T, y, T, iw, T, DT), vv, ("B",), poly=u_poly, note=f"Khoét U {UW:.0f} x {VD:.0f} từ lưng, chừa dải trước {FS:.0f} (CV slide-out)")
        p["pl3d"] = dict(ax="y", o=[T, y, T], pts=u_poly, d=T); parts.append(p)
    tren = hc - 2 * T
    pv = [(tren / 2 + 32 * j, v, 5.0, 12.0) for j in range(-2, 3) for v in (40.0, VD - 37.0)]
    parts.append(mieng("Vách ngăn ống gió trái", vl, tren, VD, (T + bay, HZ + T, T, T, tren, VD), pv, ("T",), note=f"Giữa 2 vách = {UW:.0f}"))
    parts.append(mieng("Vách ngăn ống gió phải", vl, tren, VD, (T + bay + T + UW, HZ + T, T, T, tren, VD), [(tren - x, y, d, q) for x, y, d, q in pv], ("T",)))
    cw2 = UW + 2 * T - 2
    parts.append(mieng("Tấm che ống gió (trước 2 vách)", vl, tren, cw2, (T + bay + 1, HZ + T, T + VD, cw2, tren, T), [(u, v, 5.0, X) for u in (50.0, tren / 2, tren - 50.0) for v in (T / 2 - 1, cw2 - T / 2 + 1)], ("T", "B"),
                       note="Bắt vít vào mép 2 vách (CV Duct Box Front)"))
    kes = []
    for yc in yke:
        for x in (T + 1, T + bay + T + UW + T + 1):
            kes.append(mieng("Kệ di động (khoang bên)", vl, DT - ke_lui(t), bay - 2, (x, HZ + yc - T / 2, T, bay - 2, T, DT - ke_lui(t)), (), ("R",), loai="ke"))
    pk["Chốt kệ"] += 8 * n_ke; pk["Vít 4x50 (ráp thùng)"] += 26
    if not t.get("chan"): pk["Pát treo tủ (cặp)"] += 1
    aos.append(ao("Máy hút mùi slide-out", (T + 2, 0, T + 10, iw - 4, HZ - 2, DT - 20), "#2a2b2e", loai="thiet_bi"))
    aos.append(ao("Ống gió Ø150", (T + bay + T + UW / 2 - 75, HZ, T + VD / 2 - 75, 150, hc, 150), "#b9bcc2", loai="thiet_bi"))
    return parts + kes + doors, aos, pk, cb


def tu_tu_do(t, so):
    """ĐỒ RỜI: món làm riêng (bàn, kệ…) dựng sẵn từng miếng bằng script Javis (vd job KIM) – mỗi miếng có hình cắt thật (poly, lỗ, rãnh)
    + hình 3D liền đúng hình (pl3d). Studio chỉ hiển thị / kiểm / xuất lại, không tự sinh kết cấu."""
    parts = []
    for q in t.get("chi_tiet") or []:
        vl = q.get("vl") if q.get("vl") in VAT_LIEU else "HMR16"
        p = mieng(q.get("name", "Miếng"), vl, float(q["w"]), float(q["h"]), q["box"], [tuple(h) for h in q.get("holes", [])], q.get("edges", ()), (), q.get("note", ""),
                  poly=[tuple(a) for a in q["poly"]], loai=q.get("loai", "tam"), rot=bool(q.get("rot")))
        p["grooves"] = [([tuple(a) for a in g], dp) for g, dp in q.get("grooves", [])]
        if q.get("pl3d"): p["pl3d"] = q["pl3d"]
        parts.append(p)
    pk = Counter({k: v for k, v in (t.get("phu_kien") or {}).items()})
    aos = [ao(a["name"], a["box"], a.get("mau"), loai=a.get("loai", "thiet_bi")) for a in (t.get("khoi_ao") or [])]
    return parts, aos, pk, []


def poly_rang(L, Dp, tam, r, s, truoc):
    """miếng L × Dp có các rãnh rộng r sâu s tại các tâm 'tam' (dọc L) – xẻ từ mép trước (v = Dp) hoặc mép sau (v = 0). Dùng cho lưới ráp chéo (egg-crate)."""
    tam = sorted(tam)
    if truoc:
        pts = [(L, Dp), (L, 0.0), (0.0, 0.0), (0.0, Dp)]
        for c in tam: pts += [(r1(c - r / 2), Dp), (r1(c - r / 2), r1(Dp - s)), (r1(c + r / 2), r1(Dp - s)), (r1(c + r / 2), Dp)]
    else:
        pts = [(L, Dp), (L, 0.0)]
        for c in reversed(tam): pts += [(r1(c + r / 2), 0.0), (r1(c + r / 2), r1(s)), (r1(c - r / 2), r1(s)), (r1(c - r / 2), 0.0)]
        pts += [(0.0, 0.0), (0.0, Dp)]
    return pts


def ke_ruou(t, so, kes, pk, cb, T, W, H, D):
    """KỆ RƯỢU (CV "Wine Rack" floor / wall / pantry): thùng mở, trong là lưới ô vuông ráp rãnh (egg-crate) – thanh ngang xẻ rãnh từ sau,
    vách đứng xẻ rãnh từ trước, mỗi rãnh sâu nửa miếng, rộng T + 0.5. Ô lọt lòng >= 100 cho chai Ø90 nằm."""
    vl = t["vl_thung"]; iw, ih = W - 2 * T, H - 2 * T; dk = D - T - 2.0; r = T + 0.5; s = r1(dk / 2 + 5.5)     # +5.5: dao Ø10 để lại góc bo R5 đáy rãnh – xẻ sâu thêm cho 2 miếng ráp sát hết
    O = 105.0
    nc = max(1, int((iw + T) // (O + T))); nr = max(1, int((ih + T) // (O + T)))
    cw = (iw - (nc - 1) * T) / nc; ch = (ih - (nr - 1) * T) / nr
    if iw < O or ih < O: cb.append(f"#{so}: kệ rượu lòng {iw:.0f} × {ih:.0f} quá nhỏ cho chai (cần >= 100)"); return
    xs = [i * cw + (i - 1) * T + T / 2 for i in range(1, nc)]          # tâm vách đứng, tính từ lòng trái
    ys = [j * ch + (j - 1) * T + T / 2 for j in range(1, nr)]          # tâm thanh ngang, tính từ lòng dưới
    for j, yc in enumerate(ys):
        kes.append(mieng(f"Thanh ngang kệ rượu {j + 1}", vl, iw, dk, (T, T + yc - T / 2, T, iw, T, dk), (), ("T",), loai="ke",
                         poly=poly_rang(iw, dk, xs, r, s, False) if xs else None, note="Rãnh xẻ từ MÉP SAU – ráp chéo với vách đứng; keo + đinh bắn hông" if xs else ""))
    for i, xc in enumerate(xs):
        kes.append(mieng(f"Vách đứng kệ rượu {i + 1}", vl, ih, dk, (T + xc - T / 2, T, T, T, ih, dk), (), ("T",), loai="ke",
                         poly=poly_rang(ih, dk, ys, r, s, True) if ys else None, note="Rãnh xẻ từ MÉP TRƯỚC – dán chỉ mép trước bằng tay theo đoạn" if ys else ""))
    pk["Đinh bắn / keo (kệ rượu)"] += 1
    cb.append(f"#{so}: kệ rượu {nc} × {nr} = {nc * nr} ô ({cw:.0f} × {ch:.0f})")


def tu_hop(t, so, co_canh=True):
    parts, aos, pk, cb = [], [], Counter(), []
    ruou = bool(t.get("ruou")) and t["loai"] in ("duoi_canh", "treo", "cao", "ke_mo")
    if ruou: co_canh = False; t = dict(t, ke=0, ke_cd=0, hoc_trong=0, thanh_treo=False, stack="", lat="")
    W, H, D = t["w"], t["h"], t["d"]; vl = t["vl_thung"]; T = VAT_LIEU[vl]["lz"]; X = T + 0.5; iw = W - 2 * T
    if t["loai"] in TU_TREO: t = dict(t, shadowline=False)        # tủ treo không khoét shadowline trên hông
    sl = bool(t.get("shadowline")) and co_canh
    lt, lp = [], []
    doors = []; cam = []                       # cam = các khoang không đặt kệ di động (hộc lò)
    ncd = int(t.get("ke_cd", 0) or 0)
    cd = [T / 2 + (k + 1) * (H - T) / (ncd + 1) for k in range(ncd)]            # tâm kệ cố định
    _nh = int(t.get("hoc_trong", 0) or 0) if (t["loai"] == "cao" or (t["loai"] == "tu_ao" and (t.get("kieu_ao") or "") == "ke")) else 0
    if _nh and cd and cd[0] < T + 40 + _nh * 230.0 + 60:                          # có ngăn kéo trong: đẩy kệ cố định lên trên vùng hộc
        y1 = T + 40 + _nh * 230.0 + 60 + T / 2; cd = [y1 + k * (H - T - y1) / len(cd) for k in range(len(cd))]
    ray = []                                                                       # cao thanh treo
    ka = t.get("kieu_ao") or ("1_treo" if t.get("thanh_treo") else "ke")
    if t["loai"] == "tu_ao" and ka == "1_treo":            # CV "2 Dr Robe – 1 Fixed Shelf + S/HNG": kệ cố định cách nóc 408, khoang treo dài (~1820) bên dưới, không kệ di động trong khoang treo
        cd = [H - T - 408.2]; cam = [(T, cd[0] - T / 2)]; ray = [cd[0] - T / 2 - 60]
    elif t["loai"] == "tu_ao" and ka == "chia":            # CV "2 Dr Robe – SPLIT – Dwrs + Shelves & S/HNG": kệ cố định cách nóc 408, vách giữa xuống đáy, trái ngăn kéo trong + kệ, phải treo
        cd = [H - T - 408.2]; cam = [(T, cd[0] - T / 2)]; ray = [cd[0] - T / 2 - 60]
    elif t["loai"] == "tu_ao" and ka == "2_treo":          # CV "D/HNG": 2 tầng treo (áo sơ mi / quần) – kệ trên cách nóc 408, kệ giữa chia đôi khoang treo
        top = H - T - 408.2; mid = T + (top - T) / 2
        cd = [mid, top]; cam = [(T, mid - T / 2), (mid + T / 2, top - T / 2)]; ray = [mid - T / 2 - 60, top - T / 2 - 60]
    if t["loai"] == "lo_nuong":
        ly, lc, l2 = float(t.get("lo_y", 600)), float(t.get("lo_cao", 595)), float(t.get("lo2_cao", 0) or 0)
        top_lo = ly + lc + (T + l2 if l2 > 0 else 0)
        if ly < 100 or top_lo + T + 60 > H: cb.append(f"#{so}: hộc lò ({ly:.0f} → {top_lo:.0f}) không nằm gọn trong tủ cao {H:.0f}"); ly = min(max(ly, 100), H - lc - 200); l2 = 0; top_lo = ly + lc
        cd = [y for y in [ly - T / 2, ly + lc + T / 2] + ([top_lo + T / 2] if l2 > 0 else []) if y < H - 1.5 * T]      # sát nóc thì nóc làm luôn kệ
        cam = [(ly, top_lo + T)]
        if iw < 560: cb.append(f"#{so}: lòng tủ {iw:.0f} < 560 – lò 60cm không vừa (hộc lò cần rộng tối thiểu 560)")
        if D - T < 550: cb.append(f"#{so}: lòng sâu {D - T:.0f} < 550 – lò cần sâu tối thiểu 550")
        aos.append(ao("Lò nướng", (T + 2, ly + 2, D - 20, iw - 4, lc - 4, 40), "#17181b", loai="thiet_bi"))
        if l2 > 0: aos.append(ao("Lò vi sóng", (T + 2, ly + lc + T + 2, D - 20, iw - 4, l2 - 4, 40), "#1f2023", loai="thiet_bi"))
        nh = int(t.get("hoc_duoi", 0) or 0)
        if co_canh and nh > 0:                 # ngăn kéo dưới lò (cách TPW vẫn làm): mặt hộc + đáy + hậu Tandembox
            vm, shaker, ghi = mat_ngoai(t); tf = VAT_LIEU[vm]["lz"]; zone = ly - T - HO - KHE / 2; hf = (zone - (nh - 1) * KHE) / nh; wf = W - 2 * HO
            NL = max([v for v in RAY_NL if v <= D - T - 3] or [270])
            for k in range(nh):
                yb = HO + k * (hf + KHE); an = dict(kieu="hoc", k=k)
                up = 96.0 if hf < 250 else 128.0 if hf < 310 else 160.0
                hl = [(x, y, 10.0, 12.0) for x in [46.4, 78.4] + ([46.4 + up] if hf >= 46.4 + up + 30 else []) for y in (29.9, wf - 29.9)]
                doors.append(mieng(f"Mặt hộc {'shaker ' if shaker else ''}{k + 1}", vm, hf, wf, (HO, yb, D, wf, hf, tf), hl, () if vm in ("MDF18", "MDF21") else ("T", "B", "L", "R"), (), ghi, loai="mat_hoc", anim=an, rot=False))
                trang_tri(aos, (HO, yb, D, wf, hf, tf), shaker, "N" if t.get("tay_nam") else None, an, ngang=True)
                run = [(yb + 50.9, y, 5.0, DR) for y in (D - 36, D - 132, D - 260, D - (NL - 48)) if y > T + 10]; lt += run; lp += run
                bw, bd = iw - 75, NL - 24.4; BH = 198.0 if hf >= 255 else 166.0 if hf >= 215 else 134.0 if hf >= 180 else 83.0
                parts.append(mieng(f"Đáy hộc {k + 1}", vl, bw, bd, (T + 37.5, yb + 28, D - bd, bw, T, bd), [(x, y, 5.0, 12.0) for x in (9.0, bw - 9.0) for y in (16.2, bd - 189.4, bd - 43.4) if y > 0], (), loai="hoc", anim=an))
                parts.append(mieng(f"Hậu hộc {k + 1}", vl, iw - 87, BH, (T + 43.5, yb + 28 + T, D - bd, iw - 87, BH, T), [(x, y, 5.0, 12.0) for x in (9.0, iw - 87 - 9.0) for y in (7.0, 39.0, 103.0, 135.0, 167.0) if y <= BH - 31], ("T",), loai="hoc", anim=an))
                pk[f"Ray hộc Tandembox {NL} (bộ)"] += 1
                if t.get("tay_nam"): pk["Tay nắm"] += 1
                if t.get("mo") == "push": pk["Nhấn mở (push latch)"] += 1
            cam.append((T, ly - T))
        if co_canh:
            if nh <= 0: cac_canh(t, so, doors, pk, cb, lt, lp, y0=HO, hd=ly - T - HO - KHE / 2, out_ao=aos)        # cánh dưới lò
            y1 = top_lo + T + KHE / 2; hd1 = H - y1 - (SL_CUA if sl else HO)
            if hd1 >= 100: cac_canh(t, so, doors, pk, cb, lt, lp, y0=y1, hd=hd1, out_ao=aos)            # cánh trên lò (thùng dưới của tủ lò tách 2 thùng có thể không còn)
    elif t["loai"] == "tu_lanh":
        # TỦ LẠNH ÂM (integrated): hộc lọt lòng >= 560 rộng, >= 550 sâu, cao 1772-1780 tuỳ model; cửa tủ lạnh CÙNG MÀU CÁNH (anh Tan 19/11)
        tlc = float(t.get("tl_cao") or 1780)
        if tlc < 600 or T + tlc + T + 150 > H: cb.append(f"#{so}: hộc tủ lạnh cao {tlc:.0f} không nằm gọn trong tủ cao {H:.0f}"); tlc = max(600.0, H - 2 * T - 300)
        yk = T + tlc; cd = [yk + T / 2]; cam = [(T, yk)]
        if iw < 560: cb.append(f"#{so}: lòng tủ {iw:.0f} < 560 – tủ lạnh âm cần hộc rộng tối thiểu 560")
        if D < 560: cb.append(f"#{so}: tủ sâu {D:.0f} < 560 – tủ lạnh âm cần hộc sâu tối thiểu 550")
        if t.get("mo") == "push": cb.append(f"#{so}: cửa tủ lạnh âm không dùng bấm mở (ron hút chặt) – đổi sang tay nắm")
        aos.append(ao("Tủ lạnh âm", (T + 3, T + 2, 20, iw - 6, tlc - 4, D - 42), "#e4e6e9", loai="thiet_bi"))
        if co_canh:
            vm, shaker, ghi = mat_ngoai(t); tf = VAT_LIEU[vm]["lz"]; wd = W - 2 * HO; bl = t.get("ban_le", "L"); truot = t.get("tl_ban_le") == "truot"
            y_top = yk + T / 2 - KHE / 2; chia = float(t.get("tl_chia") or 0)
            if chia and not (300 <= chia <= y_top - HO - 300 - KHE): cb.append(f"#{so}: chiều cao cửa dưới {chia:.0f} không hợp lệ – làm 1 cửa suốt"); chia = 0
            cua = [(HO, chia), (HO + chia + KHE, y_top - HO - chia - KHE)] if chia else [(HO, y_top - HO)]
            n2 = int(t.get("canh", 1) or 1)
            cua = [(yb, hd, (HO + i * ((wd - KHE) / 2 + KHE), (wd - KHE) / 2, "L" if i == 0 else "R") if (n2 == 2 and (k == len(cua) - 1)) else (HO, wd, bl))
                   for k, (yb, hd) in enumerate(cua) for i in (range(2) if (n2 == 2 and k == len(cua) - 1) else range(1))]   # tủ lạnh 2 cánh (French door): cửa trên chia đôi
            for k, (yb, hd, (x0, wk, blk)) in enumerate(cua):
                ten = "Cửa tủ lạnh" + ((" dưới" if (chia and k == 0) else (" trên" if chia else "")) + (f" {'trái' if blk == 'L' else 'phải'}" if n2 == 2 and not (chia and k == 0) else "")) + " (cùng màu cánh)"
                note = (ghi + " | " if ghi else "") + ("Bản lề TRƯỢT (sliding): cánh treo bằng bản lề tủ, nối ray trượt vào cửa tủ lạnh" if truot
                                                         else "DOOR-ON-DOOR: bắt thẳng vào cửa tủ lạnh theo dưỡng của hãng – không khoan bản lề")
                box = (x0, yb, D, wk, hd, tf); an = dict(kieu="cua", ban_le=blk, px=x0 if blk == "L" else x0 + wk, pz=D)
                doors.append(mieng(ten, vm, hd, wk, box, lo_canh(hd, wk, vm, blk) if truot else [], () if vm in ("MDF18", "MDF21") else ("T", "B", "L", "R"), (), note, loai="canh", anim=an, rot=False))
                trang_tri(aos, box, shaker, ("R" if blk == "L" else "L") if t.get("tay_nam") else None, an, vi_tri="giua" if not chia else ("tren" if (k == 0 and chia) else "duoi"))
                if truot:
                    (lt if blk == "L" else lp).extend([(yb + c + s, D - 37, 5.0, 12.0) for c in tam_ban_le(hd) for s in (-16, 16)])
                    pk["Bản lề giảm chấn + đế"] += so_ban_le(hd)
                if t.get("tay_nam"): pk["Tay nắm"] += 1
            y1 = yk + T / 2 + KHE / 2
            cac_canh(t, so, doors, pk, cb, lt, lp, y0=y1, hd=H - y1 - (SL_CUA if sl else HO), out_ao=aos)                # cánh tủ phía trên tủ lạnh
    elif co_canh and t["loai"] == "treo" and t.get("lat") in ("HF", "HK", "HS", "HL"):
        canh_lat(t, so, doors, pk, cb, lo_noc_lat := [], aos)
    elif co_canh:
        du = float(t.get("_du") or 0)
        if du > 0: cac_canh(t, so, doors, pk, cb, lt, lp, y0=-du, hd=H - HO + du, out_ao=aos)       # fingerpull: cánh tủ treo dư xuống dưới đáy thùng
        else: cac_canh(t, so, doors, pk, cb, lt, lp, out_ao=aos)
    ys = (50.0, r1((50 + D - 49) / 2), D - 49.0) if D >= 250 else (50.0, D - 49.0)
    base = [(x, y, 5.0, X) for x in ([] if (t.get("khong_day") and t["loai"] == "treo") else [T / 2]) + [H - T / 2] + cd for y in ys]
    nb = max(3, int(round(H / 400)) + 1); step = (H - 2 * 66.4) / (nb - 1)
    if t["loai"] == "tu_lanh":             # hộc tủ lạnh để hở hậu (thông gió): chỉ bắt hậu cho phần tủ phía trên
        base += [(v, T / 2, 5.0, X) for v in (cd[0] + T / 2 + 50, H - 66.4) if v < H - 20]
    else: base += [(66.4 + k * step, T / 2, 5.0, X) for k in range(nb)]
    kes = []
    # kệ di động chia đều trong từng khoang giữa các kệ cố định (bỏ khoang hộc lò)
    lat = co_canh and t["loai"] == "treo" and t.get("lat") in ("HF", "HK", "HS", "HL")
    no = ne_ong(t, cb, so) if t["loai"] in ("treo", "cao") else None
    nht = _nh if co_canh else 0
    if nht:                                        # tủ cao có ngăn kéo trong ở dưới (CV "2 Door + 4 Std + 2 Pot INT Drawers - Pantry")
        zt = T + 40 + nht * 230.0
        if cd and zt > cd[0] - T / 2 - 60: cb.append(f"#{so}: {nht} ngăn kéo trong cao {zt:.0f} chạm kệ cố định – giảm số hộc hoặc dời kệ")
        hoc_trong(t, so, kes_ht := [], aos, pk, cb, lt, lp, y0=T, buoc=230.0)
        cam.append((T, zt + 20))
    chia = t["loai"] == "tu_ao" and ka == "chia"
    xp = r1((W - T) / 2); rx0, rw = (xp + T, W - T - (xp + T)) if chia else (T, iw)
    if chia: tu_ao_chia(t, so, parts, kes0 := [], aos, pk, cb, lt, lp, xp, cd[0])
    bounds = sorted([T] + cd + [H - T] + ([T + 40 + nht * 230.0 + 20] if nht else [])); n = 0 if chia else int(t.get("ke", 0) or 0); sau = D - T - ke_lui(t) - (36.0 if lat else 0.0)   # CV Aventos HF: kệ lùi thêm chừa tay nâng (300 sâu -> kệ 237.6)
    kh = [i for i in range(len(bounds) - 1) if not any(a - 1 <= bounds[i] + T / 2 and bounds[i + 1] - T / 2 <= b + 1 for a, b in cam)]
    if n > 0 and kh:
        per = {i: 0 for i in kh}
        for k in range(n):
            i = max(kh, key=lambda i: (bounds[i + 1] - bounds[i]) / (per[i] + 1)); per[i] += 1
        xs = []
        for i, m in per.items():
            for k in range(m):
                yc = bounds[i] + (k + 1) * (bounds[i + 1] - bounds[i]) / (m + 1); xs.append(yc)
                pk_ = None
                if no:
                    xa, xb, sd = no; pk_ = poly_khoet(iw - 2, sau, xa - 2 * T - 2, xb + T - T, sd + 1) if sd + 1 < sau - 60 else "bo"
                if pk_ == "bo": cb.append(f"#{so}: kệ di động không đủ sâu sau khi né ống – bỏ 1 kệ"); continue
                kes.append(mieng("Kệ di động" + (" (khoét né ống)" if pk_ else ""), vl, iw - 2, sau, (T + 1, yc - T / 2, T, iw - 2, T, sau), (), ("T",), loai="ke", poly=pk_)) if pk_ else kes.append(mieng("Kệ di động", vl, sau, iw - 2, (T + 1, yc - T / 2, T, iw - 2, T, sau), (), ("R",), loai="ke"))
        pins = lo_chot_ke(xs, D, T); lt += pins; lp += pins; pk["Chốt kệ"] += 4 * n
    ng = int(t.get("ke_giay", 0) or 0) if (t["loai"] == "tu_ao" and ka in ("1_treo", "2_treo")) else 0
    for k in range(ng):                            # CV "+ Shoe": kệ giày nghiêng trên 4 chốt (chốt trước thấp hơn chốt sau 120) + thanh chặn gót
        yf = T + 100.0 + k * 260.0; yb = yf + 120.0; L = r1(((D - T - 10 - 89) ** 2 + 120 ** 2) ** 0.5 + 89)
        hs = [(yf, D - 49.0, 5.0, 12.0), (yb, T + 40.0, 5.0, 12.0)]; lt += hs; lp += hs
        kes.append(mieng(f"Kệ giày nghiêng {k + 1}", vl, L, iw - 2, (T + 1, (yf + yb) / 2 - T / 2, T, iw - 2, T, D - T - 10), (), ("R",), loai="ke",
                         note="Đặt nghiêng trên 4 chốt (trước thấp, sau cao 120); bắt thanh chặn ở mép trước"))
        kes.append(mieng(f"Thanh chặn giày {k + 1}", vl, 40, iw - 2, (T + 1, yf + T / 2, D - 20, iw - 2, 40, T), (), ("T",), loai="ke"))
        pk["Chốt kệ"] += 4; pk["Vít 4x30 (thanh đệm)"] += 3
    ed = ("T",)
    notch = [(H - SL_H, H)] if sl else []
    parts.append(mieng("Hông trái", vl, H, D, (0, 0, 0, T, H, D), base + lt, ed, poly=poly_hong(H, D, T, notch, False) if notch else None))
    parts.append(mieng("Hông phải", vl, H, D, (W - T, 0, 0, T, H, D), [(H - x, y, d, p) for x, y, d, p in base + lp], ed,
                       poly=poly_hong(H, D, T, notch, True) if notch else None))
    lo_noc, lo_day, ghi_day = [], [], ""
    if t["loai"] == "hut_mui":          # hút mùi âm tủ: CHẤM 4 góc lỗ khoét ở đáy + tâm ống Ø150 ở nóc (thợ khoét theo chấm, kiểm đúng model trước)
        cw, cdp = float(t.get("cat_w", 490)), float(t.get("cat_d", 265)); dd = D - T
        x0 = (iw - cw) / 2; y1 = dd - 35.0; y0 = y1 - cdp
        if x0 < 35 or y0 < 20: cb.append(f"#{so}: lỗ hút mùi {cw:.0f} x {cdp:.0f} cách mép đáy tủ < 35mm – tăng rộng / sâu tủ hoặc kiểm lại model")
        x0 = max(x0, 5); y0 = max(y0, 5)
        lo_day = [(x, y, 5.0, 2.0) for x in (x0, iw - x0) for y in (y0, y1)]
        lo_noc = [(iw / 2, y0 + cdp / 2, 5.0, 2.0)]
        ghi_day = f"KHOÉT LỖ HÚT MÙI {cw:.0f} x {cdp:.0f} theo 4 chấm (kiểm model trước khi khoét)"
        aos.append(ao("Hút mùi âm tủ", (T + x0, -6, T + y0, iw - 2 * x0, 6, cdp), "#2a2b2e", loai="thiet_bi"))
    thanh_shadowline(t, parts, notch)
    if lat: lo_noc = lo_noc + [(x - T, D - T - 37.0, 5.0, 12.0) for x in lo_noc_lat]
    pn = poly_khoet(iw, D - T, no[0] - 2 * T, no[1], no[2]) if no else None        # nóc / đáy / kệ cố định khoét chừa hộp né ống (gồm 2 vách + mặt hộp)
    parts.append(mieng("Nóc" + (" (khoét né ống)" if no else ""), vl, iw, D - T, (T, H - T, T, iw, T, D - T), lo_noc, ("T",), poly=pn, note="Khoét ống Ø150 tại chấm (hút mùi)" if (lo_noc and not lat) else ("Lỗ đế bản lề cánh lật trên (Aventos HF) – khoan pát tay nâng 2 hông theo dưỡng Blum" if lat and t.get("lat") == "HF" else (f"Khoan pát tay nâng Aventos {t.get('lat')} 2 hông theo dưỡng Blum" if lat else ""))))
    if t["loai"] == "tu_lanh": ghi_day = "TỦ LẠNH ÂM: khoét / lùi đáy thông gió ≥ 200 cm² theo hướng dẫn hãng, kickface gắn lưới thông gió"
    if t.get("khong_day") and t["loai"] == "treo":                 # CV "AB … NO BOTTOM": tủ đứng trên mặt đá, hở đáy (bỏ đáy, hông vẫn chừa lỗ)
        pass
    else: parts.append(mieng("Đáy" + (" (khoét né ống)" if no else ""), vl, iw, D - T, (T, 0, T, iw, T, D - T), lo_day, ("T",), note=ghi_day, poly=pn))
    for c in cd:
        parts.append(mieng("Kệ cố định" + (" (khoét né ống)" if no else ""), vl, iw, D - T, (T, c - T / 2, T, iw, T, D - T), (), ("T",), loai="ke", poly=pn))
    if t["loai"] == "tu_lanh":
        yh = cd[0] + T / 2
        parts.append(mieng("Hậu (tủ trên tủ lạnh)", vl, iw, H - yh, (T, yh, 0, iw, H - yh, T), (), (), loai="hau", note="Hộc tủ lạnh để hở hậu cho thông gió"))
    elif no and t.get("_ong_trong"):       # hộp ống gió hút mùi nằm TRONG tủ: hậu liền, chỉ có 2 vách + mặt hộp giữa nóc–đáy
        xa, xb, sd = no; xl, xr = xa - T, xb + T
        parts.append(mieng("Hậu", vl, iw, H, (T, 0, 0, iw, H, T), (), (), loai="hau"))
        for xv in (xl, xb):
            parts.append(mieng("Vách hộp ống gió", vl, H - 2 * T, sd - T, (xv, T, T, T, H - 2 * T, sd - T), (), ("T",), note="Giữa nóc và đáy, áp hậu"))
        parts.append(mieng("Mặt hộp ống gió (Duct Box Front)", vl, H - 2 * T, xr - xl, (xl, T, sd, xr - xl, H - 2 * T, T), (), (), note="CV Duct Box Front – ống Ø150 chạy trong hộp"))
        aos.append(ao("Ống gió Ø150", (xa + (xb - xa) / 2 - 75, 0, T + 10, 150, H, 150), "#b9bcc2", loai="thiet_bi"))
    elif no:                               # CV "WITH STACK": hậu tách 2 bên hộp né ống + hộp 2 vách + mặt hộp, cao suốt như hông
        xa, xb, sd = no; xl, xr = xa - T, xb + T
        if xl - T > 20: parts.append(mieng("Hậu trái (né ống)", vl, xl - T, H, (T, 0, 0, xl - T, H, T), (), (), loai="hau"))
        if W - T - xr > 20: parts.append(mieng("Hậu phải (né ống)", vl, W - T - xr, H, (xr, 0, 0, W - T - xr, H, T), (), (), loai="hau"))
        for xv in ([xl] if xl > T + 1 else []) + ([xb] if xr < W - T - 1 else []):
            parts.append(mieng("Vách hộp né ống", vl, H - 2 * T, sd, (xv, T, 0, T, H - 2 * T, sd), (), ("T",), note="Đứng giữa nóc và đáy, áp tường"))
        parts.append(mieng("Mặt hộp né ống", vl, xr - xl if xl > T + 1 and xr < W - T - 1 else (xr - xl - T if (xl > T + 1 or xr < W - T - 1) else xr - xl - 2 * T), H - 2 * T,
                           (max(xl, T), T, sd, min(xr, W - T) - max(xl, T), H - 2 * T, T), (), (), note=f"Hộp né ống / cột {xb - xa:.0f} × {sd:.0f} – kiểm đo thực tế trước khi cắt"))
        aos.append(ao("Ống / cột (né)", (xa + 20, -60, 0, xb - xa - 40, H + 120, sd - 20), "#9aa0a8", loai="thiet_bi"))
        pk["Vít 4x50 (ráp thùng)"] += 8
    elif iw > 1200 and H > 1200:                # hậu lớn hơn tấm 2410 × 1210: tách 2 nửa, nối giữa trên thanh đứng sau
        h1 = r1(iw / 2)
        parts.append(mieng("Hậu (nửa trái)", vl, h1, H, (T, 0, 0, h1, H, T), (), (), loai="hau", note="Hậu tách đôi (rộng hơn tấm) – nối giữa trên thanh đứng"))
        parts.append(mieng("Hậu (nửa phải)", vl, iw - h1, H, (T + h1, 0, 0, iw - h1, H, T), (), (), loai="hau", note="Hậu tách đôi (rộng hơn tấm) – nối giữa trên thanh đứng"))
        parts.append(mieng("Thanh đứng nối hậu", vl, 80, H, (T + h1 - 40, 0, -T, 80, H, T), (), (), note="Bắt PHÍA SAU 2 nửa hậu (áp tường) – chừa 16 khi lắp sát tường"))
    else: parts.append(mieng("Hậu", vl, iw, H, (T, 0, 0, iw, H, T), (), (), loai="hau", note="Chừa / khoét thông gió sau lò theo hướng dẫn hãng" if t["loai"] == "lo_nuong" else ""))
    pk["Vít 4x50 (ráp thùng)"] += len(base) * 2
    if (t.get("thanh_treo") and not (t["loai"] == "tu_ao" and ka == "ke")) or ray:
        for yr in (ray or [(cd[-1] - 60) if cd else H - 100]):
            aos.append(ao("Thanh treo đồ", (rx0, yr - 15, D / 2 - 8, rw, 30, 16), "#b9bcc2"))
            pk["Thanh treo đồ (m)"] += round(rw / 1000, 2); pk["Bát đỡ thanh treo"] += 2
    if t["loai"] in TU_TREO and not t.get("chan"): pk["Pát treo tủ (cặp)"] += 1
    chan_tu(t, aos, pk)
    if H > 2400 or D > 1200:
        cb.append(f"#{so}: hông {H:.0f} x {D:.0f} lớn hơn tấm 2410 x 1210" + (" – đặt \"Tách 2 thùng\" (vd thùng dưới " + f"{min(H - 400, 2100):.0f}" + ") để cắt được" if t["loai"] in ("cao", "tu_ao", "lo_nuong") and H > 2400 else ""))
    if nht: kes += kes_ht
    if ruou: ke_ruou(t, so, kes, pk, cb, T, W, H, D)
    if chia:
        kes += kes0
        for q in parts:                           # lỗ vít bắt vách chia xuyên đáy + kệ cố định trên
            if q["name"] == "Đáy" or q["name"] == "Kệ cố định":
                q["holes"] = list(q["holes"]) + [(r1(xp - T + T / 2), r1(y - T), 5.0, 12.0) for y in (50.0, r1((50 + D - 49) / 2), D - 49.0)]
    return parts + kes + doors, aos, pk, cb


def tu_ao_chia(t, so, parts, kes, aos, pk, cb, lt, lp, xp, ytop):
    """TỦ ÁO CHIA (CV "2 Dr Robe – SPLIT – Dwrs + Shelves & S/HNG", học 20/11, 800 × 2270 × 580):
    vách chia 562.6 × 1820.8 ở giữa (từ đáy lên kệ cố định cách nóc 408); bên trái: ngăn kéo trong (CV 4 hộc cao 950, hụt 25 mỗi bên chừa bản lề)
    + kệ; bên phải: thanh treo. Studio: ray bắt trên THANH ĐỆM (packer) ván thùng 2 bên cho hộc lọt qua bản lề, mặt hộc ván thùng (sau cánh)."""
    W, H, D = t["w"], t["h"], t["d"]; vl = t["vl_thung"]; T = VAT_LIEU[vl]["lz"]
    B = xp - T                                    # lòng khoang trái
    n = int(t.get("hoc_ao", 4) or 4); Z = min(950.0, 60.0 + n * 225.0)
    if B < 300: cb.append(f"#{so}: khoang trái tủ áo chia chỉ {B:.0f} – không đủ chỗ ngăn kéo"); return
    hv = ytop - T / 2 - T; dd = D - T
    ys = (50.0, r1((50 + D - 49) / 2), D - 49.0)                # như lỗ bắt kệ cố định trên hông (đo từ mặt sau tủ)
    lo_vach = []                                   # lỗ mặt trái vách (toạ độ vách: x = cao từ đáy vách, y = sâu từ sau)
    yo = T + Z + T / 2                              # tâm kệ cố định trên hộc
    lt += [(yo, y, 5.0, T + 0.5) for y in ys]
    lo_vach += [(yo - T, y - T, 5.0, 12.0) for y in ys]
    kes.append(mieng("Kệ cố định trên hộc", vl, B, dd, (T, yo - T / 2, T, B, T, dd), (), ("T",), loai="ke"))
    nk = max(0, int(t.get("ke", 2) or 0)); xs = []
    for k in range(nk):
        yc = yo + T / 2 + (k + 1) * (ytop - T / 2 - yo - T / 2) / (nk + 1); xs.append(yc)
        kes.append(mieng("Kệ di động (khoang trái)", vl, dd - 10, B - 2, (T + 1, yc - T / 2, T, B - 2, T, dd - 10), (), ("R",), loai="ke"))
    if nk:
        pins = lo_chot_ke(xs, D, T); lt += pins; lo_vach += [(x - T, y - T, d, p) for x, y, d, p in pins]; pk["Chốt kệ"] += 4 * nk
    # ngăn kéo trong: thanh đệm (packer) 2 bên, ray Tandembox, mặt hộc ván thùng lùi sau cánh 22
    zr = D - 22.0 - T                               # mặt sau mặt hộc = đầu ray
    NL = max([v for v in RAY_NL if v <= zr - T - 3] or [270]); lw = B - 2 * T
    wf = lw - 6.0; hf = (Z - 4.0 - (n - 1) * KHE) / n
    run_pk = []
    for k in range(n):
        yb = T + 2.0 + k * (hf + KHE); an = dict(kieu="hoc", k=k)
        up = 96.0 if hf < 250 else 128.0
        hl = [(x, y, 10.0, 12.0) for x in [46.4, 78.4] + ([46.4 + up] if hf >= 46.4 + up + 30 else []) for y in (29.9, wf - 29.9)]
        parts.append(mieng(f"Mặt hộc trong tủ áo {k + 1}", vl, hf, wf, (2 * T + 3, yb, zr, wf, hf, T), hl, ("T", "B", "L", "R"), (), "Mặt hộc ván thùng – nằm sau cánh tủ áo", loai="mat_hoc", anim=an, rot=False))
        run_pk += [(yb - T + 50.9, z - T, 5.0, DR) for z in (zr - 36, zr - 132, zr - 260, zr - (NL - 48)) if z > T + 10]
        bw, bd = lw - 75, NL - 24.4; BH = 198.0 if hf >= 255 else 166.0 if hf >= 215 else 134.0 if hf >= 180 else 83.0
        parts.append(mieng(f"Đáy hộc tủ áo {k + 1}", vl, bw, bd, (2 * T + 37.5, yb + 28, zr - bd, bw, T, bd), [(x, y, 5.0, 12.0) for x in (9.0, bw - 9.0) for y in (16.2, bd - 189.4, bd - 43.4) if y > 0], (), loai="hoc", anim=an))
        parts.append(mieng(f"Hậu hộc tủ áo {k + 1}", vl, lw - 87, BH, (2 * T + 43.5, yb + 28 + T, zr - bd, lw - 87, BH, T), [(x, y, 5.0, 12.0) for x in (9.0, lw - 87 - 9.0) for y in (7.0, 39.0, 103.0, 135.0, 167.0) if y <= BH - 31], ("T",), loai="hoc", anim=an))
        for sx in (2 * T + 21, xp - T - 21 - 13): aos.append(ao("Thành hộc kim loại", (sx, yb + 28, zr - bd, 13, min(BH, hf - 40), bd), "#c9ccd1", anim=an))
        pk[f"Ray hộc Tandembox {NL} (bộ)"] += 1
    for ten, x0, lo in (("trái", T, run_pk), ("phải (trên vách)", xp - T, [(r1(Z - a), b, c, d) for a, b, c, d in run_pk])):   # miếng phải lật cao như hông phải (mặt khoan quay sang trái)
        parts.append(mieng(f"Thanh đệm ray {ten}", vl, Z, dd - 2, (x0, T, T, T, Z, dd - 2), lo, ("T",), note="Bắt vào hông / vách bằng vít 30, mặt có lỗ quay vào hộc"))
    pk["Vít 4x30 (thanh đệm)"] += 12
    parts.append(mieng("Vách chia (tủ áo chia)", vl, hv, dd, (xp, T, T, T, hv, dd), [(r1(hv - a), b, c, d) for a, b, c, d in lo_vach], ("T",), note="Từ đáy lên kệ cố định trên, lỗ ở MẶT TRÁI (phía ngăn kéo) – lật cao như hông phải"))


def poly_khoet(w, h, a, b, n):
    """tấm w (x) × h (y), khoét chữ nhật ở cạnh y = 0 từ x = a tới b, sâu n (né ống / cột sau tủ)."""
    a, b = max(0.0, a), min(w, b); pts = []
    pts += [(0.0, 0.0)] if a > 0.01 else []
    pts += [(a, 0.0), (a, n), (b, n), (b, 0.0)] if a > 0.01 else [(0.0, n), (b, n), (b, 0.0)]
    if b >= w - 0.01: pts = pts[:-1] + [(w, n)]
    pts += [(w, 0.0)] if b < w - 0.01 else []
    pts += [(w, h), (0.0, h)]
    out = []
    for q in pts:
        q = (round(q[0], 2), round(q[1], 2))
        if not out or out[-1] != q: out.append(q)
    return out


def ne_ong(t, cb, so):
    """vị trí khoét né ống / cột (CV "WITH STACK" LEFT / MIDDLE / RIGHT): trả (xa, xb, sd) toạ độ tủ, hoặc None."""
    st = t.get("stack")
    if st not in ("L", "M", "R"): return None
    W, D = t["w"], t["d"]; T = VAT_LIEU[t["vl_thung"]]["lz"]
    sw = float(t.get("stack_w") or 300); sd = float(t.get("stack_d") or 200)
    if sd >= D - T - 60 or sw + 4 * T >= W - 2 * T:
        cb.append(f"#{so}: khoét né ống {sw:.0f} × {sd:.0f} quá lớn so với tủ {W:.0f} × {D:.0f} – bỏ khoét"); return None
    xa = T if st == "L" else (W - T - sw if st == "R" else (W - sw) / 2)            # L / R: hông tủ làm luôn vách hộp né ống
    return xa, xa + sw, sd


def canh_lat(t, so, doors, pk, cb, lo_noc, aos):
    """TỦ TREO CÁNH LẬT (CV "Aventos HF – 2 Door Bi-fold Lift Cab", học 20/11: 995 x 850 x 300 -> 2 cánh 993 x 434):
    HF = 2 cánh gập: cánh trên bắt bản lề vào NÓC (3 chén cách 2 đầu 100 + giữa), cánh dưới nối cánh trên bằng 3 bản lề giữa + pát tay nâng 2 bên;
    HK = 1 cánh lật lên bằng tay nâng (không bản lề). Giữ quy tắc TPW: hở 1.5 quanh, khe 3 giữa 2 cánh."""
    W, H, D = t["w"], t["h"], t["d"]; vm, shaker, ghi = mat_ngoai(t); tf = VAT_LIEU[vm]["lz"]
    du = float(t.get("_du") or 0); y0 = -du if du else HO; hd = (H - HO + du) if du else (H - 2 * HO); wd = W - 2 * HO
    edges = () if vm in ("MDF18", "MDF21") else ("T", "B", "L", "R")
    cy, dy = (22.5, 32.0) if vm == "MDF18" else (21.2, 30.8)
    nbl = 2 if wd <= 650 else 3 if wd <= 1250 else 4
    xs = [100.0 + k * (wd - 200.0) / (nbl - 1) for k in range(nbl)]                 # tâm chén theo bề rộng cánh (CV: 100 từ 2 đầu + giữa)
    def chen(h):  # chén Ø35 dọc cạnh TRÊN của cánh cao h
        return [q for x in xs for q in ((h - cy, x, 35.0, 14.0), (h - dy, x - 22.5, 8.0, 12.0), (h - dy, x + 22.5, 8.0, 12.0))]
    if t.get("lat") in ("HK", "HS", "HL"):
        lk = t.get("lat"); lo, hi = {"HK": (205, 600), "HS": (350, 800), "HL": (300, 580)}[lk]       # khoảng cao cánh theo catalog Blum
        if not lo <= hd <= hi: cb.append(f"#{so}: cánh lật {lk} cao {hd:.0f} ngoài khoảng {lo}–{hi} của Aventos {lk}" + (" – cao hơn nên dùng HF (2 cánh gập)" if hd > hi else ""))
        an = dict(kieu="lat", py=y0 + hd, pz=D, s=-1)
        doors.append(mieng(f"Cánh lật {'shaker ' if shaker else ''}(Aventos {lk})", vm, hd, wd, (HO, y0, D, wd, hd, tf),
                           [(hd - 60.0, y, 5.0, 12.0) for y in (28.0, wd - 28.0)], edges, (), (ghi + " | " if ghi else "") + f"Pát tay nâng {lk}: chấm Ø5 – kiểm dưỡng Blum", loai="canh", anim=an, rot=False))
        trang_tri(aos, (HO, y0, D, wd, hd, tf), shaker, "N" if t.get("tay_nam") else None, an, ngang=True)
        pk[f"Tay nâng Aventos {lk} (bộ)"] += 1
    else:
        h2 = (hd - KHE) / 2; yb2 = y0; yb1 = y0 + h2 + KHE
        if hd < 480 or hd > 1060: cb.append(f"#{so}: tổng cao cánh HF {hd:.0f} ngoài khoảng 480–1060 của Aventos HF – kiểm lại")
        an1 = dict(kieu="lat", py=yb1 + h2, pz=D, s=-1, id="HF")
        doors.append(mieng(f"Cánh lật trên {'shaker ' if shaker else ''}(Aventos HF)", vm, h2, wd, (HO, yb1, D, wd, h2, tf), chen(h2), edges, (), ghi, loai="canh", anim=an1, rot=False))
        an2 = dict(kieu="latx", cha="HF", py=yb2 + h2, pz=D + tf, s=1)
        lo2 = chen(h2) + [(y, x, 5.0, 12.0) for x in (28.0, wd - 28.0) for y in (170.0, 202.0) if y < h2 - 40]
        doors.append(mieng(f"Cánh lật dưới {'shaker ' if shaker else ''}(Aventos HF)", vm, h2, wd, (HO, yb2, D, wd, h2, tf), lo2, edges, (),
                           (ghi + " | " if ghi else "") + "Chén = bản lề giữa nối cánh trên; 4 lỗ Ø5 = pát tay nâng (kiểm dưỡng Blum)", loai="canh", anim=an2, rot=False))
        trang_tri(aos, (HO, yb2, D, wd, h2, tf), shaker, "N" if t.get("tay_nam") else None, an2, ngang=True)
        lo_noc.extend([HO + x + s_ for x in xs for s_ in (-16.0, 16.0)])
        pk["Tay nâng Aventos HF (bộ)"] += 1; pk["Bản lề CLIP top (cánh lật HF)"] += 2 * nbl
    if t.get("tay_nam"): pk["Tay nắm"] += 1
    if t.get("mo") == "push": pk["Servo-Drive / Tip-On cho cánh lật"] += 1


def tu_may_rua(t, so):
    """MÁY RỬA CHÉN. Âm (fully integrated): cửa CÙNG MÀU CÁNH phủ hết mặt máy, bắt vào cửa máy theo dưỡng của hãng (anh Tan 19/11).
    Bán âm (semi-integrated): tấm cửa nằm dưới bảng điều khiển. Rời / under-bench: mặt inox của máy, không làm cửa.
    Số liệu hãng: khoảng lọt 600 rộng, 820-880 cao, >= 560 sâu; panel rộng >= 596, cao thường 655-765, dày 16-25, nặng 3-10kg."""
    parts, aos, pk, cb = [], [], Counter(), []
    W, H, D = t["w"], t["h"], t["d"]; ch = float(t.get("chan", 0) or 0); kieu = t.get("mr_kieu", "am")
    aos.append(ao("Máy rửa chén", (3, 0, 15, W - 6, H - 3, D - 32), "#c9ccd1", loai="thiet_bi"))
    if ch > 0: aos.append(ao("Chân máy rửa chén", (3, -ch, 15, W - 6, ch, D - 90), "#2f2f31", loai="chan"))
    if W < 598: cb.append(f"#{so}: khoảng máy rửa chén {W:.0f} < 600 – máy 60cm cần lọt lòng 600")
    if H + ch < 820: cb.append(f"#{so}: khoảng cao {H + ch:.0f} < 820 – máy rửa chén chuẩn cao 820–880")
    if D < 560: cb.append(f"#{so}: khoảng sâu {D:.0f} < 560 – máy rửa chén cần sâu tối thiểu 560")
    an = dict(kieu="lat", py=HO, pz=D)
    if kieu == "roi":
        aos.append(ao("Mặt máy rửa chén (inox)", (HO, HO, D, W - 2 * HO, H - 2 * HO, 20), "#b4b8bd", anim=an, loai="thiet_bi"))
        return parts, aos, pk, cb
    vm, shaker, ghi = mat_ngoai(t); tf = VAT_LIEU[vm]["lz"]; sl = bool(t.get("shadowline")); mdf = vm in ("MDF18", "MDF21")
    wd = W - 2 * HO; bang = max(0.0, float(t.get("mr_bang") or 120)) if kieu == "ban_am" else 0.0
    hd = H - (SL_CUA if sl else HO) - HO - (bang + KHE if bang else 0)
    holes = []; e45 = (); note = (ghi + " | " if ghi else "") + "Bắt vào cửa máy rửa chén theo dưỡng của hãng – KHÔNG khoan bản lề"
    if sl and not bang:
        if mdf: note += " | CẮT 45° CẠNH TRÊN (shadowline) – chưa tự phay, kiểm tay"
        else: e45 = ("R",); holes.append((hd - 10, wd / 2, 5.0, 1.0)); note += " | Nẹp 45° cạnh có chấm Ø5 (cạnh trên)"
    box = (HO, HO, D, wd, hd, tf)
    parts.append(mieng(f"Cửa máy rửa chén {'shaker ' if shaker else ''}(cùng màu cánh)", vm, hd, wd, box, holes, () if mdf else ("T", "B", "L", "R"), e45, note, loai="canh", anim=an, rot=False))
    trang_tri(aos, box, shaker, "N" if t.get("tay_nam") else None, an, ngang=True)
    if bang: aos.append(ao("Bảng điều khiển máy rửa chén", (HO, HO + hd + KHE, D, wd, bang, 18), "#b4b8bd", anim=an, loai="thiet_bi"))
    sp = t.get("spec") if isinstance(t.get("spec"), dict) else {}
    def _f(k):
        try: return float(sp.get(k)) if sp.get(k) not in (None, "") else None
        except (TypeError, ValueError): return None
    pmin, pmax, pday, pnang = _f("panel_cao_min"), _f("panel_cao_max"), _f("panel_day_max"), _f("panel_nang_max")
    ten_m = ten_spec(sp, t)
    if kieu == "am" and (pmin or pmax):                  # spec máy đã tra: dùng đúng khoảng panel của hãng
        if (pmin and hd < pmin - 0.5) or (pmax and hd > pmax + 0.5): cb.append(f"#{so}: tấm cửa máy rửa chén cao {hd:.0f} ngoài khoảng {pmin or 0:.0f}–{pmax or 0:.0f} của {ten_m} – chỉnh chân / cao tấm cửa")
    elif kieu == "am" and not 655 <= hd <= 765: cb.append(f"#{so}: cửa máy rửa chén cao {hd:.0f} – đa số máy âm nhận panel cao 655–765, kiểm đúng model")
    if kieu == "am" and pday and tf > pday + 0.1: cb.append(f"#{so}: cửa máy rửa chén dày {tf:.0f} > {pday:.0f} cho phép của {ten_m}")
    if kieu == "am" and pnang:
        kg = hd * wd * tf * 1e-9 * (750 if mdf else 680)               # ước khối lượng: MDF ~750 kg/m³, ván dăm ~680
        if kg > pnang: cb.append(f"#{so}: cửa máy rửa chén nặng khoảng {kg:.1f} kg > {pnang:.0f} kg tối đa của {ten_m} – bản lề máy có thể không giữ được")
    if wd < 595.5: cb.append(f"#{so}: cửa máy rửa chén rộng {wd:.0f} < 596 – không phủ hết mặt máy")
    if t.get("mo") == "push": cb.append(f"#{so}: máy rửa chén âm không dùng bấm mở – chọn model tự bung cửa (knock-to-open) hoặc đổi tay nắm / shadowline")
    if t.get("tay_nam"): pk["Tay nắm"] += 1
    if sl: thanh_shadowline(t, parts, [(H - SL_H, H)])
    return parts, aos, pk, cb


def tu_tam(t, so):
    vl = t["vl_thung"]; T = VAT_LIEU[vl]["lz"]; hg = t.get("huong", "hong")
    W, H, D = t["w"], t["h"], t["d"]; cat = t.get("cat") or [None, None]; note = str(t.get("ghi_chu") or "")
    c = lambda i, v: float(cat[i]) if isinstance(cat, (list, tuple)) and len(cat) == 2 and cat[i] else v
    if hg == "hong": p = mieng(t.get("ten") or "Tấm hông", vl, c(0, H), c(1, D), (0, 0, 0, T, H, D), (), ("T", "L", "R"), note=note, loai="tam")
    elif hg == "dung": p = mieng(t.get("ten") or "Tấm đứng", vl, c(0, H), c(1, W), (0, 0, 0, W, H, T), (), ("T", "B", "L", "R"), note=note, loai="tam",
                                 rot=None if H >= W else True)
    else: p = mieng(t.get("ten") or "Tấm nằm", vl, c(0, W), c(1, D), (0, 0, 0, W, T, D), (), ("T", "L", "R"), note=note, loai="tam")
    return [p], [], Counter(), []


def ten_spec(sp, t):
    """tên máy để ghi cảnh báo: không lặp tên hãng"""
    h, n = str(sp.get("hang") or ""), str(sp.get("ten") or t.get("ma_may") or "")
    return (n if h and n.lower().startswith(h.lower()) else f"{h} {n}").strip()


def tu_lanh_roi(t, so):
    """TỦ LẠNH RỜI: khoảng chừa (không thùng) + tuỳ chọn HỘP TRÊN tủ lạnh (bản vẽ Eastwood: hộp 790, khe 20 trên nóc tủ lạnh, panel 2 bên sâu 750)."""
    hh = float(t.get("tl_hop") or 0); H = t["h"]
    if hh <= 0: return tu_ao_khoi(t, so)
    cb = []
    if hh < 250 or H - hh - 20 < 1500: cb.append(f"#{so}: hộp trên tủ lạnh {hh:.0f} không hợp lệ (cần >= 250 và chừa tủ lạnh >= 1500) – bỏ hộp"); p, a, k, c = tu_ao_khoi(t, so); return p, a, k, c + cb
    sau = min(float(t["d"]), float(t.get("tl_panel") or 750) - 18)
    u = dict(t, loai="treo", h=hh, d=sau, chan=0, ke=0, ke_cd=0, canh=2 if t["w"] > 620 else 1)
    p2, a2, k2, c2 = tu_hop(u, so)
    for q in p2: q["box"][1] += H - hh; q["name"] = "Hộp trên tủ lạnh – " + q["name"]
    for q in a2: q["box"] = (q["box"][0], q["box"][1] + H - hh, *q["box"][2:])
    a2.append(ao(f"Tủ lạnh (chừa cao {H - hh - 20:.0f})", (0, 0, 0, t["w"], H - hh - 20, t["d"]), "#9ea3a8", loai="tu_lanh"))
    return p2, a2, k2, c2 + cb


def tu_ao_khoi(t, so):
    mau = "#dcdcdf" if t["loai"] == "mat_da" else "#9ea3a8"
    return [], [ao(t.get("ten") or THU_VIEN[t["loai"]]["ten"], (0, 0, 0, t["w"], t["h"], t["d"]), mau, loai=t["loai"])], Counter(), []


# AS/NZS 5601.1:2022 (bản mới, áp cho công trình mới từ 30/3/2023): từ mặt kiềng bếp GAS tới đáy máy hút mùi >= 650, quạt hút >= 750;
# mặt gỗ / ván (dễ cháy) úp xuống thấp hơn 650 phải được bảo vệ; tuyệt đối không dưới 450. Hướng dẫn hãng lớn hơn thì theo hãng.
GAS_HUT_MUI_MIN, GAS_MAT_CHAY_MIN, GAS_TUYET_DOI = 650.0, 650.0, 450.0


def kiem_bep_gas(t, raw, job, so):
    """bếp gas trên mặt đá: kiểm tủ treo / hút mùi phía trên đủ cao chưa (đo từ mặt đá – kiềng bếp còn cao hơn mặt đá nên số thật còn thiếu hơn)"""
    sp = t.get("spec") if isinstance(t.get("spec"), dict) else {}
    if not (t.get("bep_gas") or str(sp.get("loai_may")) == "cooktop_gas"): return []
    kr = float(t.get("bep_rong") or sp.get("khoet_rong") or 0) or 560.0
    x = float(t.get("bep_x") or 0) or float(t["w"]) / 2
    xa, xb = float(t["x"]) + x - kr / 2, float(t["x"]) + x + kr / 2
    mat = float(t.get("y") or 0) + float(t["h"])
    if mat <= 0: return []
    out = []
    for r2 in job.get("tu", []):
        if r2 is raw or r2.get("day") != raw.get("day"): continue
        u = chuan_hoa(r2)
        if u["loai"] not in TU_TREO or u.get("goc") != t.get("goc") or u.get("y") in (None, ""): continue
        if float(u["x"]) >= xb or float(u["x"]) + float(u["w"]) <= xa: continue
        day = float(u["y"]) - (70.0 if u["loai"] == "hut_mui" and u.get("kieu_hm") == "fixed" else 0.0)
        kc = day - mat; ten = (u.get("ten") or THU_VIEN.get(u["loai"], {}).get("ten", u["loai"])) + f" #{job['tu'].index(r2) + 1}"
        if u["loai"] == "hut_mui":
            if kc < GAS_HUT_MUI_MIN: out.append(f"#{so}: BẾP GAS – máy hút mùi ({ten}) cách mặt đá {kc:.0f} < {GAS_HUT_MUI_MIN:.0f} (AS/NZS 5601.1:2022, đo từ mặt kiềng nên còn thiếu hơn) – nâng lên hoặc theo hướng dẫn hãng nếu lớn hơn")
        elif kc < GAS_TUYET_DOI: out.append(f"#{so}: BẾP GAS – {ten} cách mặt đá {kc:.0f} < {GAS_TUYET_DOI:.0f} – không được phép (AS/NZS 5601.1)")
        elif kc < GAS_MAT_CHAY_MIN: out.append(f"#{so}: BẾP GAS – đáy {ten} cách mặt đá {kc:.0f} < {GAS_MAT_CHAY_MIN:.0f}: mặt ván úp xuống phải được bảo vệ chống nhiệt hoặc nâng tủ (AS/NZS 5601.1:2022)")
    return out


def kiem_hut_mui_cao(t, raw, job, so):
    """tủ hút mùi có mã máy: đáy máy cách mặt đá bên dưới đủ / không quá cao theo sách hãng (bếp gas còn theo AS/NZS 5601 ≥ 650)"""
    ma, may = tra_may(t.get("ma_may"))
    if not may or not (may.get("cao_dien") or may.get("cao_max")) or t.get("y") in (None, ""): return []
    x0, x1 = float(t["x"]), float(t["x"]) + float(t["w"])
    for r2 in job.get("tu", []):
        if r2 is raw or r2.get("loai") != "mat_da" or r2.get("day") != raw.get("day"): continue
        u = chuan_hoa(r2)
        if u.get("goc") != t.get("goc") or float(u["x"]) >= x1 or float(u["x"]) + float(u["w"]) <= x0 or u.get("y") in (None, ""): continue
        sp = u.get("spec") if isinstance(u.get("spec"), dict) else {}
        gas = bool(u.get("bep_gas") or str(sp.get("loai_may")) == "cooktop_gas")
        day = float(t["y"]) - (70.0 if t.get("kieu_hm") == "fixed" else 0.0)
        kc = day - float(u["y"]) - float(u["h"])
        mn = max(float(may.get("cao_gas") or 0), GAS_HUT_MUI_MIN) if gas else float(may.get("cao_dien") or 0)
        ten = may.get("ten") or ma; out = []
        if mn and kc < mn - 0.5 and not (gas and mn <= GAS_HUT_MUI_MIN): out.append(f"#{so}: {ten} cách mặt đá {kc:.0f} < {mn:.0f} tối thiểu ({'bếp gas' if gas else 'bếp điện / từ'}) – {may.get('nguon_cao', '')}")
        if may.get("cao_max") and kc > float(may["cao_max"]) + 0.5: out.append(f"#{so}: {ten} cách mặt đá {kc:.0f} > {float(may['cao_max']):.0f} – hút kém (theo hãng)")
        return out
    return []


def noi_da(W, lo, mep, L, tranh=100.0):
    """chia tấm đá dài W thành các đoạn <= L. lo = [(x0, x1)] lỗ khoét; mối nối không nằm trong lỗ và cách mép lỗ >= tranh (khuyến nghị Studio).
    Ưu tiên nối ngay trên mép giữa 2 tủ (mep). Trả về danh sách vị trí nối (tính từ đầu trái)."""
    if W <= L: return []
    ok = lambda x: all(x <= a - tranh or x >= b + tranh for a, b in lo)
    out, s = [], 0.0
    while W - s > L:
        ung = [m for m in mep if s + 300 <= m <= s + L and ok(m)]
        if ung: x = max(ung)
        else:
            x = next((s + L - k for k in range(0, int(L - 300), 5) if ok(s + L - k)), s + L)
        out.append(round(x, 1)); s = x
    return out

def tu_mat_da(t, so):
    """mặt đá: nếu có lỗ khoét bếp (nhập tay hoặc Tra spec mã bếp) -> vẽ lỗ trên 3D + ghi chú cho thợ đá"""
    p, a, k, c = tu_ao_khoi(t, so)
    sp = t.get("spec") or {}
    kr = float(t.get("bep_rong") or sp.get("khoet_rong") or 0); ks = float(t.get("bep_sau") or sp.get("khoet_sau") or 0)
    W, H, D = float(t["w"]), float(t["h"]), float(t["d"])
    for ten_c, cr, cs, cx in t.get("_chau") or []:
        ctr = (D - cs) / 2
        a.append(ao(f"Lỗ khoét chậu {cr:.0f}×{cs:.0f}", (cx - cr / 2, H, D - ctr - cs, cr, 1.5, cs), "#2a2c30", loai="khoet"))
        c.append(f"#{so} mặt đá – GHI CHÚ THỢ ĐÁ: khoét chậu {ten_c} {cr:.0f}×{cs:.0f}, tâm cách đầu trái {cx:.0f} (giữa tủ chậu), cách mép trước {ctr:.0f} – đo chậu thật trước khi cắt")
        if cx - cr / 2 < 50 or cx + cr / 2 > W - 50: c.append(f"#{so}: lỗ khoét chậu sát / vượt đầu mặt đá – kiểm lại")
    L = float(t.get("_kho_da") or 3050)
    if W > L:
        lo = [(cx - cr / 2, cx + cr / 2) for _, cr, cs, cx in t.get("_chau") or []]
        if kr > 0 and ks > 0:
            xb = float(t.get("bep_x") or 0) or W / 2; lo.append((xb - kr / 2, xb + kr / 2))
        nn = noi_da(W, lo, t.get("_mep") or [], L)
        for xn in nn: a.append(ao("Mối nối đá", (xn - 1, H, 0, 2, 1.5, D), "#c0392b", loai="noi"))
        c.append(f"#{so}: mặt đá dài {W:.0f} > khổ tấm {L:.0f} – cần {len(nn)} mối nối")
        mep = t.get("_mep") or []
        c.append(f"#{so} mặt đá – GHI CHÚ THỢ ĐÁ: đề xuất mối nối tại " + ", ".join(f"{x:.0f}" + (" (trên mép giữa 2 tủ)" if any(abs(x - m) < 1 for m in mep) else " (không trùng mép tủ nào – cần đỡ dưới mối nối)") for x in nn)
                 + " từ đầu trái; cách lỗ khoét ≥ 100 – Studio đề xuất, thợ đá quyết theo vân / tấm thật")
    if kr <= 0 or ks <= 0: return p, a, k, c
    x = float(t.get("bep_x") or 0) or W / 2; tr = float(t.get("bep_truoc") or 0) or (D - ks) / 2
    x0 = x - kr / 2
    if x0 < 50 or x0 + kr > W - 50: c.append(f"#{so}: lỗ khoét bếp {kr:.0f} vượt / sát đầu mặt đá (còn {min(x0, W - x0 - kr):.0f} mm) – kiểm lại vị trí")
    if tr < 40 or D - tr - ks < 25: c.append(f"#{so}: lỗ khoét bếp sát mép (trước {tr:.0f} / sau {D - tr - ks:.0f} mm) – kiểm lại")
    tu_ = "chậu" if str(sp.get("loai_may")) == "sink" else "bếp"
    a.append(ao(f"Lỗ khoét {tu_} {kr:.0f}×{ks:.0f}", (x0, H, D - tr - ks, kr, 1.5, ks), "#151618", loai="khoet"))
    ten = (sp.get("ten") or t.get("ma_may") or "bếp").strip()
    c.append(f"#{so} mặt đá – GHI CHÚ THỢ ĐÁ: khoét {ten} {kr:.0f}×{ks:.0f}, tâm cách đầu trái {x:.0f}, cách mép trước {tr:.0f}" + (" (số theo spec hãng – xem link)" if sp.get("khoet_rong") == kr and sp.get("khoet_sau") == ks else " (nhập tay – chưa đối chiếu spec)")
             + (" – tự đặt giữa hộc lò dưới bếp" if t.get("_bep_tu") else "" if t.get("bep_x") else " – CHƯA đặt vị trí, đang để giữa mặt đá: nhập 'Tâm lỗ bếp' cho đúng tủ bếp bên dưới"))
    return p, a, k, c



# ---------------------------------------------------------------- CHIA Ô MẶT TỦ (học từ Cabinet Vision: Face -> Horizontal / Vertical Split, mỗi ô 1 kiểu)
O_LOAI = ("duoi_canh", "duoi_chau", "duoi_hoc", "treo", "cao", "tu_ao")
O_KIEU = ("canh", "canh_doi", "hoc", "gia", "mo")          # cánh / cánh đôi / ngăn kéo / mặt giả (False Front) / để trống (Open)


def _chia(tong, ds, khe, ten, cb, so, toi_thieu=80.0):
    """ds = số đo nhập (0 = tự chia). Trả list kích thước khớp tổng (đã trừ khe)."""
    n = len(ds); con = tong - (n - 1) * khe; co = [float(v or 0) for v in ds]; tu = [i for i, v in enumerate(co) if v <= 0]
    du = con - sum(v for v in co if v > 0)
    if not tu:                                                    # nhập đủ hết: ô cuối nhận phần lệch
        co[-1] += du; tu = []
    elif du / len(tu) < toi_thieu:
        cb.append(f"#{so}: {ten} nhập quá lớn so với tủ – đã chia đều lại"); return [con / n] * n
    else:
        for i in tu: co[i] = du / len(tu)
    if min(co) < toi_thieu: cb.append(f"#{so}: có {ten} chỉ {min(co):.0f} mm – quá nhỏ")
    return co


def mat_chia_mac_dinh(t):
    """bố cục ô ban đầu theo tủ đang có (để mở màn hình chia ô)"""
    if t["loai"] == "duoi_hoc":
        n = max(1, int(t.get("hoc", 3) or 3)); return dict(hang=[dict(cao=0, o=[dict(rong=0, kieu="hoc")]) for _ in range(n)])
    n = int(t.get("canh", 2) or 0)
    o = [dict(rong=0, kieu="canh_doi")] if n == 2 else [dict(rong=0, kieu="canh", ban_le=t.get("ban_le", "L"))] if n == 1 else [dict(rong=0, kieu="mo")]
    return dict(hang=[dict(cao=0, o=o)])


def tu_chia_o(t, so):
    loai = t["loai"]; duoi = loai in ("duoi_canh", "duoi_chau", "duoi_hoc")
    if duoi: parts, aos, pk, cb = tu_duoi_canh(dict(t, loai="duoi_canh", canh=0, ke=0), so)
    else: parts, aos, pk, cb = tu_hop(dict(t, canh=0, ke=0, ke_cd=0, thanh_treo=False), so, co_canh=False)
    W, H, D = t["w"], t["h"], t["d"]; vl = t["vl_thung"]; T = VAT_LIEU[vl]["lz"]; X = T + 0.5
    vm, shaker, ghi = mat_ngoai(t); tf = VAT_LIEU[vm]["lz"]; edges = () if vm in ("MDF18", "MDF21") else ("T", "B", "L", "R")
    sl = bool(t.get("shadowline")) and loai not in TU_TREO; du = float(t.get("_du") or 0)
    hang = [h for h in ((t.get("o_mat") or {}).get("hang") or []) if h.get("o")]
    if not hang: return parts, aos, pk, cb
    y_bot = -du if du else HO; y_top = H - (SL_CUA if sl else HO)
    hs = _chia(y_top - y_bot, [h.get("cao") for h in hang], KHE, "chiều cao hàng", cb, so)
    z_lo = T                                                      # mặt trên đáy / deck
    z_hi = H if duoi else H - T                                   # tủ dưới không có nóc (chỉ thanh giằng)
    # ---- hàng: toạ độ mặt (y) từ trên xuống
    rows = []; y = y_top
    for h, hc in zip(hang, hs):
        y1 = y; y0 = y - hc; rows.append(dict(y0=y0, y1=y1, o=h["o"])); y = y0 - KHE
    # ---- kệ cố định giữa 2 hàng (trừ khi 2 hàng đều chỉ là ngăn kéo – như CV, hộc chồng nhau không cần kệ)
    ke_cd = {}
    for r in range(len(rows) - 1):
        a, b = rows[r], rows[r + 1]; yb = b["y1"] + KHE / 2
        if all(o.get("kieu") == "hoc" for o in a["o"]) and all(o.get("kieu") == "hoc" for o in b["o"]): continue
        ke_cd[r] = yb
    lt, lp = [], []
    for r, yb in ke_cd.items():
        parts.append(mieng("Kệ cố định (chia ô)", vl, D - T, W - 2 * T, (T, yb - T / 2, T, W - 2 * T, T, D - T), (), ("R",), loai="ke", note="Giữa 2 hàng ô – bắt vít từ 2 hông"))
        v3 = [(yb, T + v, 5.0, X) for v in (50.0, (D - T) / 2, D - T - 49.0)]; lt += v3; lp += v3; pk["Vít 4x50 (ráp thùng)"] += 6
    # ---- ô của từng hàng + vách ngăn
    can_trai = lambda o: o.get("kieu") in ("hoc", "mo", "gia", "canh_doi") or (o.get("kieu") == "canh" and o.get("ban_le", "L") == "L")
    can_phai = lambda o: o.get("kieu") in ("hoc", "mo", "gia", "canh_doi") or (o.get("kieu") == "canh" and o.get("ban_le", "L") == "R")
    vach = []                                                      # [x tâm, y dưới, y trên, lỗ mặt trái, lỗ mặt phải]
    doors = []; boxes = []
    for r, row in enumerate(rows):
        os_ = row["o"]; ws = _chia(W - 2 * HO, [o.get("rong") for o in os_], KHE, "bề rộng ô", cb, so, 150.0)
        ylo = (ke_cd[r] + T / 2) if r in ke_cd else (z_lo if r == len(rows) - 1 else rows[r]["y0"] - KHE / 2)
        yhi = (ke_cd[r - 1] - T / 2) if (r - 1) in ke_cd else (z_hi if r == 0 else rows[r]["y1"] + KHE / 2)
        cells = []; x = HO
        for o, wc in zip(os_, ws): cells.append(dict(o=o, x0=x, x1=x + wc)); x += wc + KHE
        # đỡ 2 bên mỗi ô: ("hong", "L"/"R") hoặc ("vach", chỉ số vách)
        bien = []
        for c in range(len(cells) - 1):
            if can_phai(cells[c]["o"]) or can_trai(cells[c + 1]["o"]):
                xc = cells[c]["x1"] + KHE / 2; vach.append([xc, ylo, yhi, [], []]); bien.append(len(vach) - 1)
            else: bien.append(None)
        for c, ce in enumerate(cells):
            o = ce["o"]; k = o.get("kieu", "canh"); fx, fw, fy, fh = ce["x0"], ce["x1"] - ce["x0"], row["y0"], row["y1"] - row["y0"]
            trai = ("hong", "L") if c == 0 else (("vach", bien[c - 1]) if bien[c - 1] is not None else None)
            phai = ("hong", "R") if c == len(cells) - 1 else (("vach", bien[c]) if bien[c] is not None else None)
            # mép trong 2 bên ô (để tính lòng hộc / kệ)
            xl = T if c == 0 else ((vach[bien[c - 1]][0] + T / 2) if bien[c - 1] is not None else ce["x0"])
            xr = W - T if c == len(cells) - 1 else ((vach[bien[c]][0] - T / 2) if bien[c] is not None else ce["x1"])
            def gan(ben, ds):                                        # đưa lỗ vào hông hoặc mặt vách tương ứng
                if ben is None: return
                if ben[0] == "hong": (lt if ben[1] == "L" else lp).extend(ds)
                else: vach[ben[1]][4 if ben is trai else 3].extend(ds)     # vách bên TRÁI ô -> mặt PHẢI của vách
            tren = (r == 0); e45 = (); note0 = ghi
            if k in ("canh", "canh_doi"):
                ds_ = [(fx, fw, o.get("ban_le", "L"))] if k == "canh" else [(fx, (fw - KHE) / 2, "L"), (fx + (fw - KHE) / 2 + KHE, (fw - KHE) / 2, "R")]
                for x0, wd, bl in ds_:
                    pl = []; _canh_rieng(t, so, doors, pk, cb, (x0, fy, D, wd, fh, tf), bl, "z", pl, aos, "Cánh")
                    if sl and tren and vm not in ("MDF18", "MDF21"): doors[-1]["e45"] = ["R"]; doors[-1]["edges"] = [e for e in doors[-1]["edges"] if e != "R"]; doors[-1]["holes"].append((fh - 10, wd / 2, 5.0, 1.0))
                    gan(trai if bl == "L" else phai, pl)
                    if (bl == "L" and trai is None) or (bl == "R" and phai is None): cb.append(f"#{so}: cánh hàng {r + 1} ô {c + 1} không có chỗ bắt bản lề – đổi bên bản lề")
                if fw > 620 and k == "canh": cb.append(f"#{so}: cánh hàng {r + 1} rộng {fw:.0f} > 600 – nên đổi sang cánh đôi")
            elif k == "hoc":
                an = dict(kieu="hoc", k=r)
                up = 96.0 if fh < 250 else 128.0 if fh < 310 else 160.0
                xs = [46.4, 78.4] + ([46.4 + up] if fh >= 46.4 + up + 30 else [])
                hl = [(xx, yy, 10.0, 12.0) for xx in xs for yy in (29.9, fw - 29.9)] if t.get("ray", "tandembox") != "go" else []
                if sl and tren and vm not in ("MDF18", "MDF21"): e45 = ("R",); hl.append((fh - 10, fw / 2, 5.0, 1.0)); note0 = "Nẹp 45° cạnh có chấm Ø5 (cạnh trên)"
                doors.append(mieng(f"Mặt hộc {'shaker ' if shaker else ''}h{r + 1}.{c + 1}", vm, fh, fw, (fx, fy, D, fw, fh, tf), hl, edges, e45, note0, loai="mat_hoc", anim=an, rot=False))
                trang_tri(aos, (fx, fy, D, fw, fh, tf), shaker, "N" if t.get("tay_nam") else None, an, ngang=True)
                ow = xr - xl; NL = max([v for v in RAY_NL if v <= D - T - 3] or [270]); yb_ = max(fy, z_lo)
                run = [(yb_ + 50.9, v, 5.0, DR) for v in (D - 36, D - 132, D - 260, D - (NL - 48)) if v > T + 10]
                gan(trai, run); gan(phai, run)
                if t.get("ray", "tandembox") != "go":
                    bw, bd = ow - 75, NL - 24.4; BH = 198.0 if fh >= 255 else 166.0 if fh >= 215 else 134.0 if fh >= 180 else 83.0
                    boxes.append(mieng(f"Đáy hộc h{r + 1}.{c + 1}", vl, bw, bd, (xl + 37.5, yb_ + 28, D - bd, bw, T, bd), [(xx, yy, 5.0, 12.0) for xx in (9.0, bw - 9.0) for yy in (16.2, bd - 189.4, bd - 43.4) if yy > 0], (), loai="hoc", anim=an))
                    boxes.append(mieng(f"Hậu hộc h{r + 1}.{c + 1}", vl, ow - 87, BH, (xl + 43.5, yb_ + 28 + T, D - bd, ow - 87, BH, T), [(xx, yy, 5.0, 12.0) for xx in (9.0, ow - 96.0) for yy in (7.0, 39.0, 103.0, 135.0, 167.0) if yy <= BH - 31], ("T",), loai="hoc", anim=an))
                    for sx_ in (xl + 21, xr - 21 - 13): aos.append(ao("Thành hộc kim loại", (sx_, yb_ + 28, D - bd, 13, min(BH, fh - 40), bd), "#c9ccd1", anim=an))
                    pk[f"Ray hộc Tandembox {NL} (bộ)"] += 1
                else:
                    hs_ = float(min(200, max(80, int((fh - 45) // 10) * 10))); iw2 = ow - 10; ln = NL - 10.0; z0 = D - ln; sx_ = xl + 5
                    boxes.append(mieng(f"Hông hộc h{r + 1}.{c + 1} trái", vl, ln, hs_, (sx_, yb_ + 20, z0, T, hs_, ln), (), ("T",), loai="hoc", anim=an))
                    boxes.append(mieng(f"Hông hộc h{r + 1}.{c + 1} phải", vl, ln, hs_, (sx_ + iw2 - T, yb_ + 20, z0, T, hs_, ln), (), ("T",), loai="hoc", anim=an))
                    boxes.append(mieng(f"Đầu hộc h{r + 1}.{c + 1} trước", vl, iw2 - 2 * T, hs_, (sx_ + T, yb_ + 20, D - T, iw2 - 2 * T, hs_, T), (), ("T",), loai="hoc", anim=an))
                    boxes.append(mieng(f"Đầu hộc h{r + 1}.{c + 1} sau", vl, iw2 - 2 * T, hs_ - 13, (sx_ + T, yb_ + 33, z0, iw2 - 2 * T, hs_ - 13, T), (), ("T",), loai="hoc", anim=an, note="Khoét góc dưới 33x13 + lỗ móc ray Ø6 (khoan tay)"))
                    boxes.append(mieng(f"Đáy hộc h{r + 1}.{c + 1}", vl, iw2 - 2 * T, ln - T, (sx_ + T, yb_ + 33 - T, z0, iw2 - 2 * T, T, ln - T), (), (), loai="hoc", anim=an))
                    pk[f"Ray âm LEK SSC09-{NL} (bộ)"] += 1
                if t.get("tay_nam"): pk["Tay nắm"] += 1
                if t.get("mo") == "push": pk["Nhấn mở (push latch)"] += 1
                if ow < 250: cb.append(f"#{so}: ngăn kéo hàng {r + 1} ô {c + 1} lòng chỉ {ow:.0f} – quá hẹp cho ray")
            elif k == "gia":
                doors.append(mieng(f"Mặt giả h{r + 1}.{c + 1} (False Front)", vm, fh, fw, (fx, fy, D, fw, fh, tf), (), edges, (), "Bắt vít cố định từ trong ra (như CV False Front)", loai="tam", rot=False))
            if k in ("mo", "canh", "canh_doi") and int(o.get("ke", 0) or 0) > 0:           # kệ di động trong ô
                n = int(o["ke"]); lo_, hi_ = max(fy, ylo), min(fy + fh, yhi); ys_ = [lo_ + (j + 1) * (hi_ - lo_) / (n + 1) for j in range(n)]
                for yc in ys_: boxes.append(mieng(f"Kệ di động h{r + 1}.{c + 1}", vl, D - T - ke_lui(t), xr - xl - 2, (xl + 1, yc - T / 2, T, xr - xl - 2, T, D - T - ke_lui(t)), (), ("R",), loai="ke"))
                pins = [(yc + 32 * j, v, 5.0, 12.0) for yc in ys_ for j in range(-2, 3) for v in (T + 40.0, D - 49.0)]
                gan(trai, pins); gan(phai, pins); pk["Chốt kệ"] += 4 * n
    # ---- gộp vách thẳng hàng giữa 2 hàng không có kệ cố định, rồi dựng
    vach.sort(key=lambda v: (round(v[0], 1), v[1])); gop = []
    for v in vach:
        if gop and abs(gop[-1][0] - v[0]) < 0.5 and abs(gop[-1][2] - v[1]) <= KHE + 0.5:
            gop[-1][2] = v[2]; gop[-1][3] += v[3]; gop[-1][4] += v[4]
        else: gop.append([v[0], v[1], v[2], list(v[3]), list(v[4])])
    for j, (xc, y0, y1, lt_, lp_) in enumerate(gop, 1):
        hp = y1 - y0; dp = D - T
        # lỗ: u = cao tính từ chân vách, v = sâu tính từ mép sau vách (z = T)
        mat_t = [(r1(u - y0), r1(v - T), d, q) for u, v, d, q in lt_]; mat_p = [(r1(u - y0), r1(v - T), d, q) for u, v, d, q in lp_]
        lo = mat_t if (mat_t or not mat_p) else [(r1(hp - u), v, d, q) for u, v, d, q in mat_p]      # chỉ có lỗ mặt phải: lật tấm (cao đảo chiều)
        note = "Vách ngăn chia ô – bắt vít qua đáy / kệ"
        if mat_t and mat_p:
            note += f" | MẶT KIA còn {len(mat_p)} lỗ (bản lề / ray) – lật tấm khoan lần 2 hoặc khoan tay"
            cb.append(f"#{so}: vách {j} có lỗ cả 2 mặt – file CNC chỉ khoan mặt TRÁI, mặt phải {len(mat_p)} lỗ cần lật tấm")
        elif mat_p and not mat_t: note += " | ĐẶT MẶT PHẢI LÊN khi cắt"
        parts.append(mieng(f"Vách ngăn {j}", vl, hp, dp, (xc - T / 2, y0, T, T, hp, dp), lo, ("T",), note=note))
        pk["Vít 4x50 (ráp thùng)"] += 4
    for p in parts:                                              # lỗ trên 2 hông thùng
        if p["name"].startswith("Hông trái") and abs(p["box"][0]) < 1: p["holes"] += [(r1(u), r1(v), d, q) for u, v, d, q in lt]
        elif p["name"].startswith("Hông phải"): p["holes"] += [(r1(H - u), r1(v), d, q) for u, v, d, q in lp]
    return parts + boxes + doors, aos, pk, cb


DUNG0 = dict(duoi_canh=tu_duoi_canh, duoi_chau=tu_duoi_canh, duoi_hoc=tu_duoi_hoc, duoi_keo=tu_duoi_keo, treo=tu_hop, hut_mui=tu_hut_mui, tu_do=tu_tu_do, cao=tu_hop, tu_ao=tu_hop, lo_nuong=tu_hop,
            ke_mo=lambda t, so: tu_hop(t, so, co_canh=False), tam=tu_tam, mat_da=tu_mat_da, thiet_bi=tu_ao_khoi, may_rua=tu_may_rua, goc_l=tu_goc_l, treo_goc=tu_treo_goc, goc_mu=tu_goc_mu, treo_mu=tu_treo_mu, cao_mu=tu_treo_mu, cao_goc=tu_treo_goc, goc45=lambda t, so: tu_goc45(t, so), treo_goc45=lambda t, so: tu_goc45(t, so), cao_goc45=lambda t, so: tu_goc45(t, so), cong=tu_cong,
            tu_lanh=lambda t, so: tu_lanh_roi(t, so) if tl_roi(t) else tu_hop(t, so))


DUNG = dict(DUNG0, lo_nuong=lambda t, so: tu_lo_tach(t, so), cao=lambda t, so: tu_vat(t, so) if t.get("vat") in ("L", "R") else tu_keo_cao(t, so) if t.get("keo_cao") else tu_cao_tach(t, so), tu_ao=lambda t, so: tu_cao_tach(t, so))
DUNG["treo"] = (lambda f: (lambda t, so: tu_vat(t, so) if t.get("vat") in ("L", "R") else f(t, so)))(DUNG["treo"])
_DUNG_GOC = dict(DUNG)
for _l in O_LOAI:                                                   # tủ có bố cục chia ô -> dựng theo ô
    DUNG[_l] = (lambda f: (lambda t, so: tu_chia_o(t, so) if (t.get("o_mat") or {}).get("hang") and not float(t.get("tach") or 0) else f(t, so)))(_DUNG_GOC[_l])


def tu_vat(t, so):
    """TỦ VÁT 45° ĐẦU HÀNG (CV "1 Door Floor / Wall / Pantry – 45 Deg – Left/Right"): mặt trước cắt chéo 45° hết bề rộng tủ,
    1 hông đủ sâu (phía hàng tủ), 1 hông ngắn (D − W) ở đầu hàng; nóc / đáy / kệ hình thang; 1 cánh nằm trên đường chéo (bản lề 45°)."""
    parts, aos, pk, cb = [], [], Counter(), []
    W, H, D = t["w"], t["h"], t["d"]; vl = t["vl_thung"]; T = VAT_LIEU[vl]["lz"]; X = T + 0.5; iw = W - 2 * T; ben = t.get("vat", "R")
    if D - W < 80: cb.append(f"#{so}: tủ vát 45° cần sâu > rộng + 80 (đang {W:.0f} × {D:.0f}) – đã giảm rộng"); W = max(150.0, D - 80); iw = W - 2 * T; t = dict(t, w=W)
    SD = D - W                                                     # sâu hông ngắn
    mir = (lambda x: W - x) if ben == "L" else (lambda x: x)          # bên ngắn trái: lật trục x
    ys = (50.0, r1((50 + D - 49) / 2), D - 49.0); ys2 = (50.0, SD - 49.0) if SD > 140 else (r1(SD / 2),)
    base = [(x, y, 5.0, X) for x in (T / 2, H - T / 2) for y in ys] + [(66.4 + k * (H - 132.8) / 2, T / 2, 5.0, X) for k in range(3)]
    base2 = [(x, y, 5.0, X) for x in (T / 2, H - T / 2) for y in ys2] + [(66.4 + k * (H - 132.8) / 2, T / 2, 5.0, X) for k in range(3)]
    n_ke = int(t.get("ke", 1) or 0); xs = [T + (k + 1) * (H - 2 * T) / (n_ke + 1) for k in range(n_ke)]
    pins = [(x + 32 * j, y, 5.0, 12.0) for x in xs for j in (-1, 0, 1) for y in (T + 40.0,)]
    hong_dai = mieng("Hông (đủ sâu, phía hàng tủ)", vl, H, D, (mir(0) - (T if ben == "L" else 0), 0, 0, T, H, D), base + pins, ("T",))
    hong_ngan = mieng("Hông ngắn (đầu vát)", vl, H, SD, (mir(W) - (0 if ben == "L" else T), 0, 0, T, H, SD), base2 + pins, ("T",), note="Mép trước nên vát 45° (hoặc che bằng cánh)")
    parts += [hong_dai, hong_ngan]
    parts.append(mieng("Hậu", vl, iw, H, (T, 0, 0, iw, H, T), (), (), loai="hau"))
    # nóc / đáy / kệ: hình thang (u = ngang từ hông dài, v = sâu từ hậu)
    tra = lambda lui: [(0.0, 0.0), (iw, 0.0), (iw, max(SD - T - lui, 20.0)), (0.0, D - 2 * T - lui)]
    def tam(ten, y, lui, loai="thung"):
        P = tra(lui); Pm = P if ben == "R" else [(iw - u, v) for u, v in P]
        p = mieng(ten, vl, iw, D - T, (T, y, T, iw, T, D - T), (), ("T",), poly=Pm, loai=loai, note="Cạnh trước vát 45°")
        p["pl3d"] = dict(ax="y", o=[T, y, T], pts=Pm, d=T); parts.append(p)
    tam("Đáy (vát 45°)", 0, 0.0); tam("Nóc (vát 45°)", H - T, 0.0)
    for k, x in enumerate(xs): tam(f"Kệ di động {k + 1} (vát 45°)", x - T / 2, 14.0, "ke")
    pk["Chốt kệ"] += 4 * n_ke
    # cánh trên đường chéo: 3D = khối xoay 45° (pl3d), file cắt = chữ nhật
    vm, shaker, ghi = mat_ngoai(t); tf = VAT_LIEU[vm]["lz"]; edges = () if vm in ("MDF18", "MDF21") else ("T", "B", "L", "R")
    du = float(t.get("_du") or 0); sl = bool(t.get("shadowline")) and t["loai"] not in TU_TREO
    y0 = -du if du else HO; hd = (H - HO + du) if du else (H - y0 - (SL_CUA if sl else HO))
    L = W * 2 ** 0.5; wd = L - 2 * HO - 2.0; s0 = (L - wd) / 2
    import math as _m
    ux, uz = (1 / 2 ** 0.5, -1 / 2 ** 0.5); nx, nz = (1 / 2 ** 0.5, 1 / 2 ** 0.5)
    A = (0.0, D)
    pts = [(A[0] + ux * a + nx * b, A[1] + uz * a + nz * b) for a, b in ((s0, 0), (s0 + wd, 0), (s0 + wd, tf), (s0, tf))]
    if ben == "L": pts = [(W - x, z) for x, z in pts]
    bl = "L" if ben == "R" else "R"                                  # bản lề ở phía hông dài
    bxs = lambda P: (min(x for x, _ in P), y0, min(z for _, z in P), max(x for x, _ in P) - min(x for x, _ in P), hd, max(z for _, z in P) - min(z for _, z in P))   # khung bao (mặt đứng / mặt bằng)
    c = mieng(f"Cánh vát 45° {'shaker ' if shaker else ''}", vm, hd, wd, bxs(pts), lo_canh(hd, wd, vm, bl), edges, (),
              (ghi + " | " if ghi else "") + "Bản lề 45° (cánh vát) – đế khoan tay trên hông dài", loai="canh", rot=False)
    c["pl3d"] = dict(ax="y", o=[0.0, y0, 0.0], pts=[(r1(x), r1(z)) for x, z in pts], d=hd); parts.append(c)
    pk["Bản lề 45° + đế (cánh vát)"] += so_ban_le(hd)
    if t.get("tay_nam"): pk["Tay nắm"] += 1
    if t["loai"] in TU_TREO: pk["Pát treo tủ (cặp)"] += 1
    else: chan_tu(dict(t, w=W, d=SD + 10), aos, pk)
    return parts, aos, pk, cb


def tu_goc45(t, so):
    """TỦ GÓC CHÉO 45° (CV "45 Deg Floor / Wall Corner", "Corner Pantry 45 Deg"): 2 nhánh sâu `sau_nhanh` dọc 2 tường,
    mặt trước cắt chéo nối đầu 2 nhánh, 1 cánh trên đường chéo; nóc / đáy / kệ ngũ giác 1 miếng."""
    parts, aos, pk, cb = [], [], Counter(), []
    W, H, D = t["w"], t["h"], t["d"]; vl = t["vl_thung"]; T = VAT_LIEU[vl]["lz"]; X = T + 0.5
    a = float(t.get("sau_nhanh") or (300 if t["loai"] == "treo_goc45" else 580))
    if W < a + 200 or D < a + 200: cb.append(f"#{so}: tủ góc chéo cần mỗi chiều ≥ nhánh + 200 – đã nới"); W = max(W, a + 200); D = max(D, a + 200); t = dict(t, w=W, d=D)
    ys = lambda L: (50.0, L - 49.0) if L > 140 else (r1(L / 2),)
    n_ke = int(t.get("ke", 1) or 0); xs = [T + (k + 1) * (H - 2 * T) / (n_ke + 1) for k in range(n_ke)]
    pins = [(x + 32 * j, y, 5.0, 12.0) for x in xs for j in (-1, 0, 1) for y in (T + 40.0, a - 49.0)]
    b1 = [(x, y, 5.0, X) for x in (T / 2, H - T / 2) for y in ys(a)] + [(66.4 + k * (H - 132.8) / 2, T / 2, 5.0, X) for k in range(3)]
    parts.append(mieng("Hông phải (đầu nhánh dọc tường sau)", vl, H, a, (W - T, 0, 0, T, H, a), [(H - x, y, d, q) for x, y, d, q in b1 + pins], ("T",)))
    parts.append(mieng("Hông cuối (đầu nhánh dọc tường bên)", vl, H, a, (0, 0, D - T, a, H, T), b1 + pins, ("T",)))
    parts.append(mieng("Hậu dài", vl, W - T, H, (0, 0, 0, W - T, H, T), (), (), loai="hau"))
    parts.append(mieng("Hậu nhánh", vl, D - 2 * T, H, (0, 0, T, T, H, D - 2 * T), (), (), loai="hau"))
    U, V = W - 2 * T, D - 2 * T
    P5 = lambda lui: [(0.0, 0.0), (U, 0.0), (U, a - T - lui), (a - T - lui, V), (0.0, V)]
    def tam(ten, y, lui, loai="thung"):
        P = P5(lui); p = mieng(ten, vl, U, V, (T, y, T, U, T, V), (), ("T",), poly=P, loai=loai, note="Ngũ giác 1 miếng – cạnh chéo phía trước")
        p["pl3d"] = dict(ax="y", o=[T, y, T], pts=P, d=T); parts.append(p)
    tam("Đáy góc chéo", 0, 0.0); tam("Nóc góc chéo", H - T, 0.0)
    for k, x in enumerate(xs): tam(f"Kệ góc chéo {k + 1}", x - T / 2, 10.0, "ke")
    pk["Chốt kệ"] += 4 * n_ke; pk["Vít 4x50 (ráp thùng)"] += 20
    vm, shaker, ghi = mat_ngoai(t); tf = VAT_LIEU[vm]["lz"]; edges = () if vm in ("MDF18", "MDF21") else ("T", "B", "L", "R")
    du = float(t.get("_du") or 0); la_treo = t["loai"] == "treo_goc45"
    y0 = -du if du else HO; hd = (H - HO + du) if du else (H - 2 * HO)
    A, B = (W, a), (a, D); L = ((A[0] - B[0]) ** 2 + (A[1] - B[1]) ** 2) ** 0.5; wd = L - 2 * HO
    ux, uz = (B[0] - A[0]) / L, (B[1] - A[1]) / L; nx, nz = -uz, ux                     # pháp tuyến ra trước (x+z tăng)
    if nx + nz < 0: nx, nz = -nx, -nz
    pts = [(A[0] + ux * s_ + nx * q, A[1] + uz * s_ + nz * q) for s_, q in ((HO, 0), (HO + wd, 0), (HO + wd, tf), (HO, tf))]
    c = mieng(f"Cánh góc chéo {'shaker ' if shaker else ''}", vm, hd, wd, (min(x for x, _ in pts), y0, min(z for _, z in pts), max(x for x, _ in pts) - min(x for x, _ in pts), hd, max(z for _, z in pts) - min(z for _, z in pts)), lo_canh(hd, wd, vm, "R"), edges, (),
              (ghi + " | " if ghi else "") + "Bản lề 135° (cánh chéo) bắt hông phải – đế khoan tay", loai="canh", rot=False)
    c["pl3d"] = dict(ax="y", o=[0.0, y0, 0.0], pts=[(r1(x), r1(z)) for x, z in pts], d=hd); parts.append(c)
    pk["Bản lề 135° + đế (cánh góc chéo)"] += so_ban_le(hd)
    if t.get("tay_nam"): pk["Tay nắm"] += 1
    if wd > 650: cb.append(f"#{so}: cánh chéo rộng {wd:.0f} – kiểm tải bản lề (nên ≤ 600)")
    if la_treo: pk["Pát treo tủ (cặp)"] += 2
    else:
        cc = float(t.get("chan", 0) or 0)
        if cc > 0:                                   # chân 2 nhánh (không lấn vào góc vát)
            aos.append(ao("Chân tủ", (0, -cc, 0, W, cc, a - 50), "#2f2f31", loai="chan"))
            aos.append(ao("Chân tủ", (0, -cc, a - 50, a - 50, cc, D - a), "#2f2f31", loai="chan"))
    return parts, aos, pk, cb


def tu_keo_cao(t, so):
    """PANTRY KÉO (CV "VS – DUSA / Centre Mount Pull-Out Pantry", rộng 300–600): thùng tủ cao không cánh / không kệ,
    1 mặt kéo cao suốt bắt vào khung kéo của hãng (ray đáy + ray nóc), kệ rổ là của hãng."""
    parts, aos, pk, cb = tu_hop(dict(t, canh=0, ke=0, ke_cd=0, thanh_treo=False), so, co_canh=False)
    W, H, D = t["w"], t["h"], t["d"]; T = VAT_LIEU[t["vl_thung"]]["lz"]; iw = W - 2 * T
    vm, shaker, ghi = mat_ngoai(t); tf = VAT_LIEU[vm]["lz"]; edges = () if vm in ("MDF18", "MDF21") else ("T", "B", "L", "R")
    hf = H - 2 * HO; wf = W - 2 * HO; an = dict(kieu="hoc", k=0)
    parts.append(mieng(f"Mặt kéo pantry {'shaker ' if shaker else ''}(pull-out)", vm, hf, wf, (HO, HO, D, wf, hf, tf), [], edges, (),
                       (ghi + " | " if ghi else "") + "Bắt vào khung kéo theo dưỡng của hãng – không khoan bản lề", loai="mat_hoc", anim=an, rot=False))
    trang_tri(aos, (HO, HO, D, wf, hf, tf), shaker, "N" if t.get("tay_nam") else None, an, ngang=False)
    aos.append(ao("Khung rổ kéo (của hãng)", (T + 15, T + 60, 40, iw - 30, H - 2 * T - 120, D - 80), "#8d9197", anim=an, loai="thiet_bi"))
    if iw < 270: cb.append(f"#{so}: lòng {iw:.0f} – pantry kéo thường cần tủ rộng ≥ 300")
    if H > 2200: cb.append(f"#{so}: pantry kéo cao {H:.0f} – kiểm khung của hãng (thường 1700–2150)")
    pk[f"Khung pantry kéo cho tủ {W:.0f} × {H:.0f} (bộ)"] += 1
    if t.get("tay_nam"): pk["Tay nắm"] += 1
    return parts, aos, pk, cb


def tu_cao_tach(t, so):
    """tủ cao tách 2 thùng chồng nhau (cách TPW làm pantry tới trần): thùng dưới cao `tach`, hộp trên phần còn lại. Mỗi thùng có cánh riêng."""
    tach = float(t.get("tach") or 0)
    if tach <= 0 or tach >= t["h"] - 150: return tu_hop(t, so)
    n = int(t.get("ke", 0) or 0); ncd = int(t.get("ke_cd", 0) or 0)
    d = dict(t, h=tach, tach=0, ke=max(0, n - 1), ke_cd=0)
    u = dict(t, h=t["h"] - tach, tach=0, chan=0, ke=min(n, 1), ke_cd=0, thanh_treo=False)
    p1, a1, k1, c1 = tu_hop(d, so); p2, a2, k2, c2 = tu_hop(u, so)
    for p in p2:
        p["box"][1] += tach; p["name"] = "Hộp trên – " + p["name"]
    for a in a2: a["box"] = (a["box"][0], a["box"][1] + tach, *a["box"][2:])
    k1.update(k2)
    return p1 + p2, a1 + a2, k1, c1 + c2


def tu_lo_tach(t, so):
    """TỦ LÒ TÁCH 2 THÙNG (bản vẽ Eastwood của Huân: thùng dưới 1530 = ngăn kéo + OVEN + M/W, hộp trên 1130 cánh, đỉnh thẳng tủ treo).
    tach = cao thùng dưới; để 0 thì 1 thùng suốt như cũ. Thùng dưới phải chứa hết hộc lò + vi sóng."""
    tach = float(t.get("tach") or 0)
    if tach <= 0: return tu_hop(t, so)
    T = VAT_LIEU[t["vl_thung"]]["lz"]; ly, lc, l2 = float(t.get("lo_y", 600)), float(t.get("lo_cao", 595)), float(t.get("lo2_cao", 0) or 0)
    top_lo = ly + lc + (T + l2 if l2 > 0 else 0); can = top_lo + T
    if tach < can - 0.5 or tach > t["h"] - 250:
        p, a, k, c = tu_hop(dict(t, tach=0), so)
        return p, a, k, c + [f"#{so}: tách thùng {tach:.0f} không hợp lệ – thùng dưới phải >= {can:.0f} (chứa hết lò + vi sóng) và hộp trên >= 250; đã dựng 1 thùng"]
    p1, a1, k1, c1 = tu_hop(dict(t, h=tach, tach=0), so)
    u = dict(t, loai="cao", h=t["h"] - tach, tach=0, chan=0, ke=1 if t["h"] - tach > 450 else 0, ke_cd=0, hoc_trong=0, thanh_treo=False, lat=t.get("lat") or "")
    p2, a2, k2, c2 = tu_hop(u, so)
    for q in p2: q["box"][1] += tach; q["name"] = "Hộp trên – " + q["name"]
    for q in a2: q["box"] = (q["box"][0], q["box"][1] + tach, *q["box"][2:])
    k1.update(k2)
    return p1 + p2, a1 + a2, k1, c1 + c2


def chuan_hoa(t):
    base = tu_moi(t.get("loai", "duoi_canh"))
    base.update({k: v for k, v in t.items() if v is not None})
    for k in ("w", "h", "d", "x", "y", "z", "chan"):
        try: base[k] = float(base.get(k, 0) or 0)
        except (TypeError, ValueError): base[k] = 0.0
    for k in ("vl_thung", "vl_mat"):
        if base.get(k) not in VAT_LIEU: base[k] = CHUNG[k]
    for k, _, kieu, ap in THAM_SO:           # giá trị lạ (file job hỏng, AI trả bậy): đưa về mặc định của thư viện
        if k not in base or (ap and base["loai"] not in ap): continue
        v = base[k]; md = THU_VIEN[base["loai"]].get(k, CHUNG.get(k))
        if kieu == "bool": base[k] = v if isinstance(v, bool) else str(v).lower() in ("1", "true", "có", "co", "yes")
        elif isinstance(kieu, list):
            if isinstance(kieu[0], int):
                try: v = int(float(v))
                except (TypeError, ValueError): v = None
            base[k] = v if v in kieu else (md if md in kieu else kieu[0])
        elif kieu == "mm" and k not in ("w", "h", "d", "x", "y", "z", "chan"):
            try: base[k] = float(v)
            except (TypeError, ValueError): base[k] = float(md or 0)
    try: base["goc"] = int(float(base.get("goc", 0) or 0)) % 360
    except (TypeError, ValueError): base["goc"] = 0
    if "mo" not in t:                                             # file job cũ / lệnh AI chỉ có shadowline, tay_nam
        base["mo"] = "shadowline" if t.get("shadowline") else ("push" if t.get("tay_nam") is False else "tay_nam")
    if base.get("mo") not in ("tay_nam", "shadowline", "push"): base["mo"] = "tay_nam"
    base["shadowline"] = base["mo"] == "shadowline"; base["tay_nam"] = base["mo"] == "tay_nam"
    if tl_roi(base): base["chan"] = 0.0                            # tủ lạnh rời đứng thẳng trên sàn, không có kickface
    if base["loai"] == "mat_da":
        try: base["h"] = min(150.0, max(6.0, float(base.get("day_da") or base["h"])))
        except (TypeError, ValueError): pass
    return base


def dung_job(job):
    """job = {ten, so, tu:[...]} -> {tu:[{id, so, ten, khoi:[...]}], chi_tiet:[...], phu_kien:{...}, canh_bao:[...], nep:{vl: mét}}"""
    out_tu, chi_tiet, pk, cb, nep = [], [], Counter(), [], Counter()
    BT = bo_tri(job.get("phong") or {}, [chuan_hoa(t) | {"day": t.get("day")} for t in job.get("tu", []) if not t.get("auto")])
    for i, raw in enumerate(job.get("tu", [])):
        t = chuan_hoa(raw); so = i + 1
        if min(t["w"], t["h"], t["d"]) <= 0: cb.append(f"#{so}: kích thước phải lớn hơn 0"); continue
        ph0 = job.get("phong") or {}
        if t["loai"] == "mat_da":
            t["_chau"] = []
            for r2 in job.get("tu", []):          # chậu theo mã máy của tủ chậu nằm dưới mặt đá -> khoét đúng tâm tủ chậu
                s2 = r2.get("spec") if isinstance(r2.get("spec"), dict) else {}
                if r2 is raw or r2.get("loai") not in ("duoi_chau", "goc_l") or r2.get("day") != raw.get("day") or str(s2.get("loai_may")) != "sink": continue
                u = chuan_hoa(r2)
                if u.get("goc") != t.get("goc") or not s2.get("khoet_rong") or not s2.get("khoet_sau"): continue
                cx = float(u["x"]) + float(u["w"]) / 2 - float(t["x"])
                if 0 < cx < float(t["w"]): t["_chau"].append((ten_spec(s2, u), float(s2["khoet_rong"]), float(s2["khoet_sau"]), cx))
        if t["loai"] == "mat_da" and not float(t.get("bep_x") or 0) and (float(t.get("bep_rong") or 0) or (t.get("spec") or {}).get("khoet_rong")):
            for r2 in job.get("tu", []):          # lỗ bếp tự đặt giữa hộc lò âm dưới bếp nằm dưới mặt đá này
                if r2 is raw or not r2.get("lo_duoi") or r2.get("day") != raw.get("day"): continue
                u = chuan_hoa(r2)
                if u.get("goc") != t.get("goc"): continue
                cx = float(u["x"]) + float(u["w"]) / 2 - float(t["x"])
                if 0 < cx < float(t["w"]): t["bep_x"] = round(cx, 1); t["_bep_tu"] = True; break
        if t["loai"] == "mat_da":                  # mối nối đá: vị trí ứng viên = mép giữa các tủ dưới nằm dưới tấm đá
            t["_kho_da"] = float((job.get("phong") or {}).get("kho_da") or 3050)
            t["_mep"] = sorted({round(float(u["x"]) - float(t["x"]), 1) for u in (chuan_hoa(r2) for r2 in job.get("tu", []) if r2 is not raw and r2.get("day") == raw.get("day") and r2.get("loai") in TU_DUOI + ("thiet_bi", "tam"))
                                if u.get("goc") == t.get("goc") and 0 < float(u["x"]) - float(t["x"]) < float(t["w"])})
        if t["loai"] == "mat_da": cb += kiem_bep_gas(t, raw, job, so)
        if t["loai"] == "hut_mui": cb += kiem_hut_mui_cao(t, raw, job, so)
        if t["loai"] in ("treo", "hut_mui", "treo_goc", "treo_mu") and t.get("mo") == "shadowline": t["_du"] = 40.0 if ph0.get("bc") else 20.0
        if t["loai"] in ("cao", "tu_ao") and t.get("mo") == "shadowline" and not float(t.get("tach") or 0):
            cb.append(f"#{so}: pantry 1 thùng không làm fingerpull – đã chuyển sang tay nắm (muốn fingerpull thì đặt 'Tách 2 thùng')")
            t["mo"] = "tay_nam"; t["shadowline"] = False; t["tay_nam"] = True
        try:
            parts, aos, p2, c2 = DUNG[t["loai"]](t, so)
            sp = t.get("spec") if isinstance(t.get("spec"), dict) else None
            if sp and t["loai"] in ("lo_nuong", "tu_lanh", "duoi_canh", "hut_mui", "may_rua", "duoi_chau"):     # spec máy đã tra: kiểm hộc có đủ không
                Tt = 0.0 if t["loai"] == "may_rua" else VAT_LIEU[t["vl_thung"]]["lz"]          # máy rửa chén: khoảng trống, không thùng
                ten_m = ten_spec(sp, t)
                try:
                  if str(sp.get("loai_may")) == "sink":          # chậu: hãng cho rộng NGOÀI tủ chậu tối thiểu; chậu âm thì thân chậu phải lọt lòng tủ
                    if sp.get("hoc_rong_min") and t["w"] < float(sp["hoc_rong_min"]) - 0.5: c2.append(f"#{so}: tủ chậu rộng {t['w']:.0f} < {float(sp['hoc_rong_min']):.0f} tối thiểu của {ten_m}")
                    if sp.get("rong") and "âm" in str(sp.get("ten")) and float(sp["rong"]) > t["w"] - 2 * Tt + 0.5: c2.append(f"#{so}: chậu âm {ten_m} rộng {float(sp['rong']):.0f} > lòng tủ {t['w'] - 2 * Tt:.0f} ({float(sp['rong']) - (t['w'] - 2 * Tt):.0f} mm) – vành chậu đụng hông tủ: kiểm khi lắp (khoét đầu hông / chọn tủ rộng hơn)")
                  else:
                      if sp.get("hoc_rong_min") and t["w"] - 2 * Tt < float(sp["hoc_rong_min"]) - 0.5: c2.append(f"#{so}: lòng tủ {t['w'] - 2 * Tt:.0f} < hộc tối thiểu {float(sp['hoc_rong_min']):.0f} của {ten_m}")
                      if sp.get("hoc_sau_min") and t["d"] - Tt < float(sp["hoc_sau_min"]) - 0.5: c2.append(f"#{so}: lòng sâu {t['d'] - Tt:.0f} < {float(sp['hoc_sau_min']):.0f} cần cho {ten_m}")
                except (TypeError, ValueError): pass
            md_ray = (job.get("mac_dinh") or {}).get("ray")
            parts, p2 = ap_he_hoc(t if (t.get("ray") or not md_ray) else dict(t, ray=md_ray), so, parts, aos, p2, c2)
        except Exception as e:  # tham số lạ: báo, không làm sập cả job
            cb.append(f"#{so} {t.get('ten', '')}: lỗi dựng tủ ({e})"); continue
        pk.update(p2); cb += c2
        khoi = []
        for p in parts:
            p["cab"] = str(so); p["tu_ten"] = t.get("ten", "")
            v = VAT_LIEU[p["vl"]]
            if max(p["w"], p["h"]) > v["lx"] - 8 or min(p["w"], p["h"]) > v["ly"] - 8:
                cb.append(f"#{so} {p['name']}: {p['w']:.0f} x {p['h']:.0f} không lọt tấm {v['lx']} x {v['ly']}")
            for e in p["edges"] + p["e45"]:
                nep[p["vl"]] += (p["w"] if e in ("T", "B") else p["h"]) / 1000
            p["ngoai"] = v.get("cnc") is False
            vai = "mat" if p["loai"] in ("canh", "mat_hoc", "tam") or (p["vl"] != "HMR16" and p["loai"] != "hoc") else "thung"
            if p.get("pl3d"):                  # miếng có hình (khoét U, khấc, chữ L): vẽ 1 KHỐI LIỀN đúng hình cắt, không tách
                khoi.append(dict(n=p["name"], b=p["box"], c=v["mau"], k=p["loai"], a=p["anim"], vl=p["vl"], r=vai, pl=p["pl3d"]))
            else:
                bxs = p.get("k3d") or (tach_khoi_hong(p) if p["name"].startswith("Hông") else [p["box"]])
                for bx in bxs:
                    kd = dict(n=p["name"], b=bx, c=v["mau"], k=p["loai"], a=p["anim"], vl=p["vl"], r=vai, cung=p.get("cung"))
                    if not p.get("cung") and (p["edges"] or p["e45"]):          # cạnh dán nẹp -> 3D tô màu (như CV)
                        kd["nep"] = dict(e=list(p["edges"]), e45=list(p["e45"]), w=p["w"], h=p["h"], t=v["lz"], b0=list(p["box"]), tach=len(bxs) > 1)
                    khoi.append(kd)
            chi_tiet.append(p)
        for a in aos:
            vai = {"khung": "mat", "mat_da": "da", "tay": "tay", "chan": "chan"}.get(a["loai"], "kl")
            khoi.append(dict(n=a["name"], b=a["box"], c=a["mau"] or VAT_LIEU["MDF21"]["mau"], k=a["loai"], a=a["anim"], vl=None, r=vai))
        dd = BT.get(raw.get("day") or "A") or BT["A"]; wx, wz = the_gioi(dd, t["x"], t["z"])
        out_tu.append(dict(id=raw.get("id"), so=so, ten=t.get("ten", ""), loai=t["loai"], x=round(wx, 2), y=t["y"] + t["chan"], z=round(wz, 2), goc=(dd["goc"] + t["goc"]) % 360,
                           w=t["w"], h=t["h"], d=t["d"], chan=t["chan"], khoi=khoi, day=dd["id"]))
    hop = []                                # tủ chồng lên nhau (kéo tay / AI đặt sai / file cũ): báo ngay ở đầu danh sách
    for i, raw in enumerate(job.get("tu", [])):
        if raw.get("auto") or raw.get("loai") in ("tam", "mat_da"): continue
        t = chuan_hoa(raw)
        if t["goc"] % 360 == 0:
            dd = BT.get(raw.get("day") or "A") or BT["A"]
            p1 = the_gioi(dd, t["x"], t["z"]); p2 = the_gioi(dd, t["x"] + t["w"], t["z"] + t["d"])
            hop.append((i + 1, min(p1[0], p2[0]), max(p1[0], p2[0]), t["y"], t["y"] + t["chan"] + t["h"], min(p1[1], p2[1]), max(p1[1], p2[1]), dd["id"]))
    for a in range(len(hop)):
        for b in range(a + 1, len(hop)):
            A, B = hop[a], hop[b]
            if all(A[k] < B[k + 1] - 1 and B[k] < A[k + 1] - 1 for k in (1, 3, 5)):
                if A[7] == B[7]: cb.insert(0, f"Tủ #{A[0]} và #{B[0]} đang CHỒNG lên nhau {min(A[2], B[2]) - max(A[1], B[1]) if A[7] in 'AD' else min(A[6], B[6]) - max(A[5], B[5]):.0f}mm – kéo tách ra hoặc sửa bề rộng")
                else: cb.insert(0, f"Tủ #{A[0]} (dãy {A[7]}) và #{B[0]} (dãy {B[7]}) đang ĐÈ nhau ở góc – kéo tủ ra khỏi góc hoặc sửa chiều dài tường")
    ds = job.get("tu", [])
    if any(t.get("loai") in TU_DUOI + TU_CAO + TU_TREO for t in ds) and not any(t.get("auto") for t in ds):
        cb.insert(0, "Chưa có panel hông / filler / kicker: bấm nút Hoàn thiện để không lộ thùng trắng")
    # splashback: tấm ốp tường giữa mặt đá và đáy tủ treo, theo từng dãy sát tường (anh Tan 20/11: chọn được vật liệu / màu splashback)
    splash = []; ph = job.get("phong") or {}; sb = ph.get("splashback")
    if sb in ("gach", "da", "kinh"):
        day_sb = {"gach": 10.0, "da": 20.0, "kinh": 6.0}[sb]; m2 = 0.0
        ch = [chuan_hoa(t) | {"day": t.get("day") or "A"} for t in job.get("tu", []) if not t.get("auto")]
        for did, dd in BT.items():
            if did == "D": continue
            ds = [t for t in ch if t["day"] == did and not t["goc"]]
            thap = sorted([t for t in ds if t["loai"] in TU_DUOI + ("thiet_bi",) and t["chan"] + t["h"] < 1200], key=lambda t: t["x"])
            if not thap: continue
            da = [t for t in ds if t["loai"] == "mat_da"]; tr = [t for t in ds if t["loai"] in TU_TREO]
            y0 = max(t["chan"] + t["h"] for t in thap) + (max(t["h"] for t in da) if da else 0)
            seg = []
            for t in thap:
                if seg and t["x"] - seg[-1][1] <= 17: seg[-1][1] = t["x"] + t["w"]
                else: seg.append([t["x"], t["x"] + t["w"]])
            for a, b in seg:
                if dd.get("trai") == "tuong" and a <= float(ph.get("filler") or 30) + 1: a = 0.0
                if dd.get("dai") and 0 < dd["dai"] - b <= (700 if dd.get("phai") == "goc" else 150 if dd.get("phai") == "tuong" else 0): b = dd["dai"]
                if dd.get("trai") == "goc" and a <= 700: a = 0.0
                tren = [t["y"] - (float(ph.get("bc") and 40 or 20) if t.get("mo") == "shadowline" else 0) for t in tr if t["x"] < b and t["x"] + t["w"] > a]
                y1 = min(tren) if tren else y0 + 600.0
                if y1 - y0 < 50: continue
                splash.append(dict(day=did, b=[round(a, 1), round(y0, 1), 0.0, round(b - a, 1), round(y1 - y0, 1), day_sb], loai=sb)); m2 += (b - a) * (y1 - y0) / 1e6
        if m2: pk[f"Splashback {dict(gach='gạch', da='đá', kinh='kính')[sb]} (m²)"] = round(m2, 2)
    gc = [c for c in cb if "GHI CHÚ THỢ ĐÁ" in c]; cb = [c for c in cb if "GHI CHÚ THỢ ĐÁ" not in c]      # ghi chú cho thợ đá: mục riêng, không lẫn vào cảnh báo
    gc = [c.replace(" – GHI CHÚ THỢ ĐÁ:", ":") for c in gc]
    return dict(tu=out_tu, chi_tiet=chi_tiet, phu_kien=dict(pk), canh_bao=cb, ghi_chu=gc, nep={k: round(v, 1) for k, v in nep.items()}, day=list(BT.values()), splash=splash)


def xep_hang(ds, x0=0.0):
    """đặt 1 hàng tủ nối tiếp từ trái sang phải (dùng cho AI vẽ nhanh)"""
    x = x0
    for t in ds:
        t["x"] = x; x += float(t.get("w", 0) or 0)
    return ds


# ---------------------------------------------------------------- hoàn thiện: panel hông, filler sát tường, kicker, bulkhead (quy tắc anh Tan dặn 19/11/2026)
def _tam(ten, huong, x, y, z, w, h, d, cat=None, ghi="", vl=None):
    vl = vl or _VLP[0]
    return dict(loai="tam", auto=True, ten=ten, huong=huong, x=round(x, 1), y=round(y, 1), z=round(z, 1), w=round(w, 1), h=round(h, 1), d=round(d, 1),
                chan=0, goc=0, vl_thung=vl, cat=cat, ghi_chu=ghi)


_VLP = ["MAU16"]


def _ht_day(job):
    """Hoàn thiện MỘT dãy tủ (toạ độ theo dãy, góc xoay 0). Trả về (job mới, [ghi chú]).
    - Đầu hàng sát tường: FILLER mặt, chừa khe F (mặc định 30) để trừ hao đo sai; tấm cắt dư rộng 100, thợ scribe tại chỗ.
    - Đầu hàng hở (không tường): PANEL hông 16mm phủ hết hông tủ (tủ dưới/cao: từ sàn; tủ treo: bằng chiều cao tủ treo).
    - Tủ cao đứng cạnh tủ thấp / tủ treo: PANEL hông suốt chiều cao tủ cao (không để lộ thùng trắng).
    - Kicker chạy dài theo hàng tủ dưới. Bulkhead / nẹp trần: cắt dư 20mm để thợ chỉnh tại chỗ."""
    ph = dict(tuong_trai=False, tuong_phai=False, tran=0, filler=30, bc=False, led=False, splashback=""); ph.update(job.get("phong") or {})
    F = float(ph.get("filler") or 30); P = 16.0; ghi = []; Fg = float(ph.get("filler_goc") or 50)
    Fgt = float(ph["filler_goc_treo"]) if ph.get("filler_goc_treo") not in (None, "") else Fg     # filler góc tủ treo riêng (mặc định = tủ dưới)
    tu = [chuan_hoa(t) | {"id": t.get("id")} for t in job.get("tu", []) if not t.get("auto")]
    vls = Counter(vl_phu(t) for t in tu if t["loai"] in CO_CANH)
    VLP = vls.most_common(1)[0][0] if vls else "MAU16"; P = VAT_LIEU[VLP]["lz"]; _VLP[0] = VLP
    chinh = [t for t in tu if t["goc"] == 0]
    la_cao = lambda t: t["loai"] in TU_CAO
    duoi = sorted([t for t in chinh if t["loai"] in TU_DUOI + TU_CAO + ("thiet_bi",)], key=lambda t: t["x"])
    treo = sorted([t for t in chinh if t["loai"] in TU_TREO], key=lambda t: t["x"])
    tu_that = lambda ds: [t for t in ds if t["loai"] != "thiet_bi"]

    def doi(tu_x, dx):                     # dời mọi thứ từ toạ độ tu_x trở đi sang phải dx (giữ tủ treo thẳng hàng tủ dưới)
        for t in chinh:
            if t["x"] >= tu_x - 0.5: t["x"] += dx
    # 1) chừa chỗ bên trái
    dau = [ds[0] for ds in (duoi, treo) if ds]
    if dau:
        tx = [(t["x"], t["x"] + t["w"]) for t in duoi if la_cao(t)]
        sat_cao = lambda d: d["loai"] in TU_TREO and any(a - 1 <= d["x"] <= b + P + 2 for a, b in tx)      # tủ treo đầu hàng tựa vào tủ cao: không cần chừa
        def can1(d):
            if ph.get("_trai") == "goc":                                   # đầu trái là góc phòng: lùi ra khỏi mặt trước dãy tủ tường kia + filler góc
                lui = (ph.get("_lui_trai") or {}).get("treo" if d["loai"] in TU_TREO else "duoi", 0.0)
                return (lui + (Fgt if d["loai"] in TU_TREO else Fg)) if lui > 0 else F
            if sat_cao(d) or (tl_roi(d) and ph["tuong_trai"]): return 0
            return F if ph["tuong_trai"] else (P if d["loai"] != "thiet_bi" else 0)
        if ph.get("_trai") == "goc" and Fgt != Fg and duoi and treo:      # góc có filler tủ treo khác tủ dưới: dời riêng từng hàng
            for ds in (duoi, treo):
                c1 = can1(ds[0]) - ds[0]["x"]
                if c1 > 0.5:
                    for t in ds: t["x"] += c1
            can = 0.0
        else: can = max(can1(d) - d["x"] for d in dau)
        if can > 0.5: doi(-1e9, can); ghi.append(f"Dời cả hệ tủ sang phải {can:.0f} để có chỗ cho {'filler sát tường' if ph['tuong_trai'] else 'panel hông'} bên trái")
    # 2) panel giữa tủ cao và tủ thấp / thiết bị (chèn 16mm)
    for i in range(len(duoi) - 1):
        a, b = duoi[i], duoi[i + 1]
        if la_cao(a) != la_cao(b) and abs(a["x"] + a["w"] - b["x"]) < 1: doi(b["x"], P)
    them = []
    for i in range(len(duoi) - 1):
        a, b = duoi[i], duoi[i + 1]; gap = b["x"] - (a["x"] + a["w"])
        if la_cao(a) != la_cao(b) and P - 0.5 <= gap <= P + 0.5:
            c = a if la_cao(a) else b
            sau = max(c["d"] + 18, float(c.get("tl_panel") or 750)) if tl_roi(c) else c["d"] + 18       # bản vẽ Huân: panel tủ lạnh sâu 750
            them.append(_tam("Panel hông tủ lạnh" if tl_roi(c) else "Panel hông tủ cao", "hong", a["x"] + a["w"], c["y"], c["z"], P, c["chan"] + c["h"], sau, ghi="Che thùng trắng cạnh tủ cao"))
    # 3) hai đầu từng ĐOẠN tủ liền nhau: đầu ngoài cùng sát tường -> filler; mọi đầu hở khác -> panel hông
    cao_x = [(t["x"], t["x"] + t["w"]) for t in duoi if la_cao(t)]
    cham_cao = lambda x: any(abs(x - a) <= P + 2 or abs(x - b) <= P + 2 for a, b in cao_x)

    _tat = duoi + treo
    xmin = min([t["x"] for t in _tat] or [0.0]); xmax = max([t["x"] + t["w"] for t in _tat] or [0.0])

    def dau_hang(ds, la_treo):
        if not ds: return
        doan = [[ds[0]]]
        for t in ds[1:]:
            if t["x"] - (doan[-1][-1]["x"] + doan[-1][-1]["w"]) <= P + 1: doan[-1].append(t)
            else: doan.append([t])
        for k, dn in enumerate(doan):
            for ben, c in (("trai", dn[0]), ("phai", dn[-1])):
                if c["loai"] == "thiet_bi": continue
                if c["loai"] == "cong" and (c.get("cong_ben", "R") == ("L" if ben == "trai" else "R")): continue   # đầu cong không cần panel
                mep = c["x"] if ben == "trai" else c["x"] + c["w"]
                if la_treo and cham_cao(mep): continue                     # tủ treo chạm tủ cao: panel tủ cao đã che
                ngoai = (ben == "trai" and k == 0) or (ben == "phai" and k == len(doan) - 1)
                if ngoai and ph.get("_" + ben) == "goc":                   # đầu dãy nằm ở góc phòng (chữ L / U): filler góc tới mặt trước dãy tủ tường kia
                    lui = (ph.get("_lui_" + ben) or {}).get("treo" if la_treo else "duoi", 0.0)
                    lim = lui if ben == "trai" else (ph.get("_dai") or 0) - lui
                    ho = (c["x"] - lim) if ben == "trai" else (lim - mep)
                    hg = "tủ treo" if la_treo else "tủ dưới"
                    if ho < -0.5: ghi.append(f"Dãy {ph.get('_id', '')}: {hg} ở góc đang lấn vào dãy tủ tường kia {-ho:.0f}mm – kéo ra hoặc giảm bề rộng"); continue
                    if ho < 5: continue
                    if ho > 150: ghi.append(f"Dãy {ph.get('_id', '')}: {hg} còn hở {ho:.0f}mm tới góc – nới rộng tủ cuối hoặc thêm tủ cho kín (filler góc chỉ làm tới 150)"); continue
                    du = (40.0 if ph.get("bc") else 20.0) if (la_treo and c["loai"] in ("treo", "hut_mui") and c.get("mo") == "shadowline") else 0.0
                    yb = c["y"] + (0 if la_treo else c["chan"]) - du
                    them.append(_tam("Filler góc (tủ treo)" if la_treo else "Filler góc", "dung", lim if ben == "trai" else mep, yb, c["z"] + c["d"], ho, c["h"] + du, P, cat=[c["h"] + du, ho + 20.0],
                                     ghi=f"Filler ở góc chữ L, khe thiết kế {ho:.0f}, cắt dư 20 – thợ cắt lại tại chỗ"))
                    continue
                if ngoai and abs(mep - (xmin if ben == "trai" else xmax)) > 150: ngoai_tuong = False     # hàng này kết thúc xa tường (vd tủ treo ngắn hơn tủ dưới): đầu hở -> panel, không phải filler
                else: ngoai_tuong = ngoai
                if ngoai_tuong and ph["tuong_" + ben] and tl_roi(c): continue    # tủ lạnh rời sát tường: không filler
                if ngoai_tuong and ph["tuong_" + ben] and ben == "phai" and ph.get("_dai"):   # có số đo tường: filler đúng bằng khe còn lại
                    ho = ph["_dai"] - mep
                    if ho < -0.5: ghi.append(f"Dãy {ph.get('_id', '')}: tủ dài hơn tường {-ho:.0f}mm – giảm bề rộng tủ"); continue
                    if ho > 150: ghi.append(f"Dãy {ph.get('_id', '')}: còn hở {ho:.0f}mm tới tường phải – thêm tủ / nới tủ (filler chỉ làm tới 150)"); continue
                    if ho < 5: continue
                    du = (40.0 if ph.get("bc") else 20.0) if (la_treo and c["loai"] in ("treo", "hut_mui") and c.get("mo") == "shadowline") else 0.0
                    yb = c["y"] + (0 if la_treo else c["chan"]) - du
                    them.append(_tam("Filler sát tường (tủ treo)" if la_treo else "Filler sát tường", "dung", mep, yb, c["z"] + c["d"], ho, c["h"] + du, P, cat=[c["h"] + du, ho + 70.0],
                                     ghi=f"Khe thiết kế {ho:.0f} theo số đo tường, cắt dư 70 – thợ scribe tại chỗ"))
                    continue
                if c.get("vat") == ("L" if ben == "trai" else "R"): continue      # đầu vát 45°: không panel / filler phía đầu vát
                if ngoai_tuong and ph["tuong_" + ben]:
                    x = (c["x"] - F) if ben == "trai" else mep
                    du = (40.0 if ph.get("bc") else 20.0) if (la_treo and c["loai"] in ("treo", "hut_mui") and c.get("mo") == "shadowline") else 0.0
                    yb = c["y"] + (0 if la_treo else c["chan"]) - du
                    them.append(_tam("Filler sát tường (tủ treo)" if la_treo else "Filler sát tường", "dung", x, yb, c["z"] + c["d"], F, c["h"] + du, P, cat=[c["h"] + du, 100.0],
                                     ghi=f"Cắt dư rộng 100, khe thiết kế {F:.0f} – thợ scribe theo tường tại chỗ"))
                    continue
                if not ngoai:                                              # đầu hở ở giữa hàng: phải còn chỗ 16mm, và chưa có panel tủ cao ở đó
                    ke = doan[k - 1][-1] if ben == "trai" else doan[k + 1][0]
                    ho = (c["x"] - (ke["x"] + ke["w"])) if ben == "trai" else (ke["x"] - mep)
                    if ho < P - 0.5: continue
                x = (c["x"] - P) if ben == "trai" else mep
                y0p, y1p = (c["y"], c["y"] + c["h"]) if la_treo else (c["y"], c["y"] + c["chan"] + c["h"])
                if any(abs(m["x"] - x) < 1 and m["huong"] == "hong" and m["y"] <= y0p + 1 and m["y"] + m["h"] >= y1p - 1 for m in them): continue
                if la_treo:
                    du = (40.0 if ph.get("bc") else 20.0) if (c["loai"] in ("treo", "hut_mui", "treo_goc", "treo_mu") and c.get("mo") == "shadowline") else 0.0
                    them.append(_tam("Panel hông tủ treo", "hong", x, c["y"] - du, c["z"], P, c["h"] + du, (float(c.get("sau_nhanh") or 300) if (c["loai"] == "treo_goc" and ben == "phai") else c["d"]) + 18, ghi="Cao bằng cánh tủ treo" + (f" (cánh dư xuống {du:.0f})" if du else "")))
                else:
                    sau = (560.0 if (c["loai"] == "goc_l" and ben == "phai") else c["d"]) + 18      # tủ góc L: hông phải chỉ sâu 560 (nhánh dài)
                    them.append(_tam("Panel hông tủ cao" if la_cao(c) else "Panel hông", "hong", x, c["y"], c["z"], P, c["chan"] + c["h"], sau,
                                     ghi="Panel hông nhánh dọc tủ góc L – sâu hết chữ L" if c["loai"] == "goc_l" and ben == "trai" else ""))
    if ph.get("_phai") == "goc" and not ph.get("_dai"): ph["_dai"] = _dai_goc(duoi, treo, ph.get("_lui_phai") or {}, Fg, F, Fgt)
    dau_hang(duoi, False)
    dau_hang(treo, True)
    # 4) kicker chạy dài (đoạn tủ liền nhau có chân), mỗi tấm tối đa 2400
    seg = []
    for t in duoi:
        if t["loai"] == "thiet_bi":            # máy rửa bát / lò âm (≤ 700): kicker chạy luôn bên dưới; tủ lạnh thì ngắt
            if seg and t["w"] <= 700 and abs(seg[-1][1] - t["x"]) <= P + 1: seg[-1][1] = t["x"] + t["w"]
            continue
        if t["chan"] <= 0: continue
        if t["loai"] == "goc_l":                # kick theo HÌNH THÙNG chữ L: mặt nhánh dài (thẳng hàng tủ 560 kế bên) + mặt nhánh dọc (quay ra +x, chạy tới hông cuối)
            zb = t["z"] + 560 - 50; xg = t["x"] + 560 - 50
            them.append(_tam("Kickface góc L (nhánh dọc)", "hong", xg - P, 0, zb + P, P, t["chan"], t["z"] + t["d"] - zb - P, ghi="Kick chạy theo mặt nhánh dọc tủ góc L, tới hông cuối"))
            if seg and abs(seg[-1][1] - t["x"]) <= P + 1 and abs(seg[-1][3] - zb) < 1: seg[-1][1] = t["x"] + t["w"]
            else: seg.append([xg - P, t["x"] + t["w"], t["chan"], zb])
            continue
        if seg and abs(seg[-1][1] - t["x"]) <= P + 1 and abs(seg[-1][2] - t["chan"]) < 1 and abs(seg[-1][3] - (t["z"] + t["d"] - 50)) < 1: seg[-1][1] = t["x"] + t["w"]
        else: seg.append([t["x"], t["x"] + t["w"], t["chan"], t["z"] + t["d"] - 50])
    for x0, x1, ch, z in seg:
        n = max(1, -(-int(x1 - x0) // 2400)); L = (x1 - x0) / n
        for k in range(n): them.append(_tam("Kickface", "dung", x0 + k * L, 0, z, L, ch, P, ghi="Mặt chân tủ cùng màu cánh – cắt dư dài, cắt lại tại chỗ nếu cần"))
    # 4b) BC panel: tấm ván màu che đáy dàn tủ treo, soi rãnh LED (anh Tan 19/11). Có BC panel thì cánh tủ treo fingerpull dư 40 thay vì 20.
    if ph.get("bc"):
        sp = {"gach": "gạch", "da": "đá", "kinh": "kính"}.get(ph.get("splashback"), "")
        led = bool(ph.get("led"))
        if led and not sp: ghi.append("Có LED dưới tủ treo nhưng chưa chọn loại splashback (gạch / đá / kính) – cần biết để đặt rãnh LED cho đúng")
        note = "Che đáy trắng tủ treo" + (f" · SOI RÃNH LED (splashback {sp or 'CHƯA BIẾT'}) – vị trí rãnh hỏi anh Tan / Huân, chưa tự phay" if led else "")
        bc = []
        for t in treo:
            if t["loai"] == "ke_mo": continue
            if bc and abs(bc[-1][1] - t["x"]) <= 1 and abs(bc[-1][2] - t["y"]) < 1 and abs(bc[-1][3] - t["d"]) < 1: bc[-1][1] = t["x"] + t["w"]
            else: bc.append([t["x"], t["x"] + t["w"], t["y"], t["d"], t["z"]])
        for x0, x1, y, d, z in bc:
            n = max(1, -(-int(x1 - x0) // 2400)); L = (x1 - x0) / n
            for k in range(n): them.append(_tam("BC panel (đáy tủ treo)", "nam", x0 + k * L, y - P, z, L, P, d, ghi=note))
    # 5) bulkhead / nẹp trần
    tran = float(ph.get("tran") or 0)
    if tran > 0:
        nhom = []
        for t in sorted(treo + [t for t in duoi if la_cao(t) and not tl_roi(t)], key=lambda t: t["x"]):
            dinh = t["y"] + t["chan"] + t["h"]; zf = t["z"] + t["d"]
            if nhom and abs(nhom[-1][1] - t["x"]) <= P + 1 and abs(nhom[-1][2] - dinh) < 1 and abs(nhom[-1][3] - zf) < 1: nhom[-1][1] = t["x"] + t["w"]
            else: nhom.append([t["x"], t["x"] + t["w"], dinh, zf])
        for x0, x1, dinh, zf in nhom:
            ho = tran - dinh
            if ho < -0.5: ghi.append(f"Tủ tại x={x0:.0f} cao hơn trần {-ho:.0f}mm – giảm chiều cao tủ"); continue
            if ho < 5: continue
            if ho > 600: ghi.append(f"Khoảng hở tới trần {ho:.0f}mm tại x={x0:.0f}: quá lớn cho nẹp ván – bulkhead thạch cao do builder làm"); continue
            n = max(1, -(-int(x1 - x0) // 2400)); L = (x1 - x0) / n
            for k in range(n):
                them.append(_tam("Bulkhead / nẹp trần", "dung", x0 + k * L, dinh, zf, L, ho, P, cat=[L, ho + 20.0],
                                 ghi=f"Khe thiết kế {ho:.0f}, cắt dư 20 – thợ chỉnh theo trần tại chỗ"))
    # gộp lại: giữ đúng thứ tự tủ gốc, tấm tự động xếp cuối
    goc = {t.get("id"): t for t in tu}
    out = []
    for t in job.get("tu", []):
        if t.get("auto"): continue
        n = dict(t); c = goc.get(t.get("id"))
        if c: n["x"] = c["x"]
        out.append(n)
    # panel hông cao hơn tấm ván (vd tủ cao tới trần 2790 > tấm 2410): chia 2 tấm, mối nối ngang đúng mối tách thùng của tủ cao kế bên
    them2 = []
    for a in them:
        lx = VAT_LIEU.get(a.get("vl_thung") or "MAU16", VAT_LIEU["MAU16"])["lx"] - 10
        if a.get("huong") != "hong" or a["h"] <= lx: them2.append(a); continue
        kb = [c for c in tu if float(c.get("tach") or 0) > 0 and (c.get("day") or "A") == (a.get("day") or "A") and
              (abs(c["x"] - (a["x"] + a["w"])) < 2 or abs(c["x"] + c["w"] - a["x"]) < 2)]
        kl = [c for c in tu if tl_roi(c) and float(c.get("tl_hop") or 0) > 0 and (c.get("day") or "A") == (a.get("day") or "A") and
              (abs(c["x"] - (a["x"] + a["w"])) < 2 or abs(c["x"] + c["w"] - a["x"]) < 2)]
        y_noi = ((float(kb[0].get("chan") or 0) + float(kb[0]["tach"])) if kb else
                 (float(kl[0].get("chan") or 0) + kl[0]["h"] - float(kl[0]["tl_hop"])) if kl else min(lx, a["h"] - 300))
        y_noi = min(max(y_noi, a["h"] - lx), lx)
        for i, (y0, hh) in enumerate(((0.0, y_noi), (y_noi, a["h"] - y_noi))):
            b = dict(a, y=round(a["y"] + y0, 1), h=round(hh, 1), ten=a["ten"] + (" – dưới" if i == 0 else " – trên"),
                     ghi_chu=(a.get("ghi_chu") or "") + f" | Panel cao {a['h']:.0f} > tấm ván: chia 2, nối ở {y_noi:.0f} (ngang mối tách thùng) – muốn liền thì đặt tấm 3600")
            them2.append(b)
        ghi.append(f"{a['ten']} cao {a['h']:.0f} dài hơn tấm ván {lx + 10:.0f}: đã chia 2 tấm nối ở {y_noi:.0f} – muốn panel liền thì đặt tấm dài 3600")
    them = them2
    for k, t in enumerate(them): t["id"] = f"auto{k:02d}"
    j = dict(job); j["tu"] = out + them; j["phong"] = ph
    if ph["tuong_trai"] is False and ph["tuong_phai"] is False: ghi.append("Chưa đánh dấu tường nào: hai đầu hàng tủ đang được coi là đầu hở (có panel hông)")
    return j, ghi


# ---------------------------------------------------------------- MẶT BẰNG: nhiều dãy tủ (tường sau A, tường trái B, tường phải C, đảo / bar D) – anh Tan 20/11
TEN_DAY = {"A": "Tường sau", "B": "Tường trái", "C": "Tường phải", "D": "Đảo / bar"}
_HANG_DUOI = TU_DUOI + TU_CAO + ("thiet_bi",)


def _dai_goc(duoi, treo, lui, Fg, F, Fgt=None):
    """chiều dài tường tự tính cho dãy có GÓC ở đầu phải: tủ cuối + filler góc + phần lùi (mặt trước dãy tủ tường kia)"""
    v = []
    for ds, k in ((duoi, "duoi"), (treo, "treo")):
        if ds:
            l = float(lui.get(k) or 0); v.append(max(t["x"] + t["w"] for t in ds) + ((l + (Fgt if (k == "treo" and Fgt is not None) else Fg)) if l > 0 else F))
    return max(v) if v else 2400.0


def cac_day(ph, tu):
    co = {"A"} | {(t.get("day") or "A") for t in tu}
    k = ph.get("kieu") or "thang"
    if k in ("L_trai", "U"): co.add("B")
    if k in ("L_phai", "U"): co.add("C")
    if ph.get("dao"): co.add("D")
    them = [e.get("id") for e in (ph.get("day_them") or []) if isinstance(e, dict) and e.get("id")]   # tường vẽ tay thứ 4, 5… (Vẽ tường)
    return [d for d in "ABCD" if d in co] + [d for d in them if d not in "ABCD"]


def _lui(ds, ben):
    """mặt trước của dãy A ở đầu `ben` (để dãy B / C lùi ra): {'duoi': sâu + 18, 'treo': sâu + 18}; 0 = dãy A không có tủ ở hàng đó"""
    out = {}
    for k, nhom in (("duoi", _HANG_DUOI), ("treo", TU_TREO)):
        hs = sorted([t for t in ds if t["loai"] in nhom], key=lambda t: t["x"])
        c = (hs[0] if ben == "trai" else hs[-1]) if hs else None
        out[k] = (c["z"] + c["d"] + 18.0) if c else 0.0
    return out


def bo_tri(ph, tu):
    """vị trí từng dãy trong phòng: {id: dict(ox, oz, goc, dai, ten, lui_trai, lui_phai)}. tu = danh sách tủ (đã chuẩn hoá, không tính tấm tự động)."""
    F = float(ph.get("filler") or 30); Fg = float(ph.get("filler_goc") or 50); P = 16.0
    Fgt = float(ph["filler_goc_treo"]) if ph.get("filler_goc_treo") not in (None, "") else Fg
    that = [t for t in tu if not t.get("auto") and t["loai"] not in ("tam", "mat_da") and not (t.get("goc") or 0)]
    cua = lambda d: [t for t in that if (t.get("day") or "A") == d]
    hang = lambda ds: ([t for t in ds if t["loai"] in _HANG_DUOI], [t for t in ds if t["loai"] in TU_TREO])
    ids = cac_day(ph, tu); A = cua("A"); out = {}
    coB, coC = "B" in ids, "C" in ids
    mepA = max([t["x"] + t["w"] for t in A] or [0.0])
    dai_a = float(ph.get("dai_a") or 0) or ((mepA + (F if (coC or ph.get("tuong_phai")) else 0)) if A else 3000.0)
    out["A"] = dict(ox=0.0, oz=0.0, goc=0, dai=dai_a, trai="tuong" if (coB or ph.get("tuong_trai")) else "ho", phai="tuong" if (coC or ph.get("tuong_phai")) else "ho")
    if coB:
        lui = _lui(A, "trai"); d, tr = hang(cua("B"))
        dai = float(ph.get("dai_b") or 0) or _dai_goc(d, tr, lui, Fg, F, Fgt)
        out["B"] = dict(ox=0.0, oz=dai, goc=90, dai=dai, trai="tuong" if ph.get("b_tuong") else "ho", phai="goc", lui_phai=lui)
    if coC:
        lui = _lui(A, "phai"); d, tr = hang(cua("C"))
        dai = float(ph.get("dai_c") or 0) or max([t["x"] + t["w"] for t in d + tr] or [2400.0]) + (F if ph.get("c_tuong") else 0)
        out["C"] = dict(ox=dai_a, oz=0.0, goc=270, dai=dai, trai="goc", phai="tuong" if ph.get("c_tuong") else "ho", lui_trai=lui)
    if "D" in ids:
        D = cua("D"); dA = max([t["z"] + t["d"] for t in A if t["loai"] in _HANG_DUOI] or [560.0]) + 18.0
        Dd = max([t["z"] + t["d"] for t in D if t["loai"] in _HANG_DUOI] or [560.0]); L = max([t["x"] + t["w"] for t in D] or [1200.0]) + P
        ld = float(ph.get("loi_di") or 1100); dx = float(ph.get("dao_x") if ph.get("dao_x") not in (None, "") else 600)
        if (ph.get("dao_quay") or "tuong") == "tuong": out["D"] = dict(ox=dx + L, oz=dA + ld + Dd + 18.0, goc=180, dai=L, trai="ho", phai="ho")
        else: out["D"] = dict(ox=dx, oz=dA + ld + P, goc=0, dai=L, trai="ho", phai="ho")
    for e in (ph.get("day_them") or []):                                   # tường vẽ tay khác (không phải A / B / C): dãy tủ theo đúng mặt trong tường đó
        try:
            k = str(e["id"])
            if k in ids and k not in out: out[k] = dict(ox=float(e["ox"]), oz=float(e["oz"]), goc=int(e["goc"]) % 360, dai=float(e["dai"]), trai="ho", phai="ho")
        except (KeyError, TypeError, ValueError): pass
    for k, v in out.items(): v["id"] = k; v["ten"] = TEN_DAY.get(k, f"Tường {k}")
    return out


def dung_ca_job(job):
    """job nhiều phòng (job["rooms"] = [{ten, tu, phong}]): dựng từng phòng rồi gộp chi tiết để xuất CNC / xếp tấm.
    Số tủ thành "<phòng>-<số>" (vd 2-5 = phòng 2, tủ #5) cho nhãn và danh sách."""
    rooms = [r for r in (job.get("rooms") or []) if r.get("tu")]
    if len(job.get("rooms") or []) < 2: return dung_job(job)
    tong = dict(tu=[], chi_tiet=[], phu_kien=Counter(), canh_bao=[], nep=Counter(), day=[], splash=[])
    for ri, r in enumerate(job.get("rooms") or [], 1):
        if not r.get("tu"): continue
        kq = dung_job(dict(job, tu=r["tu"], phong=r.get("phong") or {}))
        ten = r.get("ten") or f"Phòng {ri}"
        for p in kq["chi_tiet"]: p["cab"] = f"{ri}-{p['cab']}"; p["phong"] = ten
        tong["chi_tiet"] += kq["chi_tiet"]; tong["tu"] += kq["tu"]; tong["phu_kien"].update(kq["phu_kien"])
        tong["canh_bao"] += [f"{ten}: {c}" for c in kq["canh_bao"]]; tong["nep"].update(kq["nep"])
    tong["phu_kien"] = dict(tong["phu_kien"]); tong["nep"] = {k: round(v, 1) for k, v in tong["nep"].items()}
    return tong


def the_gioi(d, lx, lz):
    g = int(d.get("goc") or 0) % 360
    if g == 90: return d["ox"] + lz, d["oz"] - lx
    if g == 180: return d["ox"] - lx, d["oz"] - lz
    if g == 270: return d["ox"] - lz, d["oz"] + lx
    return d["ox"] + lx, d["oz"] + lz



def _dau_da(out, them, dA, ghi):
    """mặt đá: phủ filler sát tường / panel hông dưới ở 2 đầu; ghi đầu nào sát tường / sát tủ cao / nối góc / lộ (da_trai, da_phai) cho trang thợ đá"""
    for n in out:                                                       # đầu mặt đá: phủ filler sát tường / panel hông dưới, ghi đầu nào sát tường / lộ
        if n.get("loai") != "mat_da": continue
        d = n.get("day") or "A"; x0 = float(n["x"]); x1 = x0 + float(n["w"]); dau = {}
        for t in them:
            if (t.get("day") or "A") != d or float(t.get("y") or 0) > 400: continue
            ten = str(t.get("ten") or ""); tx0, tx1 = float(t["x"]), float(t["x"]) + float(t["w"])
            if "tủ cao" in ten:                                               # panel hông tủ cao chạy suốt: mặt đá chỉ chạm, không phủ
                if abs(tx1 - x0) < 1: dau["trai"] = "sát tủ cao"
                elif abs(tx0 - x1) < 1: dau["phai"] = "sát tủ cao"
                continue
            loai_ = "sát tường" if ten.startswith("Filler sát tường") else "lộ – phủ panel hông, mài" if ten.startswith("Panel hông") and "treo" not in ten else ""
            if not loai_: continue
            if abs(tx1 - x0) < 1 or abs(tx0 - x0) < 1: dau["trai"] = loai_; x0 = min(x0, tx0)
            elif abs(tx0 - x1) < 1 or abs(tx1 - x1) < 1: dau["phai"] = loai_; x1 = max(x1, tx1)
        if (x0, x1) != (float(n["x"]), float(n["x"]) + float(n["w"])):
            ghi.append(f"Dãy {d}: mặt đá phủ filler / panel hông tới đầu dãy – dài {float(n['w']):.0f} → {x1 - x0:.0f}"); n["x"] = round(x0, 1); n["w"] = round(x1 - x0, 1)
        for t in out:                                                   # sát tủ cao cùng dãy
            if t is n or (t.get("day") or "A") != d or t.get("loai") not in TU_CAO: continue
            if abs(float(t["x"]) + float(t["w"]) - x0) < 2: dau.setdefault("trai", "sát tủ cao")
            if abs(float(t["x"]) - x1) < 2: dau.setdefault("phai", "sát tủ cao")
        if d in ("B", "C") and dA and abs(x0 - dA) < 1: dau["trai"] = "nối mặt đá dãy A ở góc"
        n["da_trai"] = dau.get("trai", "lộ – mài"); n["da_phai"] = dau.get("phai", "lộ – mài")

def hoan_thien(job):
    """Hoàn thiện cả phòng: từng dãy tủ (A tường sau, B tường trái, C tường phải, D đảo) được hoàn thiện theo toạ độ riêng của dãy.
    Góc chữ L / U: dãy A chạy hết vào góc; dãy B / C lùi ra khỏi mặt trước dãy A và có FILLER GÓC. Đảo: panel 2 đầu + PANEL LƯNG."""
    ph = dict(tuong_trai=False, tuong_phai=False, tran=0, filler=30, bc=False, led=False, splashback=""); ph.update(job.get("phong") or {})
    ph = {k: v for k, v in ph.items() if not k.startswith("_")}
    if any(not t.get("id") for t in job.get("tu", [])):         # tủ thiếu id (AI / file cũ): gán id tạm, không thì mọi tủ nhận chung toạ độ x của tủ cuối
        job = dict(job, tu=[t if t.get("id") else dict(t, id=f"_t{i}") for i, t in enumerate(job.get("tu", []))])
    try: bh = float(ph.get("treo_tran") or 0); tran = float(ph.get("tran") or 0)
    except (TypeError, ValueError): bh = tran = 0
    if bh > 0 and tran > 0:
        # TỦ TREO CAO TỚI TRẦN (bản vẽ Eastwood của Huân: trần 2780 → tủ treo 1040 + bulkhead 120): đỉnh tủ treo = trần − bulkhead
        job = dict(job, tu=[dict(t) for t in job.get("tu", [])]); doi = 0
        for t in job["tu"]:
            if t.get("auto") or float(t.get("y") or 0) <= 0: continue
            if t.get("loai") == "hut_mui": t["y"] = round(tran - bh - float(t["h"]), 1); doi += 1
            elif t.get("loai") in TU_TREO:
                h = round(tran - bh - float(t["y"]), 1)
                if 300 <= h <= 1400: t["h"] = h; doi += 1
    raw = [t for t in job.get("tu", []) if not t.get("auto")]
    ids = cac_day(ph, raw)
    if ids == ["A"] and not ph.get("dai_a"):
        j, ghi = _ht_day(dict(job, phong=ph)); j["phong"] = {k: v for k, v in j["phong"].items() if not k.startswith("_")}
        _dau_da([t for t in j["tu"] if not t.get("auto")], [dict(t, day=t.get("day") or "A") for t in j["tu"] if t.get("auto")], 0, ghi)
        return j, ghi
    kq = {}; ghi = []; them = []

    def chay(d, **extra):
        sub = [t for t in raw if (t.get("day") or "A") == d]
        j, g = _ht_day(dict(job, tu=sub, phong=dict(ph, _id=d, **extra)))
        kq[d] = {t.get("id"): t for t in j["tu"] if not t.get("auto")}
        for t in j["tu"]:
            if t.get("auto"): t["day"] = d; them.append(t)
        ghi.extend((g0 if g0.startswith("Dãy") else f"Dãy {d} ({TEN_DAY.get(d, 'tường ' + d)}): {g0}") for g0 in g if not g0.startswith("Chưa đánh dấu tường"))
        return [chuan_hoa(t) | {"id": t.get("id")} for t in j["tu"] if not t.get("auto")], j["phong"]

    coB, coC = "B" in ids, "C" in ids
    A, _ = chay("A", tuong_trai=bool(ph.get("tuong_trai") or coB), tuong_phai=bool(ph.get("tuong_phai") or coC), _dai=float(ph.get("dai_a") or 0))
    if coB: chay("B", tuong_trai=bool(ph.get("b_tuong")), tuong_phai=False, _phai="goc", _lui_phai=_lui(A, "trai"), _dai=float(ph.get("dai_b") or 0))
    if coC: chay("C", tuong_trai=False, tuong_phai=bool(ph.get("c_tuong")), _trai="goc", _lui_trai=_lui(A, "phai"), _dai=float(ph.get("dai_c") or 0))
    for d_ in ids:
        if d_ not in "ABCD": chay(d_, tuong_trai=False, tuong_phai=False, _dai=float(next((e.get("dai") for e in (ph.get("day_them") or []) if e.get("id") == d_), 0) or 0))
    if "D" in ids:
        D, _ = chay("D", tuong_trai=False, tuong_phai=False)
        duoi = [t for t in D if t["loai"] in TU_DUOI + ("thiet_bi",) and not t["goc"]]
        if duoi:                                                              # lưng đảo lộ ra phòng: panel ván màu suốt chiều dài, cao từ sàn tới mặt trên thùng
            P = VAT_LIEU[_VLP[0]]["lz"]; x0 = min(t["x"] for t in duoi) - P; x1 = max(t["x"] + t["w"] for t in duoi) + P
            hh = max(t["chan"] + t["h"] for t in duoi); z0 = min(t["z"] for t in duoi)
            n = max(1, -(-int(x1 - x0) // 2400)); L = (x1 - x0) / n
            for k in range(n):
                t = _tam("Panel lưng đảo", "dung", x0 + k * L, 0, z0 - P, L, hh, P, ghi="Lưng đảo / bar lộ ra phòng – ván màu, vân dọc"); t["day"] = "D"; them.append(t)
    out = []
    dA = max([float(t.get("d") or 0) for t in raw if (t.get("day") or "A") == "A" and t.get("loai") == "mat_da"] or [0.0])
    for t in job.get("tu", []):
        if t.get("auto"): continue
        n = dict(t); c = kq.get(t.get("day") or "A", {}).get(t.get("id"))
        if c: n["x"] = c["x"]
        if dA and n.get("loai") == "mat_da" and n.get("day") in ("B", "C"):      # mặt đá dãy góc: kéo tới chạm mép trước mặt đá dãy A (không để hở ở góc)
            hx = float(n["x"]) - dA
            if 0 < hx < 120:
                n["x"] = dA; n["w"] = round(float(n["w"]) + hx, 1)
                ghi.append(f"Dãy {n['day']}: mặt đá kéo dài {hx:.0f} vào góc cho chạm mặt đá dãy A – mối nối đá ở góc (thợ đá chọn vị trí nối)")
        out.append(n)
    _dau_da(out, them, dA, ghi)
    for k, t in enumerate(them): t["id"] = f"auto{k:02d}"
    j = dict(job); j["tu"] = out + them; j["phong"] = ph
    return j, ghi
