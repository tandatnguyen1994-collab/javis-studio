"""Javis Studio – bản quyền (mã kích hoạt có hạn) + tự cập nhật từ GitHub của anh Tan.

Mã kích hoạt = base64url(json) + "." + base64url(chữ ký Ed25519). Chỉ máy anh Tan (giữ khoá bí mật) tạo được mã.
Mỗi lần mở máy + mỗi 6 tiếng: đọc manifest.json trên GitHub -> có bản mới thì tự tải, có tên trong danh sách thu hồi thì khoá.
Không kết nối được quá 24 giờ thì khoá tới khi có mạng (anh Tan dặn: offline tối đa 1 ngày).
"""
import base64, hashlib, json, os, sys, time, zipfile, io, shutil, threading, urllib.request
from pathlib import Path

GOC = Path(__file__).resolve().parent
DATA = GOC / "du-lieu"
FILE_KH = DATA / "kich-hoat.json"
NGUON = os.environ.get("JAVIS_NGUON") or "https://raw.githubusercontent.com/tandatnguyen1994-collab/javis-studio/main/"
OFFLINE_TOI_DA = 24 * 3600
KHOA_CONG = bytes.fromhex("4e50a3aea0c905829b46d584edda60514fee141a0cfa65c06369b598510d3bb4")      # khoá công khai Ed25519 (32 byte)

# ---------------------------------------------------------------- Ed25519 kiểm chữ ký (thuần Python, theo RFC 8032)
_p = 2 ** 255 - 19
_L = 2 ** 252 + 27742317777372353535851937790883648493
_d = -121665 * pow(121666, _p - 2, _p) % _p
_I = pow(2, (_p - 1) // 4, _p)


def _xrec(y, s):
    x2 = (y * y - 1) * pow(_d * y * y + 1, _p - 2, _p)
    if x2 == 0:
        if s: return None
        return 0
    x = pow(x2, (_p + 3) // 8, _p)
    if (x * x - x2) % _p: x = x * _I % _p
    if (x * x - x2) % _p: return None
    if (x & 1) != s: x = _p - x
    return x


def _add(P, Q):
    A = (P[1] - P[0]) * (Q[1] - Q[0]) % _p; B = (P[1] + P[0]) * (Q[1] + Q[0]) % _p
    C = 2 * P[3] * Q[3] * _d % _p; D = 2 * P[2] * Q[2] % _p
    E, F, G, H = B - A, D - C, D + C, B + A
    return (E * F % _p, G * H % _p, F * G % _p, E * H % _p)


def _mul(s, P):
    Q = (0, 1, 1, 0)
    while s:
        if s & 1: Q = _add(Q, P)
        P = _add(P, P); s >>= 1
    return Q


def _eq(P, Q):
    return (P[0] * Q[2] - Q[0] * P[2]) % _p == 0 and (P[1] * Q[2] - Q[1] * P[2]) % _p == 0


def _dec(b):
    y = int.from_bytes(b, "little"); s = y >> 255; y &= (1 << 255) - 1
    if y >= _p: return None
    x = _xrec(y, s)
    return None if x is None else (x, y, 1, x * y % _p)


_gy = 4 * pow(5, _p - 2, _p) % _p
_G = (_xrec(_gy, 0), _gy, 1, _xrec(_gy, 0) * _gy % _p)


def kiem_chu_ky(pub, msg, sig):
    if len(pub) != 32 or len(sig) != 64: return False
    A = _dec(pub); R = _dec(sig[:32])
    if A is None or R is None: return False
    s = int.from_bytes(sig[32:], "little")
    if s >= _L: return False
    h = int.from_bytes(hashlib.sha512(sig[:32] + pub + msg).digest(), "little") % _L
    return _eq(_mul(s, _G), _add(R, _mul(h, A)))


# ---------------------------------------------------------------- mã kích hoạt
def _b64d(s):
    s = s.strip(); return base64.urlsafe_b64decode(s + "=" * (-len(s) % 4))


def doc_ma(ma):
    """-> dict thông tin mã (ten, id, het_han 'YYYY-MM-DD'), hoặc raise ValueError"""
    ma = "".join(str(ma or "").split())
    if ma.count(".") != 1: raise ValueError("Mã kích hoạt không đúng dạng.")
    a, b = ma.split(".")
    try: body, sig = _b64d(a), _b64d(b)
    except Exception: raise ValueError("Mã kích hoạt không đúng dạng.")
    if not kiem_chu_ky(KHOA_CONG, body, sig): raise ValueError("Mã kích hoạt không hợp lệ.")
    tt = json.loads(body.decode("utf-8"))
    if tt.get("sp") != "javis-studio": raise ValueError("Mã này không dùng cho Javis Studio.")
    return tt


def ma_may():
    v = ""
    if sys.platform.startswith("win"):
        try:
            import winreg
            k = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Cryptography", 0, winreg.KEY_READ | getattr(winreg, "KEY_WOW64_64KEY", 0))
            v = winreg.QueryValueEx(k, "MachineGuid")[0]
        except Exception: pass
    if not v:      # không đọc được MachineGuid: dùng mã ngẫu nhiên lưu ngoài thư mục phần mềm
        f = Path.home() / ".javis-may"
        try: v = f.read_text().strip()
        except Exception: v = ""
        if not v:
            import secrets; v = secrets.token_hex(16)
            try: f.write_text(v)
            except Exception: pass
    return hashlib.sha256(("javis|" + v).encode()).hexdigest()[:16]


def _doc():
    try: return json.loads(FILE_KH.read_text(encoding="utf-8"))
    except Exception: return {}


def _ghi(d):
    DATA.mkdir(parents=True, exist_ok=True)
    t = str(FILE_KH) + ".tmp"; Path(t).write_text(json.dumps(d, ensure_ascii=False, indent=1), encoding="utf-8"); os.replace(t, FILE_KH)


def kich_hoat(ma):
    tt = doc_ma(ma)
    if time.strftime("%Y-%m-%d") > tt["het_han"]: raise ValueError(f"Mã này đã hết hạn ngày {tt['het_han']}.")
    if tt.get("may") and tt["may"] != ma_may(): raise ValueError("Mã này cấp cho máy khác.")
    d = _doc(); d.update(ma="".join(str(ma).split()), may=ma_may(), luc=int(time.time()))
    d.setdefault("mang_ok", int(time.time()))
    _ghi(d); kiem_mang(cho=True)
    return trang_thai()


def trang_thai():
    """-> dict(ok, ly_do, ten, het_han, con_ngay)"""
    d = _doc()
    if not d.get("ma"): return dict(ok=False, ly_do="Chưa kích hoạt. Nhập mã kích hoạt anh Tan gửi.")
    try: tt = doc_ma(d["ma"])
    except ValueError as e: return dict(ok=False, ly_do=str(e))
    nay = time.strftime("%Y-%m-%d")
    base = dict(ten=tt.get("ten", ""), het_han=tt["het_han"], id=tt.get("id", ""))
    if nay > tt["het_han"]: return dict(base, ok=False, ly_do=f"Mã đã hết hạn ngày {tt['het_han']}. Liên hệ anh Tan để gia hạn.")
    if d.get("may") != ma_may() or (tt.get("may") and tt["may"] != ma_may()):
        return dict(base, ok=False, ly_do="Phần mềm đã chép sang máy khác – nhập lại mã kích hoạt.")
    if tt.get("id") in (d.get("thu_hoi") or []): return dict(base, ok=False, ly_do="Quyền dùng đã bị thu hồi. Liên hệ anh Tan.")
    if time.time() - d.get("mang_ok", 0) > OFFLINE_TOI_DA:
        return dict(base, ok=False, ly_do="Máy chưa kết nối mạng quá 1 ngày – bật mạng rồi bấm Thử lại.")
    import datetime
    con = (datetime.date.fromisoformat(tt["het_han"]) - datetime.date.today()).days
    return dict(base, ok=True, ly_do="", con_ngay=con)


# ---------------------------------------------------------------- manifest + cập nhật
TT = {"moi": None, "dang": False, "loi": ""}


def _tai(url, to=20):
    rq = urllib.request.Request(url + ("&" if "?" in url else "?") + "t=" + str(int(time.time())), headers={"User-Agent": "JavisStudio", "Cache-Control": "no-cache"})
    return urllib.request.urlopen(rq, timeout=to).read()


def kiem_mang(cho=False):
    """đọc manifest; cập nhật danh sách thu hồi + giờ có mạng; trả manifest hoặc None"""
    def chay():
        try:
            m = json.loads(_tai(NGUON + "manifest.json", 10).decode("utf-8"))
            d = _doc(); d["mang_ok"] = int(time.time()); d["thu_hoi"] = list(m.get("thu_hoi") or []); _ghi(d)
            TT["moi"] = m; TT["loi"] = ""
        except Exception as e:
            TT["loi"] = f"{type(e).__name__}"
    if cho: chay(); return TT["moi"]
    threading.Thread(target=chay, daemon=True).start()


def _so(v):
    return tuple(int(x) if x.isdigit() else 0 for x in str(v).split("."))


def co_ban_moi(phien_ban):
    m = TT["moi"]
    return bool(m and _so(m.get("phien_ban", "0")) > _so(phien_ban))


def cap_nhat(phien_ban):
    """tải gói mới, kiểm sha256, chép đè (giữ du-lieu). -> (True, phiên bản mới) | (False, lý do)"""
    m = kiem_mang(cho=True)
    if not m: return False, "Không kết nối được máy chủ cập nhật."
    if not co_ban_moi(phien_ban): return False, f"Đang là bản mới nhất ({phien_ban})."
    goi = _tai(NGUON + m["goi"], 120)
    if hashlib.sha256(goi).hexdigest() != m.get("sha256"): return False, "Gói tải về bị lỗi (sai mã kiểm) – thử lại sau."
    z = zipfile.ZipFile(io.BytesIO(goi))
    for n in z.namelist():
        if n.startswith("/") or ".." in Path(n).parts: return False, "Gói cập nhật không hợp lệ."
    tam = GOC.parent / (GOC.name + "-moi")
    shutil.rmtree(tam, ignore_errors=True); z.extractall(tam)
    for f in tam.rglob("*"):
        if f.is_dir(): continue
        rel = f.relative_to(tam)
        if rel.parts[0] == "du-lieu": continue
        dst = GOC / rel; dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(f, dst)
    shutil.rmtree(tam, ignore_errors=True)
    return True, m["phien_ban"]


def khoi_dong_lai():
    exe = sys.executable
    if sys.platform.startswith("win") and exe.lower().endswith("python.exe") and os.path.isfile(exe[:-10] + "pythonw.exe"): exe = exe[:-10] + "pythonw.exe"
    import subprocess
    subprocess.Popen([exe, str(GOC / ("khoi-dong.pyw" if (GOC / "khoi-dong.pyw").is_file() else "vetu.py"))], cwd=str(GOC), creationflags=getattr(subprocess, "DETACHED_PROCESS", 0) | getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0))
    threading.Timer(0.5, lambda: os._exit(0)).start()
