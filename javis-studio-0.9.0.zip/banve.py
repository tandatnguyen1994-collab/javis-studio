"""Javis Studio – bản vẽ 2D (shop drawing) ra PDF A3: mặt bằng + mặt đứng từng hướng tủ, có số tủ, kích thước, bảng tủ.
Dùng dữ liệu khối (khoi) của dung_job nên vẽ đúng cái đã dựng 3D: cánh, mặt hộc, panel, thiết bị."""
import math, datetime
from engine import dung_job, THU_VIEN, TU_TREO
from xuat import _font

A3 = (1190.55, 841.89)
INK = (0.12, 0.12, 0.14); GREY = (0.45, 0.45, 0.48); LITE = (0.80, 0.80, 0.82)
MAU = {"mat": (0.72, 0.56, 0.40), "thung": (0.95, 0.94, 0.91), "da": (0.84, 0.83, 0.80), "tay": (0.15, 0.15, 0.15), "kl": (0.60, 0.62, 0.65), "chan": (0.25, 0.25, 0.27)}
HUONG = {0: "Mặt đứng A – hàng tủ nhìn từ trước (góc 0)", 90: "Mặt đứng B – tủ xoay 90", 180: "Mặt đứng C – tủ xoay 180 (đảo / nhìn từ phía sau)", 270: "Mặt đứng D – tủ xoay 270"}


def _xoay(t, x, z):
    """điểm (x, z) toạ độ tủ -> toạ độ phòng (tủ đặt tại t.x,t.z xoay t.goc quanh gốc tủ, như three.js rotation.y)"""
    a = math.radians(t["goc"]); c, s = math.cos(a), math.sin(a)
    return t["x"] + x * c + z * s, t["z"] - x * s + z * c


class _Ve:
    def __init__(self, c, F, FB): self.c, self.F, self.FB = c, F, FB

    def khung(self, job, tieu_de, trang, tong):
        c, W, H = self.c, A3[0], A3[1]
        c.setStrokeColorRGB(*INK); c.setLineWidth(1); c.rect(24, 24, W - 48, H - 48); c.line(24, 76, W - 24, 76)
        c.setFillColorRGB(*INK); c.setFont(self.FB, 16); c.drawString(38, 50, "TPW GROUP"); c.setFont(self.F, 8); c.drawString(38, 37, "Javis Studio – bản vẽ tủ")
        c.setFont(self.FB, 12); c.drawString(230, 54, tieu_de); c.setFont(self.F, 9)
        c.drawString(230, 38, f"Job {job.get('so', '')} – {job.get('ten', '')}   ·   {datetime.date.today().strftime('%d/%m/%Y')}   ·   kích thước mm, tủ đánh số như trong Studio")
        c.setFont(self.FB, 13); c.drawRightString(W - 38, 44, f"{trang}/{tong}")

    def kich(self, x1, y1, x2, y2, txt, off=0, size=7):
        c = self.c; c.setStrokeColorRGB(*GREY); c.setLineWidth(0.5); c.line(x1, y1, x2, y2); hz = abs(y2 - y1) < 0.1
        for x, y in ((x1, y1), (x2, y2)):
            c.line(x - (0 if hz else 3), y - (3 if hz else 0), x + (0 if hz else 3), y + (3 if hz else 0))
        c.setFillColorRGB(*INK); c.setFont(self.F, size)
        if hz: c.drawCentredString((x1 + x2) / 2, y1 + 2.5 + off, txt)
        else:
            c.saveState(); c.translate(x1 - 3 - off, (y1 + y2) / 2); c.rotate(90); c.drawCentredString(0, 0, txt); c.restoreState()

    def hop(self, x, y, w, h, mau, vien=None, lw=0.5):
        c = self.c; c.setFillColorRGB(*mau); c.setStrokeColorRGB(*(vien or (1, 1, 1))); c.setLineWidth(lw); c.rect(x, y, w, h, stroke=1, fill=1)


def _mat_bang(v, job, kq, vung):
    """mặt bằng: vẽ từng tủ theo khối nhìn từ trên (x,z), số tủ, kích thước hàng góc 0 và góc 180"""
    c = v.c; tu = kq["tu"]
    if not tu: return
    pts = []
    for t in tu:
        for k in t["khoi"]:
            bx, by, bz, sx, sy, sz = k["b"]
            for x, z in ((bx, bz), (bx + sx, bz), (bx, bz + sz), (bx + sx, bz + sz)): pts.append(_xoay(t, x, z))
    x0 = min(p[0] for p in pts) - 150; x1 = max(p[0] for p in pts) + 150; z0 = min(p[1] for p in pts) - 150; z1 = max(p[1] for p in pts) + 150
    X, Y, W, H = vung; s = min(W / (x1 - x0), H / (z1 - z0))
    P = lambda x, z: (X + (x - x0) * s, Y + H - (z - z0) * s)       # z tăng = về phía trước = xuống dưới trang
    for t in sorted(tu, key=lambda t: -(t["y"] + t["h"])):               # tủ cao vẽ trước, tủ thấp đè lên
        for k in t["khoi"]:
            if k["k"] in ("tay", "khung") or k["r"] == "chan": continue
            bx, by, bz, sx, sy, sz = k["b"]
            q = [P(*_xoay(t, x, z)) for x, z in ((bx, bz), (bx + sx, bz), (bx + sx, bz + sz), (bx, bz + sz))]
            p = c.beginPath(); p.moveTo(*q[0])
            for a in q[1:]: p.lineTo(*a)
            p.close(); c.setFillColorRGB(*MAU.get(k["r"], LITE)); c.setStrokeColorRGB(0.55, 0.55, 0.58); c.setLineWidth(0.3); c.drawPath(p, stroke=1, fill=1)
        cx, cz = _xoay(t, t["w"] / 2, t["d"] / 2); px, py = P(cx, cz)
        if t["loai"] in ("tam",) and t["w"] < 60 and t["h"] < 60: continue
        if t["loai"] in ("tam", "mat_da"): continue
        c.setFillColorRGB(1, 1, 1); c.circle(px, py, 6.5, stroke=0, fill=1); c.setFillColorRGB(*INK); c.setFont(v.FB, 6.5); c.drawCentredString(px, py - 2.3, str(t["so"]))
    for goc, dy in ((0, 1), (180, -1)):
        hang = sorted([t for t in tu if t["goc"] == goc and t["loai"] not in ("tam", "mat_da") and t["loai"] not in TU_TREO], key=lambda t: t["x"])
        if not hang: continue
        zf = max((_xoay(t, 0, t["d"])[1] for t in hang)) if goc == 0 else min((_xoay(t, 0, t["d"])[1] for t in hang))
        yy = P(0, zf)[1] - 14 if goc == 0 else P(0, zf)[1] + 14
        xs = sorted({round(_xoay(t, 0, 0)[0], 1) for t in hang} | {round(_xoay(t, t["w"], 0)[0], 1) for t in hang})
        for a, b in zip(xs, xs[1:]):
            if b - a >= 60: v.kich(P(a, 0)[0], yy, P(b, 0)[0], yy, f"{b - a:.0f}", size=6)
        v.kich(P(xs[0], 0)[0], yy - 16 * dy, P(xs[-1], 0)[0], yy - 16 * dy, f"{xs[-1] - xs[0]:.0f}")
    c.setFillColorRGB(*GREY); c.setFont(v.F, 7); c.drawString(X, Y - 10, f"Tỷ lệ 1:{(1 / s) / (25.4 / 72):.0f}")


def _mat_dung(v, kq, goc, vung):
    """mặt đứng của các tủ cùng góc xoay: trục ngang = X cục bộ của tủ (chiếu lên hướng nhìn), trục dọc = cao"""
    c = v.c; tu = [t for t in kq["tu"] if t["goc"] == goc]
    if not tu: return False
    # toạ độ ngang trên mặt đứng: với góc 0 = x phòng; 90 = -z phòng; 180 = -x; 270 = z  (nhìn từ trước tủ)
    def hx(t, x):
        X, Z = _xoay(t, x, 0)
        return {0: X, 90: -Z, 180: -X, 270: Z}[goc]
    xa = min(min(hx(t, 0), hx(t, t["w"])) for t in tu) - 100; xb = max(max(hx(t, 0), hx(t, t["w"])) for t in tu) + 100
    ya = 0; yb = max(t["y"] + t["h"] for t in tu) + 150
    X, Y, W, H = vung; s = min(W / (xb - xa), H / (yb - ya))
    P = lambda x, y: (X + (x - xa) * s, Y + (y - ya) * s)
    c.setStrokeColorRGB(*GREY); c.setLineWidth(0.6); c.line(X - 20, P(0, 0)[1], X + (xb - xa) * s + 20, P(0, 0)[1])
    # thứ tự: thùng -> mặt -> đá -> tay
    thu = {"thung": 0, "kl": 1, "mat": 2, "da": 3, "chan": 0, "tay": 4}
    for t in sorted(tu, key=lambda t: t["z"]):
        kh = sorted(t["khoi"], key=lambda k: (thu.get(k["r"], 1), k["b"][2] + k["b"][5]))
        for k in kh:
            bx, by, bz, sx, sy, sz = k["b"]
            if k["k"] == "khung": continue
            if k["r"] == "thung" and k["k"] in ("hau", "ke", "hoc"): continue
            if sx <= 0 or sy <= 0: continue
            x1, x2 = sorted((hx(t, bx), hx(t, bx + sx))); yy = t["y"] + by
            px, py = P(x1, yy); w, h = (x2 - x1) * s, sy * s
            if k["r"] == "tay": v.hop(px, py, max(w, 1.5), max(h, 1.5), MAU["tay"], MAU["tay"])
            elif k["k"] == "thiet_bi": v.hop(px, py, w, h, (0.2, 0.2, 0.22), (0.4, 0.4, 0.4))
            else: v.hop(px, py, w, h, MAU.get(k["r"], LITE), (1, 1, 1) if k["r"] == "mat" else (0.6, 0.6, 0.62), 0.6 if k["r"] == "mat" else 0.3)
        if t["loai"] in ("tam", "mat_da"): continue
        cx = (hx(t, 0) + hx(t, t["w"])) / 2; px, py = P(cx, t["y"] + t["h"] + (120 if t["loai"] not in TU_TREO and t["h"] < 1200 else 40))
        c.setFillColorRGB(1, 1, 1); c.circle(px, py, 6.5, stroke=0, fill=1); c.setFillColorRGB(*INK); c.setFont(v.FB, 6.5); c.drawCentredString(px, py - 2.3, str(t["so"]))
    # kích thước ngang: hàng dưới + cao, hàng treo
    for la_treo, dy in ((False, -12), (True, -28)):
        hang = [t for t in tu if (t["loai"] in TU_TREO) == la_treo and t["loai"] not in ("tam", "mat_da")]
        if not hang: continue
        xs = sorted({round(hx(t, 0), 1) for t in hang} | {round(hx(t, t["w"]), 1) for t in hang})
        yy = P(0, 0)[1] + dy
        for a, b in zip(xs, xs[1:]):
            if b - a >= 60: v.kich(P(a, 0)[0], yy, P(b, 0)[0], yy, f"{b - a:.0f}", size=6)
        if not la_treo: v.kich(P(xs[0], 0)[0], yy - 32, P(xs[-1], 0)[0], yy - 32, f"{xs[-1] - xs[0]:.0f}")
    ys = sorted({0.0} | {round(t["y"], 1) for t in tu if t["loai"] != "tam"} | {round(t["y"] + t["h"], 1) for t in tu if t["loai"] != "tam"})
    xx = X - 14
    for a, b in zip(ys, ys[1:]):
        if b - a >= 40: v.kich(xx, P(0, a)[1], xx, P(0, b)[1], f"{b - a:.0f}", size=6)
    v.kich(xx - 16, P(0, 0)[1], xx - 16, P(0, ys[-1])[1], f"{ys[-1]:.0f}")
    return True


def _bang_tu(v, kq, vung):
    c = v.c; X, Y, W, H = vung; y = Y + H
    c.setFont(v.FB, 7.5); c.setFillColorRGB(*INK)
    for i, (tx, t) in enumerate(((0, "#"), (16, "Tủ"), (150, "Rộng"), (182, "Cao"), (212, "Sâu"), (244, "Mở"), (292, "Ghi chú"))): c.drawString(X + tx, y, t)
    y -= 11; c.setFont(v.F, 7)
    for t in kq["tu"]:
        if y < Y: c.drawString(X, y, "…"); break
        if t["loai"] == "tam" and t.get("ten", "").startswith(("Kickface", "Bulkhead", "Filler", "Panel", "BC")): ten = t.get("ten", "")
        else: ten = t.get("ten") or THU_VIEN[t["loai"]]["ten"]
        c.drawString(X, y, str(t["so"])); c.drawString(X + 16, y, ten[:30]); c.drawRightString(X + 176, y, f"{t['w']:.0f}"); c.drawRightString(X + 206, y, f"{t['h']:.0f}"); c.drawRightString(X + 236, y, f"{t['d']:.0f}")
        c.drawString(X + 244, y, {"shadowline": "SL", "tay_nam": "tay", "push": "push"}.get(t.get("mo", ""), "")); y -= 9.5
    return y


def ban_ve(path, job):
    """ghi PDF A3: trang 1 mặt bằng + bảng tủ; mỗi hướng tủ 1 trang mặt đứng. Trả về số trang."""
    from reportlab.pdfgen import canvas
    F, FB = _font(); kq = dung_job(job)
    for i, t in enumerate(kq["tu"]):
        raw = job["tu"][i] if i < len(job.get("tu", [])) else {}
        t["ten"] = raw.get("ten") or THU_VIEN[t["loai"]]["ten"]; t["mo"] = raw.get("mo", "")
    gocs = [g for g in (0, 90, 180, 270) if any(t["goc"] == g for t in kq["tu"])]
    tong = 1 + len(gocs); c = canvas.Canvas(path, pagesize=A3); v = _Ve(c, F, FB)
    c.setTitle(f"Ban ve {job.get('so', '')} {job.get('ten', '')}"); c.setAuthor("TPW GROUP – Javis Studio")
    v.khung(job, "MẶT BẰNG + BẢNG TỦ", 1, tong); _mat_bang(v, job, kq, (50, 110, 760, 690)); _bang_tu(v, kq, (840, 100, 320, 700)); c.showPage()
    for i, g in enumerate(gocs, 2):
        v.khung(job, HUONG[g], i, tong); _mat_dung(v, kq, g, (90, 120, 1050, 660)); c.showPage()
    c.save(); return tong
