"""JAVIS STUDIO - phần mềm vẽ tủ của TPW GROUP: thư viện tủ, xem/sửa 3D, xuất file cắt Biesse (.cix) + layout + label + phụ kiện.
Chạy: python vetu.py   (mở cửa sổ riêng, dữ liệu nằm trong thư mục du-lieu cạnh file này)
"""
import os, sys, json, re, time, secrets, threading, subprocess, webbrowser, urllib.request, urllib.parse, traceback, hashlib, socket, ipaddress, html, io
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import engine, xuat, banquyen

PHIEN_BAN = "0.9.0"
GOC = Path(__file__).resolve().parent
DATA = GOC / "du-lieu"; JOBS = DATA / "jobs"; MAU = DATA / "mau"
TOKEN = secrets.token_urlsafe(18)
TT = {"ui": 0.0}
MAC_DINH = {"cong": 8770, "thu_muc_xuat": "", "ollama_url": "http://127.0.0.1:11434", "mo_hinh": "", "trinh_duyet": "edge"}


def doc_json(f, md):
    try: return json.loads(Path(f).read_text(encoding="utf-8"))
    except Exception: return md


def ghi_json(f, d):
    Path(f).parent.mkdir(parents=True, exist_ok=True)
    tmp = str(f) + ".tmp"; Path(tmp).write_text(json.dumps(d, ensure_ascii=False, indent=1), encoding="utf-8"); os.replace(tmp, f)


def doc_cfg():
    c = dict(MAC_DINH); c.update(doc_json(DATA / "cau-hinh.json", {}))
    if not c["thu_muc_xuat"]:
        od = Path(os.path.expanduser("~")) / "OneDrive" / "FILE TPW GROUP CTY" / "FILE CNC"
        c["thu_muc_xuat"] = str(od / "_JAVIS") if od.is_dir() else str(GOC / "xuat")
    if not c["mo_hinh"]:   # dùng chung mô hình với Javis Local nếu có
        nao = doc_json(GOC.parent / "du-lieu" / "cau-hinh.json", {}).get("nao", "")
        c["mo_hinh"] = nao.split("local:", 1)[1] if nao.startswith("local:") else "qwen3-vl:8b"
    return c


def ten_file(ten):
    return (re.sub(r'[\\/:*?"<>|\x00-\x1f]', "-", str(ten or "")).strip(" .") or "khong-ten")[:80]


# ---------------------------------------------------------------- màu vật liệu lấy từ website nhà cung cấp
MAU_SAN = [dict(id="s1", ten="Trắng", hex="#f4f3ef"), dict(id="s2", ten="Xám nhạt", hex="#c9cbcc"), dict(id="s3", ten="Xám đậm", hex="#5b5f63"),
           dict(id="s4", ten="Đen", hex="#232426"), dict(id="s5", ten="Gỗ sồi sáng", hex="#c9a57a"), dict(id="s6", ten="Gỗ óc chó", hex="#6b4a34"),
           dict(id="s7", ten="Xanh rêu", hex="#5d6b56"), dict(id="s8", ten="Đá trắng", hex="#e9e8e4"), dict(id="s9", ten="Đá xám", hex="#9a9c9f")]


def _tai(url, toi_da=8_000_000):
    """tải 1 địa chỉ web công khai (chặn địa chỉ nội bộ / máy mình); trả về (bytes, content-type, url cuối)"""
    for _ in range(4):
        u = urllib.parse.urlsplit(url)
        if u.scheme not in ("http", "https") or not u.hostname: raise ValueError("Chỉ nhận link http/https.")
        for inf in socket.getaddrinfo(u.hostname, None):
            ip = ipaddress.ip_address(inf[4][0])
            if ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_reserved or ip.is_multicast: raise ValueError("Link này trỏ vào mạng nội bộ – không tải.")
        rq = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130 Safari/537.36", "Accept": "*/*"})
        op = urllib.request.build_opener(_KhongChuyen)
        try:
            r = op.open(rq, timeout=20)
        except urllib.error.HTTPError as e:
            if e.code in (301, 302, 303, 307, 308) and e.headers.get("Location"):
                url = urllib.parse.urljoin(url, e.headers["Location"]); continue
            raise
        b = r.read(toi_da + 1)
        if len(b) > toi_da: raise ValueError("File quá lớn.")
        return b, (r.headers.get("Content-Type") or "").split(";")[0].strip().lower(), url
    raise ValueError("Chuyển hướng quá nhiều lần.")


class _KhongChuyen(urllib.request.HTTPRedirectHandler):       # tự kiểm từng lần chuyển hướng (không để nhảy vào mạng nội bộ)
    def redirect_request(self, *a, **k): return None


def mau_tu_web(url):
    b, ct, url = _tai(str(url).strip())
    ten = ""
    if not ct.startswith("image/"):
        t = b.decode("utf-8", "replace")
        def meta(k):
            m = re.search(r'<meta[^>]+(?:property|name)=["\']%s["\'][^>]*content=["\']([^"\']+)' % re.escape(k), t, re.I) or \
                re.search(r'<meta[^>]+content=["\']([^"\']+)["\'][^>]*(?:property|name)=["\']%s["\']' % re.escape(k), t, re.I)
            return html.unescape(m.group(1)).strip() if m else ""
        anh = meta("og:image") or meta("twitter:image")
        ten = meta("og:title") or (re.search(r"<title[^>]*>(.*?)</title>", t, re.I | re.S) or [0, ""])[1]
        ten = re.sub(r"\s+", " ", html.unescape(ten)).strip()
        if not anh: raise ValueError("Trang này không có ảnh màu để lấy. Bấm chuột phải vào ảnh màu trên trang → 'Copy image address' rồi dán link ảnh đó.")
        b, ct, _ = _tai(urllib.parse.urljoin(url, anh))
        if not ct.startswith("image/"): raise ValueError("Không tải được ảnh màu từ trang này.")
    host = urllib.parse.urlsplit(url).hostname or ""
    ten = (ten or os.path.basename(urllib.parse.urlsplit(url).path).rsplit(".", 1)[0].replace("-", " ").replace("_", " ")).strip()[:70] or "Màu mới"
    mid = hashlib.sha1(b).hexdigest()[:12]; MAU.mkdir(parents=True, exist_ok=True); hx = "#b9b3a8"; duoi = {"image/png": "png", "image/webp": "webp", "image/gif": "gif"}.get(ct, "jpg")
    try:
        from PIL import Image
        im = Image.open(io.BytesIO(b)).convert("RGB"); w, h = im.size; s = min(w, h)
        im = im.crop(((w - s) // 2, (h - s) // 2, (w + s) // 2, (h + s) // 2)); im.thumbnail((768, 768))
        r, g, bl = im.resize((1, 1)).getpixel((0, 0)); hx = "#%02x%02x%02x" % (r, g, bl); duoi = "jpg"
        im.save(MAU / f"{mid}.jpg", "JPEG", quality=88)
    except ImportError:
        (MAU / f"{mid}.{duoi}").write_bytes(b)
    e = dict(id=mid, ten=ten, hex=hx, anh=f"/mau/{mid}.{duoi}", nguon=host, link=url)
    ds = [x for x in doc_json(DATA / "mau.json", []) if x.get("id") != mid] + [e]
    ghi_json(DATA / "mau.json", ds)
    return e


# ---------------------------------------------------------------- AI vẽ nhanh
AI_HE_THONG = """Bạn là Javis Studio, trợ lý vẽ tủ bếp / tủ áo cho xưởng TPW (Sydney). Người dùng ra lệnh bằng tiếng Việt, bạn trả về DUY NHẤT một JSON:
{"noi": "câu trả lời ngắn", "lenh": [ ... ]}
Các lệnh:
{"op":"moi"}                                  xoá hết, vẽ lại từ đầu
{"op":"hang","x":0,"tu":[TU,...]}             thêm 1 hàng tủ nối tiếp từ trái sang phải, bắt đầu tại x (mm)
{"op":"sua","so":[1,2] | "tat_ca" | "duoi" | "treo" | "cao","dat":{...}}   sửa thông số các tủ có sẵn (so = số thứ tự tủ)
{"op":"xoa","so":[3]}                         xoá tủ
{"op":"phong","tuong_trai":true,"tuong_phai":false,"tran":2400}   người dùng nói bên nào sát tường / trần cao bao nhiêu (để tự thêm filler, panel, bulkhead)
TU = {"loai":..., "w":rộng, tuỳ chọn: "h","d","canh","hoc","ke","shadowline","ten","ray","sl_giua","ban_le","kieu_canh","mo","day_da","phu_kien","hoc_duoi","lo2_cao","mr_kieu","tl_kieu","tl_chia"}
"kieu_canh": "phang" | "shaker" (cửa shaker). "mo": "tay_nam" | "shadowline" | "push" (bấm mở, không tay). Mặt đá: "day_da": 20 | 40 | 60 | 100.
loai: duoi_canh (tủ dưới cánh), duoi_hoc (tủ dưới ngăn kéo), duoi_chau (tủ chậu rửa), duoi_keo (tủ kéo thùng rác BIN / kệ gia vị spice rack, rộng 300-450, thêm "phu_kien":"thung_rac"|"ke_gia_vi"), treo (tủ treo), hut_mui (tủ treo có hút mùi âm), cao (tủ cao/pantry), lo_nuong (tủ cao có lò nướng), tu_ao (tủ áo), ke_mo (kệ mở), may_rua (máy rửa chén: "mr_kieu":"am" = âm tủ có cửa cùng màu cánh | "ban_am" | "roi"; rộng 600), tu_lanh (tủ lạnh: "tl_kieu":"am" = âm tủ có cửa cùng màu cánh, rộng 600 | "roi" = tủ lạnh rời, chừa khoảng theo model), thiet_bi (thiết bị khác, chỉ chừa chỗ), mat_da (mặt đá), tam (tấm hông/filler)
Đơn vị mm ("3m6" = 3600, "6 tấc" = 600). Tủ dưới chuẩn cao 730 sâu 560 (chân 130); tủ treo cao 900 sâu 300; tủ cao 2270 sâu 579. Cánh rộng tối đa 600 mỗi cánh: tủ > 600 dùng 2 cánh.
KHÔNG chép số trong ví dụ: tự tính bề rộng từng tủ để TỔNG đúng bằng chiều dài người dùng nói.
Tủ dưới và tủ cao đi chung 1 hàng; tủ treo là 1 hàng riêng (cũng bắt đầu x=0 trừ khi phía dưới là tủ cao). Tổng bề rộng 1 hàng phải bằng chiều dài người dùng yêu cầu.
Ví dụ: "bếp thẳng 3m, có tủ chậu 900, 1 tủ hộc 3 ngăn, còn lại tủ cánh, tủ treo phía trên, shadowline"
{"noi":"Em vẽ bếp thẳng 3000: chậu 900, hộc 600, 2 tủ cánh 750, tủ treo 4 cái 750.","lenh":[{"op":"moi"},{"op":"hang","x":0,"tu":[{"loai":"duoi_canh","w":750,"shadowline":true},{"loai":"duoi_chau","w":900,"shadowline":true},{"loai":"duoi_hoc","w":600,"hoc":3,"shadowline":true},{"loai":"duoi_canh","w":750,"shadowline":true}]},{"op":"hang","x":0,"tu":[{"loai":"treo","w":750},{"loai":"treo","w":750},{"loai":"treo","w":750},{"loai":"treo","w":750}]}]}
Ví dụ: "đổi tủ 2 thành 4 ngăn kéo" -> {"noi":"Đã đổi tủ 2 thành 4 ngăn kéo.","lenh":[{"op":"sua","so":[2],"dat":{"loai":"duoi_hoc","hoc":4}}]}
"""


def chieu_dai_yeu_cau(cau):
    """đọc chiều dài người dùng nói: "3m6" -> 3600, "2.4m" -> 2400, "dài 3600" -> 3600. Không thấy -> None"""
    c = cau.lower().replace(",", ".")
    m = re.search(r"(\d+)\s*m\s*(\d{1,2})(?!\d)", c)
    if m: return int(m.group(1)) * 1000 + int(m.group(2).ljust(3, "0")[:3]) * (1 if len(m.group(2)) == 3 else 1)
    m = re.search(r"(\d+(?:\.\d+)?)\s*(?:m|mét|met)\b", c)
    if m and float(m.group(1)) < 20: return int(round(float(m.group(1)) * 1000))
    m = re.search(r"(?:dài|dai|rộng|rong|tổng|tong)\s*(\d{4})\b", c)
    return int(m.group(1)) if m else None


def can_hang(ds, L, co_dan=("duoi_canh", "treo", "ke_mo")):
    """ép tổng bề rộng 1 hàng = L bằng cách chia lại các tủ 'co dãn' (tủ cánh, tủ treo); tủ chậu / hộc / thiết bị giữ nguyên"""
    cd = [t for t in ds if t.get("loai") in co_dan]
    co_dinh = sum(float(t.get("w", 0)) for t in ds if t not in cd)
    con = L - co_dinh
    if not cd or con < 300 * len(cd) or abs(sum(float(t.get("w", 0)) for t in ds) - L) < 1: return ds
    while con / len(cd) > 900:                      # tủ quá rộng: thêm 1 tủ cùng loại
        k = dict(cd[-1]); k["id"] = secrets.token_hex(4); ds.insert(ds.index(cd[-1]) + 1, k); cd.append(k)
    w = int(con // len(cd))
    for t in cd: t["w"] = float(w)
    cd[-1]["w"] = float(con - w * (len(cd) - 1))
    return ds


def ap_lenh(job, lenh, cau=""):
    """áp danh sách lệnh AI vào job; kiểm từng giá trị, bỏ cái lạ"""
    tu = list(job.get("tu", [])); n = 0
    trong = not tu                       # job đang trống thì coi như vẽ mới, kể cả khi mô hình quên lệnh "moi"
    dai = chieu_dai_yeu_cau(cau) if trong or any(isinstance(x, dict) and x.get("op") == "moi" for x in (lenh if isinstance(lenh, list) else [])) else None
    khoa = {k for k, *_ in engine.THAM_SO} | {"loai"}
    # kiểu cửa cho tủ mới: lấy theo câu anh nói (nếu nói rõ 1 kiểu), không thì theo lựa chọn "Kiểu cửa cho tủ mới" của job
    md = {k: x for k, x in (job.get("mac_dinh") or {}).items() if (k, x) in (("mo", "tay_nam"), ("mo", "shadowline"), ("mo", "push"), ("kieu_canh", "phang"), ("kieu_canh", "shaker"))}
    c0 = re.sub(r"kh[ôo]ng (c[óo] |d[ùu]ng )?tay n[ắa]m|no handles?|handle ?less", " ", cau.lower()); ep = {}
    noi_mo = [k for k, rx in (("shadowline", r"shadow\s*line|finger\s*pull"), ("tay_nam", r"tay n[ắa]m|handle"), ("push", r"b[ấa]m m[ởo]|nh[ấa]n m[ởo]|push")) if re.search(rx, c0)]
    if len(noi_mo) == 1: ep["mo"] = md["mo"] = noi_mo[0]
    if "shaker" in c0: ep["kieu_canh"] = md["kieu_canh"] = "shaker"
    def sach(d):
        o = {}
        for k, v in (d or {}).items():
            if k not in khoa: continue
            if k == "loai" and v not in engine.THU_VIEN: continue
            if k in ("w", "h", "d", "x", "y", "z", "chan"):
                try: v = max(0.0, min(6000.0, float(v)))
                except (TypeError, ValueError): continue
            o[k] = v
        d = d or {}
        if "mo" not in o and isinstance(d.get("shadowline"), bool): o["mo"] = "shadowline" if d["shadowline"] else "tay_nam"
        return o
    ph = dict(job.get("phong") or {}); moi = trong
    c = cau.lower()                        # tường / trần: đọc thẳng từ câu anh nói (không tin số mô hình tự bịa)
    if re.search(r"gi[ưữ]a (2|hai) (b[ứu]c )?t[ưườ]+ng|hai b[êe]n (l[àa] |c[óo] |s[áa]t )?t[ưườ]+ng|between (two|2) walls|wall(s)? (on )?both sides", c): ph["tuong_trai"] = ph["tuong_phai"] = True; n += 1
    if re.search(r"(b[êe]n )?tr[áa]i (l[àa] |c[óo] |s[áa]t |gi[áa]p )?t[ưườ]+ng|t[ưườ]+ng (b[êe]n |ph[íi]a )?tr[áa]i|left (side )?(is a |is )?wall|wall on the left", c): ph["tuong_trai"] = True; n += 1
    if re.search(r"(b[êe]n )?ph[ảa]i (l[àa] |c[óo] |s[áa]t |gi[áa]p )?t[ưườ]+ng|t[ưườ]+ng (b[êe]n |ph[íi]a )?ph[ảa]i|right (side )?(is a |is )?wall|wall on the right", c): ph["tuong_phai"] = True; n += 1
    m = re.search(r"(?:tr[ầa]n|ceiling)(?: nh[àa])?(?: cao| height| is)?\s*(\d{4}|\d(?:[.,]\d+)?\s*m\d*)", c)
    if m:
        t = chieu_dai_yeu_cau("dài " + m.group(1)) if m.group(1).isdigit() else chieu_dai_yeu_cau(m.group(1))
        if t and 2000 <= t <= 4000: ph["tran"] = float(t); n += 1
    F = float(ph.get("filler") or 30); P = 16.0
    for L in lenh if isinstance(lenh, list) else []:
        if not isinstance(L, dict): continue
        op = L.get("op")
        if op == "moi": tu = []; n += 1; moi = True
        elif op == "hang":
            ds = []
            for t in L.get("tu") or []:
                s = sach(t)
                if "loai" not in s: continue
                for k in ("mo", "kieu_canh"):
                    if k in ep: s[k] = ep[k]
                    elif k not in s and k in md: s[k] = md[k]
                ds.append(engine.tu_moi(s.pop("loai"), id=secrets.token_hex(4), **s))
            try: x0 = float(L.get("x", 0) or 0)
            except (TypeError, ValueError): x0 = 0.0
            ds2 = []                      # cánh tối đa ~600: tủ quá rộng thì tách thành nhiều tủ bằng nhau
            for t in ds:
                k = -(-int(float(t["w"])) // 1200) if t["loai"] in engine.CO_CANH and float(t["w"]) > 1200 else 1
                for i in range(k): ds2.append(dict(t, w=round(float(t["w"]) / k, 1), id=secrets.token_hex(4)))
            ds = ds2
            treo = bool(ds) and all(t["loai"] in engine.TU_TREO for t in ds)
            duoi_co = [t for t in tu if t.get("loai") in engine.TU_DUOI + engine.TU_CAO + ("thiet_bi",)]
            if treo and duoi_co and any(t["loai"] in engine.TU_CAO for t in duoi_co):       # tủ treo chỉ chạy trên phần tủ thấp, không qua đầu tủ cao
                thap = [t for t in duoi_co if t["loai"] not in engine.TU_CAO]
                if thap:
                    x0 = min(float(t["x"]) for t in thap); ds = can_hang(ds, max(float(t["x"]) + float(t["w"]) for t in thap) - x0)
            elif dai and ds:
                dau = sum((F if ph.get("tuong_" + b) else P) for b in ("trai", "phai"))      # chừa filler sát tường / panel hông 2 đầu
                noi = sum(1 for a, b in zip(ds, ds[1:]) if (a["loai"] in engine.TU_CAO) != (b["loai"] in engine.TU_CAO)) * P
                mem = ("duoi_canh", "treo", "ke_mo")
                ds = can_hang(ds, dai - dau - (0 if treo else noi), co_dan=mem if any(t["loai"] in mem for t in ds) else ("cao", "tu_ao", "duoi_hoc"))
            tu += engine.xep_hang(ds, x0); n += len(ds)
        elif op in ("sua", "xoa"):
            so = L.get("so")
            nhom = {"duoi": ("duoi_canh", "duoi_hoc", "duoi_chau"), "treo": ("treo",), "cao": ("cao", "tu_ao")}
            if so == "tat_ca": idx = list(range(len(tu)))
            elif isinstance(so, str) and so in nhom: idx = [i for i, t in enumerate(tu) if t.get("loai") in nhom[so]]
            else: idx = [int(s) - 1 for s in (so if isinstance(so, list) else [so]) if str(s).strip().lstrip("-").isdigit() and 0 < int(s) <= len(tu)]
            if op == "xoa": tu = [t for i, t in enumerate(tu) if i not in idx]; n += len(idx)
            else:
                d = sach(L.get("dat"))
                for i in idx:
                    t = dict(tu[i])
                    if "loai" in d and d["loai"] != t.get("loai"):       # đổi loại: giữ vị trí + bề rộng
                        giu = {k: t[k] for k in ("id", "x", "z", "goc", "w", "mo", "kieu_canh", "vl_thung", "vl_mat") if k in t}
                        t = engine.tu_moi(d["loai"], **giu)
                    t.update({k: v for k, v in d.items() if k != "loai"}); tu[i] = t; n += 1
    job = dict(job); job["tu"] = tu; job["phong"] = ph
    if md: job["mac_dinh"] = dict(dict(mo="tay_nam", kieu_canh="phang"), **md)
    if moi and tu:            # bản vẽ mới: tự thêm panel hông, filler sát tường, kicker, bulkhead theo quy tắc
        job, _ = engine.hoan_thien(job)
    return job, n


def hoi_ai(cfg, cau, job):
    tom = [f"{i + 1}. {t.get('loai')} rộng {t.get('w'):g} x={t.get('x', 0):g}" for i, t in enumerate(job.get("tu", []))]
    user = ("Tủ đang có:\n" + ("\n".join(tom) if tom else "(chưa có tủ nào)") + "\n\nLệnh: " + cau)
    m = [{"role": "system", "content": AI_HE_THONG}, {"role": "user", "content": user}]
    if any(k in cfg["mo_hinh"].lower() for k in ("qwen", "deepseek")): m.append({"role": "assistant", "content": "<think>\n\n</think>\n\n"})
    body = {"model": cfg["mo_hinh"], "messages": m, "stream": False, "format": "json", "keep_alive": "30m", "think": False,
            "options": {"num_ctx": 8192, "temperature": 0.1, "num_predict": 1500}}
    def goi(b):
        rq = urllib.request.Request(cfg["ollama_url"] + "/api/chat", json.dumps(b).encode(), {"Content-Type": "application/json"})
        return json.loads(urllib.request.urlopen(rq, timeout=180).read())
    try: d = goi(body)
    except urllib.error.HTTPError:
        body.pop("think", None); d = goi(body)
    txt = (d.get("message") or {}).get("content", "")
    a, b = txt.find("{"), txt.rfind("}")
    return json.loads(txt[a:b + 1])


from html import escape as _esc


# ---------------------------------------------------------------- trang kích hoạt (khi chưa có / hết quyền)
TRANG_KH = """<!doctype html><html><head><meta charset="utf-8"><title>Javis Studio – kích hoạt</title><style>
body{margin:0;background:#11151a;color:#e6e9ee;font:15px Segoe UI,Arial;display:flex;align-items:center;justify-content:center;height:100vh}
.b{background:#1a2027;border:1px solid #2b333d;border-radius:12px;padding:28px 30px;width:560px}h1{margin:0 0 4px;font-size:20px;color:#3ec6e0}
p{color:#9aa4b0;line-height:1.5}textarea{width:100%;height:90px;background:#0c0f13;color:#e6e9ee;border:1px solid #2b333d;border-radius:8px;padding:8px;font:13px Consolas,monospace;box-sizing:border-box}
button{margin-top:12px;background:#3ec6e0;color:#071218;border:0;border-radius:8px;padding:10px 18px;font-weight:600;cursor:pointer;margin-right:8px}#kq{margin-top:12px;color:#ff8a80;min-height:20px}
</style></head><body><div class="b"><h1>JAVIS STUDIO</h1><p id="ly">__LY__</p>
<textarea id="ma" placeholder="Dán mã kích hoạt vào đây"></textarea><br><button id="go">Kích hoạt</button><button id="th" style="background:#2b333d;color:#e6e9ee">Thử lại</button><div id="kq"></div></div>
<script>const T="__TOKEN__";async function api(p,b){const r=await fetch(p,{method:'POST',headers:{'Content-Type':'application/json','X-Javis-Token':T},body:JSON.stringify(b||{})});return r.json()}
go.onclick=async()=>{kq.textContent='Đang kiểm tra...';const r=await api('/api/kich-hoat',{ma:ma.value});if(r.ok)location.reload();else kq.textContent=r.loi||r.ly_do||'Không được'};
th.onclick=async()=>{kq.textContent='Đang kết nối...';const r=await api('/api/ban-quyen',{lai:1});if(r.ok)location.reload();else kq.textContent=r.ly_do};</script></body></html>"""


# ---------------------------------------------------------------- HTTP
class H(BaseHTTPRequestHandler):
    server_version = "JavisStudio"

    def log_message(self, *a): pass

    def gui(self, code, body, ctype="application/json; charset=utf-8"):
        if not isinstance(body, (bytes, bytearray)):
            body = (body if isinstance(body, str) else json.dumps(body, ensure_ascii=False)).encode("utf-8")
        self.send_response(code); self.send_header("Content-Type", ctype); self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store"); self.send_header("X-Content-Type-Options", "nosniff"); self.end_headers()
        try: self.wfile.write(body)
        except OSError: pass

    def ok_nguon(self):
        h = (self.headers.get("Host") or "").split(":")[0]
        return h in ("127.0.0.1", "localhost")

    def do_GET(self):
        if not self.ok_nguon(): return self.gui(403, {"loi": "host"})
        p = self.path.split("?")[0]
        if p == "/" and not banquyen.trang_thai()["ok"]:
            return self.gui(200, TRANG_KH.replace("__TOKEN__", TOKEN).replace("__LY__", _esc(banquyen.trang_thai()["ly_do"])), "text/html; charset=utf-8")
        if p == "/":
            html = (GOC / "ui.html").read_text(encoding="utf-8").replace("__TOKEN__", TOKEN).replace("__PB__", PHIEN_BAN)
            return self.gui(200, html, "text/html; charset=utf-8")
        if p == "/favicon.ico": return self.gui(204, b"", "image/x-icon")
        m = re.fullmatch(r"/mau/([0-9a-f]{12})\.(jpg|png|webp|gif)", p)
        if m and (MAU / p[5:]).is_file():
            return self.gui(200, (MAU / p[5:]).read_bytes(), {"jpg": "image/jpeg", "png": "image/png", "webp": "image/webp", "gif": "image/gif"}[m.group(2)])
        if p.startswith("/lib/") and re.fullmatch(r"/lib/[\w.\-]+\.js", p):
            f = GOC / "lib" / p[5:]
            if f.is_file(): return self.gui(200, f.read_bytes(), "text/javascript; charset=utf-8")
        self.gui(404, {"loi": "khong co"})

    def do_POST(self):
        if not self.ok_nguon() or self.headers.get("X-Javis-Token") != TOKEN: return self.gui(403, {"loi": "token"})
        try:
            n = int(self.headers.get("Content-Length") or 0)
            d = json.loads(self.rfile.read(n) or b"{}") if n else {}
            self.gui(200, self.post(self.path.split("?")[0], d))
        except Exception as e:
            traceback.print_exc(); self.gui(500, {"loi": f"{type(e).__name__}: {e}"})

    def post(self, p, d):
        cfg = doc_cfg()
        if p == "/api/kich-hoat":
            try: return banquyen.kich_hoat(d.get("ma"))
            except ValueError as e: return {"ok": False, "loi": str(e)}
        if p == "/api/ban-quyen":
            if d.get("lai"): banquyen.kiem_mang(cho=True)
            return dict(banquyen.trang_thai(), phien_ban=PHIEN_BAN, moi=(banquyen.TT["moi"] or {}).get("phien_ban") if banquyen.co_ban_moi(PHIEN_BAN) else None)
        if p == "/api/cap-nhat":
            ok, kq = banquyen.cap_nhat(PHIEN_BAN)
            if ok: banquyen.khoi_dong_lai()
            return {"ok": ok, "tin": (f"Đã cập nhật lên bản {kq} – Studio tự mở lại sau vài giây." if ok else kq)}
        if p != "/api/thoat" and not banquyen.trang_thai()["ok"]: return {"loi": "Chưa kích hoạt / hết quyền dùng."}
        if p == "/api/khoi-dong":
            TT["ui"] = time.time()
            return dict(thu_vien=engine.THU_VIEN, chung=engine.CHUNG, tham_so=engine.THAM_SO,
                        vat_lieu={k: dict(ten=v["ten"], mau=v["mau"], lz=v["lz"]) for k, v in engine.VAT_LIEU.items()},
                        cfg=dict(thu_muc_xuat=cfg["thu_muc_xuat"], mo_hinh=cfg["mo_hinh"]), gan_nhat=doc_json(DATA / "gan-nhat.json", {}).get("ten"))
        if p == "/api/song": TT["ui"] = time.time(); return {"ok": 1}
        if p == "/api/catalog": return {"catalog": doc_json(GOC / "lib" / "catalog_cv.json", [])}      # thư viện tủ lấy từ Cabinet Vision (MN Joinery, Huân)
        if p == "/api/dung":
            job = d.get("job") or {}; moi = None; gh = []
            if (job.get("phong") or {}).get("tu_dong", True) and job.get("tu"):       # tự hoàn thiện: panel / filler / kicker luôn đi theo tủ
                j2, gh = engine.hoan_thien(job)
                if json.dumps(j2.get("tu"), sort_keys=True) != json.dumps(job.get("tu"), sort_keys=True): moi = dict(tu=j2["tu"], phong=j2["phong"])
                job = j2
            kq = engine.dung_job(job)
            ct = [dict(cab=x["cab"], n=x["name"], vl=x["vl"], w=x["w"], h=x["h"], lo=len(x["holes"]), nep=x["edges"], e45=x["e45"], note=x["note"]) for x in kq["chi_tiet"]]
            cb = [g for g in gh if any(k in g for k in ("còn hở", "lấn vào", "dài hơn tường"))] + kq["canh_bao"]      # cảnh báo ở góc chữ L / số đo tường
            return dict(tu=kq["tu"], chi_tiet=ct, phu_kien=kq["phu_kien"], canh_bao=cb, nep=kq["nep"], job=moi, day=kq["day"], splash=kq["splash"])
        if p == "/api/hoan-thien":
            job = d.get("job") or {}
            if d.get("go"): job = dict(job, tu=[t for t in job.get("tu", []) if not t.get("auto")]); return {"job": job, "ghi": []}
            j, ghi = engine.hoan_thien(job); return {"job": j, "ghi": ghi}
        if p == "/api/xep": return xuat.xem_truoc(d.get("job") or {})
        if p == "/api/xuat":
            job = d.get("job") or {}
            if not job.get("tu"): return {"loi": "Job chưa có tủ nào."}
            r = xuat.xuat(job, cfg["thu_muc_xuat"])
            return r
        if p == "/api/ban-ve":
            job = d.get("job") or {}
            if not job.get("tu"): return {"loi": "Job chưa có tủ nào."}
            import banve, tempfile
            ten = re.sub(r'[\\/:*?"<>|]', "-", f"BAN VE 2D - {job.get('so', '')} {job.get('ten', '')}").strip() + ".pdf"
            out = os.path.join(cfg["thu_muc_xuat"], "_ban-ve"); os.makedirs(out, exist_ok=True); path = os.path.join(out, ten)
            n = banve.ban_ve(path, job)
            try:
                if os.name == "nt": os.startfile(path)
            except Exception: pass
            return {"duong_dan": path, "trang": n}
        if p == "/api/mo-thu-muc":
            f = str(d.get("duong_dan") or cfg["thu_muc_xuat"])
            goc = os.path.abspath(cfg["thu_muc_xuat"])
            if os.path.abspath(f).startswith(goc) and os.path.isdir(f) and sys.platform.startswith("win"): os.startfile(f)
            return {"ok": 1}
        if p == "/api/luu":
            job = d.get("job") or {}; ten = ten_file(f"{job.get('so', '')} {job.get('ten', '')}".strip())
            ghi_json(JOBS / (ten + ".jvs"), job); ghi_json(DATA / "gan-nhat.json", {"ten": ten})
            return {"ok": 1, "ten": ten}
        if p == "/api/jobs":
            JOBS.mkdir(parents=True, exist_ok=True)
            fs = sorted(JOBS.glob("*.jvs"), key=lambda f: -f.stat().st_mtime)
            return {"jobs": [dict(ten=f.stem, luc=time.strftime("%d/%m %H:%M", time.localtime(f.stat().st_mtime))) for f in fs[:200]]}
        if p == "/api/mo":
            f = JOBS / (ten_file(d.get("ten")) + ".jvs")
            if not f.is_file(): return {"loi": "Không thấy job này."}
            ghi_json(DATA / "gan-nhat.json", {"ten": f.stem}); return {"job": doc_json(f, {})}
        if p == "/api/ai":
            job = d.get("job") or {}; cau = str(d.get("lenh") or "").strip()[:2000]
            if not cau: return {"loi": "Chưa nhập lệnh."}
            try: kq = hoi_ai(cfg, cau, job)
            except Exception as e:
                return {"loi": f"Chưa gọi được mô hình AI trên máy ({cfg['mo_hinh']}). Mở Ollama / Javis Local rồi thử lại. [{type(e).__name__}]"}
            job2, n = ap_lenh(job, kq.get("lenh"), cau)
            return {"job": job2, "noi": str(kq.get("noi") or "")[:400], "n": n}
        if p == "/api/mau-ds": return {"san": MAU_SAN, "web": doc_json(DATA / "mau.json", [])}
        if p == "/api/mau-tu-web":
            try: return {"mau": mau_tu_web(d.get("url"))}
            except ValueError as e: return {"loi": str(e)}
            except Exception as e: return {"loi": f"Không lấy được màu từ link này ({type(e).__name__}). Thử dán thẳng link ảnh màu."}
        if p == "/api/mau-xoa":
            ghi_json(DATA / "mau.json", [x for x in doc_json(DATA / "mau.json", []) if x.get("id") != d.get("id")]); return {"ok": 1}
        if p == "/api/thoat":
            threading.Timer(0.3, lambda: os._exit(0)).start(); return {"ok": 1}
        return {"loi": "khong co"}


def mo_cua_so(url):
    if sys.platform.startswith("win"):
        edge = [r"%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe", r"%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"]
        chrome = [r"%ProgramFiles%\Google\Chrome\Application\chrome.exe", r"%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe", r"%LocalAppData%\Google\Chrome\Application\chrome.exe"]
        for pth in (chrome + edge if doc_cfg().get("trinh_duyet") == "chrome" else edge + chrome):
            exe = os.path.expandvars(pth)
            if os.path.isfile(exe):
                try: subprocess.Popen([exe, "--app=" + url, "--window-size=1600,980", "--window-position=60,40"]); return
                except Exception: pass
    webbrowser.open(url)


def main():
    for st in (sys.stdout, sys.stderr):
        try: st.reconfigure(encoding="utf-8", errors="replace")
        except Exception: pass
    JOBS.mkdir(parents=True, exist_ok=True)
    if not any(JOBS.glob("*.jvs")) and (GOC / "mau").is_dir():      # lần đầu: chép job mẫu để mở ra là có cái xem
        import shutil
        for f in (GOC / "mau").glob("*.jvs"): shutil.copy2(f, JOBS / f.name)
        ghi_json(DATA / "gan-nhat.json", {"ten": "00 BEP MAU 3M6 (thu)"})
    if "--khong-cap-nhat" not in sys.argv:       # tự cập nhật khi mở (anh Tan: không phải tải bản mới)
        try:
            banquyen.kiem_mang(cho=True)
            if banquyen.co_ban_moi(PHIEN_BAN):
                ok, kq = banquyen.cap_nhat(PHIEN_BAN)
                if ok: print(f"Đã cập nhật lên {kq}, mở lại..."); banquyen.khoi_dong_lai(); time.sleep(5); return
        except Exception: traceback.print_exc()

    def _dinh_ky():
        while True:
            time.sleep(6 * 3600); banquyen.kiem_mang()
    threading.Thread(target=_dinh_ky, daemon=True).start()
    cfg = doc_cfg(); cong = int(os.environ.get("VETU_PORT") or cfg.get("cong", 8770))
    cu = doc_json(DATA / "phien.json", {})
    if cu.get("token"):     # chỉ cho 1 bản chạy: nhờ bản cũ tự tắt
        try:
            rq = urllib.request.Request(f"http://127.0.0.1:{cu.get('cong', cong)}/api/thoat", b"{}", {"X-Javis-Token": cu["token"], "Content-Type": "application/json"})
            urllib.request.urlopen(rq, timeout=2).read(); time.sleep(0.8)
        except Exception: pass
    srv = None
    for _ in range(12):
        try: srv = ThreadingHTTPServer(("127.0.0.1", cong), H); break
        except OSError: time.sleep(0.5)
    if srv is None:
        print(f"Cổng {cong} đang bị chương trình khác dùng."); sys.exit(1)
    ghi_json(DATA / "phien.json", {"pid": os.getpid(), "cong": cong, "token": TOKEN})
    url = f"http://127.0.0.1:{cong}/"
    print(f"JAVIS STUDIO {PHIEN_BAN} đang chạy: {url}\nFile cắt xuất ra: {cfg['thu_muc_xuat']}\nĐóng cửa sổ này để tắt.")
    if "--no-browser" not in sys.argv:
        threading.Timer(6.0, lambda: None if time.time() - TT["ui"] < 8 else mo_cua_so(url)).start()
    try: srv.serve_forever()
    except KeyboardInterrupt: pass


if __name__ == "__main__":
    main()
