"""Javis Studio - lõi dựng tủ: thư viện tủ tham số -> chi tiết (miếng ván, lỗ khoan, nẹp), khối 3D, phụ kiện.
Quy tắc lấy từ file Cabinet Vision của Huân (Puja Carmondy R4901, job 61, job 75) và lời dặn của anh Tan 19/11/2026.

Hệ toạ độ trong 1 tủ (mm): X ngang (0 = hông trái), Y cao (0 = đáy thùng), Z sâu (0 = lưng tủ sát tường, D = mép trước thùng).
Miếng ván 2D: x,y của miếng khi nằm trên bàn máy; cạnh 'L' x=0, 'R' x=w, 'B' y=0, 'T' y=h.
"""
from collections import Counter
import math, re

VAT_LIEU = {
    "HMR16": dict(ten="HMR trắng 16.4 (thùng tủ)", lz=16.4, lx=2410, ly=1210, mat="16MM WHITE HMR 24X12 PARTICLE BOARD ",
                  tnm="10_HMR", crc=1, c9=0, van=False, mau="#f3f0e9", ma="H"),
    "MAU16": dict(ten="Ván màu 16 có vân (cánh, mặt hộc)", lz=16.0, lx=2410, ly=1210, mat="16MM GRAIN 1 -  24X12 MR MDF",
                  tnm="10_HMR", crc=2, c9=1, van=True, mau="#a9794f", ma="P"),
    "MAU16B": dict(ten="Ván MDF màu trơn 16 (màu 2 – trắng / be)", lz=16.0, lx=2410, ly=1210, mat="16MM COLOUR 2 -  24X12 MR MDF",
                  tnm="10_HMR", crc=2, c9=1, van=False, mau="#e6e1d7", ma="W"),
    "MDF18": dict(ten="MDF 18 sơn PU", lz=18.0, lx=3100, ly=1200, mat="go mdf",
                  tnm="10_MDF", crc=2, c9=0, van=False, mau="#e8e4dc", ma="M"),
    # cửa shaker: Studio CHƯA tự ra chương trình phay lòng -> không xuất .cix, chỉ ra danh sách để Huân làm
    "MDF21": dict(ten="MDF 21 (cửa shaker sơn PU)", lz=21.0, lx=3100, ly=1200, mat="21MM WHITE MDF",
                  tnm="10_HMR", crc=2, c9=0, van=False, mau="#eceae5", ma="S", cnc=False),
}
DA_DAY = (20, 40, 60, 100)
RAY_NL = (270, 300, 350, 400, 450, 500, 550, 600)
SL_H = 50.0          # shadowline cao 50 (khoét hông + thanh màu)
SL_CUA = 25.0        # cánh/mặt hộc shadowline lên cao chừa 25 dưới mặt đá (CV: SHDWLNE door top reveal 25, anh Tan 20/11)
HO = 1.5             # hở quanh cánh / mặt hộc
KHE = 3.0            # khe giữa 2 cánh / 2 mặt hộc

# ---------------------------------------------------------------- thư viện
THU_VIEN = {
    "duoi_canh": dict(ten="Tủ dưới – cánh", nhom="Tủ dưới", w=600, h=730, d=560, chan=130, canh=2, ban_le="L", ke=1),
    "duoi_hoc": dict(ten="Tủ dưới – ngăn kéo", nhom="Tủ dưới", w=600, h=730, d=560, chan=130, hoc=3, ray="tandembox", sl_giua=False),
    "duoi_keo": dict(ten="Tủ kéo phụ kiện (BIN / spice rack)", nhom="Tủ dưới", w=450, h=730, d=560, chan=130, phu_kien="thung_rac"),
    "duoi_chau": dict(ten="Tủ chậu rửa", nhom="Tủ dưới", w=900, h=730, d=560, chan=130, canh=2, ban_le="L", ke=0),
    "treo": dict(ten="Tủ treo", nhom="Tủ treo", w=600, h=900, d=300, chan=0, y=1500, canh=2, ban_le="L", ke=1),
    "hut_mui": dict(ten="Tủ treo hút mùi (rangehood)", nhom="Tủ treo", w=900, h=800, d=350, chan=0, y=1500, canh=2, ban_le="L", ke=1, kieu_hm="undermount", ma_may="", cat_w=862, cat_d=262, cat_truoc=40, buong=350),
    "cao": dict(ten="Tủ cao / pantry", nhom="Tủ cao", w=600, h=2270, d=579, chan=130, canh=2, ban_le="L", ke=4, ke_cd=1),
    "lo_nuong": dict(ten="Tủ lò nướng (oven tower)", nhom="Tủ cao", w=600, h=2270, d=579, chan=130, canh=1, ban_le="L", ke=2, hoc_duoi=2, lo_y=330, lo_cao=595, lo2_cao=380),
    "tu_ao": dict(ten="Tủ áo", nhom="Tủ cao", w=900, h=2270, d=579, chan=130, canh=2, ban_le="L", ke=1, ke_cd=1, thanh_treo=True),
    "ke_mo": dict(ten="Kệ mở", nhom="Khác", w=600, h=900, d=300, chan=0, y=1500, ke=0, ke_cd=1, vl_thung="MAU16"),
    "tam": dict(ten="Tấm rời (hông / filler / kicker)", nhom="Khác", w=16, h=860, d=580, chan=0, huong="hong", vl_thung="MAU16"),
    "mat_da": dict(ten="Mặt đá / benchtop", nhom="Khác", w=2400, h=40, d=600, chan=0, y=860, day_da=40),
    "may_rua": dict(ten="Máy rửa chén (dishwasher)", nhom="Thiết bị", w=600, h=730, d=560, chan=130, mr_kieu="am", mr_bang=120),
    "tu_lanh": dict(ten="Tủ lạnh (fridge)", nhom="Thiết bị", w=600, h=2270, d=579, chan=130, tl_kieu="am", tl_cao=1780, tl_chia=0, tl_ban_le="co_dinh", canh=1, ban_le="L", ke=0),
    "thiet_bi": dict(ten="Thiết bị khác (khối chừa chỗ)", nhom="Thiết bị", w=600, h=860, d=580, chan=0),
    "tu_do": dict(ten="Đồ rời (nhập từ file chi tiết)", nhom="Khác", w=100, h=100, d=100, chan=0, an=True, chi_tiet=[]),
    "goc_l": dict(ten="Tủ góc L (corner)", nhom="Tủ dưới", w=900, h=730, d=900, chan=130, canh=2, ke=1),
    "goc_mu": dict(ten="Tủ góc mù (blind corner)", nhom="Tủ dưới", w=1100, h=730, d=560, chan=130, canh=1, ke=1, cua_w=500, mu_ben="L"),
    "cong": dict(ten="Tủ cong bo cạnh (đầu hàng)", nhom="Tủ dưới", w=450, h=730, d=560, chan=130, ke=1, cong_ben="R"),
}
CHUNG = dict(vl_thung="HMR16", vl_mat="MAU16", mo="tay_nam", kieu_canh="phang", sl_thanh=True, x=0, y=0, z=0, goc=0)
CO_CANH = ("duoi_canh", "duoi_hoc", "duoi_chau", "duoi_keo", "treo", "hut_mui", "cao", "tu_ao", "lo_nuong", "may_rua", "tu_lanh", "goc_l", "goc_mu", "cong")
TU_CAO = ("cao", "tu_ao", "lo_nuong", "tu_lanh"); TU_TREO = ("treo", "hut_mui", "ke_mo"); TU_DUOI = ("duoi_canh", "duoi_hoc", "duoi_chau", "duoi_keo", "may_rua", "goc_l", "goc_mu", "cong")
tl_roi = lambda t: t.get("loai") == "tu_lanh" and t.get("tl_kieu") == "roi"          # tủ lạnh rời: chỉ là khoảng chừa, không có thùng
PHU_KIEN_KEO = {"thung_rac": "Thùng rác kéo (BIN)", "ke_gia_vi": "Kệ gia vị kéo (spice rack)", "ke_keo": "Rổ / kệ kéo"}
THAM_SO = [  # (khoá, nhãn, kiểu, áp dụng cho)
    ("ten", "Tên", "text", None), ("w", "Rộng", "mm", None), ("h", "Cao", "mm", None), ("d", "Sâu", "mm", None),
    ("x", "Vị trí X", "mm", None), ("y", "Cao sàn", "mm", None), ("z", "Cách tường", "mm", None),
    ("goc", "Xoay", [0, 90, 180, 270], None), ("chan", "Chân tủ", "mm", ("duoi_canh", "duoi_hoc", "duoi_chau", "duoi_keo", "cao", "tu_ao", "lo_nuong", "may_rua", "tu_lanh", "goc_l", "goc_mu", "cong")),
    ("tach", "Tách 2 thùng – thùng dưới cao (0 = 1 thùng)", "mm", ("cao", "tu_ao")),
    ("cua_w", "Cửa rộng (phần còn lại là mặt mù)", "mm", ("goc_mu",)), ("mu_ben", "Mặt mù bên", ["L", "R"], ("goc_mu",)),
    ("cong_ben", "Bo cong bên", ["L", "R"], ("cong",)),
    ("mr_kieu", "Kiểu máy rửa chén", ["am", "ban_am", "roi"], ("may_rua",)), ("mr_bang", "Bảng điều khiển cao (bán âm)", "mm", ("may_rua",)),
    ("tl_kieu", "Kiểu tủ lạnh", ["am", "roi"], ("tu_lanh",)), ("tl_cao", "Hộc tủ lạnh cao", "mm", ("tu_lanh",)), ("tl_chia", "Cửa dưới cao (0 = 1 cửa suốt)", "mm", ("tu_lanh",)),
    ("tl_ban_le", "Bản lề cửa tủ lạnh", ["co_dinh", "truot"], ("tu_lanh",)),
    ("phu_kien", "Phụ kiện bên trong", ["thung_rac", "ke_gia_vi", "ke_keo"], ("duoi_keo",)),
    ("canh", "Số cánh", [0, 1, 2], ("duoi_canh", "duoi_chau", "treo", "hut_mui", "cao", "tu_ao", "lo_nuong", "tu_lanh")),
    ("ban_le", "Bản lề (1 cánh)", ["L", "R"], ("duoi_canh", "duoi_chau", "treo", "hut_mui", "cao", "tu_ao", "lo_nuong", "tu_lanh")),
    ("hoc_duoi", "Ngăn kéo dưới lò (0 = cánh)", [0, 1, 2, 3], ("lo_nuong",)), ("lo_y", "Đáy hộc lò (từ đáy tủ)", "mm", ("lo_nuong",)), ("lo_cao", "Hộc lò cao", "mm", ("lo_nuong",)), ("lo2_cao", "Hộc vi sóng cao (0 = không)", "mm", ("lo_nuong",)),
    ("kieu_hm", "Kiểu hút mùi", ["undermount", "slide", "canopy"], ("hut_mui",)), ("ma_may", "Mã máy hút mùi (tự tra lỗ khoét)", "txt", ("hut_mui",)), ("cat_w", "Lỗ khoét đáy rộng", "mm", ("hut_mui",)), ("cat_d", "Lỗ khoét đáy sâu", "mm", ("hut_mui",)),
    ("cat_truoc", "Lỗ khoét cách mặt trước", "mm", ("hut_mui",)), ("buong", "Buồng máy cao (tới kệ cố định)", "mm", ("hut_mui",)),
    ("hoc", "Số ngăn kéo", [1, 2, 3, 4, 5], ("duoi_hoc",)), ("hoc_cao", "Cao mặt hộc từ trên xuống (vd 145,255 – còn lại tự chia)", "text", ("duoi_hoc",)), ("ray", "Loại hộc", ["tandembox", "go"], ("duoi_hoc",)),
    ("sl_giua", "Shadowline giữa hộc", "bool", ("duoi_hoc",)),
    ("ke", "Kệ di động", [0, 1, 2, 3, 4, 5, 6], ("duoi_canh", "duoi_chau", "treo", "hut_mui", "cao", "tu_ao", "lo_nuong", "ke_mo", "tu_lanh", "goc_l", "goc_mu", "cong")),
    ("ke_cd", "Kệ cố định", [0, 1, 2, 3, 4], ("cao", "tu_ao", "ke_mo")),
    ("thanh_treo", "Thanh treo đồ", "bool", ("tu_ao",)),
    ("mo", "Kiểu mở", ["tay_nam", "shadowline", "push"], CO_CANH),
    ("kieu_canh", "Kiểu cánh", ["phang", "shaker"], CO_CANH),
    ("sl_thanh", "Thanh shadowline 50 cùng màu cánh", "bool", ("duoi_canh", "duoi_hoc", "duoi_chau", "duoi_keo", "cao", "tu_ao", "lo_nuong", "may_rua", "tu_lanh", "goc_l", "goc_mu", "cong")),
    ("day_da", "Dày mặt đá", list(DA_DAY), ("mat_da",)),
    ("huong", "Hướng tấm", ["hong", "dung", "nam"], ("tam",)),
    ("vl_thung", "Ván thùng", "vl", ("duoi_canh", "duoi_hoc", "duoi_chau", "duoi_keo", "treo", "hut_mui", "cao", "tu_ao", "lo_nuong", "ke_mo", "tam", "tu_lanh", "goc_l", "goc_mu", "cong")),
    ("vl_mat", "Ván cánh/mặt", "vl", CO_CANH),
]


def tu_moi(loai, **kw):
    t = dict(CHUNG); t.update(THU_VIEN[loai]); t["loai"] = loai
    for k in ("nhom",): t.pop(k, None)
    t.update(kw)
    if "mo" not in kw and ("shadowline" in kw or "tay_nam" in kw):
        t["mo"] = "shadowline" if kw.get("shadowline") else ("push" if kw.get("tay_nam") is False else "tay_nam")
    t.pop("shadowline", None); t.pop("tay_nam", None)
    return t


# ---------------------------------------------------------------- tiện ích miếng ván
def r1(v): return round(v + 0.0, 1)


# máy hút mùi âm tủ: mã -> lỗ khoét đáy + yêu cầu lòng tủ (lấy từ tờ hướng dẫn lắp của hãng; thêm model mới vào đây)
MAY_HUT_MUI = {
    "KSGAU9P4MB": dict(ten="Smeg KSGAU9P4MB 90cm undermount", cat_w=861, cat_d=255, cat_truoc=50, long_min=861, sau_min=310, ong=150, nguon="doc.smeg.it 914780208 (KSG9)"),
    "CV-MAC-DINH": dict(ten="Mặc định Cabinet Vision #14 (pocket 862 x 262)", cat_w=862, cat_d=262, cat_truoc=40, long_min=0, sau_min=0, ong=150, nguon="MN Joinery.cvc #416"),
}


def tra_may(ma):
    m = re.sub(r"[^0-9A-Za-z-]", "", str(ma or "")).upper()
    return (m, MAY_HUT_MUI.get(m)) if m else ("", None)


def mieng(name, vl, w, h, box, holes=(), edges=(), e45=(), note="", poly=None, loai="thung", anim=None, rot=None):
    w, h = round(w, 2), round(h, 2)
    if poly is None:
        poly = [(w, h), (w, 0.0), (0.0, 0.0), (0.0, h)] if w >= h else [(w, 0.0), (0.0, 0.0), (0.0, h), (w, h)]
    return dict(name=name, vl=vl, w=w, h=h, holes=[(r1(a), r1(b), c, d) for a, b, c, d in holes], grooves=[], poly=poly,
                edges=[e for e in edges if e not in e45], e45=list(e45), note=note,
                rot=(not VAT_LIEU[vl]["van"]) if rot is None else rot, box=[round(v, 2) for v in box], loai=loai, anim=anim, cut=True)


def ao(name, box, mau, anim=None, loai="ao"):
    """khối chỉ để nhìn (không cắt): chân tủ, ray kim loại, thiết bị, mặt đá"""
    return dict(name=name, box=[round(v, 2) for v in box], mau=mau, anim=anim, loai=loai, cut=False)


def tach_khoi_hong(p):
    """3D: hông có khoét shadowline -> tách thành nhiều khối để hình 3D thấy chỗ khoét (trước đây vẽ nguyên khối nên lộ cạnh trắng trong rãnh)."""
    x, y, z, dx, dy, dz = p["box"]; poly = p.get("poly") or []
    if len(poly) <= 4 or abs(dy - p["w"]) > .5 or abs(dz - p["h"]) > .5: return [p["box"]]
    mir = abs(poly[0][0] - p["w"]) < .01
    us = sorted({round(u, 3) for u, v in poly})
    out = []
    for a, b in zip(us, us[1:]):
        um = (a + b) / 2; vs = []
        for (u1, v1), (u2, v2) in zip(poly, poly[1:] + poly[:1]):
            if (u1 - um) * (u2 - um) < 0: vs.append(v1 + (v2 - v1) * (um - u1) / (u2 - u1))
        if len(vs) < 2: continue
        v0, v1_ = min(vs), max(vs)
        y0 = (p["w"] - b) if mir else a
        out.append([x, round(y + y0, 2), round(z + v0, 2), dx, round(b - a, 2), round(v1_ - v0, 2)])
    return out or [p["box"]]


def poly_hong(H, D, T, notches, mirror):
    """hông tủ có khoét shadowline ở mép trước (y = D): notches = [(x0, x1)], khoét sâu T, cắt suốt."""
    pts = [(0.0, 0.0), (0.0, D)]
    for a, b in sorted(notches):
        if a <= 0.01: pts[-1] = (0.0, D - T)
        else: pts += [(a, D), (a, D - T)]
        pts += [(b, D - T)] if b >= H - 0.01 else [(b, D - T), (b, D)]
    if not notches or sorted(notches)[-1][1] < H - 0.01: pts.append((H, D))
    pts.append((H, 0.0))
    if mirror: pts = [(round(H - x, 3), y) for x, y in pts]
    return [(round(x, 3), round(y, 3)) for x, y in pts]


def so_ban_le(hd):
    return 2 if hd <= 900 else 3 if hd <= 1500 else 4 if hd <= 2000 else 5


def tam_ban_le(hd):
    n = so_ban_le(hd)
    return [r1(100 + k * (hd - 200) / (n - 1)) for k in range(n)]


def lo_canh(hd, wd, vl, ban_le):
    """chén bản lề Ø35 + 2 chốt Ø8 (job 75: ván màu 16 tâm 21.2 / chốt 30.8; MDF 18 tâm 22.5 / chốt 32)"""
    cy, dy = (22.5, 32.0) if vl == "MDF18" else (21.2, 30.8)
    hs = []
    for x in tam_ban_le(hd):
        hs += [(x, cy, 35.0, 14.0), (x - 22.5, dy, 8.0, 12.0), (x + 22.5, dy, 8.0, 12.0)]
    if ban_le == "R": hs = [(x, wd - y, d, p) for x, y, d, p in hs]
    return hs


def mat_ngoai(t):
    """(vật liệu mặt, shaker?, ghi chú shaker)"""
    if t.get("kieu_canh") == "shaker":
        return "MDF21", True, "SHAKER 21mm sơn PU – nhờ Huân ra chương trình phay lòng (Studio chưa tự phay)"
    return t["vl_mat"], False, ""


def trang_tri(out_ao, box, shaker, tay, an, ngang=False, vi_tri="tren"):
    """khối chỉ để nhìn trên 1 cánh / mặt hộc: khung shaker nổi 3mm, tay nắm thanh"""
    x, y, z, sx, sy, sz = box; zf = z + sz
    if shaker and sx > 190 and sy > 190:
        k = 65.0
        for bx in ((x, y, zf, k, sy, 3), (x + sx - k, y, zf, k, sy, 3), (x + k, y, zf, sx - 2 * k, k, 3), (x + k, y + sy - k, zf, sx - 2 * k, k, 3)):
            out_ao.append(ao("Khung shaker", bx, None, anim=an, loai="khung"))
    if tay:
        if ngang: bx = (x + sx / 2 - 80, y + sy - 52, zf, 160, 12, 30)
        else:
            hx = (x + sx - 42) if tay == "R" else (x + 30)
            hy = y + (60 if vi_tri == "duoi" else (sy * 0.46 if vi_tri == "giua" else sy - 60 - 150))
            bx = (hx, hy, zf, 12, 150, 30)
        out_ao.append(ao("Tay nắm", bx, "#3b3d42", anim=an, loai="tay"))


def cac_canh(t, so, parts, pk, cb, lo_trai, lo_phai, y0=None, hd=None, out_ao=None):
    """cánh phủ ngoài: hở 1.5 quanh, khe 3 giữa 2 cánh. Trả về lỗ đế bản lề cho hông trái / phải."""
    n = int(t.get("canh", 0) or 0)
    if n <= 0: return
    W, H, D = t["w"], t["h"], t["d"]; vm, shaker, ghi = mat_ngoai(t); tf = VAT_LIEU[vm]["lz"]
    sl = bool(t.get("shadowline"))
    y0 = HO if y0 is None else y0
    hd = (H - y0 - (SL_CUA if sl else HO)) if hd is None else hd
    wd = (W - 2 * HO) if n == 1 else (W - 2 * HO - KHE) / 2
    if wd > 620: cb.append(f"#{so}: cánh rộng {wd:.0f} > 600, nên chia 2 cánh hoặc giảm bề rộng")
    for i in range(n):
        bl = t.get("ban_le", "L") if n == 1 else ("L" if i == 0 else "R")
        holes = lo_canh(hd, wd, vm, bl); e45 = (); note = ghi
        if sl:
            if vm in ("MDF18", "MDF21"): note = (note + " | " if note else "") + "CẮT 45° CẠNH TRÊN (shadowline) – chưa tự phay, kiểm tay"
            else:
                e45 = ("R",); holes.append((hd - 10, wd / 2, 5.0, 1.0)); note = "Nẹp 45° cạnh có chấm Ø5 (cạnh trên)"
        edges = () if vm in ("MDF18", "MDF21") else ("T", "B", "L", "R")
        x0 = HO + i * (wd + KHE); box = (x0, y0, D, wd, hd, tf)
        an = dict(kieu="cua", ban_le=bl, px=x0 if bl == "L" else x0 + wd, pz=D)
        parts.append(mieng(f"Cánh {'shaker ' if shaker else ''}{'trái' if bl == 'L' else 'phải'}", vm, hd, wd, box, holes, edges, e45, note, loai="canh", anim=an, rot=False))
        if out_ao is not None:
            trang_tri(out_ao, box, shaker, ("R" if bl == "L" else "L") if t.get("tay_nam") else None, an,
                      vi_tri="duoi" if (t["loai"] in TU_TREO or (t["loai"] in ("lo_nuong", "tu_lanh") and y0 > 300)) else "giua" if t["loai"] in ("cao", "tu_ao") else "tren")
        plates = [(y0 + c - 16, D - 37, 5.0, 12.0) for c in tam_ban_le(hd)] + [(y0 + c + 16, D - 37, 5.0, 12.0) for c in tam_ban_le(hd)]
        (lo_trai if bl == "L" else lo_phai).extend(plates)
        pk["Bản lề giảm chấn + đế"] += so_ban_le(hd)
        if t.get("tay_nam"): pk["Tay nắm"] += 1
        if t.get("mo") == "push": pk["Nhấn mở (push latch)"] += 1


def vl_phu(t):
    """vật liệu cho panel / kickface / thanh shadowline: cùng màu cánh. Cánh shaker (MDF21 sơn) -> tấm phụ MDF18 sơn cùng màu."""
    return "MDF18" if t.get("kieu_canh") == "shaker" else t.get("vl_mat", "MAU16")


def thanh_shadowline(t, parts, notches, x0=None, x1=None):
    """anh Tan 19/11: chỗ khoét shadowline phải có thanh 50mm cùng màu cánh chèn vào (hoặc anh chọn chèn loại khác -> tắt).
    anh Tan 20/11: thanh phải CHẠM 2 HÔNG (nằm lọt giữa 2 hông, ngay sau mặt khoét) để bắn vít từ hông vào đầu thanh – như top stretcher SHDWLNE của CV."""
    if not notches or t.get("sl_thanh") is False: return
    vm = vl_phu(t); tf = VAT_LIEU[vm]["lz"]; T = VAT_LIEU[t["vl_thung"]]["lz"]; X = T + 0.5
    x0 = T if x0 is None else x0; x1 = t["w"] - T if x1 is None else x1; D = t["d"]
    zr = D - T - tf                                             # mặt trước thanh = đáy rãnh khoét (lùi T so với mặt trước hông)
    for a, b in notches:
        parts.append(mieng("Thanh shadowline 50 (cùng màu cánh)", vm, x1 - x0, b - a, (x0, a, zr, x1 - x0, b - a, tf), (), ("B",) if vm not in ("MDF18", "MDF21") else (),
                           note="Lọt giữa 2 hông, ngay sau mặt khoét shadowline – bắt vít từ 2 hông vào đầu thanh", loai="tam", rot=True))
        H = t["h"]; vit = [((a + b) / 2, zr + tf / 2, 5.0, X)]
        for p in parts:                                         # lỗ vít trên 2 hông bắt vào đầu thanh
            if p["name"].startswith("Hông trái") and abs(p["box"][0]) < 1 and abs(x0 - T) < 1: p["holes"] += [(r1(u), r1(v), d, q) for u, v, d, q in vit]
            elif p["name"].startswith("Hông phải") and abs(x1 - (t["w"] - T)) < 1: p["holes"] += [(r1(H - u), r1(v), d, q) for u, v, d, q in vit]


def lo_chot_ke(tam_x, D, T):
    hs = []
    for c in tam_x:
        for j in range(-2, 3):
            hs += [(c + 32 * j, T + 40.0, 5.0, 12.0), (c + 32 * j, D - 49.0, 5.0, 12.0)]
    return hs


# ---------------------------------------------------------------- thùng kiểu A: tủ dưới (deck + hậu đứng trên deck + thanh giằng trước)
def thung_duoi(t, so, parts, pk, cb, lo_trai, lo_phai, notches, giang_giua=()):
    W, H, D = t["w"], t["h"], t["d"]; vl = t["vl_thung"]; T = VAT_LIEU[vl]["lz"]; X = T + 0.5; iw = W - 2 * T
    sl = bool(t.get("shadowline")); sld = T if sl else 0.0
    base = [(T / 2, y, 5.0, X) for y in (50.0, r1(D / 2 - 0.5), D - 49.0)]                       # deck
    base += [(x, T / 2, 5.0, X) for x in (66.4, r1((66.4 + H - 50) / 2), H - 50.0)]              # hậu
    base += [(H - 25.0, D - sld - 25.2, 5.0, X)]                                                  # thanh giằng trước
    base += [(g + 24.0, D - sld - 25.2, 5.0, X) for g in giang_giua]                             # giằng giữa hộc
    left = base + lo_trai
    right = [(H - x, y, d, p) for x, y, d, p in base + lo_phai]
    note = ("Shadowline: khoét 50 x %.1f mép trước" % T) if notches else ""
    ed = ("T",)
    parts.append(mieng("Hông trái", vl, H, D, (0, 0, 0, T, H, D), left, ed, note=note, poly=poly_hong(H, D, T, notches, False) if notches else None))
    parts.append(mieng("Hông phải", vl, H, D, (W - T, 0, 0, T, H, D), right, ed, note=note, poly=poly_hong(H, D, T, notches, True) if notches else None))
    parts.append(mieng("Đáy (deck)", vl, D, iw, (T, 0, 0, iw, T, D), [(T / 2, y, 5.0, 12.0) for y in (50.0, r1(iw / 2), iw - 50.0)], ("R",)))
    parts.append(mieng("Hậu", vl, H - T, iw, (T, T, 0, iw, H - T, T), (), (), loai="hau"))
    zg = D - sld - 25.2 - T / 2
    parts.append(mieng("Thanh giằng trên", vl, 48, iw, (T, H - 48, zg, iw, 48, T), (), ("R",)))
    for g in giang_giua:
        parts.append(mieng("Thanh giằng giữa hộc", vl, 48, iw, (T, g, zg, iw, 48, T), (), ("R",)))
    pk["Vít 4x50 (ráp thùng)"] += 14 + 2 * len(giang_giua)
    thanh_shadowline(t, parts, notches)
    return T, iw


def chan_tu(t, out_ao, pk):
    c = float(t.get("chan", 0) or 0)
    if c > 0:
        out_ao.append(ao("Chân tủ", (0, -c, 0, t["w"], c, t["d"] - 50), "#2f2f31", loai="chan"))


def ke_di_dong(t, so, parts, pk, T, iw, y_lo, y_hi, sau, lo_trai, lo_phai):
    n = int(t.get("ke", 0) or 0)
    if n <= 0: return
    vl = t["vl_thung"]; D = t["d"]; xs = []
    for k in range(n):
        yc = y_lo + (k + 1) * (y_hi - y_lo) / (n + 1); xs.append(yc)
        parts.append(mieng("Kệ di động", vl, sau, iw - 2, (T + 1, yc - T / 2, T, iw - 2, T, sau), (), ("R",), loai="ke"))
    pins = lo_chot_ke(xs, D, T)
    lo_trai.extend(pins); lo_phai.extend(pins)
    pk["Chốt kệ"] += 4 * n


def tu_duoi_canh(t, so):
    parts, aos, pk, cb = [], [], Counter(), []
    lt, lp = [], []
    sl = bool(t.get("shadowline")); T0 = VAT_LIEU[t["vl_thung"]]["lz"]
    cac_canh(t, so, parts, pk, cb, lt, lp, out_ao=aos)
    doors = parts[:]; parts = []
    ke_parts = []
    ke_di_dong(t, so, ke_parts, pk, T0, t["w"] - 2 * T0, T0, t["h"] - 60, t["d"] - T0 - 10, lt, lp)
    thung_duoi(t, so, parts, pk, cb, lt, lp, [(t["h"] - SL_H, t["h"])] if sl else [])
    chan_tu(t, aos, pk)
    return parts + ke_parts + doors, aos, pk, cb


def _canh_rieng(t, so, parts, pk, cb, box, bl, huong, lo_hong, out_ao, ten="Cánh"):
    """1 cánh đơn tại box (x,y,z,sx,sy,sz); huong 'z' = mặt quay ra +z (bình thường), 'x' = mặt quay ra +x (tủ góc).
    Trả lỗ đế bản lề (toạ độ trên hông đứng cạnh bản lề)."""
    vm, shaker, ghi = mat_ngoai(t); x, y, z, sx, sy, sz = box
    hd, wd = sy, (sx if huong == "z" else sz)
    holes = lo_canh(hd, wd, vm, bl); edges = () if vm in ("MDF18", "MDF21") else ("T", "B", "L", "R")
    if huong == "z": an = dict(kieu="cua", ban_le=bl, px=x if bl == "L" else x + sx, pz=z)
    else: an = dict(kieu="cua", ban_le="R" if bl == "L" else "L", px=x, pz=z if bl == "L" else z + sz)
    parts.append(mieng(f"{ten} {'shaker ' if shaker else ''}{'trái' if bl == 'L' else 'phải'}", vm, hd, wd, box, holes, edges, (), ghi, loai="canh", anim=an, rot=False))
    if out_ao is not None and huong == "z": trang_tri(out_ao, box, shaker, ("R" if bl == "L" else "L") if t.get("tay_nam") else None, an, vi_tri="tren")
    lo_hong.extend([(y + c + s_, (z + sz if huong == "z" else x + sx) - 37, 5.0, 12.0) for c in tam_ban_le(hd) for s_ in (-16, 16)])
    pk["Bản lề giảm chấn + đế"] += so_ban_le(hd)
    if t.get("tay_nam"): pk["Tay nắm"] += 1


def tu_goc_l(t, so):
    """TỦ GÓC L: thùng chữ L (sâu 560 hai nhánh), 2 cánh GẬP (bi-fold) vuông góc gặp nhau ở góc trong – theo CV "90 Deg Floor Corner" (MN Joinery)."""
    parts, aos, pk, cb = [], [], Counter(), []
    W, H, D = t["w"], t["h"], t["d"]; vl = t["vl_thung"]; T = VAT_LIEU[vl]["lz"]; X = T + 0.5; S = 560.0 - T
    if W < 900 or D < 900: cb.append(f"#{so}: tủ góc L cần tối thiểu 900 x 900 (đang {W:.0f} x {D:.0f}) – đã dựng theo 900"); W = max(W, 900.0); D = max(D, 900.0); t = dict(t, w=W, d=D)
    sl = bool(t.get("shadowline")); nt = [(H - SL_H, H)] if sl else []
    # cánh: mặt 1 quay ra +z tại z = 560 (x từ 560+tru..W), mặt 2 quay ra +x tại x = 560 (z từ 560+tru..D)
    vm, shaker, ghi = mat_ngoai(t); tf = VAT_LIEU[vm]["lz"]; hd = H - HO - (SL_CUA if sl else HO)
    # CÁNH GẬP (bi-fold) theo Cabinet Vision "90 Deg Floor Corner": không có trụ góc, 2 cánh gặp nhau ở góc trong.
    #  cánh A (mặt nhánh dọc) bắt vào HÔNG CUỐI bằng bản lề góc 90 + đế 90; cánh B (mặt nhánh dài) bắt vào lưng cánh A bằng bản lề cánh đôi + đế cánh đôi
    w2 = D - HO - 560; w1 = W - HO - (560 + tf + KHE)
    if w1 < 250 or w2 < 250: cb.append(f"#{so}: cánh tủ góc quá hẹp ({w1:.0f} / {w2:.0f}) – tăng kích thước tủ")
    doors = []; lo_cuoi = []
    _canh_rieng(t, so, doors, pk, cb, (560, HO, 560, tf, hd, w2), "R", "x", [], aos, "Cánh góc A (bắt hông)")
    cA = doors[-1]; cA["anim"]["id"] = "A"
    lo_cuoi += [(HO + c + s_, 560 - 37.0, 5.0, 12.0) for c in tam_ban_le(hd) for s_ in (-16, 16)]          # đế 90 trên hông cuối
    cA["holes"] += [(r1(c + s_), 39.0, 5.0, 10.0) for c in tam_ban_le(hd) for s_ in (-16, 16)]            # đế cánh đôi bắt lưng cánh A
    xb = 560 + tf + KHE
    _canh_rieng(t, so, doors, pk, cb, (xb, HO, 560, w1, hd, tf), "L", "z", [], aos, "Cánh góc B (gập vào cánh A)")
    an = doors[-1]["anim"]; an.clear(); an.update(kieu="gap", cha="A", px=560 + tf, pz=560 + tf, s=-1)     # tay nắm dùng chung dict -> gập theo
    nb = so_ban_le(hd); pk["Bản lề giảm chấn + đế"] -= 2 * nb
    pk["Bản lề góc 90° + đế 90 (cánh A bắt hông – CV HNG90)"] += nb
    pk["Bản lề cánh đôi + đế cánh đôi (bi-fold, cánh B – CV S_HNGDD)"] += nb
    # thùng
    base = [(T / 2, y, 5.0, X) for y in (50.0, 280.0, 510.0)] + [(x, T / 2, 5.0, X) for x in (66.4, (66.4 + H - 50) / 2, H - 50.0)] + [(H - 25.0, S - 25.2 + T - (T if sl else 0), 5.0, X)]
    parts.append(mieng("Hông trái (sát tường)", vl, H, D, (0, 0, 0, T, H, D), base + [(x, D - 560 + y, d, p) for x, y, d, p in base if y <= 560], ("T",), note="Hông dài theo tường bên", poly=poly_hong(H, D, T, nt, False) if nt else None))
    parts.append(mieng("Hông phải", vl, H, 560, (W - T, 0, 0, T, H, 560), [(H - x, y, d, p) for x, y, d, p in base], ("T",), poly=poly_hong(H, 560, T, nt, True) if nt else None))
    parts.append(mieng("Hông cuối", vl, H, 560, (0, 0, D - T, 560, H, T), [(H - x, y, d, p) for x, y, d, p in base + lo_cuoi], ("T",), note="Hông đầu nhánh dọc – có đế bản lề góc 90 cho cánh A", poly=poly_hong(H, 560, T, nt, True) if nt else None))
    parts.append(mieng("Hậu dài", vl, H - T, W - 2 * T, (T, T, 0, W - 2 * T, H - T, T), (), (), loai="hau"))
    parts.append(mieng("Hậu nhánh", vl, H - T, D - 560 - T, (0, T, 560, T, H - T, D - 560 - T), (), (), loai="hau", note="Hậu nhánh dọc, bắt mặt trong hông trái"))
    # ĐÁY + KỆ = 1 MIẾNG CHỮ L LIỀN (CV "90 Deg Floor Corner": Deck 867.6 x 867.6 một miếng) – anh Tan 20/11
    wl, hl, ul = W - 2 * T, D - T, 560 - 2 * T
    RG = 20.0                                                     # góc trong bo R20 như CV (dễ dán nẹp) – anh Tan 20/11
    def chu_l(u_, s_, w_, h_):
        arc = [(round(u_ + RG + RG * math.cos(a), 3), round(s_ + RG + RG * math.sin(a), 3)) for a in [math.pi + k * (math.pi / 2) / 8 for k in range(9)]]
        return [(u_, h_)] + arc + [(w_, s_), (w_, 0.0), (0.0, 0.0), (0.0, h_)]
    pl = chu_l(ul, S, wl, hl)
    p = mieng("Đáy chữ L (1 miếng liền)", vl, wl, hl, (T, 0, 0, wl, T, hl), (), ("R",), poly=pl, note="Cắt 1 miếng chữ L như CV – không ghép, góc trong bo R20")
    p["pl3d"] = dict(ax="y", o=[T, 0, 0], pts=pl, d=T); parts.append(p)
    parts.append(mieng("Thanh giằng trên 1", vl, 48, W - 560 - T, (560, H - 48, S - 25.2 - T / 2 + T - (T if sl else 0), W - 560 - T, 48, T), (), ("R",)))
    parts.append(mieng("Thanh giằng trên 2", vl, 48, D - 560 - T, (S - 25.2 - T / 2 + T - (T if sl else 0), H - 48, 560, T, 48, D - 560 - T), (), ("R",)))
    n = int(t.get("ke", 0) or 0)
    for k in range(n):
        yc = T + (k + 1) * (H - 60 - T) / (n + 1)
        wk, hk, uk, sk = W - 2 * T - 2, D - 2 * T - 10, 560 - 2 * T - 2, S - 10
        p = mieng(f"Kệ chữ L {k + 1} (1 miếng liền)", vl, wk, hk, (T + 1, yc, T, wk, T, hk), (), ("R",), loai="ke",
                  poly=chu_l(uk, sk, wk, hk), note="Cắt 1 miếng chữ L như CV, góc trong bo R20")
        p["pl3d"] = dict(ax="y", o=[T + 1, yc, T], pts=p["poly"], d=T); parts.append(p)
    pk["Chốt kệ"] += 8 * n; pk["Vít 4x50 (ráp thùng)"] += 28
    thanh_shadowline(dict(t, d=560.0), parts, nt, x0=560.0, x1=W - T)
    if sl: cb.append(f"#{so}: tủ góc shadowline – thanh 50 cần cắt cho cả 2 mặt, kiểm tay")
    aos.append(ao("Chân tủ", (0, -float(t.get("chan") or 0), 0, W, float(t.get("chan") or 0), 560 - 50), "#2f2f31", loai="chan"))
    aos.append(ao("Chân tủ", (0, -float(t.get("chan") or 0), 560, 560 - 50, float(t.get("chan") or 0), D - 560), "#2f2f31", loai="chan"))
    return parts + doors, aos, pk, cb


def tu_goc_mu(t, so):
    """TỦ GÓC MÙ (blind corner) theo CV "Blum - 1 Door Floor - BLIND - Left/Right" (MN Joinery #415 / #40):
    mặt mù cùng màu cánh bắt chết phía bên mù, cánh BẢN LỀ VỀ PHÍA MẶT MÙ, đế bản lề bắt vào LƯNG MẶT MÙ (không khoan hông);
    sau mặt mù có tấm lót (ván thùng) để bắt vít mặt mù, chừa 100 trước mép cánh."""
    parts, aos, pk, cb = [], [], Counter(), []
    W, H, D = t["w"], t["h"], t["d"]; T0 = VAT_LIEU[t["vl_thung"]]["lz"]; sl = bool(t.get("shadowline"))
    cw = float(t.get("cua_w") or 500); mu = W - cw; ben = t.get("mu_ben", "L")
    if mu < 150: cb.append(f"#{so}: phần mù chỉ {mu:.0f} – tủ góc mù nên rộng hơn (CV: 1100 với cửa 500)")
    vm, shaker, ghi = mat_ngoai(t); tf = VAT_LIEU[vm]["lz"]; hd = H - HO - (SL_CUA if sl else HO)
    edges = () if vm in ("MDF18", "MDF21") else ("T", "B", "L", "R")
    xmep = mu if ben == "L" else cw                        # đường chia mặt mù / cánh
    ws = mu - HO - KHE / 2; xs = HO if ben == "L" else cw + KHE / 2
    doors = []
    bl = "L" if ben == "L" else "R"                        # bản lề luôn ở cạnh giáp mặt mù
    x0 = xmep + KHE / 2 if ben == "L" else HO
    lt, lp = [], []
    if int(t.get("canh", 1) or 1) >= 2:                   # 2 cánh: cánh sát mặt mù bản lề vào mặt mù, cánh kia bản lề vào hông
        wd2 = (cw - HO - KHE / 2 - KHE) / 2
        _canh_rieng(t, so, doors, pk, cb, (x0, HO, D, wd2, hd, tf), "L", "z", [] if ben == "L" else lt, aos)
        _canh_rieng(t, so, doors, pk, cb, (x0 + wd2 + KHE, HO, D, wd2, hd, tf), "R", "z", lp if ben == "L" else [], aos)
        pk["Bản lề giảm chấn + đế"] += 0
    else:
        _canh_rieng(t, so, doors, pk, cb, (x0, HO, D, cw - HO - KHE / 2, hd, tf), bl, "z", [], aos)
    dx = (xmep - 22.5) - xs if ben == "L" else (xmep + 22.5) - xs           # tâm đế, đo trên mặt mù (CV: cách đường chia 22.5)
    lo_de = [(r1(c + s_), r1(dx), 5.0, 10.0) for c in tam_ban_le(hd) for s_ in (-16, 16)]
    parts.append(mieng("Mặt mù (cùng màu cánh)", vm, hd, ws, (xs, HO, D, ws, hd, tf), lo_de, edges, (),
                       "Bắt chết vào tấm lót mù. Lưng mặt mù có đế bản lề cho cánh (theo CV)", loai="tam", rot=False))
    pk["Bản lề giảm chấn + đế"] -= so_ban_le(hd); pk["Bản lề + đế bắt lưng mặt mù (blind corner – CV)"] += so_ban_le(hd)
    if not pk["Bản lề giảm chấn + đế"]: del pk["Bản lề giảm chấn + đế"]
    lw = mu - 100 - T0
    if lw > 50:
        xl = T0 if ben == "L" else W - T0 - lw
        parts.append(mieng("Tấm lót mù (sau mặt mù)", t["vl_thung"], H - T0, lw, (xl, T0, D - T0, lw, H - T0, T0), (), ("T",),
                           note="Đứng sát mặt trước thùng, từ hông bên mù tới cách đường chia 100 (CV Blind Panel)", loai="tam"))
    ke = []
    ke_di_dong(t, so, ke, pk, T0, W - 2 * T0, T0, H - 60, D - T0 - 10 - T0, lt, lp)
    thung_duoi(t, so, parts, pk, cb, lt, lp, [(H - SL_H, H)] if sl else [])
    chan_tu(t, aos, pk)
    return parts + ke + doors, aos, pk, cb


def tu_cong(t, so):
    """TỦ CONG BO CẠNH đầu hàng: 1/4 tròn bán kính = rộng tủ, mặt cong uốn từ ván màu xẻ rãnh (QUY-TAC mục 10), nóc/đáy/kệ cắt cung."""
    parts, aos, pk, cb = [], [], Counter(), []
    W, H, D = t["w"], t["h"], t["d"]; vl = t["vl_thung"]; T = VAT_LIEU[vl]["lz"]; R = min(W, D); ben = t.get("cong_ben", "R")
    vm, shaker, ghi = mat_ngoai(t); tf = VAT_LIEU[vm]["lz"]
    if shaker: cb.append(f"#{so}: tủ cong không làm cánh shaker – đổi sang cánh phẳng ván màu")
    if R < 150: cb.append(f"#{so}: bán kính {R:.0f} nhỏ – uốn ván 16 dễ gãy, nên R ≥ 200")
    sl = bool(t.get("shadowline")); hd = H - HO - (SL_CUA if sl else HO)
    cung = dict(cx=0.0 if ben == "R" else W, cz=D - R, r=R, ben=ben)                # tâm cung ở góc sau, phía trong
    # MẶT CONG = 1 tấm ván màu quấn: đoạn thẳng hông (D-R) + cung R, rãnh CHỈ trong vùng cung (cách thư viện Huân "CUC CONG": mũi 10, bước 13, chừa da 1.5)
    # đầu tấm phía trước (cạnh lộ, sát cánh) chừa DUOI mm ván đặc để dán nẹp – anh Tan 20/11
    PITCH, WEB, DUOI = 13.0, 1.5, 19.0
    S = max(D - R, 0.0); La = math.pi / 2 * (R + tf - WEB / 2); L = S + La
    n = max(int((La - DUOI - 5) / PITCH) + 1, 1)
    us = [L - DUOI - 5 - k * PITCH for k in range(n)]                 # tâm rãnh, đo từ đầu sau (u=0 sát tường)
    if ben == "L": us = [L - u for u in us]                           # tủ cong trái: lật tấm, rãnh vẫn ở mặt trong
    p = mieng("Mặt cong (ván màu quấn hông + cung, xẻ rãnh uốn)", vm, L, hd, (0, HO, D - R, W, hd, R), (), ("T", "B", "R" if ben == "R" else "L"), (),
              f"UỐN CONG R{R:.0f}: {n} rãnh Ø10 sâu {tf - WEB:.1f} bước {PITCH:.0f} mặt trong, chỉ trong vùng cung; đoạn thẳng {S:.0f} quấn luôn hông ngoài; "
              f"đầu trước chừa {DUOI:.0f} đặc để dán nẹp; vân theo chiều quấn", loai="canh", rot=False)
    p["grooves"] = [([(round(u, 2), -0.15), (round(u, 2), hd + 0.15)], tf - WEB) for u in us]
    p["cung"] = dict(cung, s=S); p["ngoai"] = False; parts.append(p)        # 3D vẽ 1 khối liền: đoạn thẳng hông + cung (đúng 1 tấm CNC)
    # cốt cong: nóc + đáy + kệ cắt cung (HMR), hông thẳng phía sau và bên trong
    arc = [(R * math.cos(a), R * math.sin(a)) for a in [i * math.pi / 2 / 12 for i in range(13)]]
    poly = [(0.0, 0.0)] + [(round(x, 3), round(y, 3)) for x, y in arc]
    for ten, y in (("Đáy cong", 0.0), ("Nóc cong", H - T)):
        q = mieng(ten, vl, R, R, (0, y, D - R, W, T, R), (), ("R",), poly=poly, note="Cắt cung R%.0f – cốt uốn" % R); q["cung"] = cung; parts.append(q)
    n_ke = int(t.get("ke", 0) or 0)
    for k in range(n_ke):
        yc = T + (k + 1) * (H - 60 - T) / (n_ke + 1)
        q = mieng(f"Kệ cong {k + 1}", vl, R - 10, R - 10, (0, yc, D - R, W - 10, T, R - 10), (), ("R",), poly=[(0.0, 0.0)] + [(round(x * (R - 10) / R, 3), round(y * (R - 10) / R, 3)) for x, y in arc], loai="ke"); q["cung"] = dict(cung, r=R - 10); parts.append(q)
    xs = 0.0 if ben == "R" else W - T
    parts.append(mieng("Hông thẳng", vl, H, D, (xs, 0, 0, T, H, D), [(T / 2, y, 5.0, T + 0.5) for y in (50.0, D / 2, D - 49)] + [(x, T / 2, 5.0, T + 0.5) for x in (66.4, H - 50)], ("T",)))
    parts.append(mieng("Hậu", vl, H - T, W - T, (T if ben == "R" else 0, T, 0, W - T, H - T, T), (), (), loai="hau"))
    if D > R: parts.append(mieng("Hông ngoài HMR (phần thẳng, trong tấm quấn)", vl, H, D - R, (W - T if ben == "R" else 0, 0, 0, T, H, D - R), (), ()))
    pk["Vít 4x50 (ráp thùng)"] += 12; pk["Chốt kệ"] += 4 * n_ke
    if sl: cb.append(f"#{so}: tủ cong shadowline – thanh 50 phải uốn theo, chưa tự tính")
    chan_tu(dict(t, d=D), aos, pk)
    return parts, aos, pk, cb


def tu_duoi_hoc(t, so):
    parts, aos, pk, cb = [], [], Counter(), []
    W, H, D = t["w"], t["h"], t["d"]; vl = t["vl_thung"]; T = VAT_LIEU[vl]["lz"]; iw = W - 2 * T
    vm, shaker, ghi = mat_ngoai(t); tf = VAT_LIEU[vm]["lz"]
    sl = bool(t.get("shadowline")); slg = bool(t.get("sl_giua")) and sl
    n = max(1, int(t.get("hoc", 3) or 3))
    gap = SL_CUA if slg else KHE; top = SL_CUA if sl else HO
    # chiều cao từng mặt hộc: mặc định chia đều; "hoc_cao" = số đo các hộc TRÊN CÙNG trở xuống (vd "145,255"), các hộc còn lại tự chia phần còn lại (anh Tan 20/11)
    rieng = []
    for x in str(t.get("hoc_cao") or "").replace(";", ",").replace("/", ",").split(","):
        try:
            v = float(x)
            if v > 0: rieng.append(v)
        except ValueError: pass
    if len(rieng) > n: n = len(rieng)
    tong = H - HO - top - (n - 1) * gap
    if len(rieng) >= n: rieng = rieng[:n - 1]                          # hộc dưới cùng luôn nhận phần còn lại để tổng khớp chiều cao tủ
    con = tong - sum(rieng)
    if rieng and con / (n - len(rieng)) < 110:
        cb.append(f"#{so}: chiều cao mặt hộc đã nhập ({', '.join(f'{v:g}' for v in rieng)}) quá lớn so với tủ – đã chia đều lại"); rieng = []; con = tong
    hfs = ([con / (n - len(rieng))] * (n - len(rieng))) + rieng[::-1]      # từ dưới lên
    hf = min(hfs)
    if hf < 110: cb.append(f"#{so}: mặt hộc chỉ cao {hf:.0f} – quá thấp, giảm số ngăn kéo")
    NL = max([v for v in RAY_NL if v <= D - T - 3] or [0])
    if not NL: cb.append(f"#{so}: tủ sâu {D:.0f} không đủ cho ray ngắn nhất (270)"); NL = 270
    lt, lp, notches, giang = [], [], ([(H - SL_H, H)] if sl else []), []
    fronts, boxes = [], []
    wf = W - 2 * HO
    for k in range(n):
        hf = hfs[k]; yb = HO + sum(hfs[:k]) + k * gap
        if slg and k < n - 1:
            notches.append((yb + hf - (SL_H - SL_CUA), yb + hf + SL_CUA)); giang.append(yb + hf - (SL_H - SL_CUA) + 1)
        # mặt hộc: x = chiều cao, y = chiều rộng; pát Tandembox Ø10x12 cách 2 cạnh bên 29.9
        up = 96.0 if hf < 250 else 128.0 if hf < 310 else 160.0
        xs = [46.4, 78.4] + ([46.4 + up] if hf >= 46.4 + up + 30 else [])
        holes = [(x, y, 10.0, 12.0) for x in xs for y in (29.9, wf - 29.9)] if t.get("ray", "tandembox") == "tandembox" else []
        e45 = (); note = ghi
        if sl and (slg or k == n - 1):
            if vm in ("MDF18", "MDF21"): note = (note + " | " if note else "") + "CẮT 45° CẠNH TRÊN (shadowline) – chưa tự phay, kiểm tay"
            else: e45 = ("R",); holes.append((hf - 10, wf / 2, 5.0, 1.0)); note = "Nẹp 45° cạnh có chấm Ø5 (cạnh trên)"
        an = dict(kieu="hoc", k=k)
        fronts.append(mieng(f"Mặt hộc {'shaker ' if shaker else ''}{k + 1}", vm, hf, wf, (HO, yb, D, wf, hf, tf), holes, () if vm in ("MDF18", "MDF21") else ("T", "B", "L", "R"), e45, note,
                            loai="mat_hoc", anim=an, rot=False))
        trang_tri(aos, (HO, yb, D, wf, hf, tf), shaker, "N" if t.get("tay_nam") else None, an, ngang=True)
        if t.get("mo") == "push": pk["Nhấn mở (push latch)"] += 1
        run = [(yb + 50.9, y, 5.0, 12.0) for y in (D - 36, D - 132, D - 260, D - (NL - 48)) if y > T + 10]
        lt += run; lp += run
        if t.get("ray", "tandembox") == "tandembox":
            bw, bd = iw - 75, NL - 24.4
            BH = 198.0 if hf >= 310 else 166.0 if hf >= 250 else 134.0 if hf >= 190 else 83.0
            boxes.append(mieng(f"Đáy hộc {k + 1}", vl, bw, bd, (T + 37.5, yb + 28, D - bd, bw, T, bd),
                               [(x, y, 5.0, 12.0) for x in (9.0, bw - 9.0) for y in (16.2, bd - 189.4, bd - 43.4) if y > 0], (), loai="hoc", anim=an))
            boxes.append(mieng(f"Hậu hộc {k + 1}", vl, iw - 87, BH, (T + 43.5, yb + 28 + T, D - bd, iw - 87, BH, T),
                               [(x, y, 5.0, 12.0) for x in (9.0, iw - 87 - 9.0) for y in (7.0, 39.0, 103.0, 135.0, 167.0) if y <= BH - 31], ("T",), loai="hoc", anim=an))
            for sx in (T + 21, W - T - 21 - 13):
                aos.append(ao("Thành hộc kim loại", (sx, yb + 28, D - bd, 13, min(BH, hf - 40), bd), "#c9ccd1", anim=an))
            pk[f"Ray hộc Tandembox {NL} (bộ)"] += 1
        else:  # hộc gỗ trên ray âm LEK SSC09: lòng hộc = lòng tủ - 42, dài = NL - 10, hông hộc dày 16
            hs = float(min(200, max(80, int((hf - 45) // 10) * 10))); ow = iw - 10; ln = NL - 10.0; z0 = D - ln
            sx = T + 5
            boxes.append(mieng(f"Hông hộc {k + 1} trái", vl, ln, hs, (sx, yb + 20, z0, T, hs, ln), (), ("T",), loai="hoc", anim=an))
            boxes.append(mieng(f"Hông hộc {k + 1} phải", vl, ln, hs, (sx + ow - T, yb + 20, z0, T, hs, ln), (), ("T",), loai="hoc", anim=an))
            boxes.append(mieng(f"Đầu hộc {k + 1} trước", vl, ow - 2 * T, hs, (sx + T, yb + 20, D - T, ow - 2 * T, hs, T), (), ("T",), loai="hoc", anim=an))
            boxes.append(mieng(f"Đầu hộc {k + 1} sau", vl, ow - 2 * T, hs - 13, (sx + T, yb + 33, z0, ow - 2 * T, hs - 13, T), (), ("T",), loai="hoc", anim=an,
                               note="Khoét góc dưới 33x13 + lỗ móc ray Ø6 (khoan tay)"))
            boxes.append(mieng(f"Đáy hộc {k + 1}", vl, ow - 2 * T, ln - T, (sx + T, yb + 33 - T, z0, ow - 2 * T, T, ln - T), (), (), loai="hoc", anim=an))
            pk[f"Ray âm LEK SSC09-{NL} (bộ)"] += 1; pk["Vít 4x50 (ráp thùng)"] += 12
        if t.get("tay_nam"): pk["Tay nắm"] += 1
    thung_duoi(t, so, parts, pk, cb, lt, lp, notches, giang)
    chan_tu(t, aos, pk)
    return parts + boxes + fronts, aos, pk, cb


def tu_duoi_keo(t, so):
    """tủ kéo phụ kiện: 1 mặt cao hết tủ bắt vào khung phụ kiện (thùng rác, kệ gia vị) – không bản lề, không kệ.
    Tài liệu hãng: tủ 450 cần lòng 418 (Blum / Hafele / Hailo), mặt cao tối thiểu ~600, sâu tủ tối thiểu 560 với thùng rác."""
    parts, aos, pk, cb = [], [], Counter(), []
    W, H, D = t["w"], t["h"], t["d"]; T = VAT_LIEU[t["vl_thung"]]["lz"]; iw = W - 2 * T
    vm, shaker, ghi = mat_ngoai(t); tf = VAT_LIEU[vm]["lz"]; sl = bool(t.get("shadowline"))
    pk_ten = PHU_KIEN_KEO.get(t.get("phu_kien"), PHU_KIEN_KEO["thung_rac"])
    hf = H - HO - (SL_CUA if sl else HO); wf = W - 2 * HO; an = dict(kieu="hoc", k=0)
    holes = []; e45 = (); note = (ghi + " | " if ghi else "") + f"Bắt mặt vào {pk_ten} theo dưỡng của hãng"
    if sl and vm not in ("MDF18", "MDF21"): e45 = ("R",); holes.append((hf - 10, wf / 2, 5.0, 1.0)); note += " | Nẹp 45° cạnh có chấm Ø5"
    front = mieng(f"Mặt kéo {'shaker ' if shaker else ''}({pk_ten.split(' (')[0]})", vm, hf, wf, (HO, HO, D, wf, hf, tf), holes, () if vm in ("MDF18", "MDF21") else ("T", "B", "L", "R"), e45, note,
                  loai="mat_hoc", anim=an, rot=False)
    trang_tri(aos, (HO, HO, D, wf, hf, tf), shaker, "N" if t.get("tay_nam") else None, an, ngang=True)
    aos.append(ao(pk_ten, (T + 12, 60, D - 500, iw - 24, min(H - 160, 480), 480), "#8d9197", anim=an, loai="thiet_bi"))
    thung_duoi(t, so, parts, pk, cb, [], [], [(H - SL_H, H)] if sl else [])
    chan_tu(t, aos, pk)
    pk[f"{pk_ten} cho tủ {W:.0f} (bộ)"] += 1
    if t.get("tay_nam"): pk["Tay nắm"] += 1
    if t.get("mo") == "push": pk["Nhấn mở (push latch)"] += 1
    if t.get("phu_kien") == "thung_rac":
        if hf < 600: cb.append(f"#{so}: mặt thùng rác cao {hf:.0f} < 600 – nhiều loại thùng rác kéo cần mặt cao tối thiểu 600")
        if D < 560: cb.append(f"#{so}: tủ sâu {D:.0f} < 560 – thùng rác kéo thường cần sâu tối thiểu 560")
    if iw < W - 34: cb.append(f"#{so}: lòng tủ {iw:.1f} – phụ kiện cho tủ {W:.0f} thường cần lòng {W - 32:.0f}, kiểm lại model")
    return parts + [front], aos, pk, cb


# ---------------------------------------------------------------- thùng kiểu B: tủ treo / tủ cao (hậu nằm giữa 2 hông, nóc-đáy-kệ nằm trước hậu)
def tu_hut_mui(t, so):
    """TỦ HÚT MÙI ÂM (undermount, ducted) theo Cabinet Vision "2 Door Rangehood Cab - Undermount - DUCTED" (MN Joinery #416 / CV #14):
    buồng máy cao `buong` dưới kệ cố định; che buồng máy (khấc 50x150 né bản lề); nóc + kệ cố định khoét chữ U rộng 250 cho ống gió,
    chừa dải trước 79; 2 vách ngăn + tấm che ống gió; kệ di động 2 bên; đáy = thanh trước + thanh sau (+ 2 miếng bên) chừa lỗ khoét
    đúng thông số máy (nhập mã máy -> tự tra)."""
    if t.get("kieu_hm") in ("slide", "canopy"):                        # slide-out / fixed / canopy: hộp thường + lỗ khoét (chưa dựng riêng)
        if float(t.get("cat_w") or 0) > t["w"] - 100: t = dict(t, cat_w=490, cat_d=265)        # máy slide-out 60cm (mặc định cũ)
        p_, a_, k_, c_ = tu_hop(t, so); c_.append(f"#{so}: rangehood kiểu {t['kieu_hm']} – Studio dựng hộp + lỗ khoét gần đúng, kiểm với CV"); return p_, a_, k_, c_
    parts, aos, pk, cb = [], [], Counter(), []
    W, H, D = t["w"], t["h"], t["d"]; vl = t["vl_thung"]; T = VAT_LIEU[vl]["lz"]; X = T + 0.5; iw = W - 2 * T; DT = D - T
    vd = vl_phu(t); TD = VAT_LIEU[vd]["lz"]                          # đáy lộ ra dưới -> ván màu cánh
    ma, may = tra_may(t.get("ma_may"))
    cat_w, cat_d, cat_tr = float(t.get("cat_w") or 862), float(t.get("cat_d") or 262), float(t.get("cat_truoc") or 50)
    if may:
        cat_w, cat_d, cat_tr = may["cat_w"], may["cat_d"], may["cat_truoc"]
        if iw < may["long_min"]: cb.append(f"#{so}: {may['ten']} cần lòng tủ ≥ {may['long_min']:.0f}, đang {iw:.0f} – tăng rộng tủ")
        if D < may["sau_min"]: cb.append(f"#{so}: {may['ten']} cần tủ sâu ≥ {may['sau_min']:.0f}, đang {D:.0f}")
    elif ma: cb.append(f"#{so}: chưa có thông số máy '{ma}' trong thư viện – đang dùng lỗ {cat_w:.0f} x {cat_d:.0f} nhập tay, KIỂM tờ lắp của hãng")
    cat_w = min(cat_w, iw)
    if cat_w < iw - 0.5 and (iw - cat_w) / 2 < 20: cat_w = iw                 # miếng bên < 20: bỏ, khoét hết lòng
    RS = DT - cat_tr - cat_d
    if RS < 15: cb.append(f"#{so}: lỗ khoét {cat_d:.0f} + cách trước {cat_tr:.0f} quá sâu so với tủ {D:.0f} (thanh sau còn {RS:.0f}) – đã thu lỗ lại"); RS = 15.0; cat_d = DT - cat_tr - RS
    CH = float(t.get("buong") or 350); FS = 79.0; UW = 250.0
    zk = TD + CH                                                               # mặt dưới kệ cố định
    if zk + T + 150 > H - T: cb.append(f"#{so}: buồng máy {CH:.0f} quá cao so với tủ {H:.0f}"); zk = H - T - 150 - T; CH = zk - TD
    zb = zk + T; tren = H - T - zb; VD = DT - FS
    bay = (iw - UW - 2 * T) / 2
    if bay < 100: cb.append(f"#{so}: tủ hẹp – 2 khoang bên chỉ {bay:.0f} (CV: tủ 950)")
    # ---- cánh (kể cả fingerpull dư xuống)
    lt, lp, doors = [], [], []
    du = float(t.get("_du") or 0)
    if du > 0: cac_canh(t, so, doors, pk, cb, lt, lp, y0=-du, hd=H - HO + du, out_ao=aos)
    else: cac_canh(t, so, doors, pk, cb, lt, lp, out_ao=aos)
    # ---- lỗ vít trên 2 hông (u = cao từ đáy, v = sâu từ lưng)
    v3 = (50.0, DT / 2, DT - 49.0)
    base = [(zk + T / 2, T + v, 5.0, X) for v in v3] + [(H - T / 2, T + v, 5.0, X) for v in v3]
    base += [(TD / 2, T + v, 5.0, X) for v in (15.0, RS - 15.0)] + [(TD / 2, D - cat_tr + v, 5.0, X) for v in (13.0, cat_tr - 13.0)]
    base += [(TD + 150 + 49.0, D - T / 2, 5.0, X), (zk - 51.0, D - T / 2, 5.0, X)]           # che buồng máy
    base += [(66.4 + k * (H - 132.8) / 2, T / 2, 5.0, X) for k in range(3)]                 # hậu
    n_ke = int(t.get("ke", 1) or 0); yke = [zb + (k + 1) * tren / (n_ke + 1) for k in range(n_ke)]
    pins = lo_chot_ke(yke, D, T)
    ed = ("T",)
    parts.append(mieng("Hông trái", vl, H, D, (0, 0, 0, T, H, D), base + pins + lt, ed))
    parts.append(mieng("Hông phải", vl, H, D, (W - T, 0, 0, T, H, D), [(H - x, y, d, p) for x, y, d, p in base + pins + lp], ed))
    parts.append(mieng("Hậu", vl, H, iw, (T, 0, 0, iw, H, T), (), (), loai="hau"))
    # ---- nóc + kệ cố định khoét U (u = ngang, v = sâu từ lưng)
    a = bay + T; b = a + UW
    u_poly = [(iw, DT), (iw, 0.0), (b, 0.0), (b, VD), (a, VD), (a, 0.0), (0.0, 0.0), (0.0, DT)]
    k3 = lambda y: [(T, y, T + VD, iw, T, FS), (T, y, T, a, T, VD), (T + b, y, T, iw - b, T, VD)]
    vv = [(u, v, 5.0, X) for u in (bay + T / 2, iw - bay - T / 2) for v in (50.0, VD - 50.0)]
    for ten, y, extra in (("Nóc (khoét U 250 cho ống gió)", H - T, []), ("Kệ cố định – trần buồng máy (khoét U 250)", zk, [(50.0 + k * (iw - 100.0) / 3, DT - T / 2, 5.0, X) for k in range(4)])):
        p = mieng(ten, vl, iw, DT, (T, y, T, iw, T, DT), vv + extra, ("B",), poly=u_poly, note=f"Khoét U {UW:.0f} x {VD:.0f} từ lưng vào, chừa dải trước {FS:.0f} (CV)")
        p["pl3d"] = dict(ax="y", o=[T, y, T], pts=u_poly, d=T); parts.append(p)
    # ---- đáy: thanh trước + thanh sau (+ 2 miếng bên) -> lỗ khoét đúng máy
    ten_may = may["ten"] if may else f"lỗ {cat_w:.0f} x {cat_d:.0f}"
    parts.append(mieng(f"Đáy – thanh trước {cat_tr:.0f}", vd, iw, cat_tr, (T, 0, D - cat_tr, iw, TD, cat_tr), (), ("T", "B"), note=f"Giữa 2 thanh đáy = lỗ máy ({ten_may})", loai="tam"))
    parts.append(mieng(f"Đáy – thanh sau {RS:.0f}", vd, iw, RS, (T, 0, T, iw, TD, RS), (), ("T",), note="Sát hậu", loai="tam"))
    if cat_w < iw - 0.5:
        sw = (iw - cat_w) / 2
        for k, x in enumerate((T, T + iw - sw)):
            parts.append(mieng(f"Đáy – miếng bên {'trái' if k == 0 else 'phải'}", vd, sw, cat_d, (x, 0, T + RS, sw, TD, cat_d), (), ("L" if k else "R",), note="Ép giữa 2 thanh đáy", loai="tam"))
    pk["Bát / vít ghép thanh đáy"] += 4
    # ---- che buồng máy, vách ngăn, che ống gió, kệ
    che = [(iw, CH), (iw, 150.0), (iw - 50.0, 150.0), (iw - 50.0, 0.0), (50.0, 0.0), (50.0, 150.0), (0.0, 150.0), (0.0, CH)]
    p = mieng("Tấm che buồng máy (khấc 50x150 né bản lề)", vl, iw, CH, (T, TD, D - T, iw, CH, T), [(u, CH - T / 2, 5.0, 1.0) for u in ()], ("T",), poly=che, note="Đứng sát mặt trước thùng, trên thanh đáy trước, dưới kệ cố định (CV)")
    p["pl3d"] = dict(ax="z", o=[T, TD, D - T], pts=che, d=T); parts.append(p)
    pv = [(tren / 2 + 32 * j, v, 5.0, 12.0) for j in range(-2, 3) for v in (40.0, VD - 37.0)]
    parts.append(mieng("Vách ngăn ống gió trái", vl, tren, VD, (T + bay, zb, T, T, tren, VD), pv, ("T",), note=f"Giữa 2 vách = {UW:.0f}"))
    parts.append(mieng("Vách ngăn ống gió phải", vl, tren, VD, (T + bay + T + UW, zb, T, T, tren, VD), [(tren - x, y, d, q) for x, y, d, q in pv], ("T",)))
    cw2 = UW + 2 * T - 2
    parts.append(mieng("Tấm che ống gió (trước 2 vách)", vl, tren, cw2, (T + bay + 1, zb, T + VD, cw2, tren, T), [(u, v, 5.0, X) for u in (50.0, tren / 2, tren - 50.0) for v in (T / 2 - 1, cw2 - T / 2 + 1)], ("T", "B"),
                       note="Bắt 6 vít vào mép 2 vách (CV loose duct cover)"))
    kes = []
    for yc in yke:
        for x in (T + 1, T + bay + T + UW + T + 1):
            kes.append(mieng("Kệ di động (khoang bên)", vl, DT - 10, bay - 2, (x, yc - T / 2, T, bay - 2, T, DT - 10), (), ("R",), loai="ke"))
    pk["Chốt kệ"] += 8 * n_ke; pk["Vít 4x50 (ráp thùng)"] += 30
    if not t.get("chan"): pk["Pát treo tủ (cặp)"] += 1
    # ---- máy (chỉ để nhìn)
    xm = T + (iw - cat_w) / 2
    aos.append(ao(f"Máy hút mùi ({ten_may})", (xm, TD - 4, T + RS, cat_w, min(CH - 20, 200), cat_d), "#2a2b2e", loai="thiet_bi"))
    aos.append(ao("Mặt máy hút mùi", (max(xm - 18, T), -6, max(T + RS - 17, T), min(cat_w + 36, iw), 6, cat_d + 34), "#3a3b3f", loai="thiet_bi"))
    aos.append(ao("Ống gió Ø150", (T + bay + T + UW / 2 - 75, zk, T + VD / 2 - 75, 150, H - zk, 150), "#b9bcc2", loai="thiet_bi"))
    return parts + kes + doors, aos, pk, cb


def tu_tu_do(t, so):
    """ĐỒ RỜI: món làm riêng (bàn, kệ…) dựng sẵn từng miếng bằng script Javis (vd job KIM) – mỗi miếng có hình cắt thật (poly, lỗ, rãnh)
    + hình 3D liền đúng hình (pl3d). Studio chỉ hiển thị / kiểm / xuất lại, không tự sinh kết cấu."""
    parts = []
    for q in t.get("chi_tiet") or []:
        vl = q.get("vl") if q.get("vl") in VAT_LIEU else "HMR16"
        p = mieng(q.get("name", "Miếng"), vl, float(q["w"]), float(q["h"]), q["box"], [tuple(h) for h in q.get("holes", [])], q.get("edges", ()), (), q.get("note", ""),
                  poly=[tuple(a) for a in q["poly"]], loai=q.get("loai", "tam"), rot=bool(q.get("rot")))
        p["grooves"] = [([tuple(a) for a in g], dp) for g, dp in q.get("grooves", [])]
        if q.get("pl3d"): p["pl3d"] = q["pl3d"]
        parts.append(p)
    pk = Counter({k: v for k, v in (t.get("phu_kien") or {}).items()})
    aos = [ao(a["name"], a["box"], a.get("mau"), loai=a.get("loai", "thiet_bi")) for a in (t.get("khoi_ao") or [])]
    return parts, aos, pk, []


def tu_hop(t, so, co_canh=True):
    parts, aos, pk, cb = [], [], Counter(), []
    W, H, D = t["w"], t["h"], t["d"]; vl = t["vl_thung"]; T = VAT_LIEU[vl]["lz"]; X = T + 0.5; iw = W - 2 * T
    if t["loai"] in TU_TREO: t = dict(t, shadowline=False)        # tủ treo không khoét shadowline trên hông
    sl = bool(t.get("shadowline")) and co_canh
    lt, lp = [], []
    doors = []; cam = []                       # cam = các khoang không đặt kệ di động (hộc lò)
    ncd = int(t.get("ke_cd", 0) or 0)
    cd = [T / 2 + (k + 1) * (H - T) / (ncd + 1) for k in range(ncd)]            # tâm kệ cố định
    if t["loai"] == "lo_nuong":
        ly, lc, l2 = float(t.get("lo_y", 600)), float(t.get("lo_cao", 595)), float(t.get("lo2_cao", 0) or 0)
        top_lo = ly + lc + (T + l2 if l2 > 0 else 0)
        if ly < 100 or top_lo + T + 60 > H: cb.append(f"#{so}: hộc lò ({ly:.0f} → {top_lo:.0f}) không nằm gọn trong tủ cao {H:.0f}"); ly = min(max(ly, 100), H - lc - 200); l2 = 0; top_lo = ly + lc
        cd = [ly - T / 2, ly + lc + T / 2] + ([top_lo + T / 2] if l2 > 0 else [])
        cam = [(ly, top_lo + T)]
        if iw < 560: cb.append(f"#{so}: lòng tủ {iw:.0f} < 560 – lò 60cm không vừa (hộc lò cần rộng tối thiểu 560)")
        if D - T < 550: cb.append(f"#{so}: lòng sâu {D - T:.0f} < 550 – lò cần sâu tối thiểu 550")
        aos.append(ao("Lò nướng", (T + 2, ly + 2, D - 20, iw - 4, lc - 4, 40), "#17181b", loai="thiet_bi"))
        if l2 > 0: aos.append(ao("Lò vi sóng", (T + 2, ly + lc + T + 2, D - 20, iw - 4, l2 - 4, 40), "#1f2023", loai="thiet_bi"))
        nh = int(t.get("hoc_duoi", 0) or 0)
        if co_canh and nh > 0:                 # ngăn kéo dưới lò (cách TPW vẫn làm): mặt hộc + đáy + hậu Tandembox
            vm, shaker, ghi = mat_ngoai(t); tf = VAT_LIEU[vm]["lz"]; zone = ly - T - HO - KHE / 2; hf = (zone - (nh - 1) * KHE) / nh; wf = W - 2 * HO
            NL = max([v for v in RAY_NL if v <= D - T - 3] or [270])
            for k in range(nh):
                yb = HO + k * (hf + KHE); an = dict(kieu="hoc", k=k)
                up = 96.0 if hf < 250 else 128.0 if hf < 310 else 160.0
                hl = [(x, y, 10.0, 12.0) for x in [46.4, 78.4] + ([46.4 + up] if hf >= 46.4 + up + 30 else []) for y in (29.9, wf - 29.9)]
                doors.append(mieng(f"Mặt hộc {'shaker ' if shaker else ''}{k + 1}", vm, hf, wf, (HO, yb, D, wf, hf, tf), hl, () if vm in ("MDF18", "MDF21") else ("T", "B", "L", "R"), (), ghi, loai="mat_hoc", anim=an, rot=False))
                trang_tri(aos, (HO, yb, D, wf, hf, tf), shaker, "N" if t.get("tay_nam") else None, an, ngang=True)
                run = [(yb + 50.9, y, 5.0, 12.0) for y in (D - 36, D - 132, D - 260, D - (NL - 48)) if y > T + 10]; lt += run; lp += run
                bw, bd = iw - 75, NL - 24.4; BH = 198.0 if hf >= 310 else 166.0 if hf >= 250 else 134.0 if hf >= 190 else 83.0
                parts.append(mieng(f"Đáy hộc {k + 1}", vl, bw, bd, (T + 37.5, yb + 28, D - bd, bw, T, bd), [(x, y, 5.0, 12.0) for x in (9.0, bw - 9.0) for y in (16.2, bd - 189.4, bd - 43.4) if y > 0], (), loai="hoc", anim=an))
                parts.append(mieng(f"Hậu hộc {k + 1}", vl, iw - 87, BH, (T + 43.5, yb + 28 + T, D - bd, iw - 87, BH, T), [(x, y, 5.0, 12.0) for x in (9.0, iw - 87 - 9.0) for y in (7.0, 39.0, 103.0, 135.0, 167.0) if y <= BH - 31], ("T",), loai="hoc", anim=an))
                pk[f"Ray hộc Tandembox {NL} (bộ)"] += 1
                if t.get("tay_nam"): pk["Tay nắm"] += 1
                if t.get("mo") == "push": pk["Nhấn mở (push latch)"] += 1
            cam.append((T, ly - T))
        if co_canh:
            if nh <= 0: cac_canh(t, so, doors, pk, cb, lt, lp, y0=HO, hd=ly - T - HO - KHE / 2, out_ao=aos)        # cánh dưới lò
            y1 = top_lo + T + KHE / 2
            cac_canh(t, so, doors, pk, cb, lt, lp, y0=y1, hd=H - y1 - (SL_CUA if sl else HO), out_ao=aos)            # cánh trên lò
    elif t["loai"] == "tu_lanh":
        # TỦ LẠNH ÂM (integrated): hộc lọt lòng >= 560 rộng, >= 550 sâu, cao 1772-1780 tuỳ model; cửa tủ lạnh CÙNG MÀU CÁNH (anh Tan 19/11)
        tlc = float(t.get("tl_cao") or 1780)
        if tlc < 600 or T + tlc + T + 150 > H: cb.append(f"#{so}: hộc tủ lạnh cao {tlc:.0f} không nằm gọn trong tủ cao {H:.0f}"); tlc = max(600.0, H - 2 * T - 300)
        yk = T + tlc; cd = [yk + T / 2]; cam = [(T, yk)]
        if iw < 560: cb.append(f"#{so}: lòng tủ {iw:.0f} < 560 – tủ lạnh âm cần hộc rộng tối thiểu 560")
        if D < 560: cb.append(f"#{so}: tủ sâu {D:.0f} < 560 – tủ lạnh âm cần hộc sâu tối thiểu 550")
        if t.get("mo") == "push": cb.append(f"#{so}: cửa tủ lạnh âm không dùng bấm mở (ron hút chặt) – đổi sang tay nắm")
        aos.append(ao("Tủ lạnh âm", (T + 3, T + 2, 20, iw - 6, tlc - 4, D - 42), "#e4e6e9", loai="thiet_bi"))
        if co_canh:
            vm, shaker, ghi = mat_ngoai(t); tf = VAT_LIEU[vm]["lz"]; wd = W - 2 * HO; bl = t.get("ban_le", "L"); truot = t.get("tl_ban_le") == "truot"
            y_top = yk + T / 2 - KHE / 2; chia = float(t.get("tl_chia") or 0)
            if chia and not (300 <= chia <= y_top - HO - 300 - KHE): cb.append(f"#{so}: chiều cao cửa dưới {chia:.0f} không hợp lệ – làm 1 cửa suốt"); chia = 0
            cua = [(HO, chia), (HO + chia + KHE, y_top - HO - chia - KHE)] if chia else [(HO, y_top - HO)]
            n2 = int(t.get("canh", 1) or 1)
            cua = [(yb, hd, (HO + i * ((wd - KHE) / 2 + KHE), (wd - KHE) / 2, "L" if i == 0 else "R") if (n2 == 2 and (k == len(cua) - 1)) else (HO, wd, bl))
                   for k, (yb, hd) in enumerate(cua) for i in (range(2) if (n2 == 2 and k == len(cua) - 1) else range(1))]   # tủ lạnh 2 cánh (French door): cửa trên chia đôi
            for k, (yb, hd, (x0, wk, blk)) in enumerate(cua):
                ten = "Cửa tủ lạnh" + ((" dưới" if (chia and k == 0) else (" trên" if chia else "")) + (f" {'trái' if blk == 'L' else 'phải'}" if n2 == 2 and not (chia and k == 0) else "")) + " (cùng màu cánh)"
                note = (ghi + " | " if ghi else "") + ("Bản lề TRƯỢT (sliding): cánh treo bằng bản lề tủ, nối ray trượt vào cửa tủ lạnh" if truot
                                                         else "DOOR-ON-DOOR: bắt thẳng vào cửa tủ lạnh theo dưỡng của hãng – không khoan bản lề")
                box = (x0, yb, D, wk, hd, tf); an = dict(kieu="cua", ban_le=blk, px=x0 if blk == "L" else x0 + wk, pz=D)
                doors.append(mieng(ten, vm, hd, wk, box, lo_canh(hd, wk, vm, blk) if truot else [], () if vm in ("MDF18", "MDF21") else ("T", "B", "L", "R"), (), note, loai="canh", anim=an, rot=False))
                trang_tri(aos, box, shaker, ("R" if blk == "L" else "L") if t.get("tay_nam") else None, an, vi_tri="giua" if not chia else ("tren" if (k == 0 and chia) else "duoi"))
                if truot:
                    (lt if blk == "L" else lp).extend([(yb + c + s, D - 37, 5.0, 12.0) for c in tam_ban_le(hd) for s in (-16, 16)])
                    pk["Bản lề giảm chấn + đế"] += so_ban_le(hd)
                if t.get("tay_nam"): pk["Tay nắm"] += 1
            y1 = yk + T / 2 + KHE / 2
            cac_canh(t, so, doors, pk, cb, lt, lp, y0=y1, hd=H - y1 - (SL_CUA if sl else HO), out_ao=aos)                # cánh tủ phía trên tủ lạnh
    elif co_canh:
        du = float(t.get("_du") or 0)
        if du > 0: cac_canh(t, so, doors, pk, cb, lt, lp, y0=-du, hd=H - HO + du, out_ao=aos)       # fingerpull: cánh tủ treo dư xuống dưới đáy thùng
        else: cac_canh(t, so, doors, pk, cb, lt, lp, out_ao=aos)
    ys = (50.0, r1((50 + D - 49) / 2), D - 49.0) if D >= 250 else (50.0, D - 49.0)
    base = [(x, y, 5.0, X) for x in [T / 2, H - T / 2] + cd for y in ys]
    nb = max(3, int(round(H / 400)) + 1); step = (H - 2 * 66.4) / (nb - 1)
    if t["loai"] == "tu_lanh":             # hộc tủ lạnh để hở hậu (thông gió): chỉ bắt hậu cho phần tủ phía trên
        base += [(v, T / 2, 5.0, X) for v in (cd[0] + T / 2 + 50, H - 66.4) if v < H - 20]
    else: base += [(66.4 + k * step, T / 2, 5.0, X) for k in range(nb)]
    kes = []
    # kệ di động chia đều trong từng khoang giữa các kệ cố định (bỏ khoang hộc lò)
    bounds = [T] + cd + [H - T]; n = int(t.get("ke", 0) or 0); sau = D - T - 10
    kh = [i for i in range(len(bounds) - 1) if not any(a - 1 <= bounds[i] + T / 2 and bounds[i + 1] - T / 2 <= b + 1 for a, b in cam)]
    if n > 0 and kh:
        per = {i: 0 for i in kh}
        for k in range(n):
            i = max(kh, key=lambda i: (bounds[i + 1] - bounds[i]) / (per[i] + 1)); per[i] += 1
        xs = []
        for i, m in per.items():
            for k in range(m):
                yc = bounds[i] + (k + 1) * (bounds[i + 1] - bounds[i]) / (m + 1); xs.append(yc)
                kes.append(mieng("Kệ di động", vl, sau, iw - 2, (T + 1, yc - T / 2, T, iw - 2, T, sau), (), ("R",), loai="ke"))
        pins = lo_chot_ke(xs, D, T); lt += pins; lp += pins; pk["Chốt kệ"] += 4 * n
    ed = ("T",)
    notch = [(H - SL_H, H)] if sl else []
    parts.append(mieng("Hông trái", vl, H, D, (0, 0, 0, T, H, D), base + lt, ed, poly=poly_hong(H, D, T, notch, False) if notch else None))
    parts.append(mieng("Hông phải", vl, H, D, (W - T, 0, 0, T, H, D), [(H - x, y, d, p) for x, y, d, p in base + lp], ed,
                       poly=poly_hong(H, D, T, notch, True) if notch else None))
    lo_noc, lo_day, ghi_day = [], [], ""
    if t["loai"] == "hut_mui":          # hút mùi âm tủ: CHẤM 4 góc lỗ khoét ở đáy + tâm ống Ø150 ở nóc (thợ khoét theo chấm, kiểm đúng model trước)
        cw, cdp = float(t.get("cat_w", 490)), float(t.get("cat_d", 265)); dd = D - T
        x0 = (iw - cw) / 2; y1 = dd - 35.0; y0 = y1 - cdp
        if x0 < 35 or y0 < 20: cb.append(f"#{so}: lỗ hút mùi {cw:.0f} x {cdp:.0f} cách mép đáy tủ < 35mm – tăng rộng / sâu tủ hoặc kiểm lại model")
        x0 = max(x0, 5); y0 = max(y0, 5)
        lo_day = [(x, y, 5.0, 2.0) for x in (x0, iw - x0) for y in (y0, y1)]
        lo_noc = [(iw / 2, y0 + cdp / 2, 5.0, 2.0)]
        ghi_day = f"KHOÉT LỖ HÚT MÙI {cw:.0f} x {cdp:.0f} theo 4 chấm (kiểm model trước khi khoét)"
        aos.append(ao("Hút mùi âm tủ", (T + x0, -6, T + y0, iw - 2 * x0, 6, cdp), "#2a2b2e", loai="thiet_bi"))
    thanh_shadowline(t, parts, notch)
    parts.append(mieng("Nóc", vl, iw, D - T, (T, H - T, T, iw, T, D - T), lo_noc, ("T",), note="Khoét ống Ø150 tại chấm (hút mùi)" if lo_noc else ""))
    if t["loai"] == "tu_lanh": ghi_day = "TỦ LẠNH ÂM: khoét / lùi đáy thông gió ≥ 200 cm² theo hướng dẫn hãng, kickface gắn lưới thông gió"
    parts.append(mieng("Đáy", vl, iw, D - T, (T, 0, T, iw, T, D - T), lo_day, ("T",), note=ghi_day))
    for c in cd:
        parts.append(mieng("Kệ cố định", vl, iw, D - T, (T, c - T / 2, T, iw, T, D - T), (), ("T",), loai="ke"))
    if t["loai"] == "tu_lanh":
        yh = cd[0] + T / 2
        parts.append(mieng("Hậu (tủ trên tủ lạnh)", vl, iw, H - yh, (T, yh, 0, iw, H - yh, T), (), (), loai="hau", note="Hộc tủ lạnh để hở hậu cho thông gió"))
    else: parts.append(mieng("Hậu", vl, iw, H, (T, 0, 0, iw, H, T), (), (), loai="hau", note="Chừa / khoét thông gió sau lò theo hướng dẫn hãng" if t["loai"] == "lo_nuong" else ""))
    pk["Vít 4x50 (ráp thùng)"] += len(base) * 2
    if t.get("thanh_treo"):
        yr = (cd[-1] - 60) if cd else H - 100
        aos.append(ao("Thanh treo đồ", (T, yr - 15, D / 2 - 8, iw, 30, 16), "#b9bcc2"))
        pk["Thanh treo đồ (m)"] += round(iw / 1000, 2); pk["Bát đỡ thanh treo"] += 2
    if t["loai"] in TU_TREO and not t.get("chan"): pk["Pát treo tủ (cặp)"] += 1
    chan_tu(t, aos, pk)
    if H > 2400 or D > 1200: cb.append(f"#{so}: hông {H:.0f} x {D:.0f} lớn hơn tấm 2410 x 1210")
    return parts + kes + doors, aos, pk, cb


def tu_may_rua(t, so):
    """MÁY RỬA CHÉN. Âm (fully integrated): cửa CÙNG MÀU CÁNH phủ hết mặt máy, bắt vào cửa máy theo dưỡng của hãng (anh Tan 19/11).
    Bán âm (semi-integrated): tấm cửa nằm dưới bảng điều khiển. Rời / under-bench: mặt inox của máy, không làm cửa.
    Số liệu hãng: khoảng lọt 600 rộng, 820-880 cao, >= 560 sâu; panel rộng >= 596, cao thường 655-765, dày 16-25, nặng 3-10kg."""
    parts, aos, pk, cb = [], [], Counter(), []
    W, H, D = t["w"], t["h"], t["d"]; ch = float(t.get("chan", 0) or 0); kieu = t.get("mr_kieu", "am")
    aos.append(ao("Máy rửa chén", (3, 0, 15, W - 6, H - 3, D - 32), "#c9ccd1", loai="thiet_bi"))
    if ch > 0: aos.append(ao("Chân máy rửa chén", (3, -ch, 15, W - 6, ch, D - 90), "#2f2f31", loai="chan"))
    if W < 598: cb.append(f"#{so}: khoảng máy rửa chén {W:.0f} < 600 – máy 60cm cần lọt lòng 600")
    if H + ch < 820: cb.append(f"#{so}: khoảng cao {H + ch:.0f} < 820 – máy rửa chén chuẩn cao 820–880")
    if D < 560: cb.append(f"#{so}: khoảng sâu {D:.0f} < 560 – máy rửa chén cần sâu tối thiểu 560")
    an = dict(kieu="lat", py=HO, pz=D)
    if kieu == "roi":
        aos.append(ao("Mặt máy rửa chén (inox)", (HO, HO, D, W - 2 * HO, H - 2 * HO, 20), "#b4b8bd", anim=an, loai="thiet_bi"))
        return parts, aos, pk, cb
    vm, shaker, ghi = mat_ngoai(t); tf = VAT_LIEU[vm]["lz"]; sl = bool(t.get("shadowline")); mdf = vm in ("MDF18", "MDF21")
    wd = W - 2 * HO; bang = max(0.0, float(t.get("mr_bang") or 120)) if kieu == "ban_am" else 0.0
    hd = H - (SL_CUA if sl else HO) - HO - (bang + KHE if bang else 0)
    holes = []; e45 = (); note = (ghi + " | " if ghi else "") + "Bắt vào cửa máy rửa chén theo dưỡng của hãng – KHÔNG khoan bản lề"
    if sl and not bang:
        if mdf: note += " | CẮT 45° CẠNH TRÊN (shadowline) – chưa tự phay, kiểm tay"
        else: e45 = ("R",); holes.append((hd - 10, wd / 2, 5.0, 1.0)); note += " | Nẹp 45° cạnh có chấm Ø5 (cạnh trên)"
    box = (HO, HO, D, wd, hd, tf)
    parts.append(mieng(f"Cửa máy rửa chén {'shaker ' if shaker else ''}(cùng màu cánh)", vm, hd, wd, box, holes, () if mdf else ("T", "B", "L", "R"), e45, note, loai="canh", anim=an, rot=False))
    trang_tri(aos, box, shaker, "N" if t.get("tay_nam") else None, an, ngang=True)
    if bang: aos.append(ao("Bảng điều khiển máy rửa chén", (HO, HO + hd + KHE, D, wd, bang, 18), "#b4b8bd", anim=an, loai="thiet_bi"))
    if kieu == "am" and not 655 <= hd <= 765: cb.append(f"#{so}: cửa máy rửa chén cao {hd:.0f} – đa số máy âm nhận panel cao 655–765, kiểm đúng model")
    if wd < 595.5: cb.append(f"#{so}: cửa máy rửa chén rộng {wd:.0f} < 596 – không phủ hết mặt máy")
    if t.get("mo") == "push": cb.append(f"#{so}: máy rửa chén âm không dùng bấm mở – chọn model tự bung cửa (knock-to-open) hoặc đổi tay nắm / shadowline")
    if t.get("tay_nam"): pk["Tay nắm"] += 1
    if sl: thanh_shadowline(t, parts, [(H - SL_H, H)])
    return parts, aos, pk, cb


def tu_tam(t, so):
    vl = t["vl_thung"]; T = VAT_LIEU[vl]["lz"]; hg = t.get("huong", "hong")
    W, H, D = t["w"], t["h"], t["d"]; cat = t.get("cat") or [None, None]; note = str(t.get("ghi_chu") or "")
    c = lambda i, v: float(cat[i]) if isinstance(cat, (list, tuple)) and len(cat) == 2 and cat[i] else v
    if hg == "hong": p = mieng(t.get("ten") or "Tấm hông", vl, c(0, H), c(1, D), (0, 0, 0, T, H, D), (), ("T", "L", "R"), note=note, loai="tam")
    elif hg == "dung": p = mieng(t.get("ten") or "Tấm đứng", vl, c(0, H), c(1, W), (0, 0, 0, W, H, T), (), ("T", "B", "L", "R"), note=note, loai="tam",
                                 rot=None if H >= W else True)
    else: p = mieng(t.get("ten") or "Tấm nằm", vl, c(0, W), c(1, D), (0, 0, 0, W, T, D), (), ("T", "L", "R"), note=note, loai="tam")
    return [p], [], Counter(), []


def tu_ao_khoi(t, so):
    mau = "#dcdcdf" if t["loai"] == "mat_da" else "#9ea3a8"
    return [], [ao(t.get("ten") or THU_VIEN[t["loai"]]["ten"], (0, 0, 0, t["w"], t["h"], t["d"]), mau, loai=t["loai"])], Counter(), []


DUNG0 = dict(duoi_canh=tu_duoi_canh, duoi_chau=tu_duoi_canh, duoi_hoc=tu_duoi_hoc, duoi_keo=tu_duoi_keo, treo=tu_hop, hut_mui=tu_hut_mui, tu_do=tu_tu_do, cao=tu_hop, tu_ao=tu_hop, lo_nuong=tu_hop,
            ke_mo=lambda t, so: tu_hop(t, so, co_canh=False), tam=tu_tam, mat_da=tu_ao_khoi, thiet_bi=tu_ao_khoi, may_rua=tu_may_rua, goc_l=tu_goc_l, goc_mu=tu_goc_mu, cong=tu_cong,
            tu_lanh=lambda t, so: tu_ao_khoi(t, so) if tl_roi(t) else tu_hop(t, so))


DUNG = dict(DUNG0, cao=lambda t, so: tu_cao_tach(t, so), tu_ao=lambda t, so: tu_cao_tach(t, so))


def tu_cao_tach(t, so):
    """tủ cao tách 2 thùng chồng nhau (cách TPW làm pantry tới trần): thùng dưới cao `tach`, hộp trên phần còn lại. Mỗi thùng có cánh riêng."""
    tach = float(t.get("tach") or 0)
    if tach <= 0 or tach >= t["h"] - 150: return tu_hop(t, so)
    n = int(t.get("ke", 0) or 0); ncd = int(t.get("ke_cd", 0) or 0)
    d = dict(t, h=tach, tach=0, ke=max(0, n - 1), ke_cd=0)
    u = dict(t, h=t["h"] - tach, tach=0, chan=0, ke=min(n, 1), ke_cd=0, thanh_treo=False)
    p1, a1, k1, c1 = tu_hop(d, so); p2, a2, k2, c2 = tu_hop(u, so)
    for p in p2:
        p["box"][1] += tach; p["name"] = "Hộp trên – " + p["name"]
    for a in a2: a["box"] = (a["box"][0], a["box"][1] + tach, *a["box"][2:])
    k1.update(k2)
    return p1 + p2, a1 + a2, k1, c1 + c2


def chuan_hoa(t):
    base = tu_moi(t.get("loai", "duoi_canh"))
    base.update({k: v for k, v in t.items() if v is not None})
    for k in ("w", "h", "d", "x", "y", "z", "chan"):
        try: base[k] = float(base.get(k, 0) or 0)
        except (TypeError, ValueError): base[k] = 0.0
    for k in ("vl_thung", "vl_mat"):
        if base.get(k) not in VAT_LIEU: base[k] = CHUNG[k]
    for k, _, kieu, ap in THAM_SO:           # giá trị lạ (file job hỏng, AI trả bậy): đưa về mặc định của thư viện
        if k not in base or (ap and base["loai"] not in ap): continue
        v = base[k]; md = THU_VIEN[base["loai"]].get(k, CHUNG.get(k))
        if kieu == "bool": base[k] = v if isinstance(v, bool) else str(v).lower() in ("1", "true", "có", "co", "yes")
        elif isinstance(kieu, list):
            if isinstance(kieu[0], int):
                try: v = int(float(v))
                except (TypeError, ValueError): v = None
            base[k] = v if v in kieu else (md if md in kieu else kieu[0])
        elif kieu == "mm" and k not in ("w", "h", "d", "x", "y", "z", "chan"):
            try: base[k] = float(v)
            except (TypeError, ValueError): base[k] = float(md or 0)
    try: base["goc"] = int(float(base.get("goc", 0) or 0)) % 360
    except (TypeError, ValueError): base["goc"] = 0
    if "mo" not in t:                                             # file job cũ / lệnh AI chỉ có shadowline, tay_nam
        base["mo"] = "shadowline" if t.get("shadowline") else ("push" if t.get("tay_nam") is False else "tay_nam")
    if base.get("mo") not in ("tay_nam", "shadowline", "push"): base["mo"] = "tay_nam"
    base["shadowline"] = base["mo"] == "shadowline"; base["tay_nam"] = base["mo"] == "tay_nam"
    if tl_roi(base): base["chan"] = 0.0                            # tủ lạnh rời đứng thẳng trên sàn, không có kickface
    if base["loai"] == "mat_da":
        try: base["h"] = float(base.get("day_da") or base["h"])
        except (TypeError, ValueError): pass
    return base


def dung_job(job):
    """job = {ten, so, tu:[...]} -> {tu:[{id, so, ten, khoi:[...]}], chi_tiet:[...], phu_kien:{...}, canh_bao:[...], nep:{vl: mét}}"""
    out_tu, chi_tiet, pk, cb, nep = [], [], Counter(), [], Counter()
    BT = bo_tri(job.get("phong") or {}, [chuan_hoa(t) | {"day": t.get("day")} for t in job.get("tu", []) if not t.get("auto")])
    for i, raw in enumerate(job.get("tu", [])):
        t = chuan_hoa(raw); so = i + 1
        if min(t["w"], t["h"], t["d"]) <= 0: cb.append(f"#{so}: kích thước phải lớn hơn 0"); continue
        ph0 = job.get("phong") or {}
        if t["loai"] in ("treo", "hut_mui") and t.get("mo") == "shadowline": t["_du"] = 40.0 if ph0.get("bc") else 20.0
        if t["loai"] in ("cao", "tu_ao") and t.get("mo") == "shadowline" and not float(t.get("tach") or 0):
            cb.append(f"#{so}: pantry 1 thùng không làm fingerpull – đã chuyển sang tay nắm (muốn fingerpull thì đặt 'Tách 2 thùng')")
            t["mo"] = "tay_nam"; t["shadowline"] = False; t["tay_nam"] = True
        try:
            parts, aos, p2, c2 = DUNG[t["loai"]](t, so)
        except Exception as e:  # tham số lạ: báo, không làm sập cả job
            cb.append(f"#{so} {t.get('ten', '')}: lỗi dựng tủ ({e})"); continue
        pk.update(p2); cb += c2
        khoi = []
        for p in parts:
            p["cab"] = str(so); p["tu_ten"] = t.get("ten", "")
            v = VAT_LIEU[p["vl"]]
            if max(p["w"], p["h"]) > v["lx"] - 8 or min(p["w"], p["h"]) > v["ly"] - 8:
                cb.append(f"#{so} {p['name']}: {p['w']:.0f} x {p['h']:.0f} không lọt tấm {v['lx']} x {v['ly']}")
            for e in p["edges"] + p["e45"]:
                nep[p["vl"]] += (p["w"] if e in ("T", "B") else p["h"]) / 1000
            p["ngoai"] = v.get("cnc") is False
            vai = "mat" if p["loai"] in ("canh", "mat_hoc", "tam") or (p["vl"] != "HMR16" and p["loai"] != "hoc") else "thung"
            if p.get("pl3d"):                  # miếng có hình (khoét U, khấc, chữ L): vẽ 1 KHỐI LIỀN đúng hình cắt, không tách
                khoi.append(dict(n=p["name"], b=p["box"], c=v["mau"], k=p["loai"], a=p["anim"], vl=p["vl"], r=vai, pl=p["pl3d"]))
            else:
                for bx in (p.get("k3d") or (tach_khoi_hong(p) if p["name"].startswith("Hông") else [p["box"]])):
                    khoi.append(dict(n=p["name"], b=bx, c=v["mau"], k=p["loai"], a=p["anim"], vl=p["vl"], r=vai, cung=p.get("cung")))
            chi_tiet.append(p)
        for a in aos:
            vai = {"khung": "mat", "mat_da": "da", "tay": "tay", "chan": "chan"}.get(a["loai"], "kl")
            khoi.append(dict(n=a["name"], b=a["box"], c=a["mau"] or VAT_LIEU["MDF21"]["mau"], k=a["loai"], a=a["anim"], vl=None, r=vai))
        dd = BT.get(raw.get("day") or "A") or BT["A"]; wx, wz = the_gioi(dd, t["x"], t["z"])
        out_tu.append(dict(id=raw.get("id"), so=so, ten=t.get("ten", ""), loai=t["loai"], x=round(wx, 2), y=t["y"] + t["chan"], z=round(wz, 2), goc=(dd["goc"] + t["goc"]) % 360,
                           w=t["w"], h=t["h"], d=t["d"], chan=t["chan"], khoi=khoi, day=dd["id"]))
    hop = []                                # tủ chồng lên nhau (kéo tay / AI đặt sai / file cũ): báo ngay ở đầu danh sách
    for i, raw in enumerate(job.get("tu", [])):
        if raw.get("auto") or raw.get("loai") in ("tam", "mat_da"): continue
        t = chuan_hoa(raw)
        if t["goc"] % 360 == 0:
            dd = BT.get(raw.get("day") or "A") or BT["A"]
            p1 = the_gioi(dd, t["x"], t["z"]); p2 = the_gioi(dd, t["x"] + t["w"], t["z"] + t["d"])
            hop.append((i + 1, min(p1[0], p2[0]), max(p1[0], p2[0]), t["y"], t["y"] + t["chan"] + t["h"], min(p1[1], p2[1]), max(p1[1], p2[1]), dd["id"]))
    for a in range(len(hop)):
        for b in range(a + 1, len(hop)):
            A, B = hop[a], hop[b]
            if all(A[k] < B[k + 1] - 1 and B[k] < A[k + 1] - 1 for k in (1, 3, 5)):
                if A[7] == B[7]: cb.insert(0, f"Tủ #{A[0]} và #{B[0]} đang CHỒNG lên nhau {min(A[2], B[2]) - max(A[1], B[1]) if A[7] in 'AD' else min(A[6], B[6]) - max(A[5], B[5]):.0f}mm – kéo tách ra hoặc sửa bề rộng")
                else: cb.insert(0, f"Tủ #{A[0]} (dãy {A[7]}) và #{B[0]} (dãy {B[7]}) đang ĐÈ nhau ở góc – kéo tủ ra khỏi góc hoặc sửa chiều dài tường")
    ds = job.get("tu", [])
    if any(t.get("loai") in TU_DUOI + TU_CAO + TU_TREO for t in ds) and not any(t.get("auto") for t in ds):
        cb.insert(0, "Chưa có panel hông / filler / kicker: bấm nút Hoàn thiện để không lộ thùng trắng")
    # splashback: tấm ốp tường giữa mặt đá và đáy tủ treo, theo từng dãy sát tường (anh Tan 20/11: chọn được vật liệu / màu splashback)
    splash = []; ph = job.get("phong") or {}; sb = ph.get("splashback")
    if sb in ("gach", "da", "kinh"):
        day_sb = {"gach": 10.0, "da": 20.0, "kinh": 6.0}[sb]; m2 = 0.0
        ch = [chuan_hoa(t) | {"day": t.get("day") or "A"} for t in job.get("tu", []) if not t.get("auto")]
        for did, dd in BT.items():
            if did == "D": continue
            ds = [t for t in ch if t["day"] == did and not t["goc"]]
            thap = sorted([t for t in ds if t["loai"] in TU_DUOI + ("thiet_bi",) and t["chan"] + t["h"] < 1200], key=lambda t: t["x"])
            if not thap: continue
            da = [t for t in ds if t["loai"] == "mat_da"]; tr = [t for t in ds if t["loai"] in TU_TREO]
            y0 = max(t["chan"] + t["h"] for t in thap) + (max(t["h"] for t in da) if da else 0)
            seg = []
            for t in thap:
                if seg and t["x"] - seg[-1][1] <= 17: seg[-1][1] = t["x"] + t["w"]
                else: seg.append([t["x"], t["x"] + t["w"]])
            for a, b in seg:
                if dd.get("trai") == "tuong" and a <= float(ph.get("filler") or 30) + 1: a = 0.0
                if dd.get("dai") and 0 < dd["dai"] - b <= (700 if dd.get("phai") == "goc" else 150 if dd.get("phai") == "tuong" else 0): b = dd["dai"]
                if dd.get("trai") == "goc" and a <= 700: a = 0.0
                tren = [t["y"] - (float(ph.get("bc") and 40 or 20) if t.get("mo") == "shadowline" else 0) for t in tr if t["x"] < b and t["x"] + t["w"] > a]
                y1 = min(tren) if tren else y0 + 600.0
                if y1 - y0 < 50: continue
                splash.append(dict(day=did, b=[round(a, 1), round(y0, 1), 0.0, round(b - a, 1), round(y1 - y0, 1), day_sb], loai=sb)); m2 += (b - a) * (y1 - y0) / 1e6
        if m2: pk[f"Splashback {dict(gach='gạch', da='đá', kinh='kính')[sb]} (m²)"] = round(m2, 2)
    return dict(tu=out_tu, chi_tiet=chi_tiet, phu_kien=dict(pk), canh_bao=cb, nep={k: round(v, 1) for k, v in nep.items()}, day=list(BT.values()), splash=splash)


def xep_hang(ds, x0=0.0):
    """đặt 1 hàng tủ nối tiếp từ trái sang phải (dùng cho AI vẽ nhanh)"""
    x = x0
    for t in ds:
        t["x"] = x; x += float(t.get("w", 0) or 0)
    return ds


# ---------------------------------------------------------------- hoàn thiện: panel hông, filler sát tường, kicker, bulkhead (quy tắc anh Tan dặn 19/11/2026)
def _tam(ten, huong, x, y, z, w, h, d, cat=None, ghi="", vl=None):
    vl = vl or _VLP[0]
    return dict(loai="tam", auto=True, ten=ten, huong=huong, x=round(x, 1), y=round(y, 1), z=round(z, 1), w=round(w, 1), h=round(h, 1), d=round(d, 1),
                chan=0, goc=0, vl_thung=vl, cat=cat, ghi_chu=ghi)


_VLP = ["MAU16"]


def _ht_day(job):
    """Hoàn thiện MỘT dãy tủ (toạ độ theo dãy, góc xoay 0). Trả về (job mới, [ghi chú]).
    - Đầu hàng sát tường: FILLER mặt, chừa khe F (mặc định 30) để trừ hao đo sai; tấm cắt dư rộng 100, thợ scribe tại chỗ.
    - Đầu hàng hở (không tường): PANEL hông 16mm phủ hết hông tủ (tủ dưới/cao: từ sàn; tủ treo: bằng chiều cao tủ treo).
    - Tủ cao đứng cạnh tủ thấp / tủ treo: PANEL hông suốt chiều cao tủ cao (không để lộ thùng trắng).
    - Kicker chạy dài theo hàng tủ dưới. Bulkhead / nẹp trần: cắt dư 20mm để thợ chỉnh tại chỗ."""
    ph = dict(tuong_trai=False, tuong_phai=False, tran=0, filler=30, bc=False, led=False, splashback=""); ph.update(job.get("phong") or {})
    F = float(ph.get("filler") or 30); P = 16.0; ghi = []; Fg = float(ph.get("filler_goc") or 50)
    tu = [chuan_hoa(t) | {"id": t.get("id")} for t in job.get("tu", []) if not t.get("auto")]
    vls = Counter(vl_phu(t) for t in tu if t["loai"] in CO_CANH)
    VLP = vls.most_common(1)[0][0] if vls else "MAU16"; P = VAT_LIEU[VLP]["lz"]; _VLP[0] = VLP
    chinh = [t for t in tu if t["goc"] == 0]
    la_cao = lambda t: t["loai"] in TU_CAO
    duoi = sorted([t for t in chinh if t["loai"] in TU_DUOI + TU_CAO + ("thiet_bi",)], key=lambda t: t["x"])
    treo = sorted([t for t in chinh if t["loai"] in TU_TREO], key=lambda t: t["x"])
    tu_that = lambda ds: [t for t in ds if t["loai"] != "thiet_bi"]

    def doi(tu_x, dx):                     # dời mọi thứ từ toạ độ tu_x trở đi sang phải dx (giữ tủ treo thẳng hàng tủ dưới)
        for t in chinh:
            if t["x"] >= tu_x - 0.5: t["x"] += dx
    # 1) chừa chỗ bên trái
    dau = [ds[0] for ds in (duoi, treo) if ds]
    if dau:
        tx = [(t["x"], t["x"] + t["w"]) for t in duoi if la_cao(t)]
        sat_cao = lambda d: d["loai"] in TU_TREO and any(a - 1 <= d["x"] <= b + P + 2 for a, b in tx)      # tủ treo đầu hàng tựa vào tủ cao: không cần chừa
        def can1(d):
            if ph.get("_trai") == "goc":                                   # đầu trái là góc phòng: lùi ra khỏi mặt trước dãy tủ tường kia + filler góc
                lui = (ph.get("_lui_trai") or {}).get("treo" if d["loai"] in TU_TREO else "duoi", 0.0)
                return (lui + Fg) if lui > 0 else F
            if sat_cao(d) or (tl_roi(d) and ph["tuong_trai"]): return 0
            return F if ph["tuong_trai"] else (P if d["loai"] != "thiet_bi" else 0)
        can = max(can1(d) - d["x"] for d in dau)
        if can > 0.5: doi(-1e9, can); ghi.append(f"Dời cả hệ tủ sang phải {can:.0f} để có chỗ cho {'filler sát tường' if ph['tuong_trai'] else 'panel hông'} bên trái")
    # 2) panel giữa tủ cao và tủ thấp / thiết bị (chèn 16mm)
    for i in range(len(duoi) - 1):
        a, b = duoi[i], duoi[i + 1]
        if la_cao(a) != la_cao(b) and abs(a["x"] + a["w"] - b["x"]) < 1: doi(b["x"], P)
    them = []
    for i in range(len(duoi) - 1):
        a, b = duoi[i], duoi[i + 1]; gap = b["x"] - (a["x"] + a["w"])
        if la_cao(a) != la_cao(b) and P - 0.5 <= gap <= P + 0.5:
            c = a if la_cao(a) else b
            them.append(_tam("Panel hông tủ cao", "hong", a["x"] + a["w"], c["y"], c["z"], P, c["chan"] + c["h"], c["d"] + 18, ghi="Che thùng trắng cạnh tủ cao"))
    # 3) hai đầu từng ĐOẠN tủ liền nhau: đầu ngoài cùng sát tường -> filler; mọi đầu hở khác -> panel hông
    cao_x = [(t["x"], t["x"] + t["w"]) for t in duoi if la_cao(t)]
    cham_cao = lambda x: any(abs(x - a) <= P + 2 or abs(x - b) <= P + 2 for a, b in cao_x)

    _tat = duoi + treo
    xmin = min([t["x"] for t in _tat] or [0.0]); xmax = max([t["x"] + t["w"] for t in _tat] or [0.0])

    def dau_hang(ds, la_treo):
        if not ds: return
        doan = [[ds[0]]]
        for t in ds[1:]:
            if t["x"] - (doan[-1][-1]["x"] + doan[-1][-1]["w"]) <= P + 1: doan[-1].append(t)
            else: doan.append([t])
        for k, dn in enumerate(doan):
            for ben, c in (("trai", dn[0]), ("phai", dn[-1])):
                if c["loai"] == "thiet_bi": continue
                if c["loai"] == "cong" and (c.get("cong_ben", "R") == ("L" if ben == "trai" else "R")): continue   # đầu cong không cần panel
                mep = c["x"] if ben == "trai" else c["x"] + c["w"]
                if la_treo and cham_cao(mep): continue                     # tủ treo chạm tủ cao: panel tủ cao đã che
                ngoai = (ben == "trai" and k == 0) or (ben == "phai" and k == len(doan) - 1)
                if ngoai and ph.get("_" + ben) == "goc":                   # đầu dãy nằm ở góc phòng (chữ L / U): filler góc tới mặt trước dãy tủ tường kia
                    lui = (ph.get("_lui_" + ben) or {}).get("treo" if la_treo else "duoi", 0.0)
                    lim = lui if ben == "trai" else (ph.get("_dai") or 0) - lui
                    ho = (c["x"] - lim) if ben == "trai" else (lim - mep)
                    hg = "tủ treo" if la_treo else "tủ dưới"
                    if ho < -0.5: ghi.append(f"Dãy {ph.get('_id', '')}: {hg} ở góc đang lấn vào dãy tủ tường kia {-ho:.0f}mm – kéo ra hoặc giảm bề rộng"); continue
                    if ho < 5: continue
                    if ho > 150: ghi.append(f"Dãy {ph.get('_id', '')}: {hg} còn hở {ho:.0f}mm tới góc – nới rộng tủ cuối hoặc thêm tủ cho kín (filler góc chỉ làm tới 150)"); continue
                    du = (40.0 if ph.get("bc") else 20.0) if (la_treo and c["loai"] in ("treo", "hut_mui") and c.get("mo") == "shadowline") else 0.0
                    yb = c["y"] + (0 if la_treo else c["chan"]) - du
                    them.append(_tam("Filler góc (tủ treo)" if la_treo else "Filler góc", "dung", lim if ben == "trai" else mep, yb, c["z"] + c["d"], ho, c["h"] + du, P, cat=[c["h"] + du, ho + 20.0],
                                     ghi=f"Filler ở góc chữ L, khe thiết kế {ho:.0f}, cắt dư 20 – thợ cắt lại tại chỗ"))
                    continue
                if ngoai and abs(mep - (xmin if ben == "trai" else xmax)) > 150: ngoai_tuong = False     # hàng này kết thúc xa tường (vd tủ treo ngắn hơn tủ dưới): đầu hở -> panel, không phải filler
                else: ngoai_tuong = ngoai
                if ngoai_tuong and ph["tuong_" + ben] and tl_roi(c): continue    # tủ lạnh rời sát tường: không filler
                if ngoai_tuong and ph["tuong_" + ben] and ben == "phai" and ph.get("_dai"):   # có số đo tường: filler đúng bằng khe còn lại
                    ho = ph["_dai"] - mep
                    if ho < -0.5: ghi.append(f"Dãy {ph.get('_id', '')}: tủ dài hơn tường {-ho:.0f}mm – giảm bề rộng tủ"); continue
                    if ho > 150: ghi.append(f"Dãy {ph.get('_id', '')}: còn hở {ho:.0f}mm tới tường phải – thêm tủ / nới tủ (filler chỉ làm tới 150)"); continue
                    if ho < 5: continue
                    du = (40.0 if ph.get("bc") else 20.0) if (la_treo and c["loai"] in ("treo", "hut_mui") and c.get("mo") == "shadowline") else 0.0
                    yb = c["y"] + (0 if la_treo else c["chan"]) - du
                    them.append(_tam("Filler sát tường (tủ treo)" if la_treo else "Filler sát tường", "dung", mep, yb, c["z"] + c["d"], ho, c["h"] + du, P, cat=[c["h"] + du, ho + 70.0],
                                     ghi=f"Khe thiết kế {ho:.0f} theo số đo tường, cắt dư 70 – thợ scribe tại chỗ"))
                    continue
                if ngoai_tuong and ph["tuong_" + ben]:
                    x = (c["x"] - F) if ben == "trai" else mep
                    du = (40.0 if ph.get("bc") else 20.0) if (la_treo and c["loai"] in ("treo", "hut_mui") and c.get("mo") == "shadowline") else 0.0
                    yb = c["y"] + (0 if la_treo else c["chan"]) - du
                    them.append(_tam("Filler sát tường (tủ treo)" if la_treo else "Filler sát tường", "dung", x, yb, c["z"] + c["d"], F, c["h"] + du, P, cat=[c["h"] + du, 100.0],
                                     ghi=f"Cắt dư rộng 100, khe thiết kế {F:.0f} – thợ scribe theo tường tại chỗ"))
                    continue
                if not ngoai:                                              # đầu hở ở giữa hàng: phải còn chỗ 16mm, và chưa có panel tủ cao ở đó
                    ke = doan[k - 1][-1] if ben == "trai" else doan[k + 1][0]
                    ho = (c["x"] - (ke["x"] + ke["w"])) if ben == "trai" else (ke["x"] - mep)
                    if ho < P - 0.5: continue
                x = (c["x"] - P) if ben == "trai" else mep
                y0p, y1p = (c["y"], c["y"] + c["h"]) if la_treo else (c["y"], c["y"] + c["chan"] + c["h"])
                if any(abs(m["x"] - x) < 1 and m["huong"] == "hong" and m["y"] <= y0p + 1 and m["y"] + m["h"] >= y1p - 1 for m in them): continue
                if la_treo:
                    du = (40.0 if ph.get("bc") else 20.0) if (c["loai"] in ("treo", "hut_mui") and c.get("mo") == "shadowline") else 0.0
                    them.append(_tam("Panel hông tủ treo", "hong", x, c["y"] - du, c["z"], P, c["h"] + du, c["d"] + 18, ghi="Cao bằng cánh tủ treo" + (f" (cánh dư xuống {du:.0f})" if du else "")))
                else:
                    sau = (560.0 if (c["loai"] == "goc_l" and ben == "phai") else c["d"]) + 18      # tủ góc L: hông phải chỉ sâu 560 (nhánh dài)
                    them.append(_tam("Panel hông tủ cao" if la_cao(c) else "Panel hông", "hong", x, c["y"], c["z"], P, c["chan"] + c["h"], sau,
                                     ghi="Panel hông nhánh dọc tủ góc L – sâu hết chữ L" if c["loai"] == "goc_l" and ben == "trai" else ""))
    if ph.get("_phai") == "goc" and not ph.get("_dai"): ph["_dai"] = _dai_goc(duoi, treo, ph.get("_lui_phai") or {}, Fg, F)
    dau_hang(duoi, False)
    dau_hang(treo, True)
    # 4) kicker chạy dài (đoạn tủ liền nhau có chân), mỗi tấm tối đa 2400
    seg = []
    for t in duoi:
        if t["loai"] == "thiet_bi":            # máy rửa bát / lò âm (≤ 700): kicker chạy luôn bên dưới; tủ lạnh thì ngắt
            if seg and t["w"] <= 700 and abs(seg[-1][1] - t["x"]) <= P + 1: seg[-1][1] = t["x"] + t["w"]
            continue
        if t["chan"] <= 0: continue
        if t["loai"] == "goc_l":                # kick theo HÌNH THÙNG chữ L: mặt nhánh dài (thẳng hàng tủ 560 kế bên) + mặt nhánh dọc (quay ra +x, chạy tới hông cuối)
            zb = t["z"] + 560 - 50; xg = t["x"] + 560 - 50
            them.append(_tam("Kickface góc L (nhánh dọc)", "hong", xg - P, 0, zb + P, P, t["chan"], t["z"] + t["d"] - zb - P, ghi="Kick chạy theo mặt nhánh dọc tủ góc L, tới hông cuối"))
            if seg and abs(seg[-1][1] - t["x"]) <= P + 1 and abs(seg[-1][3] - zb) < 1: seg[-1][1] = t["x"] + t["w"]
            else: seg.append([xg - P, t["x"] + t["w"], t["chan"], zb])
            continue
        if seg and abs(seg[-1][1] - t["x"]) <= P + 1 and abs(seg[-1][2] - t["chan"]) < 1 and abs(seg[-1][3] - (t["z"] + t["d"] - 50)) < 1: seg[-1][1] = t["x"] + t["w"]
        else: seg.append([t["x"], t["x"] + t["w"], t["chan"], t["z"] + t["d"] - 50])
    for x0, x1, ch, z in seg:
        n = max(1, -(-int(x1 - x0) // 2400)); L = (x1 - x0) / n
        for k in range(n): them.append(_tam("Kickface", "dung", x0 + k * L, 0, z, L, ch, P, ghi="Mặt chân tủ cùng màu cánh – cắt dư dài, cắt lại tại chỗ nếu cần"))
    # 4b) BC panel: tấm ván màu che đáy dàn tủ treo, soi rãnh LED (anh Tan 19/11). Có BC panel thì cánh tủ treo fingerpull dư 40 thay vì 20.
    if ph.get("bc"):
        sp = {"gach": "gạch", "da": "đá", "kinh": "kính"}.get(ph.get("splashback"), "")
        led = bool(ph.get("led"))
        if led and not sp: ghi.append("Có LED dưới tủ treo nhưng chưa chọn loại splashback (gạch / đá / kính) – cần biết để đặt rãnh LED cho đúng")
        note = "Che đáy trắng tủ treo" + (f" · SOI RÃNH LED (splashback {sp or 'CHƯA BIẾT'}) – vị trí rãnh hỏi anh Tan / Huân, chưa tự phay" if led else "")
        bc = []
        for t in treo:
            if t["loai"] == "ke_mo": continue
            if bc and abs(bc[-1][1] - t["x"]) <= 1 and abs(bc[-1][2] - t["y"]) < 1 and abs(bc[-1][3] - t["d"]) < 1: bc[-1][1] = t["x"] + t["w"]
            else: bc.append([t["x"], t["x"] + t["w"], t["y"], t["d"], t["z"]])
        for x0, x1, y, d, z in bc:
            n = max(1, -(-int(x1 - x0) // 2400)); L = (x1 - x0) / n
            for k in range(n): them.append(_tam("BC panel (đáy tủ treo)", "nam", x0 + k * L, y - P, z, L, P, d, ghi=note))
    # 5) bulkhead / nẹp trần
    tran = float(ph.get("tran") or 0)
    if tran > 0:
        nhom = []
        for t in sorted(treo + [t for t in duoi if la_cao(t) and not tl_roi(t)], key=lambda t: t["x"]):
            dinh = t["y"] + t["chan"] + t["h"]; zf = t["z"] + t["d"]
            if nhom and abs(nhom[-1][1] - t["x"]) <= P + 1 and abs(nhom[-1][2] - dinh) < 1 and abs(nhom[-1][3] - zf) < 1: nhom[-1][1] = t["x"] + t["w"]
            else: nhom.append([t["x"], t["x"] + t["w"], dinh, zf])
        for x0, x1, dinh, zf in nhom:
            ho = tran - dinh
            if ho < -0.5: ghi.append(f"Tủ tại x={x0:.0f} cao hơn trần {-ho:.0f}mm – giảm chiều cao tủ"); continue
            if ho < 5: continue
            if ho > 600: ghi.append(f"Khoảng hở tới trần {ho:.0f}mm tại x={x0:.0f}: quá lớn cho nẹp ván – bulkhead thạch cao do builder làm"); continue
            n = max(1, -(-int(x1 - x0) // 2400)); L = (x1 - x0) / n
            for k in range(n):
                them.append(_tam("Bulkhead / nẹp trần", "dung", x0 + k * L, dinh, zf, L, ho, P, cat=[L, ho + 20.0],
                                 ghi=f"Khe thiết kế {ho:.0f}, cắt dư 20 – thợ chỉnh theo trần tại chỗ"))
    # gộp lại: giữ đúng thứ tự tủ gốc, tấm tự động xếp cuối
    goc = {t.get("id"): t for t in tu}
    out = []
    for t in job.get("tu", []):
        if t.get("auto"): continue
        n = dict(t); c = goc.get(t.get("id"))
        if c: n["x"] = c["x"]
        out.append(n)
    for k, t in enumerate(them): t["id"] = f"auto{k:02d}"
    j = dict(job); j["tu"] = out + them; j["phong"] = ph
    if ph["tuong_trai"] is False and ph["tuong_phai"] is False: ghi.append("Chưa đánh dấu tường nào: hai đầu hàng tủ đang được coi là đầu hở (có panel hông)")
    return j, ghi


# ---------------------------------------------------------------- MẶT BẰNG: nhiều dãy tủ (tường sau A, tường trái B, tường phải C, đảo / bar D) – anh Tan 20/11
TEN_DAY = {"A": "Tường sau", "B": "Tường trái", "C": "Tường phải", "D": "Đảo / bar"}
_HANG_DUOI = TU_DUOI + TU_CAO + ("thiet_bi",)


def _dai_goc(duoi, treo, lui, Fg, F):
    """chiều dài tường tự tính cho dãy có GÓC ở đầu phải: tủ cuối + filler góc + phần lùi (mặt trước dãy tủ tường kia)"""
    v = []
    for ds, k in ((duoi, "duoi"), (treo, "treo")):
        if ds:
            l = float(lui.get(k) or 0); v.append(max(t["x"] + t["w"] for t in ds) + ((l + Fg) if l > 0 else F))
    return max(v) if v else 2400.0


def cac_day(ph, tu):
    co = {"A"} | {(t.get("day") or "A") for t in tu}
    k = ph.get("kieu") or "thang"
    if k in ("L_trai", "U"): co.add("B")
    if k in ("L_phai", "U"): co.add("C")
    if ph.get("dao"): co.add("D")
    return [d for d in "ABCD" if d in co]


def _lui(ds, ben):
    """mặt trước của dãy A ở đầu `ben` (để dãy B / C lùi ra): {'duoi': sâu + 18, 'treo': sâu + 18}; 0 = dãy A không có tủ ở hàng đó"""
    out = {}
    for k, nhom in (("duoi", _HANG_DUOI), ("treo", TU_TREO)):
        hs = sorted([t for t in ds if t["loai"] in nhom], key=lambda t: t["x"])
        c = (hs[0] if ben == "trai" else hs[-1]) if hs else None
        out[k] = (c["z"] + c["d"] + 18.0) if c else 0.0
    return out


def bo_tri(ph, tu):
    """vị trí từng dãy trong phòng: {id: dict(ox, oz, goc, dai, ten, lui_trai, lui_phai)}. tu = danh sách tủ (đã chuẩn hoá, không tính tấm tự động)."""
    F = float(ph.get("filler") or 30); Fg = float(ph.get("filler_goc") or 50); P = 16.0
    that = [t for t in tu if not t.get("auto") and t["loai"] not in ("tam", "mat_da") and not (t.get("goc") or 0)]
    cua = lambda d: [t for t in that if (t.get("day") or "A") == d]
    hang = lambda ds: ([t for t in ds if t["loai"] in _HANG_DUOI], [t for t in ds if t["loai"] in TU_TREO])
    ids = cac_day(ph, tu); A = cua("A"); out = {}
    coB, coC = "B" in ids, "C" in ids
    mepA = max([t["x"] + t["w"] for t in A] or [0.0])
    dai_a = float(ph.get("dai_a") or 0) or ((mepA + (F if (coC or ph.get("tuong_phai")) else 0)) if A else 3000.0)
    out["A"] = dict(ox=0.0, oz=0.0, goc=0, dai=dai_a, trai="tuong" if (coB or ph.get("tuong_trai")) else "ho", phai="tuong" if (coC or ph.get("tuong_phai")) else "ho")
    if coB:
        lui = _lui(A, "trai"); d, tr = hang(cua("B"))
        dai = float(ph.get("dai_b") or 0) or _dai_goc(d, tr, lui, Fg, F)
        out["B"] = dict(ox=0.0, oz=dai, goc=90, dai=dai, trai="tuong" if ph.get("b_tuong") else "ho", phai="goc", lui_phai=lui)
    if coC:
        lui = _lui(A, "phai"); d, tr = hang(cua("C"))
        dai = float(ph.get("dai_c") or 0) or max([t["x"] + t["w"] for t in d + tr] or [2400.0]) + (F if ph.get("c_tuong") else 0)
        out["C"] = dict(ox=dai_a, oz=0.0, goc=270, dai=dai, trai="goc", phai="tuong" if ph.get("c_tuong") else "ho", lui_trai=lui)
    if "D" in ids:
        D = cua("D"); dA = max([t["z"] + t["d"] for t in A if t["loai"] in _HANG_DUOI] or [560.0]) + 18.0
        Dd = max([t["z"] + t["d"] for t in D if t["loai"] in _HANG_DUOI] or [560.0]); L = max([t["x"] + t["w"] for t in D] or [1200.0]) + P
        ld = float(ph.get("loi_di") or 1100); dx = float(ph.get("dao_x") if ph.get("dao_x") not in (None, "") else 600)
        if (ph.get("dao_quay") or "tuong") == "tuong": out["D"] = dict(ox=dx + L, oz=dA + ld + Dd + 18.0, goc=180, dai=L, trai="ho", phai="ho")
        else: out["D"] = dict(ox=dx, oz=dA + ld + P, goc=0, dai=L, trai="ho", phai="ho")
    for k, v in out.items(): v["id"] = k; v["ten"] = TEN_DAY[k]
    return out


def the_gioi(d, lx, lz):
    g = int(d.get("goc") or 0) % 360
    if g == 90: return d["ox"] + lz, d["oz"] - lx
    if g == 180: return d["ox"] - lx, d["oz"] - lz
    if g == 270: return d["ox"] - lz, d["oz"] + lx
    return d["ox"] + lx, d["oz"] + lz


def hoan_thien(job):
    """Hoàn thiện cả phòng: từng dãy tủ (A tường sau, B tường trái, C tường phải, D đảo) được hoàn thiện theo toạ độ riêng của dãy.
    Góc chữ L / U: dãy A chạy hết vào góc; dãy B / C lùi ra khỏi mặt trước dãy A và có FILLER GÓC. Đảo: panel 2 đầu + PANEL LƯNG."""
    ph = dict(tuong_trai=False, tuong_phai=False, tran=0, filler=30, bc=False, led=False, splashback=""); ph.update(job.get("phong") or {})
    ph = {k: v for k, v in ph.items() if not k.startswith("_")}
    raw = [t for t in job.get("tu", []) if not t.get("auto")]
    ids = cac_day(ph, raw)
    if ids == ["A"] and not ph.get("dai_a"):
        j, ghi = _ht_day(dict(job, phong=ph)); j["phong"] = {k: v for k, v in j["phong"].items() if not k.startswith("_")}
        return j, ghi
    kq = {}; ghi = []; them = []

    def chay(d, **extra):
        sub = [t for t in raw if (t.get("day") or "A") == d]
        j, g = _ht_day(dict(job, tu=sub, phong=dict(ph, _id=d, **extra)))
        kq[d] = {t.get("id"): t for t in j["tu"] if not t.get("auto")}
        for t in j["tu"]:
            if t.get("auto"): t["day"] = d; them.append(t)
        ghi.extend((g0 if g0.startswith("Dãy") else f"Dãy {d} ({TEN_DAY[d]}): {g0}") for g0 in g if not g0.startswith("Chưa đánh dấu tường"))
        return [chuan_hoa(t) | {"id": t.get("id")} for t in j["tu"] if not t.get("auto")], j["phong"]

    coB, coC = "B" in ids, "C" in ids
    A, _ = chay("A", tuong_trai=bool(ph.get("tuong_trai") or coB), tuong_phai=bool(ph.get("tuong_phai") or coC), _dai=float(ph.get("dai_a") or 0))
    if coB: chay("B", tuong_trai=bool(ph.get("b_tuong")), tuong_phai=False, _phai="goc", _lui_phai=_lui(A, "trai"), _dai=float(ph.get("dai_b") or 0))
    if coC: chay("C", tuong_trai=False, tuong_phai=bool(ph.get("c_tuong")), _trai="goc", _lui_trai=_lui(A, "phai"), _dai=float(ph.get("dai_c") or 0))
    if "D" in ids:
        D, _ = chay("D", tuong_trai=False, tuong_phai=False)
        duoi = [t for t in D if t["loai"] in TU_DUOI + ("thiet_bi",) and not t["goc"]]
        if duoi:                                                              # lưng đảo lộ ra phòng: panel ván màu suốt chiều dài, cao từ sàn tới mặt trên thùng
            P = VAT_LIEU[_VLP[0]]["lz"]; x0 = min(t["x"] for t in duoi) - P; x1 = max(t["x"] + t["w"] for t in duoi) + P
            hh = max(t["chan"] + t["h"] for t in duoi); z0 = min(t["z"] for t in duoi)
            n = max(1, -(-int(x1 - x0) // 2400)); L = (x1 - x0) / n
            for k in range(n):
                t = _tam("Panel lưng đảo", "dung", x0 + k * L, 0, z0 - P, L, hh, P, ghi="Lưng đảo / bar lộ ra phòng – ván màu, vân dọc"); t["day"] = "D"; them.append(t)
    out = []
    for t in job.get("tu", []):
        if t.get("auto"): continue
        n = dict(t); c = kq.get(t.get("day") or "A", {}).get(t.get("id"))
        if c: n["x"] = c["x"]
        out.append(n)
    for k, t in enumerate(them): t["id"] = f"auto{k:02d}"
    j = dict(job); j["tu"] = out + them; j["phong"] = ph
    return j, ghi
