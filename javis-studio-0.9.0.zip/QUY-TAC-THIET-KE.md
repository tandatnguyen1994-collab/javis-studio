# Quy tắc thiết kế tủ của TPW (anh Tan dặn) – Javis PHẢI đọc trước khi vẽ bất kỳ hệ tủ nào

Cập nhật 19/11/2026. Thêm quy tắc mới thì ghi tiếp xuống dưới, kèm ngày. Các quy tắc cắt CNC nằm ở `CNC-QUY-TRINH.md`.

## 1. Không bao giờ để lộ thùng trắng
- Tủ cao (pantry, tủ lò, tủ áo) đứng cạnh tủ thấp hoặc nối với tủ treo: PHẢI có **panel hông** ván màu che hết hông tủ cao (từ sàn tới đỉnh).
- Đầu hàng tủ hở (không sát tường): panel hông ván màu. Tủ dưới / tủ cao: panel từ sàn. **Tủ treo: panel cao bằng đúng chiều cao tủ treo.**
- Panel sâu hơn thùng 18 để che luôn mép cánh.

## 2. Đầu hàng sát tường: filler, không làm khít
- Một bên là tường chết thì đặt **filler mặt** ở bên đó để trừ hao đo sai / tường không thẳng. Khe thiết kế mặc định 30.
- Filler sát tường không cần panel sâu hết tủ: tấm rộng **100** là đủ (tiết kiệm ván), cắt dư để thợ scribe theo tường tại chỗ.
- Hàng tủ dưới có filler thì hàng tủ treo phía trên cũng phải có filler thẳng hàng.

## 3. Bulkhead / nẹp trần là chỗ để chỉnh chiều cao
- Phần phía trên đầu tủ (bulkhead) dùng để ăn sai số chiều cao. Lệch trong khoảng 20mm thì chấp nhận.
- Lệch nhiều hơn thì phải thiết kế sao cho thợ ráp chỉnh được tại jobsite: nẹp trần cắt dư 20, không làm tủ đụng trần.
- Khe tới trần lớn (trên ~600): bulkhead thạch cao do builder, không làm bằng ván.

## 4. Thiết bị bếp phải vừa
- Luôn hỏi / tra model thiết bị trước khi chốt: lò nướng, vi sóng, hút mùi, bếp, máy rửa bát, tủ lạnh.
- **Lò nướng 60cm**: hộc lò rộng tối thiểu 560, sâu tối thiểu 550, cao 580–600 tuỳ hãng (AEG/Electrolux 600 hoặc 590, Fisher & Paykel 580, có máy 575–585). Tủ 600 ván 16.4 có lòng 567 là vừa. Phải chừa thông gió sau lò theo hãng.
- **Hút mùi âm tủ (undermount)**: lỗ khoét đáy tủ treo tuỳ model. 52cm thường 490–505 × 262–275; 86cm khoảng 840 × 243. Mép lỗ cách mép tủ tối thiểu 35. Ống thoát Ø150 lên nóc. Tủ treo 300 sâu thường KHÔNG đủ, cần tủ sâu hơn (350).
- Máy rửa bát: khoang 600, kicker chạy luôn bên dưới. Tủ lạnh: chừa khe thông gió theo hãng, tủ trên tủ lạnh sâu hơn tủ treo thường.

- **Máy rửa chén và tủ lạnh ÂM (integrated) phải có cửa cùng màu cánh** (anh Tan 19/11). Studio có 2 loại riêng trong thư viện "Thiết bị":
  - *Máy rửa chén*: âm tủ → tự ra "Cửa máy rửa chén (cùng màu cánh)" rộng = tủ − 3, cao bằng cánh tủ bên cạnh, KHÔNG khoan bản lề (bắt vào cửa máy theo dưỡng của hãng); kickface chạy luôn bên dưới; bếp shadowline thì có thanh 50 phía trên. Bán âm → tấm cửa nằm dưới bảng điều khiển. Rời → không làm cửa. Số hãng: khoảng lọt 600 rộng, 820–880 cao, ≥ 560 sâu; panel rộng ≥ 596, cao thường 655–765, dày 16–25, nặng 3–10 kg → Studio báo khi lệch.
  - *Tủ lạnh*: âm tủ → thùng tủ cao có hộc tủ lạnh (lọt lòng ≥ 560 rộng, ≥ 550 sâu, cao 1772–1780 tuỳ model, mặc định 1780), hộc để hở hậu + đáy khoét thông gió ≥ 200 cm², cửa tủ lạnh cùng màu cánh (1 cửa suốt hoặc 2 cửa trên/dưới theo model), tủ nhỏ phía trên. Bản lề: cố định (door-on-door, không khoan bản lề) hoặc trượt (sliding, có bản lề tủ) – PHẢI hỏi model. Rời → chỉ chừa khoảng, có panel cao 2 bên, không filler, không kickface.
  - Chưa kiểm với cách TPW đã ráp thực tế (giằng sau hộc tủ lạnh, vị trí thông gió) – hỏi Huân / anh Tan trước khi cắt.

## 5. Tuỳ chọn phải hỏi / phải có trong bản vẽ
- Kiểu cánh: phẳng hay **shaker** (shaker cộng tiền, MDF 21 sơn PU, Huân ra chương trình phay).
- Kiểu mở: **tay nắm**, **shadowline** hay bấm mở.
- Mặt đá dày **20 / 40 / 60 / 100**.
- Màu vật liệu: lấy đúng màu từ website nhà cung cấp (Polytec, Laminex, ForestOne…), ghi tên màu lên bản vẽ và nhãn.

- **Kiểu cửa phải chọn được ngay khi bỏ tủ mới vào** (anh Tan 19/11): handle hay shadowline, phẳng hay shaker. Studio có ô "Kiểu cửa cho tủ mới" ngay trên thư viện + nút áp cho tất cả tủ đang có; AI vẽ cũng lấy theo ô này nếu anh không nói rõ.

- **Pantry (tủ cao 1 thùng) không làm fingerpull / shadowline** – chỉ khi tách 2 tủ chồng nhau (anh Tan 20/11). Studio: tự chuyển tay nắm + báo; có ô "Tách 2 thùng".
- **Mọi tấm phụ (panel hông, kickface, filler, thanh shadowline, bulkhead) phải cùng màu cánh** – cánh shaker sơn thì tấm phụ MDF sơn cùng màu (anh Tan 20/11: "shadowline lộ cạnh trắng").
- Thư viện phải có **tủ góc L, tủ góc mù (blind corner), tủ cong bo cạnh** (anh Tan 20/11) – đã thêm bản 0.6, kết cấu cần Huân/anh kiểm.

## 6. Cách làm việc
- Mọi yêu cầu của anh Tan đều phải ghi lại thành quy tắc ở đây / trong bộ nhớ để lần sau không sai lại.
- Làm xong phải tự kiểm, tự test hết rồi mới đưa anh xem.
- Đọc thêm tài liệu (hướng dẫn lắp của hãng thiết bị, tài liệu nhà cung cấp ván) trước khi tự đặt số.

- **Tủ mới phải tự nối với tủ cũ và không được chồng lên tủ cũ** (anh Tan 19/11). Studio: thêm tủ sau tủ đang chọn thì các tủ bên phải tự dạt ra; đổi bề rộng thì các tủ nối liền đi theo; kéo đè lên tủ khác thì tủ đang kéo nhảy tới chỗ trống gần nhất sát tủ cũ; tủ treo không đè lên tủ cao; còn chồng (file cũ / AI) thì có cảnh báo đỏ.
- **Ô số đo phải tính trực tiếp được** (anh Tan 19/11): đang 720 gõ `-20` → 700; cũng nhận `+50`, `720-20`, `600+16`, `1200/2`, `2x300`.

## 7. Shadowline (fingerpull), BC panel, LED (anh Tan dặn 19/11 tối)
- Bếp dùng **shadowline / fingerpull** thì tủ treo đi kèm **cánh dư xuống dưới đáy thùng 20mm** để móc tay.
- Có **BC panel** (tấm panel che mặt đáy dàn tủ treo, để soi rãnh LED) thì cánh tủ treo phải **dư 40mm**.
- Làm LED thì phải biết **splashback là gì** (gạch, đá, kính) trước khi đặt rãnh.
- Studio: tủ treo chọn kiểu mở Shadowline → cánh tự dư 20, bật BC panel trong Hoàn thiện → tự dư 40; chọn LED mà chưa chọn splashback thì cảnh báo.

- **Chỗ khoét shadowline phải có thanh 50mm cùng màu cánh chèn vào** (hoặc cho chọn chèn loại khác). Studio: mỗi tủ shadowline tự có "Thanh shadowline 50 (cùng màu cánh)" trong danh sách cắt, tắt được ở thuộc tính tủ.
- **Kickface**: mặt chân tủ cùng màu cánh, chạy dài theo hàng tủ. Studio tự thêm.

## 8. Học từ 9 bộ bản vẽ sản xuất anh gửi (Cabinet Vision của Huân) – em mới đọc kỹ 7/50 trang
Đã đọc: 22 Fitzwater (trang 1–3), job 66 Opah St (1, 3), Unit 2 Eastwood (2), Master bed Unit 1 (1), Bexley laundry (1). CHƯA đọc: phần còn lại + Ryan House, Unit 1 Eastwood, Unit 2 (5 trang).
- **Chân tủ 130** ở mọi job. Kicker ghi thành đoạn dài: `KICKER dài × sâu × 130H` (vd 7000×510×130, tủ pantry 380 sâu) → TPW làm **kicker dạng đế chạy dài**, không dùng chân nhựa.
- **Tủ dưới**: thùng 750 + đá 40 = mặt bếp 920 (Fitzwater); 730 + đá 40 = 900 (job 66, Eastwood); đảo 710 + đá 60 = 900. Studio đặt mặc định 130 + 730 + 40.
- **Panel 16 (ván màu) hoặc 18 (MDF poly)** ở HAI đầu mọi hàng tủ và hai bên mọi tủ cao / hộc tủ lạnh (panel tủ lạnh sâu 750). Laundry lọt giữa 2 tường vẫn có panel 2 bên.
- **Tủ cao tới trần = tủ dưới + hộp trên + nẹp trần**: WIP 130 + 1970 + 500 + 20; tủ áo 130 + 1890 + 530 + 150; bếp Eastwood nẹp trần 120. Tức là tủ cao chia 2 thùng chồng lên nhau, phần trên cùng là nẹp để chỉnh.
- **Filler ghi "Cut later"** (job 66: 201 và 80) = cắt tại chỗ. Hút mùi Eastwood: tủ 820 có filler 65 mỗi bên.
- **BC panel** vẽ dưới đáy tủ treo (Eastwood).
- **Tủ lò (oven tower)**: rộng 600, panel 2 bên. Eastwood: 2 ngăn kéo dưới → OVEN → M/W → cánh trên. Fitzwater: 1 ngăn kéo dưới → OVEN (trong tầm tủ dưới 750) → MICROWAVE 598 → tủ cánh trên 1122 có kệ ADJ. Studio đặt mặc định 2 ngăn kéo + lò 595 + vi sóng 380 + cánh trên.
- **Tủ hút mùi** (Eastwood #9): tủ treo NGẮN hơn tủ bên cạnh (đáy cao hơn), cánh lật lên, máy hút mùi nằm bên dưới, filler 2 bên.
- **Phụ kiện trong tủ** (Fitzwater): SPICE RACK tủ 450, BIN tủ 450, INTEGRATED DW 610, ngăn kéo 900, "inner drawer" trong tủ áo, LED kicker / LED kệ.
- Bản vẽ có khung tên: BASE CABS DOORS (vd "Colour Board 45 Grain Doors" = cánh ván màu vát 45 cho shadowline, "MDF POLY Std Doors"), CONSTRUCTION ("1 - STD Internal Back" / "3 - SHDWLNE Internal Back"), DRAWER SYSTEM (Blum Antaro), HINGE SYSTEM (Blum soft close Inserta), HANDLES.

### 8b. Đọc thêm đêm 20/11: Unit 1 Eastwood (8 trang, MDF poly std doors) + Ryan House Extra (2 trang)
- **Chiều cao bếp Eastwood, trần 2780**: kick 130 + thùng dưới 730 + đá 40 + splashback 700 + tủ treo **1040** + bulkhead/scribe **120** = 2760 (+18 panel). → Tủ treo cao 1040 chứ không phải 900 khi trần 2780; Studio nên tính tủ treo = trần − 120 − 1600 (mặt đá 900 + splash 700).
- **Tủ lò (oven tower) Eastwood**: 2 ngăn kéo dưới (trong vùng 730) → OVEN → M/W → tủ trên; **tách 2 thùng: dưới 1530 + hộp trên 1130**, đỉnh hộp trên thẳng với đỉnh tủ treo, bulkhead 120 chung. Studio hiện dựng 1 thùng suốt → cần tuỳ chọn tách thùng (đã ghi việc tiếp).
- **Face filler 40mm** ở đầu hàng tủ dưới sát tường (chỗ máy giặt / tủ #9), ghi rõ "Face filler 40mm" trên bản vẽ. **BC panel** vẽ dưới tủ treo, **Undermount RH** trong tủ treo 950 ngay trên bếp.
- **Tủ lạnh**: khoảng chừa **964** (tủ lạnh đứng 2 cánh), hộp trên tủ lạnh cao **790** + khe 20 trên nóc tủ lạnh, panel 2 bên 18.
- **Máy giặt 610** đặt hở dưới mặt đá (không cửa), kế bên máy rửa bát 450 (#4) và tủ chậu 762 (#3); kickface chạy luôn dưới máy rửa bát.
- **Đảo 1600 × 900 cao (130 + 730 + 40)**: 2 tủ 3 ngăn kéo 782 + panel 18 hai đầu + panel hậu; kick màu đỏ nổi bật trên bản vẽ 3D = kickface cùng màu.
- Bản vẽ Cabinet Vision của Huân luôn có: trang 1 hình 3D cả phòng, trang mặt bằng có số tủ, mỗi tường 1 mặt đứng với kích thước từng tủ (ngang) và tầng (dọc), khung tên ghi loại cánh / construction / hinge. → "Bản vẽ 2D" của Studio (bản 0.5) đã theo đúng bố cục này; còn thiếu hình 3D trang đầu và khung tên loại cánh.
- **Ryan House Extra**: tủ giày + pantry sink, kệ mở nhiều ngăn (ô 584/150), tủ cao có kệ chia nhỏ; bản vẽ cũ của M&N Joinery dùng kick đỏ, cánh ván màu vân gỗ.

## 9. Phụ kiện kéo (tra tài liệu hãng 19/11)
- Thùng rác / kệ kéo cho tủ 450: cần **lòng tủ 418** (Blum Tandembox antaro bin 418 × 510 sâu, cao lòng tối thiểu 610; Hafele rổ kéo 450/600/900 → lòng 418/568/868). Hailo Euro Cargo 45: mặt cao tối thiểu 600, tủ sâu tối thiểu 560, mặt bắt thẳng vào khung thùng (không bản lề).
- Tủ kéo trong Studio: 1 mặt cao hết tủ, không kệ, không bản lề, đếm 1 bộ phụ kiện, cảnh báo khi mặt < 600 hoặc tủ < 560 sâu.

## 10. Miếng uốn cong – rút từ file cũ của Huân (6 file có rãnh uốn)
- Ván màu 16, dao **10_MDF Ø10, CRC 0**, rãnh chạy suốt bề rộng miếng, **sâu 14.5–14.8** (chừa lại lớp mặt 1.2–1.5mm), **bước rãnh 14** (rãnh 10 + gân 4).
- Số rãnh cho 1 góc 90°: file có 19 rãnh đi với cung R144 (mặt trong) / R161 (mặt ngoài): 19 × 14 = 266 ≈ ¼ chu vi mặt ngoài (253) + 1 rãnh dư. Công thức em dùng: **số rãnh ≈ (π/2 × R ngoài) / 14 + 1**, rãnh đầu và cuối lố qua tiếp điểm 1 bước.
- **Base bên trong (cốt uốn)**: các tấm HMR cắt cung, bán kính = R ngoài − 16 (file Huân: HMR R147 đi với mặt ngoài ~R161–163). Gân của miếng uốn tì lên mép cong của các tấm base này.
- Bán kính nhỏ nhất gặp trong file: 144 (mặt trong) với ván màu 16. Nhỏ hơn nữa em CHƯA có bằng chứng là không vỡ → hỏi Huân.
- Để uốn không vỡ (cách làm chung của nghề, cần anh / Huân xác nhận cho ván của mình): chừa mặt không dưới 1.2mm; rãnh song song, đều bước; đặt tấm base trên + dưới + giữa cách nhau khoảng 300–400; bơm keo vào rãnh rồi ép dần theo base, không bẻ gấp; bắn đinh / vít vào gân chứ không vào chỗ rãnh.

### 10b. Cách TPW làm cục cong THẬT – job 31 Lonhro "tam uon cong" (anh Tan chỉ 20/11) → Studio phải làm y vậy
- **1 TẤM QUẤN liền** cho cả mặt: hông phẳng + cung + mặt phẳng + cung + hông (job 31: 554 cao × 1605 dài, "curve panel", Cab #27). Không cắt rời từng cục cong.
- Tấm nằm **ngang** trên ván (chiều dài quấn theo chiều 2410 = theo vân) → vân chạy ngang quanh cục cong. Rãnh uốn **chạy suốt chiều cao** (lố 0.15 mỗi đầu), chỉ nằm trong vùng cung, vùng phẳng không rãnh.
- Rãnh: dao **10_MDF Ø10, CRC 0, ZS −35 / ZE 49.5 → sâu 14.5** trên ván 16, **bước 14**; job 31 mỗi cung 24 rãnh (vùng 322 mm). Outline 10_MDF CRC 2 như thường.
- Số rãnh = (π/2 × R ngoài) / 14 + 1, rải đều quanh tâm cung. Cốt uốn: nóc / vành giữa / đế HMR cắt cung R ngoài − 16 (mục 10).
- Job 22 rangehood 1300: tấm quấn 1928 × 1100 (hông 200 | cung R200 23 rãnh | mặt 900 | cung | hông 200), lưng ván màu 1300 × 1100 vân ngang cùng chiều, đáy ván màu bo R200, xương HMR 4 vành R184 + 4 trụ.

## Chỗ Javis đang hiểu, cần anh xác nhận
- "Filler sâu 100mm": em đang hiểu là **tấm filler rộng 100, cắt dư, thợ cắt lại theo khe thực tế** (đặt mặt trước, ngang mặt cánh).
- Tủ treo sát tường: em đang cho **filler** giống tủ dưới; tủ treo đầu hở thì **panel cao bằng tủ treo**.
