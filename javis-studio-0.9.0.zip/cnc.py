"""Javis Studio - ghi file CIX (Biesse Klever, bSolid CID3) + xep tam MaxRects.
Dinh dang khoi lenh giong tung byte voi file Cabinet Vision cua Huan (da kiem chung 18/11-19/11/2026)."""
import random, time

def f3(v):
    s = f"{v:.3f}"
    return "-0.000" if s == "-0.000" else s


def _m(lines):
    return "BEGIN MACRO\r\n" + "".join(lines) + "END MACRO\r\n"




def _rout_head(n, tnm, crc, dia=None):
    dia = dia or (3.0 if tnm == "FPV" else 10.0)
    return _m([
        "        NAME=ROUT\r\n",
        f'        PARAM,NAME=ID,VALUE="{n}001"\r\n',
        '        PARAM,NAME=CRN,VALUE="2"\r\n',
        "        PARAM,NAME=SIDE,VALUE=0\r\n",
        "        PARAM,NAME=DP,VALUE=0\r\n",
        f"        PARAM,NAME=DIA,VALUE={dia:.3f}\r\n",
        f'        PARAM,NAME=TNM,VALUE="{tnm}"\r\n',
        f"        PARAM,NAME=CRC,VALUE={crc}\r\n",
        "        PARAM,NAME=TCL,VALUE=1\r\n",
        "        PARAM,NAME=BFC,VALUE=YES\r\n",
        "\tPARAM,NAME=VTR,VALUE=0\t\r\n",
        "        PARAM,NAME=TIN,VALUE=0\r\n",
        "        PARAM,NAME=AIN,VALUE=0\r\n",
        "        PARAM,NAME=DIN,VALUE=0\r\n",
        "        PARAM,NAME=TOU,VALUE=0\r\n",
        "        PARAM,NAME=AOU,VALUE=0\r\n",
        "        PARAM,NAME=DOU,VALUE=0\r\n",
        "        PARAM,NAME=OPT,VALUE=0\r\n",
        "        PARAM,NAME=TTP,VALUE=102\r\n",
        "        PARAM,NAME=SHP,VALUE=2\r\n",
        "        PARAM,NAME=THR,VALUE=NO\r\n",
    ])


def _sp(n, p):
    return _m(["        NAME=START_POINT\r\n", f'        PARAM,NAME=ID,VALUE="{n}002"\r\n',
               f"        PARAM,NAME=X,VALUE={f3(p[0])}\r\n", f"        PARAM,NAME=Y,VALUE={f3(p[1])}\r\n"]) + "\r\n"


def _line(n, i, p, z=None):
    ln = ["        NAME=LINE_EP\r\n", f'        PARAM,NAME=ID,VALUE="{n}{i:03d}"\r\n',
          f"        PARAM,NAME=XE,VALUE={f3(p[0])}\r\n", f"        PARAM,NAME=YE,VALUE={f3(p[1])}\r\n"]
    if z is None:
        ln.append("        PARAM,NAME=ZE,VALUE=-0.000\t\t\r\n")
    elif z[0] == "zs":
        ln.append("        PARAM,NAME=ZS,VALUE=-35.000\r\n")
        ln.append(f"        PARAM,NAME=ZE,VALUE={f3(z[1])}\t\t\r\n")
    else:
        ln.append(f"        PARAM,NAME=ZE,VALUE={f3(z[1])}\t\t\r\n")
    return _m(ln)


def _circ3(a, b, c):
    ax, ay = a; bx, by = b; cx, cy = c
    d = 2 * (ax * (by - cy) + bx * (cy - ay) + cx * (ay - by))
    if abs(d) < 1e-9: return None
    ux = ((ax * ax + ay * ay) * (by - cy) + (bx * bx + by * by) * (cy - ay) + (cx * cx + cy * cy) * (ay - by)) / d
    uy = ((ax * ax + ay * ay) * (cx - bx) + (bx * bx + by * by) * (ax - cx) + (cx * cx + cy * cy) * (bx - ax)) / d
    return ux, uy, ((ax - ux) ** 2 + (ay - uy) ** 2) ** .5


def fit_arcs(pts, tol=0.1, maxseg=30.0, maxang=2.9):
    """Bích 21/11 (KIM): cạnh cong cắt bằng nhiều đoạn thẳng bị lồi lõm -> gộp chuỗi điểm nằm trên 1 cung thành ARC_EPRA (như Cabinet Vision).
    pts: [p0, p1, ...] -> [('L', p) | ('A', p, R, 'dirCCW'|'dirCW')] cho các điểm p1.. (p0 là điểm đang đứng)."""
    import math
    out = []; i = 0; n = len(pts)
    while i < n - 1:
        best = None; j = i + 3
        while j < n:
            seg_ok = all(((pts[k + 1][0] - pts[k][0]) ** 2 + (pts[k + 1][1] - pts[k][1]) ** 2) ** .5 <= maxseg and pts[k + 1] != pts[k] for k in range(i, j))
            if not seg_ok: break
            c = _circ3(pts[i], pts[(i + j) // 2], pts[j])
            if c is None or c[2] > 5000: break
            ux, uy, R = c
            if any(abs(((pts[k][0] - ux) ** 2 + (pts[k][1] - uy) ** 2) ** .5 - R) > tol for k in range(i, j + 1)): break
            cr = [(pts[k][0] - pts[k - 1][0]) * (pts[k + 1][1] - pts[k][1]) - (pts[k][1] - pts[k - 1][1]) * (pts[k + 1][0] - pts[k][0]) for k in range(i + 1, j)]
            if not (all(x > 0 for x in cr) or all(x < 0 for x in cr)): break
            ang = 0.0
            for k in range(i, j):
                a0 = math.atan2(pts[k][1] - uy, pts[k][0] - ux); a1 = math.atan2(pts[k + 1][1] - uy, pts[k + 1][0] - ux)
                ang += abs((a1 - a0 + math.pi) % (2 * math.pi) - math.pi)
            if ang > maxang: break
            best = (j, R, "dirCCW" if cr[0] > 0 else "dirCW"); j += 1
        if best:
            j, R, d = best; out.append(("A", pts[j], R, d)); i = j
        else:
            out.append(("L", pts[i + 1])); i += 1
    return out


def _arc(n, i, p, R, d):
    return _m(["        NAME=ARC_EPRA\r\n", f'        PARAM,NAME=ID,VALUE="{n}{i:03d}"\r\n',
               f"        PARAM,NAME=XE,VALUE={f3(p[0])}\r\n", f"        PARAM,NAME=YE,VALUE={f3(p[1])}\r\n",
               "        PARAM,NAME=SOL,VALUE=1\r\n", f"        PARAM,NAME=R,VALUE={f3(R)}\r\n",
               "        PARAM,NAME=ZE,VALUE=-0.000\r\n", f"        PARAM,NAME=DIR,VALUE={d}\r\n"])


def _chain(n, i0, pts):
    """khối lệnh cho chuỗi pts[1:] (đang đứng ở pts[0]); trả (text_blocks, số lệnh)"""
    bl = []
    for k, it in enumerate(fit_arcs(pts)):
        bl.append(_line(n, i0 + k, it[1]) if it[0] == "L" else _arc(n, i0 + k, it[1], it[2], it[3]))
    return bl


def outline_rout(n, poly, tnm, lz, crc=1):
    """poly: CW polygon, poly[0]=C entry corner, the edge poly[-1]->poly[0] must be >=100mm long (lead-in edge)."""
    C = poly[0]; prev = poly[-1]
    dx, dy = C[0] - prev[0], C[1] - prev[1]; L = (dx * dx + dy * dy) ** .5; d = (dx / L, dy / L)
    P = lambda k: (C[0] + k * d[0], C[1] + k * d[1])
    out = "\r\n" + _rout_head(n, tnm, crc) + _sp(n, P(-30))
    blocks = [_line(n, 3, P(-20), ("zs", lz + 35)), _line(n, 4, C)]
    blocks += _chain(n, 5, [C] + list(poly[1:]))
    i = 5 + len(blocks) - 2
    blocks += [_line(n, i, P(-70)), _line(n, i + 1, C), _line(n, i + 2, P(10), ("ze", -(lz + 35)))]
    out += "\r\n".join(blocks)
    out += _m(["        NAME=ENDPATH\r\n", f'        PARAM,NAME=ID,VALUE="{n}{i + 3:03d}"\r\n'])
    return out


def groove_rout(n, pts, depth, tnm):
    """open polyline groove, tool centre on line (CRC=0), plunge at pts[0]."""
    out = "\r\n" + _rout_head(n, tnm, 0) + _sp(n, pts[0])
    blocks = [_line(n, 3, pts[0], ("zs", depth + 35))] + _chain(n, 4, list(pts))
    out += "\r\n".join(blocks)
    out += _m(["        NAME=ENDPATH\r\n", f'        PARAM,NAME=ID,VALUE="{n}{len(blocks) + 3:03d}"\r\n'])
    return out


def bg(x, y, dia, dp):
    return _m(["        NAME=BG\r\n", '        PARAM,NAME=CRN,VALUE="2"\r\n',
               f"        PARAM,NAME=X,VALUE={f3(x)}\r\n", f"        PARAM,NAME=Y,VALUE={f3(y)}\r\n",
               "        PARAM,NAME=Z,VALUE=0\r\n", f"        PARAM,NAME=DIA,VALUE={f3(dia)}\r\n",
               "        PARAM,NAME=TTP,VALUE=0\r\n", '        PARAM,NAME=ID,VALUE="0"\r\n',
               f"        PARAM,NAME=DP,VALUE={f3(dp)}\r\n", "        PARAM,NAME=SIDE,VALUE=0\r\n"])


def orient(poly, ccw):
    """CW (CRC1, HMR) or CCW (CRC2, colour board / MDF) loop; entry corner chosen so the lead-in edge is the longest edge."""
    a = sum(poly[i][0] * poly[i - 1][1] - poly[i - 1][0] * poly[i][1] for i in range(len(poly)))  # >0 => CW
    if (a > 0) == ccw: poly = poly[::-1]
    L = [((poly[i][0] - poly[i - 1][0]) ** 2 + (poly[i][1] - poly[i - 1][1]) ** 2, i) for i in range(len(poly))]
    k = max(L)[1]
    return poly[k:] + poly[:k]


def write_sheet(path, lx, ly, lz, material, placed, tnm, crc=1, gtnm=None):
    """placed: list of dicts with world-coord 'poly','holes','grooves' (already transformed), small parts first."""
    s = ("BEGIN ID CID3\r\n  REL=5.0\r\nEND ID\r\n\r\nBEGIN MAINDATA\r\n"
         f"        LPX={f3(lx)}\r\n        LPY={f3(ly)}\r\n        LPZ={f3(lz)}\r\n        FCN=1.000\r\n"
         f'        MATERIAL="{material}"\r\n        ORLST="1"\r\nEND MAINDATA\r\n\r\n\r\n')
    s += _m(["        NAME=OFFSET\r\n", "        PARAM,NAME=X,VALUE=0.000\r\n", "        PARAM,NAME=Y,VALUE=0.000\r\n",
             "        PARAM,NAME=Z,VALUE=0\r\n", "        PARAM,NAME=SHW,VALUE=NO\r\n"])
    for p in placed:
        for h in p["holes"]:
            s += bg(*h)
    k = 0
    for p in placed:
        for g, dp in p["grooves"]:
            k += 1; s += groove_rout(k, g, dp, gtnm or tnm)
    for p in placed:
        k += 1; s += outline_rout(k, orient(p["poly"], crc == 2), tnm, lz, crc)
    open(path, "w", newline="").write(s)


# ---------------------------------------------------------------- xep tam (MaxRects)
def maxrects2(parts, LX=2410, LY=1210, M=4, GAP=15, order_key=None, rule='bssf', rot=False):
    W,H=LX-2*M+GAP, LY-2*M+GAP
    order=sorted(range(len(parts)),key=order_key)
    sheets=[]
    def score(fw,fh,w,h,fx,fy):
        if rule=='bssf': return (min(fw-w,fh-h),max(fw-w,fh-h))
        if rule=='blsf': return (max(fw-w,fh-h),min(fw-w,fh-h))
        if rule=='baf': return (fw*fh-w*h,min(fw-w,fh-h))
        if rule=='bl': return (fy+h,fx)
    def place(sh,i):
        best=None
        opts=[(parts[i]['w'],parts[i]['h'],0)]
        if rot and parts[i].get('canrot',True): opts.append((parts[i]['h'],parts[i]['w'],1))
        for pw,ph,r in opts:
            w,h=pw+GAP,ph+GAP
            for fx,fy,fw,fh in sh['free']:
                if w<=fw+1e-6 and h<=fh+1e-6:
                    sc=score(fw,fh,w,h,fx,fy)
                    if best is None or sc<best[0]: best=(sc,fx,fy,w,h,r)
        if not best: return False
        _,x,y,w,h,r=best; rr=(x,y,x+w,y+h); nf=[]
        for f in sh['free']:
            fx0,fy0,fx1,fy1=f[0],f[1],f[0]+f[2],f[1]+f[3]
            if rr[0]>=fx1 or rr[2]<=fx0 or rr[1]>=fy1 or rr[3]<=fy0: nf.append(f); continue
            if rr[0]>fx0: nf.append((fx0,fy0,rr[0]-fx0,f[3]))
            if rr[2]<fx1: nf.append((rr[2],fy0,fx1-rr[2],f[3]))
            if rr[1]>fy0: nf.append((fx0,fy0,f[2],rr[1]-fy0))
            if rr[3]<fy1: nf.append((fx0,rr[3],f[2],fy1-rr[3]))
        nf=list(set(nf))
        nf=[a for a in nf if not any(a!=b and a[0]>=b[0] and a[1]>=b[1] and a[0]+a[2]<=b[0]+b[2] and a[1]+a[3]<=b[1]+b[3] for b in nf)]
        sh['free']=nf; sh['items'].append((i,x+M,y+M,r)); return True
    for i in order:
        if not any(place(sh,i) for sh in sheets):
            sh={'free':[(0,0,W,H)],'items':[]}; sheets.append(sh); assert place(sh,i)
    return sheets



def place_fn(w, h, rot, tx, ty):
    """toa do chi tiet -> toa do tren tam. rot=1: xoay 90 do nguoc chieu kim dong ho."""
    if not rot:
        return lambda x, y: (round(x + tx, 3), round(y + ty, 3))
    return lambda x, y: (round(-y + h + tx, 3), round(x + ty, 3))


def nest(Q, LX, LY, budget=2.0, seed=3):
    """Q: [dict(w,h,canrot)] -> list sheets [{'items':[(i,x,y,rot)]}]; thu nhieu thu tu, lay phuong an it tam nhat."""
    best = None; rnd = random.Random(seed); t0 = time.time(); n = 0
    while n < 6 or time.time() - t0 < budget:
        n += 1
        noise = {i: Q[i]["w"] * Q[i]["h"] * (1 if n == 1 else rnd.uniform(.8, 1.2)) for i in range(len(Q))}
        for rule in ("bssf", "baf"):
            s = maxrects2(Q, LX=LX, LY=LY, order_key=lambda i: -noise[i], rule=rule, rot=True)
            sc = (len(s), sum(Q[i]["w"] * Q[i]["h"] for i, _, _, _ in s[-1]["items"]))
            if best is None or sc < best[0]: best = (sc, s)
        if n > 400: break
    return best[1]
