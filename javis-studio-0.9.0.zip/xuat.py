"""Javis Studio - xuất bộ file cắt: .cix (mỗi tấm 1 file) + CncRun##.txt + layout.pdf + label.pdf + danh sách chi tiết / phụ kiện."""
import os, re, csv, datetime, json
from engine import VAT_LIEU, dung_job
from cnc import write_sheet, nest, place_fn

M, GAP = 4, 15
NEP = 1.0          # anh Tan: cạnh có dán nẹp thì cắt nhỏ đi 1mm (mọi tủ, kể cả BC panel) – nếu không sẽ thấy đường gợn


def tru_nep(p):
    """miếng thành phẩm -> miếng cắt: trừ NEP ở mỗi cạnh có nẹp (T/B/L/R), dời lỗ + rãnh theo."""
    e = set(p.get("edges") or ())
    if not e or p.get("da_tru"): return p
    from shapely.geometry import Polygon, box
    from shapely import affinity
    dl, dr, db, dt = [NEP if s in e else 0.0 for s in "LRBT"]
    P0 = Polygon(p["poly"])
    if not P0.is_valid: P0 = P0.buffer(0)
    W, H = p["w"], p["h"]
    vuong = len(p["poly"]) == 4 and all(abs(x) < .01 or abs(x - W) < .01 for x, _ in p["poly"]) and all(abs(y) < .01 or abs(y - H) < .01 for _, y in p["poly"])
    if vuong:
        P1 = P0.intersection(box(dl, db, W - dr, H - dt))
    else:                       # miếng có cung / chữ L / khấc: đoạn nằm trên cạnh bao KHÔNG nẹp giữ nguyên, mọi đoạn khác (cung, khấc) lùi 1
        from shapely.geometry import LineString
        from shapely.ops import unary_union
        tren = lambda x0, y0, x1, y1: ((not dl and abs(x0) < .01 and abs(x1) < .01) or (not dr and abs(x0 - W) < .01 and abs(x1 - W) < .01)
                                       or (not db and abs(y0) < .01 and abs(y1) < .01) or (not dt and abs(y0 - H) < .01 and abs(y1 - H) < .01))
        pts = list(P0.exterior.coords); giu, nep = [], []
        for (x0, y0), (x1, y1) in zip(pts, pts[1:]):
            (giu if tren(x0, y0, x1, y1) else nep).append(LineString([(x0, y0), (x1, y1)]))
        if not nep: return p
        vung_nep = unary_union(nep).buffer(NEP, cap_style=2, join_style=2)
        dai_giu = unary_union([g.buffer(1.5, cap_style=2) for g in giu]).difference(vung_nep) if giu else Polygon()
        P1 = P0.intersection(unary_union([P0.buffer(-NEP, join_style=2), dai_giu]))
    if P1.geom_type in ("MultiPolygon", "GeometryCollection"):
        ds = [g for g in getattr(P1, "geoms", []) if g.geom_type == "Polygon"]
        P1 = max(ds, key=lambda g: g.area) if ds else P1
    P1 = P1.simplify(0.05) if P1.geom_type == "Polygon" else P1
    if P1.geom_type != "Polygon" or P1.area < 1: return p
    x0, y0, x1, y1 = P1.bounds
    P1 = affinity.translate(P1, -x0, -y0)
    q = dict(p)
    q["poly"] = [(round(x, 3), round(y, 3)) for x, y in list(P1.exterior.coords)[:-1]]
    q["w"], q["h"] = round(x1 - x0, 2), round(y1 - y0, 2)
    q["holes"] = [(round(a - x0, 1), round(b - y0, 1), d, dp) for a, b, d, dp in p["holes"]]
    q["grooves"] = [([(min(max(gx - x0, -0.2), q["w"] + 0.2), min(max(gy - y0, -0.2), q["h"] + 0.2)) for gx, gy in g], dp) for g, dp in p.get("grooves", [])]
    q["fin"] = (p["w"], p["h"]); q["da_tru"] = True
    q["note"] = (f"TP {p['w']:g}x{p['h']:g} (trừ nẹp {NEP:g}). " + (p.get("note") or "")).strip()
    return q


def _font():
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.ttfonts import TTFont
    if "JV" in pdfmetrics.getRegisteredFontNames(): return "JV", "JVB"
    cands = [(r"C:\Windows\Fonts\arial.ttf", r"C:\Windows\Fonts\arialbd.ttf"),
             ("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf")]
    for a, b in cands:
        if os.path.exists(a):
            pdfmetrics.registerFont(TTFont("JV", a)); pdfmetrics.registerFont(TTFont("JVB", b if os.path.exists(b) else a))
            return "JV", "JVB"
    return "Helvetica", "Helvetica-Bold"


def ma_job(job):
    return (re.sub(r"[^0-9A-Za-z]", "", str(job.get("so") or "")) or "00")[:6]


def xep_tam(job, budget=1.5):
    """-> (kq dung_job, nhom:[{vl, v, sheets:[{prog, placed:[...], dung%}]}], kiem:[lỗi])"""
    kq = dung_job(job); so = ma_job(job); nhom = []; kiem = []
    for vl, v in VAT_LIEU.items():
        ps = [tru_nep(p) for p in kq["chi_tiet"] if p["vl"] == vl and not p.get("ngoai")]
        if not ps: continue
        ok = []
        for p in ps:
            fits = lambda w, h: w <= v["lx"] - 2 * M and h <= v["ly"] - 2 * M
            if fits(p["w"], p["h"]) or (p["rot"] and fits(p["h"], p["w"])): ok.append(p)
            else: kiem.append(f"#{p['cab']} {p['name']} {p['w']:.0f}x{p['h']:.0f} không lọt tấm – bỏ qua, phải chia nhỏ")
        Q = [dict(w=p["w"], h=p["h"], canrot=p["rot"]) for p in ok]
        sheets = []
        for si, sh in enumerate(nest(Q, v["lx"], v["ly"], budget) if Q else [], 1):
            items = sorted(sh["items"], key=lambda it: Q[it[0]]["w"] * Q[it[0]]["h"])       # miếng nhỏ cắt trước
            placed = []; used = 0
            for pn, (i, x, y, r) in enumerate(items, 1):
                p = ok[i]; fn = place_fn(p["w"], p["h"], r, x, y)
                poly = [fn(*q) for q in p["poly"]]
                holes = [(*fn(a, b), d, dp) for a, b, d, dp in p["holes"]]
                grooves = [([fn(gx, gy) for gx, gy in g], dp) for g, dp in p.get("grooves", [])]
                xs = [q[0] for q in poly]; ys = [q[1] for q in poly]
                bb = (min(xs), min(ys), max(xs), max(ys)); used += p["w"] * p["h"]
                if bb[0] < M - .01 or bb[1] < M - .01 or bb[2] > v["lx"] - M + .01 or bb[3] > v["ly"] - M + .01:
                    kiem.append(f"{vl} tấm {si} miếng {pn}: lấn mép tấm")
                for hx, hy, d, dp in holes:
                    if not (bb[0] < hx < bb[2] and bb[1] < hy < bb[3]): kiem.append(f"{vl} tấm {si} miếng {pn}: lỗ ngoài miếng")
                placed.append(dict(poly=poly, holes=holes, grooves=grooves, pn=pn, src=p, r=r, bb=bb))
            for a in placed:
                for b in placed:
                    if a["pn"] < b["pn"] and a["bb"][0] < b["bb"][2] + GAP - .1 and b["bb"][0] < a["bb"][2] + GAP - .1 and a["bb"][1] < b["bb"][3] + GAP - .1 and b["bb"][1] < a["bb"][3] + GAP - .1:
                        kiem.append(f"{vl} tấm {si}: miếng {a['pn']} sát / đè miếng {b['pn']} (khe < {GAP})")
            sheets.append(dict(prog=f"J{so}{v['ma']}{si:02d}", placed=placed, dung=round(used / (v["lx"] * v["ly"]) * 100)))
        nhom.append(dict(vl=vl, v=v, sheets=sheets))
    return kq, nhom, kiem


def xem_truoc(job):
    """dữ liệu xếp tấm gọn cho giao diện"""
    kq, nhom, kiem = xep_tam(job, 0.6)
    out = []
    for g in nhom:
        out.append(dict(vl=g["vl"], ten=g["v"]["ten"], lx=g["v"]["lx"], ly=g["v"]["ly"], mau=g["v"]["mau"], sheets=[
            dict(prog=s["prog"], dung=s["dung"], parts=[dict(pn=q["pn"], poly=q["poly"], cab=q["src"]["cab"], n=q["src"]["name"],
                                                               w=q["src"]["w"], h=q["src"]["h"], holes=[(h[0], h[1], h[2]) for h in q["holes"]]) for q in s["placed"]])
            for s in g["sheets"]]))
    return dict(nhom=out, kiem=kiem, canh_bao=kq["canh_bao"])


def ten_mau(job, vl):
    """tên màu anh Tan chọn cho nhóm vật liệu này (để in lên layout / nhãn)"""
    m = (job.get("mau") or {}).get({"HMR16": "thung", "MAU16B": "mat2"}.get(vl, "mat")) or {}
    return str(m.get("ten") or "")[:40]


def _layout_pdf(path, job, g, ngay):
    from reportlab.pdfgen import canvas
    from reportlab.lib.pagesizes import A4
    F, FB = _font(); c = canvas.Canvas(path, pagesize=A4); PW, PH = A4; v = g["v"]
    for si, s in enumerate(g["sheets"], 1):
        k = (PW - 60) / v["lx"]; ox, oy = 30, PH - 40 - v["ly"] * k
        c.setLineWidth(1); c.rect(ox, oy, v["lx"] * k, v["ly"] * k)
        for q in s["placed"]:
            pth = c.beginPath(); pts = q["poly"]; pth.moveTo(ox + pts[0][0] * k, oy + pts[0][1] * k)
            for x, y in pts[1:]: pth.lineTo(ox + x * k, oy + y * k)
            pth.close(); c.setFillColorRGB(.96, .93, .86); c.setLineWidth(.5); c.drawPath(pth, fill=1, stroke=1)
            c.setStrokeColorRGB(.3, .3, .35); c.setLineWidth(.3)
            for gr_, dp in q.get("grooves", []):                    # rãnh (uốn cong) vẽ thành vạch
                for (x1, y1), (x2, y2) in zip(gr_, gr_[1:]): c.line(ox + x1 * k, oy + y1 * k, ox + x2 * k, oy + y2 * k)
            c.setStrokeColorRGB(0, 0, 0); c.setFillColorRGB(.8, 0, 0)
            for hx, hy, d, dp in q["holes"]:
                if dp <= 1: c.setFillColorRGB(.85, .6, 0)
                c.circle(ox + hx * k, oy + hy * k, max(.5, d * k / 2), fill=1, stroke=0)
                if dp <= 1: c.setFillColorRGB(.8, 0, 0)
            c.setFillColorRGB(0, 0, 0); c.setFont(FB, 8)
            c.drawCentredString(ox + (q["bb"][0] + q["bb"][2]) / 2 * k, oy + (q["bb"][1] + q["bb"][3]) / 2 * k - 3, str(q["pn"]))
        c.setFont(FB, 8); y = oy - 18
        c.drawString(30, y, f"{'#':<4}"); c.drawString(55, y, "Rộng"); c.drawString(105, y, "Dài"); c.drawString(155, y, "Tên"); c.drawString(330, y, "Tủ"); c.drawString(365, y, "Nẹp / ghi chú")
        c.setFont(F, 7.5)
        for q in s["placed"]:
            y -= 11
            if y < 95: break
            p = q["src"]; w, l = sorted((p["w"], p["h"]))
            c.drawString(30, y, str(q["pn"])); c.drawRightString(90, y, f"{w:.1f}"); c.drawRightString(140, y, f"{l:.1f}")
            c.drawString(155, y, p["name"][:34]); c.drawString(330, y, "#" + p["cab"])
            nt = ("nẹp " + ",".join(p["edges"]) if p["edges"] else "") + (" | 45°: " + ",".join(p["e45"]) if p["e45"] else "") + ((" | " + p["note"]) if p["note"] else "")
            c.drawString(365, y, nt[:52])
        c.setLineWidth(.8); c.rect(30, 25, PW - 60, 60); c.line(PW / 2, 25, PW / 2, 85)
        c.setFont(F, 8.5); c.drawCentredString(PW / 4 + 15, 71, v["mat"].strip() + (f"  ({ten_mau(job, g['vl'])})" if ten_mau(job, g["vl"]) else "")); c.drawCentredString(PW / 4 + 15, 58, f"Sheet {si} of {len(g['sheets'])} ({v['ly']} x {v['lx']})")
        c.setFont(FB, 15); c.drawCentredString(PW / 4 + 15, 34, f"*{s['prog']}*")
        c.setFont(F, 9); c.drawCentredString(PW * 3 / 4 - 15, 64, f"JOB {job.get('so', '')} – {job.get('ten', '')}"[:48])
        c.drawCentredString(PW * 3 / 4 - 15, 40, f"{ngay} | Javis Studio | dùng {s['dung']}% tấm")
        c.showPage()
    c.save()


_SO_TU = {}


def _label_pdf(path, job, g):
    """Nhãn theo mẫu Cabinet Vision (Bích 21/11): chữ bên trái, Sheet/Part + '# tủ' bên phải, số dài in đậm trên-trái hình, số rộng xoay đứng bên trái hình, hình nhỏ góc dưới phải có dấu E."""
    from reportlab.pdfgen import canvas
    from reportlab.lib.pagesizes import A4
    F, FB = _font(); c = canvas.Canvas(path, pagesize=A4); PW, PH = A4
    labs = [(si, s["prog"], q) for si, s in enumerate(g["sheets"], 1) for q in s["placed"]]
    cw, ch = PW / 2, PH / 4
    mat = g["v"]["mat"].strip(); mau = ten_mau(job, g["vl"])
    def fit(txt, font, size, maxw):
        while size > 5 and c.stringWidth(txt, font, size) > maxw: size -= .5
        return size
    SO_TU = _SO_TU.setdefault(str(job.get('so', '')) + '|' + str(job.get('ten', '')), {})   # cùng 1 job: cùng số tủ ở mọi file nhãn
    for n, (si, prog, q) in enumerate(labs):
        j = n % 8
        if n and j == 0: c.showPage()
        x0, y0 = (j % 2) * cw + 8, PH - (j // 2 + 1) * ch + 6; w, h = cw - 16, ch - 12; p = q["src"]
        c.setFillColorRGB(0, 0, 0); c.setStrokeColorRGB(0, 0, 0)
        c.setDash(3, 2); c.setLineWidth(.3); c.rect(x0, y0, w, h); c.setDash()
        L = x0 + 6; top = y0 + h
        # ---- cột chữ bên trái
        def dong(y, nhan, val, size, font=F):
            c.setFont(F, 6.5); c.drawString(L, y, nhan)
            vx = L + c.stringWidth(nhan, F, 6.5) + 4
            c.setFont(font, fit(val, font, size, x0 + w * .60 - vx)); c.drawString(vx, y, val)
        dong(top - 20, "Job:", f"{job.get('so', '')} {job.get('ten', '')}".strip(), 12)
        dong(top - 38, "Room:", p.get("tu_ten") or p.get("cab", ""), 9.5)
        dong(top - 54, "Part:", p["name"], 8.5)
        ed = ("NẸP 1MM: " + ",".join(p["edges"]) if p["edges"] else "KHÔNG NẸP") + (f" | NẸP 45°: {','.join(p['e45'])}" if p["e45"] else "")
        dong(top - 70, "Edging:", ed, 6.5)
        if p["note"]:
            c.setFillColorRGB(.65, 0, 0); c.setFont(F, 5.8)
            from reportlab.lib.utils import simpleSplit
            for i_, ln_ in enumerate(simpleSplit(p["note"], F, 5.8, w * .44 - 30)[:5]): c.drawString(L + 30, top - 79 - 7 * i_, ln_)
            c.setFillColorRGB(0, 0, 0)
        c.setFont(F, 6.5); c.drawString(L, y0 + 22, "Material:"); _m = f"{mat} {mau}"; _fs = fit(_m, F, 6.5, w * .50 - 34)
        while c.stringWidth(_m, F, _fs) > w * .50 - 34 and len(_m) > 5: _m = _m[:-2]
        c.setFont(F, _fs); c.drawString(L + 32, y0 + 22, _m)
        c.setFont(F, 6.5); c.drawString(L, y0 + 8, "Comment"); c.setFont(F, 6.5); c.drawString(L + 36, y0 + 8, prog)
        # ---- Sheet / Part
        bx0 = x0 + w - 66; c.setLineWidth(.6); c.rect(bx0, top - 36, 58, 30)
        c.setFont(F, 10); c.drawString(bx0 + 3, top - 18, "Sheet"); c.drawString(bx0 + 3, top - 32, "Part")
        c.setFont(F, 11); c.drawRightString(bx0 + 55, top - 18, str(si)); c.drawRightString(bx0 + 55, top - 32, str(q["pn"]))
        c.line(bx0 + 3, top - 34, bx0 + 55, top - 34)
        # ---- # tủ (to, canh phải)
        cab = SO_TU.setdefault(str(p["cab"]), str(p["cab"]) if str(p["cab"]).isdigit() else str(len([v for v in SO_TU.values()]) + 1)); sz = fit(cab, F, 26, 110)   # Bích 23/11: mỗi tủ 1 SỐ, không dùng chữ
        c.setFont(F, sz); c.drawRightString(x0 + w - 8, top - 66, cab); cw_ = c.stringWidth(cab, F, sz)
        c.setFont(F, 13); c.drawRightString(x0 + w - 12 - cw_, top - 66, "#")
        # ---- hình miếng nhỏ góc dưới phải + 2 số kích thước kiểu CV
        bx, by, bw, bh = x0 + w * .56, y0 + 10, w * .40, h * .28
        k = min(bw / p["w"], bh / p["h"]); px = bx + bw - p["w"] * k; py = by + (bh - p["h"] * k) / 2
        pts = p["poly"]; pth = c.beginPath(); pth.moveTo(px + pts[0][0] * k, py + pts[0][1] * k)
        for x, y in pts[1:]: pth.lineTo(px + x * k, py + y * k)
        pth.close(); c.setLineWidth(.7); c.setFillColorRGB(1, 1, 1); c.drawPath(pth, fill=1, stroke=1); c.setFillColorRGB(0, 0, 0)
        c.setFont(FB, 11); c.drawCentredString(px + p["w"] * k / 2, py + p["h"] * k + (10 if "T" in p["edges"] else 5), f"{p['w']:.1f}")   # Bích 23/11: số dài ngay trên giữa hình (chỗ màu cam)   # dài: dưới '# tủ', trên-trái hình (như CV)
        c.saveState(); c.translate(px - 6 - (6 if "L" in p["edges"] else 0), py + p["h"] * k / 2); c.rotate(90); c.drawCentredString(0, 0, f"{p['h']:.1f}"); c.restoreState()   # rộng: đứng bên trái
        for hx, hy, d, dp in p["holes"]:
            c.setFillColorRGB(*((.85, .6, 0) if dp <= 1 else (.8, 0, 0))); c.circle(px + hx * k, py + hy * k, 1.2 if dp <= 1 else .7, fill=1, stroke=0)
        c.setFillColorRGB(0, 0, 0)
        pos = {"T": (px + p["w"] * k / 2, py + p["h"] * k), "B": (px + p["w"] * k / 2, py), "L": (px, py + p["h"] * k / 2), "R": (px + p["w"] * k, py + p["h"] * k / 2)}
        for sd in p["edges"]:
            c.setFillColorRGB(1, 1, 1); c.circle(*pos[sd], 4.5, fill=1, stroke=1); c.setFillColorRGB(0, 0, 0); c.setFont(FB, 5.5); c.drawCentredString(pos[sd][0], pos[sd][1] - 2, "E")
        for sd in p["e45"]:
            c.setFillColorRGB(1, .83, 0); c.circle(*pos[sd], 5.5, fill=1, stroke=1); c.setFillColorRGB(0, 0, 0); c.setFont(FB, 5); c.drawCentredString(pos[sd][0], pos[sd][1] - 1.8, "45")
    c.save()


def xuat(job, goc):
    """ghi cả bộ vào goc/<JOB so - ten>/ ; trả về tóm tắt"""
    kq, nhom, kiem = xep_tam(job, 3.0)
    so = ma_job(job); now = datetime.datetime.now(); ngay = now.strftime("%d-%m-%Y")
    ten = re.sub(r'[\\/:*?"<>|]', "-", f"JOB {job.get('so', '')} - {job.get('ten', 'KHONG TEN')}").strip()
    out = os.path.join(goc, ten); os.makedirs(out, exist_ok=True)
    tom = []
    for gi, g in enumerate(nhom, 1):
        v = g["v"]; gdir = os.path.join(out, f"{gi} - {re.sub(r'[^0-9A-Za-z ._-]', '', g['vl'])} {v['lz']:g}mm"); os.makedirs(gdir, exist_ok=True)
        for f in os.listdir(gdir):                       # file .cix cũ của lần xuất trước: đổi tên giữ lại, không xoá
            if f.lower().endswith(".cix"): os.replace(os.path.join(gdir, f), os.path.join(gdir, f + ".cu"))
        for s in g["sheets"]:
            write_sheet(os.path.join(gdir, s["prog"] + ".cix"), v["lx"], v["ly"], v["lz"], v["mat"], s["placed"], v["tnm"], v["crc"], "10_MDF")
        run = [f"^Job         : {job.get('so', '')} - {job.get('ten', '')} (JAVIS)", "^Description : ", f"^Date        : {now.strftime('%A, %b %d %Y')}", f"^Sheets      : {len(g['sheets'])}"]
        run += [f"{s['prog']},Nest Sheet {k},{v['ly']:g},{v['lx']:g},{v['lz']:g},{v['mat']},0,1,{v['c9']},B,0," for k, s in enumerate(g["sheets"], 1)]
        open(os.path.join(gdir, f"CncRun{so}.txt"), "w", newline="", encoding="utf-8").write("\r\n".join(run) + "\r\n")
        _layout_pdf(os.path.join(gdir, "layout.pdf"), job, g, ngay); _label_pdf(os.path.join(gdir, "label.pdf"), job, g)
        tom.append(dict(vl=g["vl"], ten=v["ten"], tam=len(g["sheets"]), mieng=sum(len(s["placed"]) for s in g["sheets"]), thu_muc=gdir, file=[s["prog"] + ".cix" for s in g["sheets"]]))
    with open(os.path.join(out, "DANH SACH CHI TIET.csv"), "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f); w.writerow(["Tủ", "Tên tủ", "Chi tiết", "Vật liệu", "Rộng", "Dài", "Số lỗ", "Nẹp", "Nẹp 45", "Ghi chú"])
        for p in kq["chi_tiet"]:
            a, b = sorted((p["w"], p["h"])); w.writerow(["#" + p["cab"], p.get("tu_ten", ""), p["name"], VAT_LIEU[p["vl"]]["ten"], a, b, len(p["holes"]), " ".join(p["edges"]), " ".join(p["e45"]), p["note"]])
    with open(os.path.join(out, "PHU KIEN.csv"), "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f); w.writerow(["Phụ kiện", "Số lượng"])
        for k, n in sorted(kq["phu_kien"].items()): w.writerow([k, n])
        for g in tom: w.writerow([f"Số tấm – {g['ten']}", g["tam"]])
        for vl, m in kq["nep"].items(): w.writerow([f"Nẹp cạnh cho {VAT_LIEU[vl]['ten']} (mét)", m])
    json.dump(job, open(os.path.join(out, "job.jvs"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    try:
        import banve; banve.ban_ve(os.path.join(out, "BAN VE 2D.pdf"), job)
    except Exception as e: kiem.append(f"Bản vẽ 2D lỗi: {e}")
    ngoai = [p for p in kq["chi_tiet"] if p.get("ngoai")]
    if ngoai:      # cửa shaker: chưa tự ra chương trình phay -> danh sách để Huân làm
        with open(os.path.join(out, "CUA SHAKER - nho Huan ra file.csv"), "w", newline="", encoding="utf-8-sig") as f:
            w = csv.writer(f); w.writerow(["Tủ", "Tên tủ", "Chi tiết", "Cao", "Rộng", "Dày", "Bản lề (lỗ chén)", "Ghi chú"])
            for p in ngoai: w.writerow(["#" + p["cab"], p.get("tu_ten", ""), p["name"], p["w"], p["h"], VAT_LIEU[p["vl"]]["lz"], sum(1 for h in p["holes"] if h[2] == 35), p["note"]])
    return dict(thu_muc=out, nhom=tom, kiem=kiem, canh_bao=kq["canh_bao"], ngoai=len(ngoai))
