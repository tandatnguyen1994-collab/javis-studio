# JAVIS STUDIO 0.5 – phần mềm vẽ tủ của TPW GROUP

Mở: bấm đúp `CHAY-STUDIO.bat` (hoặc biểu tượng JAVIS STUDIO ngoài Desktop). Cửa sổ riêng, không cần mạng.

## Làm được gì
- **Thư viện tủ** (cột trái): tủ dưới cánh / ngăn kéo / chậu, tủ treo, tủ cao, tủ áo, kệ mở, tấm rời, mặt đá, thiết bị. Bấm là thêm vào, tự nối tiếp tủ trước.
- **Xem 3D**: chuột trái xoay, chuột phải dời, lăn chuột phóng to. Nút *Mở cửa* (phím O) mở hết cánh + ngăn kéo; bấm đúp 1 tủ để mở riêng tủ đó; *Ẩn cánh* để nhìn thùng.
- **Sửa tay**: bấm 1 tủ → cột phải đổi rộng / cao / sâu, số cánh, số ngăn kéo, kệ, shadowline, loại hộc, vật liệu… Kéo tủ để dời (tự hút vào mép tủ bên cạnh), phím mũi tên dời 10mm (Shift 1mm, Ctrl 100mm), Ctrl+D nhân đôi, Delete xoá, Ctrl+Z / Ctrl+Y.
- **Vẽ nhanh bằng AI** (ô dưới cùng): gõ "bếp thẳng 3m6, chậu 900, 1 tủ hộc 3 ngăn, tủ treo phía trên, shadowline" hoặc "đổi tủ 2 thành 4 ngăn kéo". Dùng mô hình đang cài trong Ollama (chung với Javis Local).
- **Chi tiết / Phụ kiện** (cột phải): danh sách miếng ván từng tủ; bản lề, ray, tay nắm, chân tủ, chốt kệ, vít, mét nẹp cạnh, số tấm ván.
- **Xếp tấm**: xem trước từng tấm 2410 × 1210.
- **Xuất file CNC**: ghi vào OneDrive `FILE CNC\_JAVIS\JOB <số> - <tên>\<vật liệu>\`: mỗi tấm 1 file `.cix` (Biesse Klever), `CncRun##.txt`, `layout.pdf`, `label.pdf` (nhãn có hình cạnh dán nẹp, cạnh 45°), kèm `DANH SACH CHI TIET.csv`, `PHU KIEN.csv`, `job.jvs`.

## Quy tắc đã cài sẵn (theo file của Huân + lời anh Tan dặn)
- HMR 16.4: dao 10_HMR, chạy thuận (CRC 1). Ván màu 16: 10_HMR, chạy ngược (CRC 2), không xoay miếng (giữ vân). MDF 18: 10_MDF, tấm 3100 × 1200.
- Khoan xuyên = dày + 0.5. Chén bản lề Ø35 sâu 14, tâm 21.2 (ván màu) / 22.5 (MDF). Pát mặt hộc Ø10 sâu 12 cách cạnh bên 29.9.
- **Shadowline**: khoét hông 50 × dày ván ở mép trước (cắt suốt), cánh / mặt hộc ngắn lại 50. Cánh ván màu: chấm Ø5 sâu 1 ở cạnh trên để dán nẹp 45°, nhãn ghi "45". Cánh MDF sơn PU: nhãn ghi "CẮT 45° CẠNH TRÊN" (chưa tự phay – làm tay hoặc nhờ Huân).
- Cánh hở quanh 1.5, khe giữa 2 cánh 3. Bản lề: cánh ≤ 900 cao 2 cái, ≤ 1500 3 cái, ≤ 2000 4 cái, hơn nữa 5 cái.
- Ngăn kéo Tandembox: chỉ cắt đáy + hậu. Hộc gỗ (ray âm LEK SSC09): lòng hộc = lòng tủ − 42, dài = ray − 10.

## File job (.jvs)
Là file chữ (JSON) chứa danh sách tủ. Kéo thả file .jvs vào cửa sổ là mở. **File .skp không mở thẳng được** (định dạng kín của SketchUp): mỗi lần Javis ra .skp sẽ ra kèm .jvs cùng tên.

## Thêm trong bản 0.2 (theo lời anh dặn tối 19/11)
- **Tự hoàn thiện luôn bật**: thêm / dời / đổi kích thước tủ là panel hông, filler, kicker tự đi theo, không bao giờ lộ thùng trắng. Tắt được trong nút Hoàn thiện.
- **Hoàn thiện** (nút trên thanh): chọn bên trái / phải có tường không, trần cao bao nhiêu → Javis tự thêm panel hông (đầu hở, cạnh tủ cao), filler sát tường (khe 30, tấm cắt dư rộng 100), kicker chạy dài, bulkhead / nẹp trần (cắt dư 20). Bấm lại là làm lại, có nút gỡ.
- **Kiểu cánh**: Phẳng / Shaker. Cửa shaker hiện trong 3D, danh sách chi tiết và file `CUA SHAKER - nho Huan ra file.csv`; KHÔNG có trong .cix vì Studio chưa tự phay lòng shaker.
- **Kiểu mở**: Tay nắm / Shadowline / Bấm mở. **Mặt đá** dày 20 / 40 / 60 / 100.
- **Tủ lò nướng** (hộc lò chỉnh được, thêm hộc vi sóng) và **tủ treo hút mùi** (chấm 4 góc lỗ khoét + tâm ống Ø150 để thợ khoét; kiểm model trước).
- **Màu vật liệu**: dán link trang màu của nhà cung cấp (vd https://www.polytec.com.au/colour/florentine-walnut/) → Studio lấy ảnh màu về, phủ lên 3D, ghi tên màu lên layout và nhãn. Chọn riêng cho cánh, thùng, mặt đá.
- **VI / EN**: nút góc phải đổi giao diện Việt ↔ Anh. Gõ lệnh cho Javis bằng tiếng nào cũng được.
- AI vẽ: nói "bên trái là tường", "giữa 2 tường", "trần 2400" thì tự chừa filler và tổng chiều dài vẫn đúng số anh nói.

## Thêm trong bản 0.3 – 0.4
- Chân tủ 130, tủ dưới 730, đá 40; tủ lò nướng có ngăn kéo dưới; tủ kéo BIN / spice rack; BC panel + LED + loại splashback; cánh tủ treo fingerpull dư 20 (40 khi có BC panel).
- Thanh shadowline 50 cùng màu cánh ở chỗ khoét, Kickface.
- **Máy rửa chén / tủ lạnh âm**: mục "Thiết bị" trong thư viện, tự ra cửa cùng màu cánh. Đổi kiểu (âm / bán âm / rời) ở thuộc tính.
- **Kiểu cửa cho tủ mới**: 2 ô ngay trên thư viện (handle / shadowline / bấm mở · phẳng / shaker). Chọn trước rồi bấm tủ; nút bên dưới để áp cho mọi tủ đang có.
- **Tủ tự nối, không chồng**: chọn 1 tủ rồi bấm mẫu trong thư viện = chèn ngay sau tủ đó, các tủ bên phải tự dạt ra. Đổi bề rộng thì các tủ nối liền đi theo. Kéo đè lên tủ khác thì nó nhảy tới chỗ trống gần nhất.
- **Ô số đo tính trực tiếp**: đang 720 gõ `-20` rồi Enter → 700. Cũng nhận `+50`, `720-20`, `600+16`, `1200/2`, `2x300`.

## Bản 0.5
- Nút **Bản vẽ 2D**: mặt bằng + mặt đứng ra PDF A3, tự mở. Khi Xuất file CNC cũng có sẵn `BAN VE 2D.pdf` trong thư mục job.

## Chưa có (làm tiếp)
Tủ góc, cánh tách tầng, J-pull, tự phay shaker, tự khoét lỗ hút mùi / chậu, hàng tủ theo tường trái-phải có tự hoàn thiện, thước đo, bản vẽ 2D (plan / elevation PDF), mở thẳng file .skp, xuất máy Rover C9, tính giá theo BANG-GIA.

## Trước khi cắt thật
Bản 0.1 CHƯA cắt thử lần nào trên máy. Mở file .cix trong bSolid xem mô phỏng, cắt thử 1 tấm vụn, đo lại lỗ bản lề / lỗ ray rồi mới cắt hàng.
